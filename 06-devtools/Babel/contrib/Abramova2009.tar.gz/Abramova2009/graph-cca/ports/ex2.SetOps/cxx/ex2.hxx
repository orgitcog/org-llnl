// 
// File:          ex2.hxx
// Symbol:        ex2-v0.0
// Symbol Type:   package
// Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
// sidl Created:  20090805 11:08:14 PDT
// Generated:     20090805 11:08:17 PDT
// Description:   Client-side glue code for ex2
// 
// WARNING: Automatically generated; changes will be lost
// 
// source-url = /export/tmp-abramova1/cint/ports/sidl/ex2.SetOps.sidl
// 


#ifndef included_ex2_Data_hxx
#include "ex2_Data.hxx"
#endif

#ifndef included_ex2_ListNode_hxx
#include "ex2_ListNode.hxx"
#endif

#ifndef included_ex2_ListOps_hxx
#include "ex2_ListOps.hxx"
#endif

#ifndef included_ex2_SetOps_hxx
#include "ex2_SetOps.hxx"
#endif


