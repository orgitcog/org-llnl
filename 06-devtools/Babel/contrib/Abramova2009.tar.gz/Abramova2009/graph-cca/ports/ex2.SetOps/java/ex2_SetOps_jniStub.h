/*
 * File:          ex2_SetOps_jniStub.h
 * Symbol:        ex2.SetOps-v0.0
 * Symbol Type:   interface
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * sidl Created:  20090805 11:09:06 PDT
 * Generated:     20090805 11:09:09 PDT
 * Description:   Client-side header code for ex2.SetOps
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 * source-url = /export/tmp-abramova1/cint/ports/sidl/ex2.SetOps.sidl
 */

#ifndef included_ex2_SetOps_jniStub_h
#define included_ex2_SetOps_jniStub_h

/**
 * Symbol "ex2.SetOps" (version 0.0)
 * 
 * This is an interface for a set
 */

#ifndef included_ex2_SetOps_IOR_h
#include "ex2_SetOps_IOR.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif


#pragma weak ex2_SetOps__connectI

/**
 * RMI connector function for the class. (no addref)
 */
struct ex2_SetOps__object*
ex2_SetOps__connectI(const char * url, sidl_bool ar, struct 
  sidl_BaseInterface__object **_ex);

#ifdef __cplusplus
}
#endif
#endif
