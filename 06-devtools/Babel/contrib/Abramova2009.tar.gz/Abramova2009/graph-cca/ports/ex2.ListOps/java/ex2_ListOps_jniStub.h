/*
 * File:          ex2_ListOps_jniStub.h
 * Symbol:        ex2.ListOps-v0.0
 * Symbol Type:   interface
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * sidl Created:  20090805 11:08:56 PDT
 * Generated:     20090805 11:08:59 PDT
 * Description:   Client-side header code for ex2.ListOps
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 * source-url = /export/tmp-abramova1/cint/ports/sidl/ex2.ListOps.sidl
 */

#ifndef included_ex2_ListOps_jniStub_h
#define included_ex2_ListOps_jniStub_h

/**
 * Symbol "ex2.ListOps" (version 0.0)
 * 
 * This is the interface for a list.
 * All list classes implement this interface
 */

#ifndef included_ex2_ListOps_IOR_h
#include "ex2_ListOps_IOR.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif


#pragma weak ex2_ListOps__connectI

/**
 * RMI connector function for the class. (no addref)
 */
struct ex2_ListOps__object*
ex2_ListOps__connectI(const char * url, sidl_bool ar, struct 
  sidl_BaseInterface__object **_ex);

#ifdef __cplusplus
}
#endif
#endif
