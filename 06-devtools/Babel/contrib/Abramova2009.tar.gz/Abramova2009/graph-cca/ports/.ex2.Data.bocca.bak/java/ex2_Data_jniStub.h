/*
 * File:          ex2_Data_jniStub.h
 * Symbol:        ex2.Data-v0.0
 * Symbol Type:   interface
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * sidl Created:  20090716 18:22:36 PDT
 * Generated:     20090716 18:22:39 PDT
 * Description:   Client-side header code for ex2.Data
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 * source-url = /export/tmp-abramova1/copy/ports/sidl/ex2.Data.sidl
 */

#ifndef included_ex2_Data_jniStub_h
#define included_ex2_Data_jniStub_h

/**
 * Symbol "ex2.Data" (version 0.0)
 */

#ifndef included_ex2_Data_IOR_h
#include "ex2_Data_IOR.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif


#pragma weak ex2_Data__connectI

/**
 * RMI connector function for the class. (no addref)
 */
struct ex2_Data__object*
ex2_Data__connectI(const char * url, sidl_bool ar, struct 
  sidl_BaseInterface__object **_ex);

#ifdef __cplusplus
}
#endif
#endif
