/*
 * File:          ex2.h
 * Symbol:        ex2-v0.0
 * Symbol Type:   package
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * sidl Created:  20090716 18:20:43 PDT
 * Generated:     20090716 18:20:47 PDT
 * Description:   Client-side glue code for ex2
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 * source-url = /export/tmp-abramova1/copy/ports/sidl/ex2.Data.sidl
 */

#ifndef included_ex2_Data_h
#include "ex2_Data.h"
#endif

