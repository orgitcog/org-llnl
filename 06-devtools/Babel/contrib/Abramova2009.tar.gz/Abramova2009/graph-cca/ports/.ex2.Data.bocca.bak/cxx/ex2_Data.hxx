// 
// File:          ex2_Data.hxx
// Symbol:        ex2.Data-v0.0
// Symbol Type:   interface
// Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
// sidl Created:  20090716 18:21:29 PDT
// Generated:     20090716 18:21:32 PDT
// Description:   Client-side glue code for ex2.Data
// 
// WARNING: Automatically generated; changes will be lost
// 
// source-url = /export/tmp-abramova1/copy/ports/sidl/ex2.Data.sidl
// 

#ifndef included_ex2_Data_hxx
#define included_ex2_Data_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
// declare class before main #includes
// (this alleviates circular #include guard problems)[BUG#393]
namespace ex2 { 

  class Data;
} // end namespace ex2

// Some compilers need to define array template before the specializations
namespace sidl {
  template<>
  class array< ::ex2::Data >;
}
// 
// Forward declarations for method dependencies.
// 
namespace ex2 { 

  class Data;
} // end namespace ex2

namespace sidl { 

  class RuntimeException;
} // end namespace sidl

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_ex2_Data_IOR_h
#include "ex2_Data_IOR.h"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
namespace sidl {
  namespace rmi {
    class Call;
    class Return;
    class Ticket;
  }
  namespace rmi {
    class InstanceHandle;
  }
}
namespace ex2 { 

  /**
   * Symbol "ex2.Data" (version 0.0)
   */
  class Data: public virtual ::sidl::BaseInterface {

    //////////////////////////////////////////////////
    // 
    // Special methods for throwing exceptions
    // 

  private:
    static 
    void
    throwException0(
      const char* methodName,
      struct sidl_BaseInterface__object *_exception
    )
      // throws:
    ;

    //////////////////////////////////////////////////
    // 
    // User Defined Methods
    // 

  public:
    /**
     * user defined non-static method
     */
    void
    display() ;

    /**
     * user defined non-static method
     */
    int32_t
    hashCode() ;

    /**
     * user defined non-static method
     */
    int32_t
    compare (
      /* in */const ::ex2::Data& data
    )
    ;


    /**
     * user defined non-static method
     */
    void
    setData (
      /* in */const ::ex2::Data& data
    )
    ;



    //////////////////////////////////////////////////
    // 
    // End User Defined Methods
    // (everything else in this file is specific to
    //  Babel's C++ bindings)
    // 

  public:
    typedef struct ex2_Data__object ior_t;
    typedef struct ex2_Data__external ext_t;
    typedef struct ex2_Data__sepv sepv_t;

    // default constructor
    Data()  : ex2_Data_IORCache((ior_t*) NULL){ }

#ifdef WITH_RMI

    // RMI connect
    static inline ::ex2::Data _connect( /*in*/ const std::string& url ) { 
      return _connect(url, true);
    }

    // RMI connect 2
    static ::ex2::Data _connect( /*in*/ const std::string& url, /*in*/ const 
      bool ar  );


#endif /*WITH_RMI*/

    // default destructor
    virtual ~Data () { }

    // copy constructor
    Data ( const Data& original );

    // assignment operator
    Data& operator= ( const Data& rhs );

    // conversion from ior to C++ class
    Data ( Data::ior_t* ior );

    // Alternate constructor: does not call addRef()
    // (sets d_weak_reference=isWeak)
    // For internal use by Impls (fixes bug#275)
    Data ( Data::ior_t* ior, bool isWeak );

    inline ior_t* _get_ior() const throw() {
      if(!ex2_Data_IORCache) { 
        ex2_Data_IORCache = ::ex2::Data::_cast((void*)d_self);
        if (ex2_Data_IORCache) {
          struct sidl_BaseInterface__object *throwaway_exception;
          (ex2_Data_IORCache->d_epv->f_deleteRef)(ex2_Data_IORCache->d_object, 
            &throwaway_exception);  
        }  
      }
      return ex2_Data_IORCache;
    }

    inline void _set_ior( ior_t* ptr ) throw () { 
      d_self = reinterpret_cast< void*>(ptr);
      ex2_Data_IORCache = (ior_t*) ptr;

    }

    virtual int _set_ior_typesafe( struct sidl_BaseInterface__object *obj,
                                   const ::std::type_info &argtype );

    bool _is_nil() const throw () { return (d_self==0); }

    bool _not_nil() const throw () { return (d_self!=0); }

    bool operator !() const throw () { return (d_self==0); }

    static inline const char * type_name() throw () { return "ex2.Data";}

    static struct ex2_Data__object* _cast(const void* src);

    // execute member function by name
    void _exec(const std::string& methodName,
               ::sidl::rmi::Call& inArgs,
               ::sidl::rmi::Return& outArgs);

    /**
     * Get the URL of the Implementation of this object (for RMI)
     */
    ::std::string
    _getURL() // throws:
    //    ::sidl::RuntimeException
    ;


    /**
     * Method to enable/disable method hooks invocation.
     */
    void
    _set_hooks (
      /* in */bool enable
    )
    // throws:
    //    ::sidl::RuntimeException
    ;


    /**
     * Method to enable/disable interface contract enforcement.
     */
    void
    _set_contracts (
      /* in */bool enable,
      /* in */const ::std::string& enfFilename,
      /* in */bool resetCounters
    )
    // throws:
    //    ::sidl::RuntimeException
    ;


    /**
     * Method to dump contract enforcement statistics.
     */
    void
    _dump_stats (
      /* in */const ::std::string& filename,
      /* in */const ::std::string& prefix
    )
    // throws:
    //    ::sidl::RuntimeException
    ;

    // return true iff object is remote
    bool _isRemote() const { 
      ior_t* self = const_cast<ior_t*>(_get_ior() );
      struct sidl_BaseInterface__object *throwaway_exception;
      return (*self->d_epv->f__isRemote)(self, &throwaway_exception) == TRUE;
    }

    // return true iff object is local
    bool _isLocal() const {
      return !_isRemote();
    }

  protected:
    // Pointer to external (DLL loadable) symbols (shared among instances)
    static const ext_t * s_ext;

  public:
    static const ext_t * _get_ext() throw ( ::sidl::NullIORException );


    //////////////////////////////////////////////////
    // 
    // Locally Cached IOR pointer
    // 

  protected:
    mutable ior_t* ex2_Data_IORCache;
  }; // end class Data
} // end namespace ex2

extern "C" {


#pragma weak ex2_Data__connectI

  /**
   * RMI connector function for the class. (no addref)
   */
  struct ex2_Data__object*
  ex2_Data__connectI(const char * url, sidl_bool ar, struct 
    sidl_BaseInterface__object **_ex);


} // end extern "C"
namespace sidl {
  // traits specialization
  template<>
  struct array_traits< ::ex2::Data > {
    typedef array< ::ex2::Data > cxx_array_t;
    typedef ::ex2::Data cxx_item_t;
    typedef struct ex2_Data__array ior_array_t;
    typedef sidl_interface__array ior_array_internal_t;
    typedef struct ex2_Data__object ior_item_t;
    typedef cxx_item_t value_type;
    typedef value_type reference;
    typedef value_type* pointer;
    typedef const value_type const_reference;
    typedef const value_type* const_pointer;
    typedef array_iter< array_traits< ::ex2::Data > > iterator;
    typedef const_array_iter< array_traits< ::ex2::Data > > const_iterator;
  };

  // array specialization
  template<>
  class array< ::ex2::Data >: public interface_array< array_traits< ::ex2::Data 
    > > {
  public:
    typedef interface_array< array_traits< ::ex2::Data > > Base;
    typedef array_traits< ::ex2::Data >::cxx_array_t          cxx_array_t;
    typedef array_traits< ::ex2::Data >::cxx_item_t           cxx_item_t;
    typedef array_traits< ::ex2::Data >::ior_array_t          ior_array_t;
    typedef array_traits< ::ex2::Data >::ior_array_internal_t 
      ior_array_internal_t;
    typedef array_traits< ::ex2::Data >::ior_item_t           ior_item_t;

    /**
     * conversion from ior to C++ class
     * (constructor/casting operator)
     */
    array( struct ex2_Data__array* src = 0) : Base(src) {}

    /**
     * copy constructor
     */
    array( const array< ::ex2::Data >&src) : Base(src) {}

    /**
     * assignment
     */
    array< ::ex2::Data >&
    operator =( const array< ::ex2::Data >&rhs ) { 
      if (d_array != rhs._get_baseior()) {
        if (d_array) deleteRef();
        d_array = const_cast<sidl__array *>(rhs._get_baseior());
        if (d_array) addRef();
      }
      return *this;
    }

  };
}

#endif
