/*
 * File:          ex2_GraphSrchPort_jniStub.h
 * Symbol:        ex2.GraphSrchPort-v0.0
 * Symbol Type:   interface
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * sidl Created:  20090805 11:11:18 PDT
 * Generated:     20090805 11:11:21 PDT
 * Description:   Client-side header code for ex2.GraphSrchPort
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 * source-url = /export/tmp-abramova1/cint/ports/sidl/ex2.GraphSrchPort.sidl
 */

#ifndef included_ex2_GraphSrchPort_jniStub_h
#define included_ex2_GraphSrchPort_jniStub_h

/**
 * Symbol "ex2.GraphSrchPort" (version 0.0)
 */

#ifndef included_ex2_GraphSrchPort_IOR_h
#include "ex2_GraphSrchPort_IOR.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif


#pragma weak ex2_GraphSrchPort__connectI

/**
 * RMI connector function for the class. (no addref)
 */
struct ex2_GraphSrchPort__object*
ex2_GraphSrchPort__connectI(const char * url, sidl_bool ar, struct 
  sidl_BaseInterface__object **_ex);

#ifdef __cplusplus
}
#endif
#endif
