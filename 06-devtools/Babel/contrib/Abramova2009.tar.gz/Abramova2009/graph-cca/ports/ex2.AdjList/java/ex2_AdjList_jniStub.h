/*
 * File:          ex2_AdjList_jniStub.h
 * Symbol:        ex2.AdjList-v0.0
 * Symbol Type:   interface
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * sidl Created:  20090805 11:08:33 PDT
 * Generated:     20090805 11:08:36 PDT
 * Description:   Client-side header code for ex2.AdjList
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 * source-url = /export/tmp-abramova1/cint/ports/sidl/ex2.AdjList.sidl
 */

#ifndef included_ex2_AdjList_jniStub_h
#define included_ex2_AdjList_jniStub_h

/**
 * Symbol "ex2.AdjList" (version 0.0)
 * 
 * Helper interface used by the Graph to represent incident vertices
 * as a form of adjacency list.
 * The class stores a vertex and a list of all adjacent vertices.
 */

#ifndef included_ex2_AdjList_IOR_h
#include "ex2_AdjList_IOR.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif


#pragma weak ex2_AdjList__connectI

/**
 * RMI connector function for the class. (no addref)
 */
struct ex2_AdjList__object*
ex2_AdjList__connectI(const char * url, sidl_bool ar, struct 
  sidl_BaseInterface__object **_ex);

#ifdef __cplusplus
}
#endif
#endif
