/*
 * File:          ex2_DataSource_jniStub.h
 * Symbol:        ex2.DataSource-v0.0
 * Symbol Type:   interface
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * sidl Created:  20090805 11:09:42 PDT
 * Generated:     20090805 11:09:45 PDT
 * Description:   Client-side header code for ex2.DataSource
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 * source-url = /export/tmp-abramova1/cint/ports/sidl/ex2.DataSource.sidl
 */

#ifndef included_ex2_DataSource_jniStub_h
#define included_ex2_DataSource_jniStub_h

/**
 * Symbol "ex2.DataSource" (version 0.0)
 */

#ifndef included_ex2_DataSource_IOR_h
#include "ex2_DataSource_IOR.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif


#pragma weak ex2_DataSource__connectI

/**
 * RMI connector function for the class. (no addref)
 */
struct ex2_DataSource__object*
ex2_DataSource__connectI(const char * url, sidl_bool ar, struct 
  sidl_BaseInterface__object **_ex);

#ifdef __cplusplus
}
#endif
#endif
