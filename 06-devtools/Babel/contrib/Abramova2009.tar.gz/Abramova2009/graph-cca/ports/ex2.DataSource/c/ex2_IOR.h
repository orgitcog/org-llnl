/*
 * File:          ex2_IOR.h
 * Symbol:        ex2-v0.0
 * Symbol Type:   package
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * sidl Created:  20090805 11:09:22 PDT
 * Generated:     20090805 11:09:25 PDT
 * Description:   Intermediate Object Representation for ex2
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 * source-url = /export/tmp-abramova1/cint/ports/sidl/ex2.DataSource.sidl
 */

#ifndef included_ex2_IOR_h
#define included_ex2_IOR_h

/*
 * Symbol "ex2" (version 0.0)
 */

#ifndef included_ex2_Data_IOR_h
#include "ex2_Data_IOR.h"
#endif
#ifndef included_ex2_DataSource_IOR_h
#include "ex2_DataSource_IOR.h"
#endif

#endif
