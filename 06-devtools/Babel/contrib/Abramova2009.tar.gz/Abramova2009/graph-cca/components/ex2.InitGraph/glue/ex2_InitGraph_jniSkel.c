/*
 * File:          ex2_InitGraph_jniSkel.c
 * Symbol:        ex2.InitGraph-v0.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side JNI glue code for ex2.InitGraph
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#include "sidl_Java.h"
#include "sidl_Loader.h"
#include "sidl_String.h"
#include "ex2_InitGraph_IOR.h"
#include "babel_config.h"
#include "sidl_Exception.h"
#ifndef included_sidl_BaseException_h
#include "sidl_BaseException.h"
#endif
#ifndef included_sidl_LangSpecificException_h
#include "sidl_LangSpecificException.h"
#endif
#include <stdio.h>
/*
 * Includes for all method dependencies.
 */

#ifndef included_ex2_AdjList_jniStub_h
#include "ex2_AdjList_jniStub.h"
#endif
#ifndef included_ex2_Data_jniStub_h
#include "ex2_Data_jniStub.h"
#endif
#ifndef included_ex2_DataSource_jniStub_h
#include "ex2_DataSource_jniStub.h"
#endif
#ifndef included_ex2_GraphOps_jniStub_h
#include "ex2_GraphOps_jniStub.h"
#endif
#ifndef included_ex2_InitGraph_jniStub_h
#include "ex2_InitGraph_jniStub.h"
#endif
#ifndef included_ex2_InitGraphPort_jniStub_h
#include "ex2_InitGraphPort_jniStub.h"
#endif
#ifndef included_ex2_IntData_jniStub_h
#include "ex2_IntData_jniStub.h"
#endif
#ifndef included_gov_cca_CCAException_jniStub_h
#include "gov_cca_CCAException_jniStub.h"
#endif
#ifndef included_gov_cca_Component_jniStub_h
#include "gov_cca_Component_jniStub.h"
#endif
#ifndef included_gov_cca_ComponentRelease_jniStub_h
#include "gov_cca_ComponentRelease_jniStub.h"
#endif
#ifndef included_gov_cca_Port_jniStub_h
#include "gov_cca_Port_jniStub.h"
#endif
#ifndef included_gov_cca_Services_jniStub_h
#include "gov_cca_Services_jniStub.h"
#endif
#ifndef included_sidl_BaseClass_jniStub_h
#include "sidl_BaseClass_jniStub.h"
#endif
#ifndef included_sidl_BaseInterface_jniStub_h
#include "sidl_BaseInterface_jniStub.h"
#endif
#ifndef included_sidl_ClassInfo_jniStub_h
#include "sidl_ClassInfo_jniStub.h"
#endif
#ifndef included_sidl_RuntimeException_jniStub_h
#include "sidl_RuntimeException_jniStub.h"
#endif

/*
 * Convert between jlong and void* pointers.
 */

#if (SIZEOF_VOID_P == 8)
#define JLONG_TO_POINTER(x) ((void*)(x))
#define POINTER_TO_JLONG(x) ((jlong)(x))
#else
#define JLONG_TO_POINTER(x) ((void*)(int32_t)(x))
#define POINTER_TO_JLONG(x) ((jlong)(int32_t)(x))
#endif

#ifndef NULL
#define NULL 0
#endif

/**
 * JNISkel data struct to cache JNIEnv, class, and needed MID's
 */
static struct ex2_InitGraph_jniSkel__data
{
  jclass thisCls;
  jmethodID ctorMID;
  jmethodID dtorMID;
  jmethodID boccaSetServices_ImplMID;
  jmethodID boccaReleaseServices_ImplMID;
  jmethodID boccaForceUsePortInclude_ImplMID;
  jmethodID setServices_ImplMID;
  jmethodID releaseServices_ImplMID;
  jmethodID initFromFile_ImplMID;
} s_data;

/**
 * Method to initialize struct members
 */
static void
init_data(void)
{
  JNIEnv* env = sidl_Java_getEnv();
  {
    jclass tempCls = NULL;
    tempCls = (*env)->FindClass(env, "ex2/InitGraph_Impl");
    if ((*env)->ExceptionCheck(env)) {
      (*env)->ExceptionDescribe(env);
      return ;
    }

    s_data.thisCls = (*env)->NewGlobalRef(env, tempCls);
    (*env)->DeleteLocalRef(env, tempCls);
    if ((*env)->ExceptionCheck(env)) {
      (*env)->ExceptionDescribe(env);
      return ;
    }
  }
  s_data.ctorMID = (*env)->GetMethodID(env, s_data.thisCls, "<init>", "(J)V");
  if ((*env)->ExceptionCheck(env)) {
    (*env)->ExceptionDescribe(env);
    return ;
  }
  s_data.dtorMID = (*env)->GetMethodID(env, s_data.thisCls, "dtor", "()V");
  if ((*env)->ExceptionCheck(env)) {
    (*env)->ExceptionDescribe(env);
    return ;
  }
  s_data.boccaSetServices_ImplMID = (*env)->GetMethodID(env, s_data.thisCls, 
    "boccaSetServices_Impl", "(Lgov/cca/Services;)V");
  if ((*env)->ExceptionCheck(env)) {
    (*env)->ExceptionDescribe(env);
    return ;
  }
  s_data.boccaReleaseServices_ImplMID = (*env)->GetMethodID(env, s_data.thisCls,
    "boccaReleaseServices_Impl", "(Lgov/cca/Services;)V");
  if ((*env)->ExceptionCheck(env)) {
    (*env)->ExceptionDescribe(env);
    return ;
  }
  s_data.boccaForceUsePortInclude_ImplMID = (*env)->GetMethodID(env, 
    s_data.thisCls, "boccaForceUsePortInclude_Impl", 
    "(Lex2/DataSource;Lex2/AdjList;Lex2/Data;Lex2/IntData;Lex2/IntData;)V");
  if ((*env)->ExceptionCheck(env)) {
    (*env)->ExceptionDescribe(env);
    return ;
  }
  s_data.setServices_ImplMID = (*env)->GetMethodID(env, s_data.thisCls, 
    "setServices_Impl", "(Lgov/cca/Services;)V");
  if ((*env)->ExceptionCheck(env)) {
    (*env)->ExceptionDescribe(env);
    return ;
  }
  s_data.releaseServices_ImplMID = (*env)->GetMethodID(env, s_data.thisCls, 
    "releaseServices_Impl", "(Lgov/cca/Services;)V");
  if ((*env)->ExceptionCheck(env)) {
    (*env)->ExceptionDescribe(env);
    return ;
  }
  s_data.initFromFile_ImplMID = (*env)->GetMethodID(env, s_data.thisCls, 
    "initFromFile_Impl", "(Lex2/GraphOps$Holder;Ljava/lang/String;)V");
  if ((*env)->ExceptionCheck(env)) {
    (*env)->ExceptionDescribe(env);
    return ;
  }
}

static void handleUnidentifiableException(JNIEnv* env, jthrowable javaEx, 
  sidl_BaseInterface* _ex) {
  sidl_BaseInterface _throwaway =  NULL;
  sidl_BaseException _be =  NULL;
  sidl_BaseInterface _tmp_ex = NULL;
  sidl_LangSpecificException _le = 
    sidl_LangSpecificException__create(&_throwaway);
  if(sidl_Java_isSIDLException(env, javaEx)) {
    _tmp_ex = sidl_Java_catch_SIDLException(env, javaEx, "sidl.BaseException", 
      NULL);
    if(_tmp_ex != NULL) {
      _be = sidl_BaseException__cast(_tmp_ex, &_throwaway);
      sidl_LangSpecificException_setNote(_le, sidl_BaseException_getNote(_be, 
        &_throwaway), &_throwaway);
      sidl_LangSpecificException_addLine(_le, sidl_BaseException_getTrace(_be, 
        &_throwaway), &_throwaway);
      sidl_BaseInterface_deleteRef(_tmp_ex, &_throwaway);
      sidl_BaseException_deleteRef(_be, &_throwaway);
    } else {
      /*
       * If the thrown object isn't a BaseException either... 
       */

      sidl_LangSpecificException_setNote(_le, "Unidentifiable SIDL object thrown as exception from Java", &_throwaway);
      sidl_LangSpecificException_addLine(_le, "in unknown at unknown", &_throwaway);
    }
  } else {
    jclass locCls = (*env)->FindClass(env, "java/lang/Throwable");
    jmethodID toString = (*env)->GetMethodID(env, locCls, "toString", 
      "()Ljava/lang/String;");
    jstring note = NULL;
    note = (*env)->CallObjectMethod(env, javaEx, toString);
    sidl_LangSpecificException_setNote(_le, sidl_Java_J2I_string(env, note), 
      &_throwaway);
    sidl_LangSpecificException_addLine(_le, "in unknown at unknown", 
      &_throwaway);
  }
  *_ex = (sidl_BaseInterface) _le;
}
/**
 * Constructor
 */
static void
jni__ctor(struct ex2_InitGraph__object *self, struct sidl_BaseInterface__object 
  * *_ex)
{
  JNIEnv* env = sidl_Java_getEnv();
  if (env != NULL) {
    if ((*env)->PushLocalFrame(env, 8) < 0) goto JAVA_EXIT;
    {
      jobject this = (*env)->NewObject(env, s_data.thisCls, s_data.ctorMID, 
        POINTER_TO_JLONG(self));
      JAVA_CHECK(env);
      self->d_data = (*env)->NewGlobalRef(env, this);
      (*env)->DeleteLocalRef(env, this);

      JAVA_CHECK(env);
    }
    (*env)->PopLocalFrame(env, NULL);
  }
  return;
  JAVA_EXIT:
  {
    jthrowable javaEx = (*env)->ExceptionOccurred(env);
    (*env)->ExceptionClear(env);
    if(sidl_Java_isSIDLException(env, javaEx)) {
      *_ex = sidl_Java_catch_SIDLException(env, javaEx, 
        "sidl.RuntimeException",
      NULL);
    } 

    /**
     * If _ex is still Null, the exception was not expected.  
     * Throw a LangSpecificException instead.  
     */
    if(*_ex == NULL) {
      handleUnidentifiableException(env, javaEx, _ex);
    }
    /*
     * Return all inout and out arguments a NULL
     */

    (*env)->PopLocalFrame(env, NULL);
    return;
  } 
}

/**
 * This constructor is called by the IOR when a user passes intheir own private data. (new the Impl) Java doesn't need it, so it's empty
 */
static void
jni__ctor2(struct ex2_InitGraph__object *self, void* ddata, struct 
  sidl_BaseInterface__object * *_ex)
{ *_ex = NULL; }
/**
 * Deconstructing method
 */
static void
jni__dtor(struct ex2_InitGraph__object *self, struct sidl_BaseInterface__object 
  * *_ex)
{
  jfieldID j_ior = NULL;
  JNIEnv* env = sidl_Java_getEnv();
  if ((*env)->PushLocalFrame(env, 4) < 0) goto JAVA_EXIT;
  (*env)->CallVoidMethod(env, (jobject)self->d_data, s_data.dtorMID);
  JAVA_CHECK(env);
  j_ior = (*env)->GetFieldID(env, s_data.thisCls, "d_ior", "J");
  (*env)->SetLongField(env, (jobject)self->d_data, j_ior, 
    POINTER_TO_JLONG(NULL));
  (*env)->DeleteGlobalRef(env, (jobject)self->d_data);
  JAVA_CHECK(env);
  (*env)->PopLocalFrame(env, NULL);
  return;
  JAVA_EXIT:
  {
    jthrowable javaEx = (*env)->ExceptionOccurred(env);
    (*env)->ExceptionClear(env);
    if(sidl_Java_isSIDLException(env, javaEx)) {
      *_ex = sidl_Java_catch_SIDLException(env, javaEx, 
        "sidl.RuntimeException",
      NULL);
    } 

    /**
     * If _ex is still Null, the exception was not expected.  
     * Throw a LangSpecificException instead.  
     */
    if(*_ex == NULL) {
      handleUnidentifiableException(env, javaEx, _ex);
    }
    /*
     * Return all inout and out arguments a NULL
     */

    (*env)->PopLocalFrame(env, NULL);
    return;
  } 
}

void ex2_InitGraph__call_load(void) { 
  /* FIXME: Not implemented for Java yet */
}

/*
 * Method:  boccaSetServices[]
 */

static void
jni_boccaSetServices(
  struct ex2_InitGraph__object *self,
  struct gov_cca_Services__object* services,
  struct sidl_BaseInterface__object **_ex
  )
{
  JNIEnv* env = sidl_Java_getEnv();
  /* Reference to the object */
  jobject this = (jobject)(self->d_data);

  /* Declare return and temp variables */
  jobject _tmp_services = (jobject) NULL;
  *_ex = NULL;

  if ((*env)->PushLocalFrame(env, 10) < 0) goto JAVA_EXIT;
  /* Preprocess JNI variables */
  _tmp_services = sidl_Java_I2J_ifc(env, services, "gov.cca.Services", 
    TRUE);JAVA_CHECK(env);

  /* Callback to java method */
  (*env)->CallVoidMethod(env, this, s_data.boccaSetServices_ImplMID, 
    _tmp_services);
  JAVA_CHECK(env);
  /* Postprocess inout/out args */
  (*env)->DeleteLocalRef(env, _tmp_services);
  JAVA_CHECK(env);

  (*env)->PopLocalFrame(env, NULL);
  return;
  JAVA_EXIT:
  {
    jthrowable javaEx = (*env)->ExceptionOccurred(env);
    (*env)->ExceptionClear(env);
    if(sidl_Java_isSIDLException(env, javaEx)) {
      *_ex = sidl_Java_catch_SIDLException(env, javaEx, 
        "gov.cca.CCAException",
        "sidl.RuntimeException",
      NULL);
    } 

    /**
     * If _ex is still Null, the exception was not expected.  
     * Throw a LangSpecificException instead.  
     */
    if(*_ex == NULL) {
      handleUnidentifiableException(env, javaEx, _ex);
    }
    /*
     * Return all inout and out arguments a NULL
     */

    (*env)->PopLocalFrame(env, NULL);
    return;
  } 
}

/*
 * Method:  boccaReleaseServices[]
 */

static void
jni_boccaReleaseServices(
  struct ex2_InitGraph__object *self,
  struct gov_cca_Services__object* services,
  struct sidl_BaseInterface__object **_ex
  )
{
  JNIEnv* env = sidl_Java_getEnv();
  /* Reference to the object */
  jobject this = (jobject)(self->d_data);

  /* Declare return and temp variables */
  jobject _tmp_services = (jobject) NULL;
  *_ex = NULL;

  if ((*env)->PushLocalFrame(env, 10) < 0) goto JAVA_EXIT;
  /* Preprocess JNI variables */
  _tmp_services = sidl_Java_I2J_ifc(env, services, "gov.cca.Services", 
    TRUE);JAVA_CHECK(env);

  /* Callback to java method */
  (*env)->CallVoidMethod(env, this, s_data.boccaReleaseServices_ImplMID, 
    _tmp_services);
  JAVA_CHECK(env);
  /* Postprocess inout/out args */
  (*env)->DeleteLocalRef(env, _tmp_services);
  JAVA_CHECK(env);

  (*env)->PopLocalFrame(env, NULL);
  return;
  JAVA_EXIT:
  {
    jthrowable javaEx = (*env)->ExceptionOccurred(env);
    (*env)->ExceptionClear(env);
    if(sidl_Java_isSIDLException(env, javaEx)) {
      *_ex = sidl_Java_catch_SIDLException(env, javaEx, 
        "gov.cca.CCAException",
        "sidl.RuntimeException",
      NULL);
    } 

    /**
     * If _ex is still Null, the exception was not expected.  
     * Throw a LangSpecificException instead.  
     */
    if(*_ex == NULL) {
      handleUnidentifiableException(env, javaEx, _ex);
    }
    /*
     * Return all inout and out arguments a NULL
     */

    (*env)->PopLocalFrame(env, NULL);
    return;
  } 
}

/*
 *  This function should never be called, but helps babel generate better code. 
 */

static void
jni_boccaForceUsePortInclude(
  struct ex2_InitGraph__object *self,
  struct ex2_DataSource__object* dummy0,
  struct ex2_AdjList__object* dummy1,
  struct ex2_Data__object* dummy2,
  struct ex2_IntData__object* dummy3,
  struct ex2_IntData__object* dummy4,
  struct sidl_BaseInterface__object **_ex
  )
{
  JNIEnv* env = sidl_Java_getEnv();
  /* Reference to the object */
  jobject this = (jobject)(self->d_data);

  /* Declare return and temp variables */
  jobject _tmp_dummy0 = (jobject) NULL;
  jobject _tmp_dummy1 = (jobject) NULL;
  jobject _tmp_dummy2 = (jobject) NULL;
  jobject _tmp_dummy3 = (jobject) NULL;
  jobject _tmp_dummy4 = (jobject) NULL;
  *_ex = NULL;

  if ((*env)->PushLocalFrame(env, 14) < 0) goto JAVA_EXIT;
  /* Preprocess JNI variables */
  _tmp_dummy0 = sidl_Java_I2J_ifc(env, dummy0, "ex2.DataSource", 
    TRUE);JAVA_CHECK(env);
  _tmp_dummy1 = sidl_Java_I2J_ifc(env, dummy1, "ex2.AdjList", 
    TRUE);JAVA_CHECK(env);
  _tmp_dummy2 = sidl_Java_I2J_ifc(env, dummy2, "ex2.Data", 
    TRUE);JAVA_CHECK(env);
  _tmp_dummy3 = sidl_Java_I2J_cls(env, dummy3, "ex2.IntData", 
    TRUE);JAVA_CHECK(env);
  _tmp_dummy4 = sidl_Java_I2J_cls(env, dummy4, "ex2.IntData", 
    TRUE);JAVA_CHECK(env);

  /* Callback to java method */
  (*env)->CallVoidMethod(env, this, s_data.boccaForceUsePortInclude_ImplMID, 
    _tmp_dummy0, _tmp_dummy1, _tmp_dummy2, _tmp_dummy3, _tmp_dummy4);
  JAVA_CHECK(env);
  /* Postprocess inout/out args */
  (*env)->DeleteLocalRef(env, _tmp_dummy0);
  JAVA_CHECK(env);
  (*env)->DeleteLocalRef(env, _tmp_dummy1);
  JAVA_CHECK(env);
  (*env)->DeleteLocalRef(env, _tmp_dummy2);
  JAVA_CHECK(env);
  (*env)->DeleteLocalRef(env, _tmp_dummy3);
  JAVA_CHECK(env);
  (*env)->DeleteLocalRef(env, _tmp_dummy4);
  JAVA_CHECK(env);

  (*env)->PopLocalFrame(env, NULL);
  return;
  JAVA_EXIT:
  {
    jthrowable javaEx = (*env)->ExceptionOccurred(env);
    (*env)->ExceptionClear(env);
    if(sidl_Java_isSIDLException(env, javaEx)) {
      *_ex = sidl_Java_catch_SIDLException(env, javaEx, 
        "sidl.RuntimeException",
      NULL);
    } 

    /**
     * If _ex is still Null, the exception was not expected.  
     * Throw a LangSpecificException instead.  
     */
    if(*_ex == NULL) {
      handleUnidentifiableException(env, javaEx, _ex);
    }
    /*
     * Return all inout and out arguments a NULL
     */

    (*env)->PopLocalFrame(env, NULL);
    return;
  } 
}

/*
 *  Starts up a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument services will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */

static void
jni_setServices(
  struct ex2_InitGraph__object *self,
  struct gov_cca_Services__object* services,
  struct sidl_BaseInterface__object **_ex
  )
{
  JNIEnv* env = sidl_Java_getEnv();
  /* Reference to the object */
  jobject this = (jobject)(self->d_data);

  /* Declare return and temp variables */
  jobject _tmp_services = (jobject) NULL;
  *_ex = NULL;

  if ((*env)->PushLocalFrame(env, 10) < 0) goto JAVA_EXIT;
  /* Preprocess JNI variables */
  _tmp_services = sidl_Java_I2J_ifc(env, services, "gov.cca.Services", 
    TRUE);JAVA_CHECK(env);

  /* Callback to java method */
  (*env)->CallVoidMethod(env, this, s_data.setServices_ImplMID, _tmp_services);
  JAVA_CHECK(env);
  /* Postprocess inout/out args */
  (*env)->DeleteLocalRef(env, _tmp_services);
  JAVA_CHECK(env);

  (*env)->PopLocalFrame(env, NULL);
  return;
  JAVA_EXIT:
  {
    jthrowable javaEx = (*env)->ExceptionOccurred(env);
    (*env)->ExceptionClear(env);
    if(sidl_Java_isSIDLException(env, javaEx)) {
      *_ex = sidl_Java_catch_SIDLException(env, javaEx, 
        "gov.cca.CCAException",
        "sidl.RuntimeException",
      NULL);
    } 

    /**
     * If _ex is still Null, the exception was not expected.  
     * Throw a LangSpecificException instead.  
     */
    if(*_ex == NULL) {
      handleUnidentifiableException(env, javaEx, _ex);
    }
    /*
     * Return all inout and out arguments a NULL
     */

    (*env)->PopLocalFrame(env, NULL);
    return;
  } 
}

/*
 * Shuts down a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * This function is called exactly once for each callback registered
 * through Services.
 * 
 * The argument services will never be nil/null.
 * The argument services will always be the same as that received in
 * setServices.
 * 
 * During this call the component should release any interfaces
 * acquired by getPort().
 * 
 * During this call the component should reset to nil any stored
 * reference to services.
 * 
 * After this call, the component instance will be removed from the
 * framework. If the component instance was created by the
 * framework, it will be destroyed, not recycled, The behavior of
 * any port references obtained from this component instance and
 * stored elsewhere becomes undefined.
 * 
 * Notes for the component implementor:
 * 1) The component writer may perform blocking activities
 * within releaseServices, such as waiting for remote computations
 * to shutdown.
 * 2) It is good practice during releaseServices for the component
 * writer to remove or unregister all the ports it defined.
 */

static void
jni_releaseServices(
  struct ex2_InitGraph__object *self,
  struct gov_cca_Services__object* services,
  struct sidl_BaseInterface__object **_ex
  )
{
  JNIEnv* env = sidl_Java_getEnv();
  /* Reference to the object */
  jobject this = (jobject)(self->d_data);

  /* Declare return and temp variables */
  jobject _tmp_services = (jobject) NULL;
  *_ex = NULL;

  if ((*env)->PushLocalFrame(env, 10) < 0) goto JAVA_EXIT;
  /* Preprocess JNI variables */
  _tmp_services = sidl_Java_I2J_ifc(env, services, "gov.cca.Services", 
    TRUE);JAVA_CHECK(env);

  /* Callback to java method */
  (*env)->CallVoidMethod(env, this, s_data.releaseServices_ImplMID, 
    _tmp_services);
  JAVA_CHECK(env);
  /* Postprocess inout/out args */
  (*env)->DeleteLocalRef(env, _tmp_services);
  JAVA_CHECK(env);

  (*env)->PopLocalFrame(env, NULL);
  return;
  JAVA_EXIT:
  {
    jthrowable javaEx = (*env)->ExceptionOccurred(env);
    (*env)->ExceptionClear(env);
    if(sidl_Java_isSIDLException(env, javaEx)) {
      *_ex = sidl_Java_catch_SIDLException(env, javaEx, 
        "gov.cca.CCAException",
        "sidl.RuntimeException",
      NULL);
    } 

    /**
     * If _ex is still Null, the exception was not expected.  
     * Throw a LangSpecificException instead.  
     */
    if(*_ex == NULL) {
      handleUnidentifiableException(env, javaEx, _ex);
    }
    /*
     * Return all inout and out arguments a NULL
     */

    (*env)->PopLocalFrame(env, NULL);
    return;
  } 
}

/*
 * Method:  initFromFile[]
 */

static void
jni_initFromFile(
  struct ex2_InitGraph__object *self,
  struct ex2_GraphOps__object** g,
  const char* fileName,
  struct sidl_BaseInterface__object **_ex
  )
{
  JNIEnv* env = sidl_Java_getEnv();
  /* Reference to the object */
  jobject this = (jobject)(self->d_data);

  /* Declare return and temp variables */
  jobject _tmp_g = (jobject) NULL;
  jstring _tmp_fileName = (jstring) NULL;
  *_ex = NULL;

  if ((*env)->PushLocalFrame(env, 12) < 0) goto JAVA_EXIT;
  /* Preprocess JNI variables */
  _tmp_g = sidl_Java_create_empty_class(env, "ex2.GraphOps$Holder");
  sidl_Java_I2J_ifc_holder(env, _tmp_g, *g, "ex2.GraphOps", 
    FALSE);JAVA_CHECK(env);
  _tmp_fileName = sidl_Java_I2J_string(env, fileName);

  /* Callback to java method */
  (*env)->CallVoidMethod(env, this, s_data.initFromFile_ImplMID, _tmp_g, 
    _tmp_fileName);
  JAVA_CHECK(env);
  /* Postprocess inout/out args */
  *g = (struct ex2_GraphOps__object*) sidl_Java_J2I_ifc_holder(env, _tmp_g, 
    "ex2.GraphOps", TRUE);JAVA_CHECK(env);
  (*env)->DeleteLocalRef(env, _tmp_g);
  JAVA_CHECK(env);
  (*env)->DeleteLocalRef(env, _tmp_fileName);
  JAVA_CHECK(env);

  (*env)->PopLocalFrame(env, NULL);
  return;
  JAVA_EXIT:
  {
    jthrowable javaEx = (*env)->ExceptionOccurred(env);
    (*env)->ExceptionClear(env);
    if(sidl_Java_isSIDLException(env, javaEx)) {
      *_ex = sidl_Java_catch_SIDLException(env, javaEx, 
        "sidl.RuntimeException",
      NULL);
    } 

    /**
     * If _ex is still Null, the exception was not expected.  
     * Throw a LangSpecificException instead.  
     */
    if(*_ex == NULL) {
      handleUnidentifiableException(env, javaEx, _ex);
    }
    /*
     * Return all inout and out arguments a NULL
     */

    *g = NULL; 
    (*env)->PopLocalFrame(env, NULL);
    return;
  } 
}

#ifdef __cplusplus
extern "C" {
#endif

void
ex2_InitGraph__set_epv(struct ex2_InitGraph__epv *epv)
{
  /* initialize skel data struct */
  init_data();

  /* initialize builtin methods */
  epv->f__ctor = jni__ctor;
  epv->f__ctor2 = jni__ctor2;
  epv->f__dtor = jni__dtor;

  /* initialize local methods */
  epv->f_boccaSetServices = jni_boccaSetServices;
  epv->f_boccaReleaseServices = jni_boccaReleaseServices;
  epv->f_boccaForceUsePortInclude = jni_boccaForceUsePortInclude;
  epv->f_setServices = jni_setServices;
  epv->f_releaseServices = jni_releaseServices;
  epv->f_initFromFile = jni_initFromFile;
}
#ifdef __cplusplus
}
#endif

#ifdef WITH_RMI
#ifdef __cplusplus
extern "C" {
#endif

struct ex2_GraphOps__object* skel_ex2_InitGraph_fconnect_ex2_GraphOps(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex) { 
  return ex2_GraphOps__connectI(url, ar, _ex);
}

struct ex2_DataSource__object* skel_ex2_InitGraph_fconnect_ex2_DataSource(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex) { 
  return ex2_DataSource__connectI(url, ar, _ex);
}

struct gov_cca_Services__object* 
  skel_ex2_InitGraph_fconnect_gov_cca_Services(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex) { 
  return gov_cca_Services__connectI(url, ar, _ex);
}

struct ex2_Data__object* skel_ex2_InitGraph_fconnect_ex2_Data(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) { 
  return ex2_Data__connectI(url, ar, _ex);
}

struct sidl_BaseInterface__object* 
  skel_ex2_InitGraph_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex) { 
  return sidl_BaseInterface__connectI(url, ar, _ex);
}

struct ex2_IntData__object* skel_ex2_InitGraph_fconnect_ex2_IntData(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex) { 
  return ex2_IntData__connectI(url, ar, _ex);
}

struct ex2_AdjList__object* skel_ex2_InitGraph_fconnect_ex2_AdjList(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex) { 
  return ex2_AdjList__connectI(url, ar, _ex);
}

#ifdef __cplusplus
}
#endif
#endif /*WITH_RMI*/
