/*
 * File:          InitGraph_Impl.java
 * Symbol:        ex2.InitGraph-v0.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for ex2.InitGraph
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

package ex2;

import ex2.AdjList;
import ex2.Data;
import ex2.DataSource;
import ex2.GraphOps;
import ex2.InitGraphPort;
import ex2.IntData;
import gov.cca.CCAException;
import gov.cca.Component;
import gov.cca.ComponentRelease;
import gov.cca.Port;
import gov.cca.Services;
import sidl.BaseClass;
import sidl.BaseInterface;
import sidl.ClassInfo;
import sidl.RuntimeException;

// DO-NOT-DELETE splicer.begin(ex2.InitGraph._imports)
// Insert-Code-Here {ex2.InitGraph._imports} (additional imports)
import sidl.PreViolation;
import sidl.PostViolation;
// DO-NOT-DELETE splicer.end(ex2.InitGraph._imports)

/**
 * Symbol "ex2.InitGraph" (version 0.0)
 */
public class InitGraph_Impl extends InitGraph
{

  // DO-NOT-DELETE splicer.begin(ex2.InitGraph._data)

    // Bocca generated code. bocca.protected.begin(ex2.InitGraph._data)
    gov.cca.Services    d_services;
    public boolean bocca_print_errs = true;
    // Bocca generated code. bocca.protected.end(ex2.InitGraph._data)
  // DO-NOT-DELETE splicer.end(ex2.InitGraph._data)


  static { 
  // DO-NOT-DELETE splicer.begin(ex2.InitGraph._load)
  // Insert-Code-Here {ex2.InitGraph._load} (class initialization)
  // DO-NOT-DELETE splicer.end(ex2.InitGraph._load)

  }

  /**
   * User defined constructor
   */
  public InitGraph_Impl(long IORpointer){
    super(IORpointer);
    // DO-NOT-DELETE splicer.begin(ex2.InitGraph.InitGraph)
    // Insert-Code-Here {ex2.InitGraph.InitGraph} (constructor)
    // DO-NOT-DELETE splicer.end(ex2.InitGraph.InitGraph)

  }

  /**
   * Back door constructor
   */
  public InitGraph_Impl(){
    d_ior = _wrap(this);
    // DO-NOT-DELETE splicer.begin(ex2.InitGraph._wrap)
    // Insert-Code-Here {ex2.InitGraph._wrap} (_wrap)
    // DO-NOT-DELETE splicer.end(ex2.InitGraph._wrap)

  }

  /**
   * User defined destructing method
   */
  public void dtor() throws Throwable{
    // DO-NOT-DELETE splicer.begin(ex2.InitGraph._dtor)
    // Insert-Code-Here {ex2.InitGraph._dtor} (destructor)
    // DO-NOT-DELETE splicer.end(ex2.InitGraph._dtor)

  }

  /**
   * finalize method (Only use this if you're sure you need it!)
   */
  public void finalize() throws Throwable{
    // DO-NOT-DELETE splicer.begin(ex2.InitGraph.finalize)
    // Insert-Code-Here {ex2.InitGraph.finalize} (finalize)
    // DO-NOT-DELETE splicer.end(ex2.InitGraph.finalize)

  }

  // user defined static methods: (none)

  // user defined non-static methods:
  /**
   * Method:  boccaSetServices[]
   */
  public void boccaSetServices_Impl (
    /*in*/ gov.cca.Services services ) 
    throws gov.cca.CCAException.Wrapper, 
    sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(ex2.InitGraph.boccaSetServices)
// DO-NOT-EDIT-BOCCA
// Bocca generated code. bocca.protected.begin(ex2.InitGraph.boccaSetServices)

   gov.cca.TypeMap typeMap;
   gov.cca.Port    port;

   this.d_services = services;

   typeMap = this.d_services.createTypeMap();

   port = (gov.cca.Port)(this);


  // Provide a ex2.InitGraphPort port with port name InitGraphPort 
   try{
      this.d_services.addProvidesPort(port, // the implementing object
                                      "InitGraphPort", // the name the user sees
                                      "ex2.InitGraphPort", // the sidl name of the port type
                                      typeMap); // extra properties
   } catch ( gov.cca.CCAException.Wrapper ex )  {
      String msg = "Error calling addProvidesPort(port,\"InitGraphPort\", "
          + "\"ex2.InitGraphPort\", typeMap) ";
      ex.add(msg);
      throw ex;
   }    

  // Use a ex2.DDataSource port with port name DataSource 
   try{
      this.d_services.registerUsesPort("DataSource", // name the user sees
                                       "ex2.DDataSource", // sidl name of the port type
                                       typeMap); // extra properties
   } catch ( gov.cca.CCAException.Wrapper ex )  {
      String msg = "Error calling registerUsesPort(\"DataSource\", "
              + "\"ex2.DDataSource\", typeMap) ";
      ex.add(msg);
      throw ex;
   }


   gov.cca.ComponentRelease cr = (gov.cca.ComponentRelease)this; // CAST
   this.d_services.registerForRelease(cr);
   return;
// Bocca generated code. bocca.protected.end(ex2.InitGraph.boccaSetServices)
    // DO-NOT-DELETE splicer.end(ex2.InitGraph.boccaSetServices)

  }

  /**
   * Method:  boccaReleaseServices[]
   */
  public void boccaReleaseServices_Impl (
    /*in*/ gov.cca.Services services ) 
    throws gov.cca.CCAException.Wrapper, 
    sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(ex2.InitGraph.boccaReleaseServices)
  // Bocca generated code. bocca.protected.begin(ex2.InitGraph.boccaReleaseServices)

   this.d_services=null;

  // Un-provide ex2.InitGraphPort port with port name InitGraphPort 
  try{
    services.removeProvidesPort("InitGraphPort");
  } catch ( gov.cca.CCAException.Wrapper ex )  {
    if (bocca_print_errs) {
      System.err.print("ex2.InitGraph: Error calling removeProvidesPort" 
          + "(\"InitGraphPort\"): " + ex.getNote());
    }
  }

  // Release ex2.DDataSource port with port name DataSource 
  try{
    services.unregisterUsesPort("DataSource");
  } catch ( gov.cca.CCAException.Wrapper ex )  {
    if (bocca_print_errs) {
      System.err.println("ex2.InitGraph: Error calling unregisterUsesPort"
          + "(\"DataSource\"): " +ex.getNote());
    }
  }

   return;
  // Bocca generated code. bocca.protected.end(ex2.InitGraph.boccaReleaseServices)
    
    // DO-NOT-DELETE splicer.end(ex2.InitGraph.boccaReleaseServices)

  }

  /**
   *  This function should never be called, but helps babel generate better code. 
   */
  public void boccaForceUsePortInclude_Impl (
    /*in*/ ex2.DataSource dummy0,
    /*in*/ ex2.AdjList dummy1,
    /*in*/ ex2.Data dummy2,
    /*in*/ ex2.IntData dummy3,
    /*in*/ ex2.IntData dummy4 ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(ex2.InitGraph.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(ex2.InitGraph.boccaForceUsePortInclude)
    Object o;
    o = dummy0;
    o = dummy1;
    o = dummy2;
    o = dummy3;
    o = dummy4;

  // Bocca generated code. bocca.protected.end(ex2.InitGraph.boccaForceUsePortInclude)
    // DO-NOT-DELETE splicer.end(ex2.InitGraph.boccaForceUsePortInclude)

  }

  /**
   *  Starts up a component presence in the calling framework.
   * @param services the component instance's handle on the framework world.
   * Contracts concerning services and setServices:
   * 
   * The component interaction with the CCA framework
   * and Ports begins on the call to setServices by the framework.
   * 
   * This function is called exactly once for each instance created
   * by the framework.
   * 
   * The argument services will never be nil/null.
   * 
   * Those uses ports which are automatically connected by the framework
   * (so-called service-ports) may be obtained via getPort during
   * setServices.
   */
  public void setServices_Impl (
    /*in*/ gov.cca.Services services ) 
    throws gov.cca.CCAException.Wrapper, 
    sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(ex2.InitGraph.setServices)

  // Insert-Code-Here {ex2.InitGraph.setServices} (setServices method prolog)

  // bocca-default-code. User may edit or delete.begin(ex2.InitGraph.setServices)
     boccaSetServices(services); 
  // bocca-default-code. User may edit or delete.end(ex2.InitGraph.setServices)

  // Insert-Code-Here {ex2.InitGraph.setServices} (setServices method epilog)

    // DO-NOT-DELETE splicer.end(ex2.InitGraph.setServices)

  }

  /**
   * Shuts down a component presence in the calling framework.
   * @param services the component instance's handle on the framework world.
   * Contracts concerning services and setServices:
   * 
   * This function is called exactly once for each callback registered
   * through Services.
   * 
   * The argument services will never be nil/null.
   * The argument services will always be the same as that received in
   * setServices.
   * 
   * During this call the component should release any interfaces
   * acquired by getPort().
   * 
   * During this call the component should reset to nil any stored
   * reference to services.
   * 
   * After this call, the component instance will be removed from the
   * framework. If the component instance was created by the
   * framework, it will be destroyed, not recycled, The behavior of
   * any port references obtained from this component instance and
   * stored elsewhere becomes undefined.
   * 
   * Notes for the component implementor:
   * 1) The component writer may perform blocking activities
   * within releaseServices, such as waiting for remote computations
   * to shutdown.
   * 2) It is good practice during releaseServices for the component
   * writer to remove or unregister all the ports it defined.
   */
  public void releaseServices_Impl (
    /*in*/ gov.cca.Services services ) 
    throws gov.cca.CCAException.Wrapper, 
    sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(ex2.InitGraph.releaseServices)

  // Insert-Code-Here {ex2.InitGraph.releaseServices} (releaseServices method prolog)

  // bocca-default-code. User may edit or delete.end(ex2.InitGraph.releaseServices)
     boccaReleaseServices(services); 
  // bocca-default-code. User may edit or delete.end(ex2.InitGraph.releaseServices)

  // Insert-Code-Here {ex2.InitGraph.releaseServices} (releaseServices method epilog)

    // DO-NOT-DELETE splicer.end(ex2.InitGraph.releaseServices)

  }

  /**
   * Method:  initFromFile[]
   */
  public void initFromFile_Impl (
    /*inout*/ ex2.GraphOps.Holder g,
    /*in*/ java.lang.String fileName ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(ex2.InitGraph.initFromFile)
        String grSettingsFname = "graphS";
        boolean undirected= true;
	boolean policyEnbl = false;
        ex2.GraphOps graph = g.get();

        ex2.DataSource DataSource;
	gov.cca.Port generalPort;
        try {
	    generalPort = this.d_services.getPort("DataSource");
	} catch ( gov.cca.CCAException.Wrapper ex) {
	    // we cannot go on. add to the error report.
	    ex.add("DataSource port not available in InitGraph.initFromFile");
	    throw ex;
	}
	DataSource = (ex2.DataSource)generalPort._cast2("ex2.DataSource");
	if (DataSource == null){
	    // we cannot go on. toss an exception after cleaning up.
	    try {
		this.d_services.releasePort("DataSource");
	    } catch (Exception e) {
		// suppress framework complaints; weâre already handling an exception.
	    }
	    sidl.SIDLException ex = new sidl.SIDLException();
	    ex.setNote("Error: DataSource port is nul. Weird.");
	    ex.add("ex2.InitGraph.initFromFile_impl");
	    throw ex;
	}

	try {
	    
	    
	    try {
		java.io.BufferedReader fin = new java.io.BufferedReader (new java.io.FileReader(fileName));
		grSettingsFname = fin.readLine();
		undirected = new Boolean(fin.readLine()).booleanValue();
		policyEnbl = new Boolean(fin.readLine()).booleanValue();
		fin.close();
		fin = null;
		
	    }catch (java.io.IOException e){
		// grSettingsFname = "graphS";
// 		undirected = true;
	    }
	    if (graph ==null) System.out.println("The graph object is null");
	    java.io.BufferedReader in = new java.io.BufferedReader(new java.io.FileReader(grSettingsFname));
	    String str;
       
	    sidl.EnfPolicy policy = new sidl.EnfPolicy();
	    policy.setEnforceAll(sidl.ContractClass.ALLCLASSES, true);

	    str = in.readLine();
            if (str.equals("vertices")){
		while (! (str = in.readLine()).equals("edges") ){
		    java.util.StringTokenizer Tok = new java.util.StringTokenizer(str);
		    while (Tok.hasMoreElements()){
			int n = java.lang.Integer.parseInt(Tok.nextToken());		    
			ex2.IntData d = (ex2.IntData)DataSource.createData()._cast2("ex2.IntData");
			d.setIntData(n);
			
			int result = graph.insVertex(d);
			// System.out.println("Inserted vertex "+n + " result = "+result);
                  
		    }
		}

	    }
	    if (str.equals("edges")){
                while ((str = in.readLine())!= null){
		    java.util.StringTokenizer Tok = new java.util.StringTokenizer(str);
                    int e1 = java.lang.Integer.parseInt(Tok.nextToken());
                    int e2 = java.lang.Integer.parseInt(Tok.nextToken());
		    ex2.Data startV=null, endV=null;
                    ex2.IntData d1 = (ex2.IntData) DataSource.createData()._cast2("ex2.IntData");
                    d1.setIntData(e1);
                    ex2.IntData d2 = (ex2.IntData) DataSource.createData()._cast2("ex2.IntData");
                    d2.setIntData(e2);

                    ex2.AdjList adjlist = graph.getAdjList(d1);		
		    if (adjlist!=null){
			startV = adjlist.getVertex();		    
		    }
                    
                    ex2.AdjList adjlist2 = graph.getAdjList(d2);
		    if (adjlist2!=null){
			endV = adjlist2.getVertex();	    
		    }
		    if ((startV!=null)&&(endV!=null)){ 
			int result = graph.insEdge(startV, endV);
			if (undirected) graph.insEdge(endV, startV);
		    }
			adjlist = adjlist2 = null;
			startV = endV = null;
			d1 = d2 = null;
			// System.out.println("Inserting edge between " + e1 + " and " + e2+ " result = "+ result);
                    
			}
		}
		in.close();
		g.set(graph);
	    } catch (java.io.IOException e) {
		System.out.println("IO EXCEPTION happened");
		e.printStackTrace();
		e.getMessage();
		//initialize simple graph otherwise
		ex2.IntData d1 = new IntData();
		ex2.IntData d2 = new IntData();
		ex2.IntData d3 = new IntData();
		ex2.IntData d4 = new IntData();
		ex2.IntData d5 = new IntData();
		ex2.IntData d6 = new IntData();

		d1.setIntData(1);
		d2.setIntData(2);
		d3.setIntData(3);
		d4.setIntData(4);
		d5.setIntData(5);
		d6.setIntData(6);

		
		graph.insVertex(d1);
		graph.insVertex(d2);
		graph.insVertex(d3);
		graph.insVertex(d4);
		graph.insVertex(d5);
		graph.insVertex(d6);
 
		graph.insEdge(d1,d2); graph.insEdge(d2,d1);
		graph.insEdge(d3,d1); graph.insEdge(d1,d3);
		graph.insEdge(d2,d3); graph.insEdge(d3,d2);
		graph.insEdge(d2,d4); graph.insEdge(d4,d2);
		graph.insEdge(d4,d5); graph.insEdge(d5,d4);
		graph.insEdge(d3,d5); graph.insEdge(d5,d3);
		graph.insEdge(d6,d5); graph.insEdge(d5,d6);
		g.set(graph);

	    }
	    catch (sidl.PreViolation preExc){
		System.out.println(preExc.getNote());
	    }
	    catch (sidl.PostViolation postViol){
		System.out.println(postViol.getNote());
	    }catch (java.lang.Exception e){
		e.printStackTrace();
		return;
	    }
    
    // DO-NOT-DELETE splicer.end(ex2.InitGraph.initFromFile)

  }


  // DO-NOT-DELETE splicer.begin(ex2.InitGraph._misc)
  // Insert-Code-Here {ex2.InitGraph._misc} (miscellaneous)
  // DO-NOT-DELETE splicer.end(ex2.InitGraph._misc)

} // end class InitGraph

