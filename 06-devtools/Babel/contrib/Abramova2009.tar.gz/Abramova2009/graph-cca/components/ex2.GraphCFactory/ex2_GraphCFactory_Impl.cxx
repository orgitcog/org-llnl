// 
// File:          ex2_GraphCFactory_Impl.cxx
// Symbol:        ex2.GraphCFactory-v0.0
// Symbol Type:   class
// Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
// Description:   Server-side implementation for ex2.GraphCFactory
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "ex2_GraphCFactory_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_ex2_GraphC_hxx
#include "ex2_GraphC.hxx"
#endif
#ifndef included_ex2_GraphOps_hxx
#include "ex2_GraphOps.hxx"
#endif
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
// DO-NOT-DELETE splicer.begin(ex2.GraphCFactory._includes)

  // Insert-UserCode-Here {ex2.GraphCFactory._includes:prolog} (additional includes or code)

  // Bocca generated code. bocca.protected.begin(ex2.GraphCFactory._includes)

#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR

#include <iostream>

#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR


#endif // _BOCCA_STDERR



  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics 
  // will include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in 
  // messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif

  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}

  // This simplifies exception extending and rethrowing in c++, like 
  // SIDL_CHECK in C. EX_OBJ must be the caught exception and is extended with 
  // msg and file/line/func added. Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}


  // Bocca generated code. bocca.protected.end(ex2.GraphCFactory._includes)

  // Insert-UserCode-Here {ex2.GraphCFactory._includes:epilog} (additional includes or code)

// DO-NOT-DELETE splicer.end(ex2.GraphCFactory._includes)

// special constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
ex2::GraphCFactory_impl::GraphCFactory_impl() : StubBase(reinterpret_cast< 
  void*>(::ex2::GraphCFactory::_wrapObj(reinterpret_cast< void*>(this))),false) 
  , _wrapped(true){ 
  // DO-NOT-DELETE splicer.begin(ex2.GraphCFactory._ctor2)
  // Insert-Code-Here {ex2.GraphCFactory._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(ex2.GraphCFactory._ctor2)
}

// user defined constructor
void ex2::GraphCFactory_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(ex2.GraphCFactory._ctor)
    
  // Insert-UserCode-Here {ex2.GraphCFactory._ctor:prolog} (constructor method) 

  // bocca-default-code. User may edit or delete.begin(ex2.GraphCFactory._ctor)
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "CTOR ex2.GraphCFactory: " << BOOST_CURRENT_FUNCTION 
               << " constructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(ex2.GraphCFactory._ctor)

  // Insert-UserCode-Here {ex2.GraphCFactory._ctor:epilog} (constructor method)

  // DO-NOT-DELETE splicer.end(ex2.GraphCFactory._ctor)
}

// user defined destructor
void ex2::GraphCFactory_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(ex2.GraphCFactory._dtor)
  // Insert-UserCode-Here {ex2.GraphCFactory._dtor} (destructor method) 
    
  // bocca-default-code. User may edit or delete.begin(ex2.GraphCFactory._dtor) 
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "DTOR ex2.GraphCFactory: " << BOOST_CURRENT_FUNCTION 
               << " destructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES 
  // bocca-default-code. User may edit or delete.end(ex2.GraphCFactory._dtor) 

  // DO-NOT-DELETE splicer.end(ex2.GraphCFactory._dtor)
}

// static class initializer
void ex2::GraphCFactory_impl::_load() {
  // DO-NOT-DELETE splicer.begin(ex2.GraphCFactory._load)
  // Insert-Code-Here {ex2.GraphCFactory._load} (class initialization)
  // DO-NOT-DELETE splicer.end(ex2.GraphCFactory._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  boccaSetServices[]
 */
void
ex2::GraphCFactory_impl::boccaSetServices_impl (
  /* in */::gov::cca::Services& services ) 
// throws:
//    ::gov::cca::CCAException
//    ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(ex2.GraphCFactory.boccaSetServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(ex2.GraphCFactory.boccaSetServices)

  gov::cca::TypeMap typeMap;
  gov::cca::Port    port;

  this->d_services = services;

  typeMap = this->d_services.createTypeMap();

  port = ::babel_cast< gov::cca::Port>(*this);
  if (port._is_nil()) {
    BOCCA_THROW_CXX( ::sidl::SIDLException , 
                     "ex2.GraphCFactory: Error casting self to gov::cca::Port");
  } 


  // Provide a ex2.GraphSource port with port name GraphSource 
  try{
    this->d_services.addProvidesPort(
                   port,              // implementing object
                   "GraphSource", // port instance name
                   "ex2.GraphSource",     // full sidl type of port
                   typeMap);          // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex, 
        "ex2.GraphCFactory: Error calling addProvidesPort(port,"
        "\"GraphSource\", \"ex2.GraphSource\", typeMap) ", -2);
    throw;
  }    


  gov::cca::ComponentRelease cr = 
        ::babel_cast< gov::cca::ComponentRelease>(*this);
  this->d_services.registerForRelease(cr);
  return;
  // Bocca generated code. bocca.protected.end(ex2.GraphCFactory.boccaSetServices)
    
  // DO-NOT-DELETE splicer.end(ex2.GraphCFactory.boccaSetServices)
}

/**
 * Method:  boccaReleaseServices[]
 */
void
ex2::GraphCFactory_impl::boccaReleaseServices_impl (
  /* in */::gov::cca::Services& services ) 
// throws:
//    ::gov::cca::CCAException
//    ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(ex2.GraphCFactory.boccaReleaseServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(ex2.GraphCFactory.boccaReleaseServices)
  this->d_services=0;


  // Un-provide ex2.GraphSource port with port name GraphSource 
  try{
    services.removeProvidesPort("GraphSource");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "ex2.GraphCFactory: Error calling removeProvidesPort("
              << "\"GraphSource\") at " 
              << __FILE__ << ": " << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  return;
  // Bocca generated code. bocca.protected.end(ex2.GraphCFactory.boccaReleaseServices)
    
  // DO-NOT-DELETE splicer.end(ex2.GraphCFactory.boccaReleaseServices)
}

/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
ex2::GraphCFactory_impl::boccaForceUsePortInclude_impl (
  /* in */::ex2::GraphC& dummy0 ) 
{
  // DO-NOT-DELETE splicer.begin(ex2.GraphCFactory.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(ex2.GraphCFactory.boccaForceUsePortInclude)
    (void)dummy0;

  // Bocca generated code. bocca.protected.end(ex2.GraphCFactory.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(ex2.GraphCFactory.boccaForceUsePortInclude)
}

/**
 *  Starts up a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument services will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */
void
ex2::GraphCFactory_impl::setServices_impl (
  /* in */::gov::cca::Services& services ) 
// throws:
//    ::gov::cca::CCAException
//    ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(ex2.GraphCFactory.setServices)

  // Insert-UserCode-Here{ex2.GraphCFactory.setServices:prolog}

  // bocca-default-code. User may edit or delete.begin(ex2.GraphCFactory.setServices)
     boccaSetServices(services); 
  // bocca-default-code. User may edit or delete.end(ex2.GraphCFactory.setServices)
  
  // Insert-UserCode-Here{ex2.GraphCFactory.setServices:epilog}

  // DO-NOT-DELETE splicer.end(ex2.GraphCFactory.setServices)
}

/**
 * Shuts down a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * This function is called exactly once for each callback registered
 * through Services.
 * 
 * The argument services will never be nil/null.
 * The argument services will always be the same as that received in
 * setServices.
 * 
 * During this call the component should release any interfaces
 * acquired by getPort().
 * 
 * During this call the component should reset to nil any stored
 * reference to services.
 * 
 * After this call, the component instance will be removed from the
 * framework. If the component instance was created by the
 * framework, it will be destroyed, not recycled, The behavior of
 * any port references obtained from this component instance and
 * stored elsewhere becomes undefined.
 * 
 * Notes for the component implementor:
 * 1) The component writer may perform blocking activities
 * within releaseServices, such as waiting for remote computations
 * to shutdown.
 * 2) It is good practice during releaseServices for the component
 * writer to remove or unregister all the ports it defined.
 */
void
ex2::GraphCFactory_impl::releaseServices_impl (
  /* in */::gov::cca::Services& services ) 
// throws:
//    ::gov::cca::CCAException
//    ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(ex2.GraphCFactory.releaseServices)

  // Insert-UserCode-Here {ex2.GraphCFactory.releaseServices} 

  // bocca-default-code. User may edit or delete.begin(ex2.GraphCFactory.releaseServices)
     boccaReleaseServices(services);
  // bocca-default-code. User may edit or delete.end(ex2.GraphCFactory.releaseServices)
    
  // DO-NOT-DELETE splicer.end(ex2.GraphCFactory.releaseServices)
}

/**
 * Method:  createGraph[]
 */
::ex2::GraphOps
ex2::GraphCFactory_impl::createGraph_impl () 

{
  // DO-NOT-DELETE splicer.begin(ex2.GraphCFactory.createGraph)
  return ex2::GraphC::_create();
  
  // DO-NOT-DELETE splicer.end(ex2.GraphCFactory.createGraph)
}


// DO-NOT-DELETE splicer.begin(ex2.GraphCFactory._misc)
// Insert-Code-Here {ex2.GraphCFactory._misc} (miscellaneous code)
// DO-NOT-DELETE splicer.end(ex2.GraphCFactory._misc)

