/*
 * File:          ex2_DepthFirstSrch_jniStub.h
 * Symbol:        ex2.DepthFirstSrch-v0.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Client-side header code for ex2.DepthFirstSrch
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 */

#ifndef included_ex2_DepthFirstSrch_jniStub_h
#define included_ex2_DepthFirstSrch_jniStub_h

/**
 * Symbol "ex2.DepthFirstSrch" (version 0.0)
 */

#ifndef included_ex2_DepthFirstSrch_IOR_h
#include "ex2_DepthFirstSrch_IOR.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif


#pragma weak ex2_DepthFirstSrch__connectI

/**
 * RMI connector function for the class. (no addref)
 */
struct ex2_DepthFirstSrch__object*
ex2_DepthFirstSrch__connectI(const char * url, sidl_bool ar, struct 
  sidl_BaseInterface__object **_ex);

#ifdef __cplusplus
}
#endif
#endif
