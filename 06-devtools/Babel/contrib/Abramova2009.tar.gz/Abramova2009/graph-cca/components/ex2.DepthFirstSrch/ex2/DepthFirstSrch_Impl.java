/*
 * File:          DepthFirstSrch_Impl.java
 * Symbol:        ex2.DepthFirstSrch-v0.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for ex2.DepthFirstSrch
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

package ex2;

import ex2.Data;
import ex2.GraphOps;
import ex2.GraphSrchPort;
import ex2.ListC;
import ex2.ListNode;
import ex2.ListNodeC;
import ex2.ListOps;
import gov.cca.CCAException;
import gov.cca.Component;
import gov.cca.ComponentRelease;
import gov.cca.Port;
import gov.cca.Services;
import sidl.BaseClass;
import sidl.BaseInterface;
import sidl.ClassInfo;
import sidl.RuntimeException;

// DO-NOT-DELETE splicer.begin(ex2.DepthFirstSrch._imports)
// Insert-Code-Here {ex2.DepthFirstSrch._imports} (additional imports)
// DO-NOT-DELETE splicer.end(ex2.DepthFirstSrch._imports)

/**
 * Symbol "ex2.DepthFirstSrch" (version 0.0)
 */
public class DepthFirstSrch_Impl extends DepthFirstSrch
{

  // DO-NOT-DELETE splicer.begin(ex2.DepthFirstSrch._data)

    // Bocca generated code. bocca.protected.begin(ex2.DepthFirstSrch._data)
    gov.cca.Services    d_services;
    public boolean bocca_print_errs = true;
    // Bocca generated code. bocca.protected.end(ex2.DepthFirstSrch._data)
  // DO-NOT-DELETE splicer.end(ex2.DepthFirstSrch._data)


  static { 
  // DO-NOT-DELETE splicer.begin(ex2.DepthFirstSrch._load)
  // Insert-Code-Here {ex2.DepthFirstSrch._load} (class initialization)
  // DO-NOT-DELETE splicer.end(ex2.DepthFirstSrch._load)

  }

  /**
   * User defined constructor
   */
  public DepthFirstSrch_Impl(long IORpointer){
    super(IORpointer);
    // DO-NOT-DELETE splicer.begin(ex2.DepthFirstSrch.DepthFirstSrch)
    // Insert-Code-Here {ex2.DepthFirstSrch.DepthFirstSrch} (constructor)
    // DO-NOT-DELETE splicer.end(ex2.DepthFirstSrch.DepthFirstSrch)

  }

  /**
   * Back door constructor
   */
  public DepthFirstSrch_Impl(){
    d_ior = _wrap(this);
    // DO-NOT-DELETE splicer.begin(ex2.DepthFirstSrch._wrap)
    // Insert-Code-Here {ex2.DepthFirstSrch._wrap} (_wrap)
    // DO-NOT-DELETE splicer.end(ex2.DepthFirstSrch._wrap)

  }

  /**
   * User defined destructing method
   */
  public void dtor() throws Throwable{
    // DO-NOT-DELETE splicer.begin(ex2.DepthFirstSrch._dtor)
    // Insert-Code-Here {ex2.DepthFirstSrch._dtor} (destructor)
    // DO-NOT-DELETE splicer.end(ex2.DepthFirstSrch._dtor)

  }

  /**
   * finalize method (Only use this if you're sure you need it!)
   */
  public void finalize() throws Throwable{
    // DO-NOT-DELETE splicer.begin(ex2.DepthFirstSrch.finalize)
    // Insert-Code-Here {ex2.DepthFirstSrch.finalize} (finalize)
    // DO-NOT-DELETE splicer.end(ex2.DepthFirstSrch.finalize)

  }

  // user defined static methods: (none)

  // user defined non-static methods:
  /**
   * Method:  boccaSetServices[]
   */
  public void boccaSetServices_Impl (
    /*in*/ gov.cca.Services services ) 
    throws gov.cca.CCAException.Wrapper, 
    sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(ex2.DepthFirstSrch.boccaSetServices)
// DO-NOT-EDIT-BOCCA
// Bocca generated code. bocca.protected.begin(ex2.DepthFirstSrch.boccaSetServices)

   gov.cca.TypeMap typeMap;
   gov.cca.Port    port;

   this.d_services = services;

   typeMap = this.d_services.createTypeMap();

   port = (gov.cca.Port)(this);


  // Provide a ex2.GraphSrchPort port with port name GraphSrchPort 
   try{
      this.d_services.addProvidesPort(port, // the implementing object
                                      "GraphSrchPort", // the name the user sees
                                      "ex2.GraphSrchPort", // the sidl name of the port type
                                      typeMap); // extra properties
   } catch ( gov.cca.CCAException.Wrapper ex )  {
      String msg = "Error calling addProvidesPort(port,\"GraphSrchPort\", "
          + "\"ex2.GraphSrchPort\", typeMap) ";
      ex.add(msg);
      throw ex;
   }    


   gov.cca.ComponentRelease cr = (gov.cca.ComponentRelease)this; // CAST
   this.d_services.registerForRelease(cr);
   return;
// Bocca generated code. bocca.protected.end(ex2.DepthFirstSrch.boccaSetServices)
    // DO-NOT-DELETE splicer.end(ex2.DepthFirstSrch.boccaSetServices)

  }

  /**
   * Method:  boccaReleaseServices[]
   */
  public void boccaReleaseServices_Impl (
    /*in*/ gov.cca.Services services ) 
    throws gov.cca.CCAException.Wrapper, 
    sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(ex2.DepthFirstSrch.boccaReleaseServices)
  // Bocca generated code. bocca.protected.begin(ex2.DepthFirstSrch.boccaReleaseServices)

   this.d_services=null;

  // Un-provide ex2.GraphSrchPort port with port name GraphSrchPort 
  try{
    services.removeProvidesPort("GraphSrchPort");
  } catch ( gov.cca.CCAException.Wrapper ex )  {
    if (bocca_print_errs) {
      System.err.print("ex2.DepthFirstSrch: Error calling removeProvidesPort" 
          + "(\"GraphSrchPort\"): " + ex.getNote());
    }
  }

   return;
  // Bocca generated code. bocca.protected.end(ex2.DepthFirstSrch.boccaReleaseServices)
    
    // DO-NOT-DELETE splicer.end(ex2.DepthFirstSrch.boccaReleaseServices)

  }

  /**
   *  This function should never be called, but helps babel generate better code. 
   */
  public void boccaForceUsePortInclude_Impl (
    /*in*/ ex2.ListOps dummy0,
    /*in*/ ex2.ListNode dummy1,
    /*in*/ ex2.ListNodeC dummy2,
    /*in*/ ex2.Data dummy3,
    /*in*/ ex2.ListC dummy4 ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(ex2.DepthFirstSrch.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(ex2.DepthFirstSrch.boccaForceUsePortInclude)
    Object o;
    o = dummy0;
    o = dummy1;
    o = dummy2;
    o = dummy3;
    o = dummy4;

  // Bocca generated code. bocca.protected.end(ex2.DepthFirstSrch.boccaForceUsePortInclude)
    // DO-NOT-DELETE splicer.end(ex2.DepthFirstSrch.boccaForceUsePortInclude)

  }

  /**
   *  Starts up a component presence in the calling framework.
   * @param services the component instance's handle on the framework world.
   * Contracts concerning services and setServices:
   * 
   * The component interaction with the CCA framework
   * and Ports begins on the call to setServices by the framework.
   * 
   * This function is called exactly once for each instance created
   * by the framework.
   * 
   * The argument services will never be nil/null.
   * 
   * Those uses ports which are automatically connected by the framework
   * (so-called service-ports) may be obtained via getPort during
   * setServices.
   */
  public void setServices_Impl (
    /*in*/ gov.cca.Services services ) 
    throws gov.cca.CCAException.Wrapper, 
    sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(ex2.DepthFirstSrch.setServices)

  // Insert-Code-Here {ex2.DepthFirstSrch.setServices} (setServices method prolog)

  // bocca-default-code. User may edit or delete.begin(ex2.DepthFirstSrch.setServices)
     boccaSetServices(services); 
  // bocca-default-code. User may edit or delete.end(ex2.DepthFirstSrch.setServices)

  // Insert-Code-Here {ex2.DepthFirstSrch.setServices} (setServices method epilog)

    // DO-NOT-DELETE splicer.end(ex2.DepthFirstSrch.setServices)

  }

  /**
   * Shuts down a component presence in the calling framework.
   * @param services the component instance's handle on the framework world.
   * Contracts concerning services and setServices:
   * 
   * This function is called exactly once for each callback registered
   * through Services.
   * 
   * The argument services will never be nil/null.
   * The argument services will always be the same as that received in
   * setServices.
   * 
   * During this call the component should release any interfaces
   * acquired by getPort().
   * 
   * During this call the component should reset to nil any stored
   * reference to services.
   * 
   * After this call, the component instance will be removed from the
   * framework. If the component instance was created by the
   * framework, it will be destroyed, not recycled, The behavior of
   * any port references obtained from this component instance and
   * stored elsewhere becomes undefined.
   * 
   * Notes for the component implementor:
   * 1) The component writer may perform blocking activities
   * within releaseServices, such as waiting for remote computations
   * to shutdown.
   * 2) It is good practice during releaseServices for the component
   * writer to remove or unregister all the ports it defined.
   */
  public void releaseServices_Impl (
    /*in*/ gov.cca.Services services ) 
    throws gov.cca.CCAException.Wrapper, 
    sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(ex2.DepthFirstSrch.releaseServices)

  // Insert-Code-Here {ex2.DepthFirstSrch.releaseServices} (releaseServices method prolog)

  // bocca-default-code. User may edit or delete.end(ex2.DepthFirstSrch.releaseServices)
     boccaReleaseServices(services); 
  // bocca-default-code. User may edit or delete.end(ex2.DepthFirstSrch.releaseServices)

  // Insert-Code-Here {ex2.DepthFirstSrch.releaseServices} (releaseServices method epilog)

    // DO-NOT-DELETE splicer.end(ex2.DepthFirstSrch.releaseServices)

  }

  /**
   * Method:  search[]
   */
  public int search_Impl (
    /*in*/ ex2.GraphOps graph,
    /*in*/ ex2.Data startNode,
    /*out*/ ex2.ListOps.Holder ordered,
    /*out*/ sidl.Integer.Array1.Holder hops ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(ex2.DepthFirstSrch.search)
	java.util.HashMap <Integer, VertexColor> vertMap = new java.util.HashMap <Integer, VertexColor> ();	

        //initialize vertMap to adjacency lists and all of the vertices of the graph.
         
	ex2.ListNode elem;
	ex2.ListOps graphAdjacencyLists;
	ex2.ListOps orderedList = ordered.get();
	if (orderedList == null){
	    orderedList = new ex2.ListC();
      	}
	graphAdjacencyLists = graph.getAdjLists();
	elem =  graphAdjacencyLists.getHead();
	for (; elem!= null; elem = elem.getNext()){

	    ex2.AdjList adjListElem = (ex2.AdjList)elem.getData()._cast2("ex2.AdjList");
            ex2.Data vert = adjListElem.getVertex();
	    
	    vertMap.put(Integer.valueOf(vert.hashCode()), VertexColor.white);	    
	}
	
	//ensure that every component of unconnected graph is searched
	elem =  graphAdjacencyLists.getHead();
	for (; elem!= null; elem = elem.getNext()){

	    ex2.AdjList adjListElem = (ex2.AdjList)elem.getData()._cast2("ex2.AdjList");
            ex2.Data vert = adjListElem.getVertex();
	
	    VertexColor vertColor = vertMap.get(Integer.valueOf(vert.hashCode()));
	    if (vertColor == VertexColor.white){
		dfs_main(graph, adjListElem, orderedList, vertMap);
	    }
	}
	ordered.set(orderedList);
	return 0;

    // DO-NOT-DELETE splicer.end(ex2.DepthFirstSrch.search)

  }


  // DO-NOT-DELETE splicer.begin(ex2.DepthFirstSrch._misc)
  // Insert-Code-Here {ex2.DepthFirstSrch._misc} (miscellaneous)
    public int dfs_main(ex2.GraphOps graph, ex2.AdjList adjlist, ex2.ListOps ordered, java.util.HashMap<Integer, VertexColor> vertMap){
	ex2.Data vertex = adjlist.getVertex();
	
	VertexColor vColor = vertMap.get(vertex.hashCode());
	vColor = VertexColor.gray;
	vertMap.put(Integer.valueOf(vertex.hashCode()), vColor);
        //now search deeper
	ex2.ListNode elem = adjlist.getList().getHead();
	for (; elem != null; elem = elem.getNext()){
	    ex2.Data adjVert = elem.getData();
	    
	    VertexColor vColor2 = vertMap.get(Integer.valueOf(adjVert.hashCode()));
	    if (vColor2 == VertexColor.white){
		ex2.AdjList adjacent = graph.getAdjList(adjVert);
		dfs_main(graph, adjacent, ordered, vertMap);
	    }
	}
	
	//ordered.add(0, vertex);
	ordered.insertNext(null, vertex);
	return 0;
    }



    public enum VertexColor{white, gray}
  // DO-NOT-DELETE splicer.end(ex2.DepthFirstSrch._misc)

} // end class DepthFirstSrch

