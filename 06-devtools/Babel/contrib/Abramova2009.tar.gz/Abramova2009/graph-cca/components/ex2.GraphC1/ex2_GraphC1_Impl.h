/*
 * File:          ex2_GraphC1_Impl.h
 * Symbol:        ex2.GraphC1-v0.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for ex2.GraphC1
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#ifndef included_ex2_GraphC1_Impl_h
#define included_ex2_GraphC1_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_ex2_AdjList_h
#include "ex2_AdjList.h"
#endif
#ifndef included_ex2_AdjListC_h
#include "ex2_AdjListC.h"
#endif
#ifndef included_ex2_Data_h
#include "ex2_Data.h"
#endif
#ifndef included_ex2_GraphC1_h
#include "ex2_GraphC1.h"
#endif
#ifndef included_ex2_GraphOps_h
#include "ex2_GraphOps.h"
#endif
#ifndef included_ex2_ListC_h
#include "ex2_ListC.h"
#endif
#ifndef included_ex2_ListNode_h
#include "ex2_ListNode.h"
#endif
#ifndef included_ex2_ListOps_h
#include "ex2_ListOps.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_PostViolation_h
#include "sidl_PostViolation.h"
#endif
#ifndef included_sidl_PreViolation_h
#include "sidl_PreViolation.h"
#endif
#ifndef included_sidl_RuntimeException_h
#include "sidl_RuntimeException.h"
#endif
/* DO-NOT-DELETE splicer.begin(ex2.GraphC1._hincludes) */
/* Insert-Code-Here {ex2.GraphC1._hincludes} (include files) */
/* DO-NOT-DELETE splicer.end(ex2.GraphC1._hincludes) */

/*
 * Private data for class ex2.GraphC1
 */

struct ex2_GraphC1__data {
  /* DO-NOT-DELETE splicer.begin(ex2.GraphC1._data) */
  /* Insert-Code-Here {ex2.GraphC1._data} (private data members) */
  //int ignore; /* dummy to force non-empty struct; remove if you add data */
  int vcount;
  int ecount;
  ex2_ListOps adjlists;
  /* DO-NOT-DELETE splicer.end(ex2.GraphC1._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct ex2_GraphC1__data*
ex2_GraphC1__get_data(
  ex2_GraphC1);

extern void
ex2_GraphC1__set_data(
  ex2_GraphC1,
  struct ex2_GraphC1__data*);

extern
void
impl_ex2_GraphC1__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_GraphC1__ctor(
  /* in */ ex2_GraphC1 self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_GraphC1__ctor2(
  /* in */ ex2_GraphC1 self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_GraphC1__dtor(
  /* in */ ex2_GraphC1 self,
  /* out */ sidl_BaseInterface *_ex);

/*
 * User-defined object methods
 */

#ifdef WITH_RMI
extern struct ex2_Data__object* impl_ex2_GraphC1_fconnect_ex2_Data(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_ex2_GraphC1_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct ex2_ListC__object* impl_ex2_GraphC1_fconnect_ex2_ListC(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ex2_AdjListC__object* impl_ex2_GraphC1_fconnect_ex2_AdjListC(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ex2_ListOps__object* impl_ex2_GraphC1_fconnect_ex2_ListOps(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ex2_ListNode__object* impl_ex2_GraphC1_fconnect_ex2_ListNode(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ex2_AdjList__object* impl_ex2_GraphC1_fconnect_ex2_AdjList(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/
extern
void
impl_ex2_GraphC1_boccaForceUsePortInclude(
  /* in */ ex2_GraphC1 self,
  /* in */ ex2_AdjList dummy0,
  /* in */ ex2_ListOps dummy1,
  /* in */ ex2_AdjListC dummy2,
  /* in */ ex2_Data dummy3,
  /* in */ ex2_ListC dummy4,
  /* in */ ex2_ListNode dummy5,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_GraphC1_insVertex(
  /* in */ ex2_GraphC1 self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_GraphC1_remVertex(
  /* in */ ex2_GraphC1 self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_GraphC1_insEdge(
  /* in */ ex2_GraphC1 self,
  /* in */ ex2_Data d1,
  /* in */ ex2_Data d2,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_GraphC1_remEdge(
  /* in */ ex2_GraphC1 self,
  /* in */ ex2_Data d1,
  /* in */ ex2_Data d2,
  /* out */ sidl_BaseInterface *_ex);

extern
ex2_AdjList
impl_ex2_GraphC1_getAdjList(
  /* in */ ex2_GraphC1 self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_GraphC1_isAdjacent(
  /* in */ ex2_GraphC1 self,
  /* in */ ex2_Data d1,
  /* in */ ex2_Data d2,
  /* out */ sidl_BaseInterface *_ex);

extern
ex2_ListOps
impl_ex2_GraphC1_getAdjLists(
  /* in */ ex2_GraphC1 self,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_GraphC1_getVertCount(
  /* in */ ex2_GraphC1 self,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_GraphC1_getEdgeCount(
  /* in */ ex2_GraphC1 self,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_ex2_GraphC1_vertexExists(
  /* in */ ex2_GraphC1 self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex);

#ifdef WITH_RMI
extern struct ex2_Data__object* impl_ex2_GraphC1_fconnect_ex2_Data(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_ex2_GraphC1_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct ex2_ListC__object* impl_ex2_GraphC1_fconnect_ex2_ListC(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ex2_AdjListC__object* impl_ex2_GraphC1_fconnect_ex2_AdjListC(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ex2_ListOps__object* impl_ex2_GraphC1_fconnect_ex2_ListOps(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ex2_ListNode__object* impl_ex2_GraphC1_fconnect_ex2_ListNode(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ex2_AdjList__object* impl_ex2_GraphC1_fconnect_ex2_AdjList(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/

/* DO-NOT-DELETE splicer.begin(_hmisc) */
/* Insert-Code-Here {_hmisc} (miscellaneous things) */
/* DO-NOT-DELETE splicer.end(_hmisc) */

#ifdef __cplusplus
}
#endif
#endif
