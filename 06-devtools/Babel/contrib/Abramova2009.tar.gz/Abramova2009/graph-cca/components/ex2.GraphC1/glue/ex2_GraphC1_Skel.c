/*
 * File:          ex2_GraphC1_Skel.c
 * Symbol:        ex2.GraphC1-v0.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side glue code for ex2.GraphC1
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 */

#include "ex2_GraphC1_IOR.h"
#include "ex2_GraphC1.h"
#include <stddef.h>

#ifdef WITH_RMI
#ifndef included_ex2_Data_h
#include "ex2_Data.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_ex2_ListC_h
#include "ex2_ListC.h"
#endif
#ifndef included_ex2_AdjListC_h
#include "ex2_AdjListC.h"
#endif
#ifndef included_ex2_ListOps_h
#include "ex2_ListOps.h"
#endif
#ifndef included_ex2_ListNode_h
#include "ex2_ListNode.h"
#endif
#ifndef included_ex2_AdjList_h
#include "ex2_AdjList.h"
#endif
#endif /* WITH_RMI */
extern
void
impl_ex2_GraphC1__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_GraphC1__ctor(
  /* in */ ex2_GraphC1 self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_GraphC1__ctor2(
  /* in */ ex2_GraphC1 self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_GraphC1__dtor(
  /* in */ ex2_GraphC1 self,
  /* out */ sidl_BaseInterface *_ex);

#ifdef WITH_RMI
extern struct ex2_Data__object* impl_ex2_GraphC1_fconnect_ex2_Data(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_ex2_GraphC1_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct ex2_ListC__object* impl_ex2_GraphC1_fconnect_ex2_ListC(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ex2_AdjListC__object* impl_ex2_GraphC1_fconnect_ex2_AdjListC(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ex2_ListOps__object* impl_ex2_GraphC1_fconnect_ex2_ListOps(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ex2_ListNode__object* impl_ex2_GraphC1_fconnect_ex2_ListNode(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ex2_AdjList__object* impl_ex2_GraphC1_fconnect_ex2_AdjList(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/
extern
void
impl_ex2_GraphC1_boccaForceUsePortInclude(
  /* in */ ex2_GraphC1 self,
  /* in */ ex2_AdjList dummy0,
  /* in */ ex2_ListOps dummy1,
  /* in */ ex2_AdjListC dummy2,
  /* in */ ex2_Data dummy3,
  /* in */ ex2_ListC dummy4,
  /* in */ ex2_ListNode dummy5,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_GraphC1_insVertex(
  /* in */ ex2_GraphC1 self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_GraphC1_remVertex(
  /* in */ ex2_GraphC1 self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_GraphC1_insEdge(
  /* in */ ex2_GraphC1 self,
  /* in */ ex2_Data d1,
  /* in */ ex2_Data d2,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_GraphC1_remEdge(
  /* in */ ex2_GraphC1 self,
  /* in */ ex2_Data d1,
  /* in */ ex2_Data d2,
  /* out */ sidl_BaseInterface *_ex);

extern
ex2_AdjList
impl_ex2_GraphC1_getAdjList(
  /* in */ ex2_GraphC1 self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_GraphC1_isAdjacent(
  /* in */ ex2_GraphC1 self,
  /* in */ ex2_Data d1,
  /* in */ ex2_Data d2,
  /* out */ sidl_BaseInterface *_ex);

extern
ex2_ListOps
impl_ex2_GraphC1_getAdjLists(
  /* in */ ex2_GraphC1 self,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_GraphC1_getVertCount(
  /* in */ ex2_GraphC1 self,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_GraphC1_getEdgeCount(
  /* in */ ex2_GraphC1 self,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_ex2_GraphC1_vertexExists(
  /* in */ ex2_GraphC1 self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex);

#ifdef WITH_RMI
extern struct ex2_Data__object* impl_ex2_GraphC1_fconnect_ex2_Data(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_ex2_GraphC1_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct ex2_ListC__object* impl_ex2_GraphC1_fconnect_ex2_ListC(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ex2_AdjListC__object* impl_ex2_GraphC1_fconnect_ex2_AdjListC(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ex2_ListOps__object* impl_ex2_GraphC1_fconnect_ex2_ListOps(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ex2_ListNode__object* impl_ex2_GraphC1_fconnect_ex2_ListNode(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ex2_AdjList__object* impl_ex2_GraphC1_fconnect_ex2_AdjList(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/
#ifdef __cplusplus
extern "C" {
#endif

void
ex2_GraphC1__set_epv(struct ex2_GraphC1__epv *epv,
  struct ex2_GraphC1__pre_epv *pre_epv, 
  struct ex2_GraphC1__post_epv *post_epv
)
{
  epv->f__ctor = impl_ex2_GraphC1__ctor;
  epv->f__ctor2 = impl_ex2_GraphC1__ctor2;
  epv->f__dtor = impl_ex2_GraphC1__dtor;
  pre_epv->f_boccaForceUsePortInclude_pre = NULL;
  epv->f_boccaForceUsePortInclude = impl_ex2_GraphC1_boccaForceUsePortInclude;
  post_epv->f_boccaForceUsePortInclude_post = NULL;
  pre_epv->f_insVertex_pre = NULL;
  epv->f_insVertex = impl_ex2_GraphC1_insVertex;
  post_epv->f_insVertex_post = NULL;
  pre_epv->f_remVertex_pre = NULL;
  epv->f_remVertex = impl_ex2_GraphC1_remVertex;
  post_epv->f_remVertex_post = NULL;
  pre_epv->f_insEdge_pre = NULL;
  epv->f_insEdge = impl_ex2_GraphC1_insEdge;
  post_epv->f_insEdge_post = NULL;
  pre_epv->f_remEdge_pre = NULL;
  epv->f_remEdge = impl_ex2_GraphC1_remEdge;
  post_epv->f_remEdge_post = NULL;
  pre_epv->f_getAdjList_pre = NULL;
  epv->f_getAdjList = impl_ex2_GraphC1_getAdjList;
  post_epv->f_getAdjList_post = NULL;
  pre_epv->f_isAdjacent_pre = NULL;
  epv->f_isAdjacent = impl_ex2_GraphC1_isAdjacent;
  post_epv->f_isAdjacent_post = NULL;
  pre_epv->f_getAdjLists_pre = NULL;
  epv->f_getAdjLists = impl_ex2_GraphC1_getAdjLists;
  post_epv->f_getAdjLists_post = NULL;
  pre_epv->f_getVertCount_pre = NULL;
  epv->f_getVertCount = impl_ex2_GraphC1_getVertCount;
  post_epv->f_getVertCount_post = NULL;
  pre_epv->f_getEdgeCount_pre = NULL;
  epv->f_getEdgeCount = impl_ex2_GraphC1_getEdgeCount;
  post_epv->f_getEdgeCount_post = NULL;
  pre_epv->f_vertexExists_pre = NULL;
  epv->f_vertexExists = impl_ex2_GraphC1_vertexExists;
  post_epv->f_vertexExists_post = NULL;

}
#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
extern "C" {
#endif

void ex2_GraphC1__call_load(void) { 
  sidl_BaseInterface _throwaway_exception = NULL;
  impl_ex2_GraphC1__load(&_throwaway_exception);
}
#ifdef WITH_RMI
struct ex2_Data__object* skel_ex2_GraphC1_fconnect_ex2_Data(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) { 
  return ex2_Data__connectI(url, ar, _ex);
}

struct sidl_BaseInterface__object* skel_ex2_GraphC1_fconnect_sidl_BaseInterface(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex) { 
  return sidl_BaseInterface__connectI(url, ar, _ex);
}

struct ex2_ListC__object* skel_ex2_GraphC1_fconnect_ex2_ListC(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) { 
  return ex2_ListC__connectI(url, ar, _ex);
}

struct ex2_AdjListC__object* skel_ex2_GraphC1_fconnect_ex2_AdjListC(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex) { 
  return ex2_AdjListC__connectI(url, ar, _ex);
}

struct ex2_ListOps__object* skel_ex2_GraphC1_fconnect_ex2_ListOps(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex) { 
  return ex2_ListOps__connectI(url, ar, _ex);
}

struct ex2_ListNode__object* skel_ex2_GraphC1_fconnect_ex2_ListNode(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex) { 
  return ex2_ListNode__connectI(url, ar, _ex);
}

struct ex2_AdjList__object* skel_ex2_GraphC1_fconnect_ex2_AdjList(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex) { 
  return ex2_AdjList__connectI(url, ar, _ex);
}

#endif /*WITH_RMI*/
struct ex2_GraphC1__data*
ex2_GraphC1__get_data(ex2_GraphC1 self)
{
  return (struct ex2_GraphC1__data*)(self ? self->d_data : NULL);
}

void ex2_GraphC1__set_data(
  ex2_GraphC1 self,
  struct ex2_GraphC1__data* data)
{
  if (self) {
    self->d_data = data;
  }
}
#ifdef __cplusplus
}
#endif
