/*
 * File:          ex2_GraphC1_Impl.c
 * Symbol:        ex2.GraphC1-v0.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for ex2.GraphC1
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "ex2.GraphC1" (version 0.0)
 */

#include "ex2_GraphC1_Impl.h"
#include "sidl_NotImplementedException.h"
#include "sidl_Exception.h"
#ifndef included_sidl_MemAllocException_h
#include "sidl_MemAllocException.h"
#endif

/* DO-NOT-DELETE splicer.begin(ex2.GraphC1._includes) */

/* Insert-UserCode-Here {ex2.GraphC1._includes} (includes and arbitrary code) */
#include <time.h>
int randint()
{
  
  int randres = ((rand() % 100) < 70)? 1: 0;
  return randres;
} 

/* Bocca generated code. bocca.protected.begin(ex2.GraphC1._includes) */
#include <stdlib.h>
#include <string.h>
#include "sidl_SIDLException.h"

#define _BOCCA_CTOR_MESSAGES 0

#ifdef _BOCCA_STDERR

#define BOCCA_FPRINTF fprintf
#include <stdio.h>
#include "sidl_String.h"
#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif /* _BOCCA_CTOR_PRINT */

#else /* _BOCCA_STDERR */
#define BOCCA_FPRINTF boccaPrintNothing
#endif /* _BOCCA_STDERR */

static int
boccaPrintNothing(void *v, const char * s, ...)
{
  (void)v; (void)s;
  return 0;
}
/* Bocca generated code. bocca.protected.end(ex2.GraphC1._includes) */

/* Insert-UserCode-Here {ex2.GraphC1._includes} (includes and arbitrary code) */

/* DO-NOT-DELETE splicer.end(ex2.GraphC1._includes) */

#define SIDL_IOR_MAJOR_VERSION 2
#define SIDL_IOR_MINOR_VERSION 0
/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_GraphC1__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_GraphC1__load(
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.GraphC1._load) */
    /* Insert-Code-Here {ex2.GraphC1._load} (static class initializer method) */
    /*
     * This method has not been implemented
     */

    /* DO-DELETE-WHEN-IMPLEMENTING exception.begin(ex2.GraphC1._load) */
    SIDL_THROW(*_ex, sidl_NotImplementedException,     "This method has not been implemented");
  EXIT:;
    /* DO-DELETE-WHEN-IMPLEMENTING exception.end(ex2.GraphC1._load) */
    /* DO-NOT-DELETE splicer.end(ex2.GraphC1._load) */
  }
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_GraphC1__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_GraphC1__ctor(
  /* in */ ex2_GraphC1 self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.GraphC1._ctor) */

  /* Insert-UserDecl-Here {ex2.GraphC1._ctor} (constructor method) */
    
  /* bocca-default-code. User may edit or delete.begin(ex2.GraphC1._ctor) */
   struct ex2_GraphC1__data *dptr = 
       (struct ex2_GraphC1__data*)malloc(sizeof(struct ex2_GraphC1__data));
   if (dptr) {
      memset(dptr, 0, sizeof(struct ex2_GraphC1__data));
   }
   ex2_GraphC1__set_data(self, dptr);
   #if _BOCCA_CTOR_MESSAGES
     BOCCA_FPRINTF(stderr, 
        "CTOR ex2.GraphC1: %s constructed data %p in self %p\n", 
        __FUNC__, dptr, self);
   #endif /* _BOCCA_CTOR_MESSAGES */
  /* bocca-default-code. User may edit or delete.end(ex2.GraphC1._ctor) */

  /* initialize user elements of dptr here */
     srand(time(NULL));
     dptr->vcount = 0;
     dptr->ecount = 0;
     ex2_ListC adjacencyLists = ex2_ListC__create(_ex);
     dptr->adjlists = ex2_ListOps__cast(adjacencyLists, _ex);
     ex2_ListC_deleteRef(adjacencyLists, _ex);
  /* Insert-UserCode-Here {ex2.GraphC1._ctor} (constructor method) */

    /* DO-NOT-DELETE splicer.end(ex2.GraphC1._ctor) */
  }
}

/*
 * Special Class constructor called when the user wants to wrap his own private data.
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_GraphC1__ctor2"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_GraphC1__ctor2(
  /* in */ ex2_GraphC1 self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.GraphC1._ctor2) */
    /* Insert-Code-Here {ex2.GraphC1._ctor2} (special constructor method) */
    /*
     * This method has not been implemented
     */

    /* DO-DELETE-WHEN-IMPLEMENTING exception.begin(ex2.GraphC1._ctor2) */
    SIDL_THROW(*_ex, sidl_NotImplementedException,     "This method has not been implemented");
  EXIT:;
    /* DO-DELETE-WHEN-IMPLEMENTING exception.end(ex2.GraphC1._ctor2) */
    /* DO-NOT-DELETE splicer.end(ex2.GraphC1._ctor2) */
  }
}
/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_GraphC1__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_GraphC1__dtor(
  /* in */ ex2_GraphC1 self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.GraphC1._dtor) */

  /* deinitialize user elements of dptr here */
  /* Insert-UserCode-Here {ex2.GraphC1._dtor} (destructor method) */
    
  /* bocca-default-code. User may edit or delete.begin(ex2.GraphC1._dtor) */
   struct ex2_GraphC1__data *dptr = 
                ex2_GraphC1__get_data(self);
   if (dptr) {
     dptr->vcount = NULL;
     dptr->ecount = NULL;
     ex2_ListOps_deleteRef(dptr->adjlists, _ex);
     dptr->adjlists = NULL;
      free(dptr);
      ex2_GraphC1__set_data(self, NULL);
   }
   #if _BOCCA_CTOR_MESSAGES
     BOCCA_FPRINTF(stderr, "DTOR ex2.GraphC1: %s freed data %p in self %p\n", 
                   __FUNC__, dptr, self);
   #endif /* _BOCCA_CTOR_MESSAGES */
  /* bocca-default-code. User may edit or delete.end(ex2.GraphC1._dtor) */

    /* DO-NOT-DELETE splicer.end(ex2.GraphC1._dtor) */
  }
}

/*
 *  This function should never be called, but helps babel generate better code. 
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_GraphC1_boccaForceUsePortInclude"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_GraphC1_boccaForceUsePortInclude(
  /* in */ ex2_GraphC1 self,
  /* in */ ex2_AdjList dummy0,
  /* in */ ex2_ListOps dummy1,
  /* in */ ex2_AdjListC dummy2,
  /* in */ ex2_Data dummy3,
  /* in */ ex2_ListC dummy4,
  /* in */ ex2_ListNode dummy5,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.GraphC1.boccaForceUsePortInclude) */
/* DO-NOT-EDIT-BOCCA */
  /* Bocca generated code. bocca.protected.begin(ex2.GraphC1.boccaForceUsePortInclude) */
    (void)self;
    (void)dummy0;
    (void)dummy1;
    (void)dummy2;
    (void)dummy3;
    (void)dummy4;
    (void)dummy5;

  /* Bocca generated code. bocca.protected.end(ex2.GraphC1.boccaForceUsePortInclude) */
    /* DO-NOT-DELETE splicer.end(ex2.GraphC1.boccaForceUsePortInclude) */
  }
}

/*
 * Inserts a vertex into a graph. 
 * returns 0 if the insertion is successful, 
 * 1 if the vertex already exists. -1 otherwise
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_GraphC1_insVertex"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_ex2_GraphC1_insVertex(
  /* in */ ex2_GraphC1 self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.GraphC1.insVertex) */
    /* Insert-Code-Here {ex2.GraphC1.insVertex} (insVertex method) */
    struct ex2_GraphC1__data * dptr = ex2_GraphC1__get_data(self);
    ex2_ListNode elem,next;
    ex2_AdjList adjlist;
    elem = ex2_ListOps_getHead(dptr->adjlists, _ex); SIDL_REPORT(*_ex);
    while (elem){
      adjlist = ex2_ListNode_getData(elem, _ex); SIDL_REPORT(*_ex); 
      int compare_result = ex2_AdjList_compare(adjlist, d, _ex);
      if (compare_result == 0){
        //means there is already an existing vertex
        ex2_AdjList_deleteRef(adjlist, _ex); SIDL_REPORT(*_ex);
        ex2_ListNode_deleteRef(elem,_ex); SIDL_REPORT(*_ex);
        return 1;
      }
      ex2_AdjList_deleteRef(adjlist,_ex); SIDL_REPORT(*_ex);
      next = ex2_ListNode_getNext(elem, _ex); SIDL_REPORT(*_ex);
      ex2_ListNode_deleteRef(elem, _ex); SIDL_REPORT(*_ex);
      elem = next; 
    }
    //vertex not found, create adjacency list and insert vertex
    ex2_AdjListC ad = ex2_AdjListC__create(_ex); SIDL_REPORT(*_ex); 
    adjlist = ex2_AdjList__cast(ad, _ex);
    ex2_AdjListC_deleteRef(ad, _ex);
    ex2_AdjList_setData(adjlist, d, _ex); SIDL_REPORT(*_ex); 
    ex2_ListNode tail = ex2_ListOps_getTail(dptr->adjlists, _ex); SIDL_REPORT(*_ex);
    int retval = ex2_ListOps_insertNext(dptr->adjlists, tail, adjlist, _ex); SIDL_REPORT(*_ex);
    if (tail) ex2_ListNode_deleteRef(tail, _ex); SIDL_REPORT(*_ex);
    ex2_AdjList_deleteRef(adjlist, _ex); SIDL_REPORT(*_ex);
    if (retval != 0)
      return retval;
    dptr->vcount++;   
    
    return 0;        
  EXIT:
    return -1;
    /* DO-NOT-DELETE splicer.end(ex2.GraphC1.insVertex) */
  }
}

/*
 * Removes vertex from a graph. 
 * returns 0 if removal was successful, 
 * -1 otherwise 
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_GraphC1_remVertex"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_ex2_GraphC1_remVertex(
  /* in */ ex2_GraphC1 self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.GraphC1.remVertex) */
    struct ex2_GraphC1__data * dptr = ex2_GraphC1__get_data(self);
    //traverse each adjacency list and the vertices it contains
    //do not allow removal of a vertex if it is in an adjacency list.. 
    //test for 3 cases: vertex can be removed, vertex not found, vertex is present in one of adjacency lists
    ex2_ListNode elem, next, temp= NULL;
    ex2_ListNode prev = NULL;
    int found = 0;
    ex2_AdjList adjlist, adjListToRemove;
    elem = ex2_ListOps_getHead(dptr->adjlists, _ex); SIDL_REPORT(*_ex);
    while (elem){
      adjlist = ex2_ListNode_getData(elem, _ex); SIDL_REPORT(*_ex);
      if (ex2_AdjList_isMember(adjlist,d, _ex)){
        ex2_AdjList_deleteRef(adjlist, _ex); SIDL_REPORT(*_ex);
        ex2_ListNode_deleteRef(elem, _ex); SIDL_REPORT(*_ex);
        if (prev) ex2_ListNode_deleteRef(prev, _ex); SIDL_REPORT(*_ex);
        if (temp) ex2_ListNode_deleteRef(temp, _ex); SIDL_REPORT(*_ex);
        return -1;
      }
      //compare the vertex, keep a pointer to the adjlist element.
      int retval = ex2_AdjList_compare(adjlist, d, _ex);
      if (retval == 0){
        temp = elem;
        adjListToRemove = adjlist;
        found = 1;
      }
      if (retval!= 0){
	ex2_AdjList_deleteRef(adjlist, _ex);
        ex2_ListNode_deleteRef(elem, _ex);
      }
      
      if (!found){
        if (prev) ex2_ListNode_deleteRef(prev, _ex); SIDL_REPORT(*_ex);
        //ex2_AdjListC_deleteRef(adjlist, _ex);
        prev = elem;
        ex2_ListNode_addRef(prev, _ex);
      }           
      next = ex2_ListNode_getNext(elem, _ex); SIDL_REPORT(*_ex);
      elem = next;
    }
    if (!found){
      if (prev) ex2_ListNode_deleteRef(prev, _ex); SIDL_REPORT(*_ex);
      
      return -1;
    }
    int size = ex2_AdjList_getSize(adjListToRemove, _ex);
    if (size > 0){
      ex2_ListNode_deleteRef(temp, _ex);
      if (prev) ex2_ListNode_deleteRef(prev, _ex);
      ex2_AdjList_deleteRef(adjListToRemove, _ex);
      return -1;
    }
    ex2_AdjList_deleteRef(adjListToRemove,_ex);
    if (prev)ex2_ListNode_deleteRef(prev, _ex);
    ex2_ListNode_deleteRef(temp, _ex);
    // ex2_AdjListC_deleteRef(adjListToRemove, _ex);
    int retval = ex2_ListOps_removeNext(dptr->adjlists, prev, &adjlist,_ex);
    if (retval != 0)
      return -1;
    ex2_AdjList_deleteRef(adjlist,_ex);
    dptr->vcount--;
    return 0;
      
  EXIT:
    return -1;
    /* DO-NOT-DELETE splicer.end(ex2.GraphC1.remVertex) */
  }
}

/*
 * Inserts an edge specified by vertices d1 and d2. 
 * Both vertices must have been inserted previously. 
 * The new edge is represented by pointer to d2 
 * in the adjacency list of d1. To enter an edge 
 * into an undirected graph, call this operation 
 * twice, once to insert an edge from d1 to d2, 
 * and again to insert an edge from d2 to d1. 
 * Method returns 0 if the insertion was successful,
 * 1 if the edge already exists and -1 otherwise.
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_GraphC1_insEdge"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_ex2_GraphC1_insEdge(
  /* in */ ex2_GraphC1 self,
  /* in */ ex2_Data d1,
  /* in */ ex2_Data d2,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.GraphC1.insEdge) */
    struct ex2_GraphC1__data * dptr = ex2_GraphC1__get_data(self);
    ex2_ListNode elem,next;
    ex2_AdjList adjlist;
    
    elem = ex2_ListOps_getHead(dptr->adjlists, _ex); SIDL_REPORT(*_ex);
    while (elem){
      adjlist = ex2_ListNode_getData(elem, _ex); SIDL_REPORT(*_ex); 
      int compare_result = ex2_AdjList_compare(adjlist, d2, _ex);
      if (compare_result == 0){
        //means there is already an existing vertex with d2 element
        ex2_AdjList_deleteRef(adjlist, _ex); SIDL_REPORT(*_ex);
        ex2_ListNode_deleteRef(elem, _ex); SIDL_REPORT(*_ex);
        break;
      }
      ex2_AdjList_deleteRef(adjlist,_ex); SIDL_REPORT(*_ex);
      next = ex2_ListNode_getNext(elem, _ex); SIDL_REPORT(*_ex);
      ex2_ListNode_deleteRef(elem, _ex); SIDL_REPORT(*_ex);
      elem = next; 
    }
    if (!elem){
      return -1;
    }
    elem = ex2_ListOps_getHead(dptr->adjlists, _ex); SIDL_REPORT(*_ex);
    while (elem){
      adjlist = ex2_ListNode_getData(elem, _ex); SIDL_REPORT(*_ex); 
      int compare_result = ex2_AdjList_compare(adjlist, d1, _ex);
      if (compare_result == 0){
        //means there is already an existing vertex with d2 element        
        ex2_ListNode_deleteRef(elem, _ex); SIDL_REPORT(*_ex);
        break;
      }
      ex2_AdjList_deleteRef(adjlist,_ex); SIDL_REPORT(*_ex);
      next = ex2_ListNode_getNext(elem, _ex); SIDL_REPORT(*_ex);
      ex2_ListNode_deleteRef(elem, _ex); SIDL_REPORT(*_ex);
      elem = next; 
    }
    if (!elem){
      return -1;
    }
    //insert the second vertex into the adjacency list of first vertex
    int retval = -1;
    
    int randResult = randint();
    if (randResult == 1) {retval = ex2_AdjList_insert(adjlist, d2, _ex); SIDL_REPORT(*_ex);}
    
    ex2_AdjList_deleteRef(adjlist, _ex); SIDL_REPORT(*_ex);
    if (retval != 0) return retval;
    dptr->ecount++;
    return 0;    
  EXIT:
    return -1;
    /* DO-NOT-DELETE splicer.end(ex2.GraphC1.insEdge) */
  }
}

/*
 * Removes the edge from d1 to d2. returns 0 
 * if removing of edge was successful, -1 otherwise.
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_GraphC1_remEdge"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_ex2_GraphC1_remEdge(
  /* in */ ex2_GraphC1 self,
  /* in */ ex2_Data d1,
  /* in */ ex2_Data d2,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.GraphC1.remEdge) */
    struct ex2_GraphC1__data * dptr = ex2_GraphC1__get_data(self);
    ex2_ListNode elem,next;
    ex2_AdjList adjlist;
    elem = ex2_ListOps_getHead(dptr->adjlists, _ex); SIDL_REPORT(*_ex);
    while (elem){
      adjlist = ex2_ListNode_getData(elem, _ex); SIDL_REPORT(*_ex); 
      int compare_result = ex2_AdjList_compare(adjlist, d1, _ex);
      if (compare_result == 0){
        break;
      }
      next = ex2_ListNode_getNext(elem, _ex);
      ex2_ListNode_deleteRef(elem, _ex);
      ex2_AdjList_deleteRef(adjlist, _ex);
      elem = next;
    }
    if (! elem ){
      return -1;
    }
    int result = ex2_AdjList_remove(adjlist, d2, _ex);
    ex2_AdjList_deleteRef(adjlist, _ex);
    ex2_ListNode_deleteRef(elem, _ex);
    if (result != 0){

      return -1;
    }
    dptr->ecount--;
    return 0;
    EXIT:
    return -1;
    /* DO-NOT-DELETE splicer.end(ex2.GraphC1.remEdge) */
  }
}

/*
 *  
 * Returns vertices that are adjacent to Data d.
 * The vertices are returned in the form of actual 
 * AdjList data structure with vertex data member pointing to d.
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_GraphC1_getAdjList"

#ifdef __cplusplus
extern "C"
#endif
ex2_AdjList
impl_ex2_GraphC1_getAdjList(
  /* in */ ex2_GraphC1 self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.GraphC1.getAdjList) */
   struct ex2_GraphC1__data * dptr = ex2_GraphC1__get_data(self);
    ex2_ListNode elem,next;
    ex2_AdjList adjlist;
    elem = ex2_ListOps_getHead(dptr->adjlists, _ex); SIDL_REPORT(*_ex);
    while (elem){
      adjlist = ex2_ListNode_getData(elem, _ex); SIDL_REPORT(*_ex); 
      int compare_result = ex2_AdjList_compare(adjlist, d, _ex);
      if (compare_result == 0){
        ex2_ListNode_deleteRef(elem, _ex);
        break;
      }
      ex2_AdjList_deleteRef(adjlist,_ex); SIDL_REPORT(*_ex);
      next = ex2_ListNode_getNext(elem, _ex); SIDL_REPORT(*_ex);
      ex2_ListNode_deleteRef(elem, _ex); SIDL_REPORT(*_ex);
      elem = next; 
    }
    if (! elem){
      return NULL;
    } 
    
    
    return adjlist;
  EXIT:
      return NULL;
    /* DO-NOT-DELETE splicer.end(ex2.GraphC1.getAdjList) */
  }
}

/*
 * Determines whether the vertex specified by d2
 * is adjacent to the vertex specified by d1 in graph.
 * Returns 1 if the second vertex is adjacent to the 
 * first vertex, or 0 otherwise
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_GraphC1_isAdjacent"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_ex2_GraphC1_isAdjacent(
  /* in */ ex2_GraphC1 self,
  /* in */ ex2_Data d1,
  /* in */ ex2_Data d2,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.GraphC1.isAdjacent) */
    struct ex2_GraphC1__data * dptr = ex2_GraphC1__get_data(self);
    ex2_ListNode elem,next;
    ex2_AdjList adjlist;
    elem = ex2_ListOps_getHead(dptr->adjlists, _ex); SIDL_REPORT(*_ex);
    while (elem){
      adjlist = ex2_ListNode_getData(elem, _ex); SIDL_REPORT(*_ex); 
      int compare_result = ex2_AdjList_compare(adjlist, d1, _ex);
      if (compare_result == 0){
        break;
      }
      ex2_AdjList_deleteRef(adjlist,_ex); SIDL_REPORT(*_ex);
      next = ex2_ListNode_getNext(elem, _ex); SIDL_REPORT(*_ex);
      ex2_ListNode_deleteRef(elem, _ex); SIDL_REPORT(*_ex);
      elem = next; 
    }
    if (! elem){
      return NULL;
    }
    int32_t result = ex2_AdjList_isMember(adjlist, d2, _ex);  
    ex2_ListNode_deleteRef(elem, _ex);
    ex2_AdjList_deleteRef(adjlist, _ex);
    return result;
    
   EXIT:
    return NULL;
    /* DO-NOT-DELETE splicer.end(ex2.GraphC1.isAdjacent) */
  }
}

/*
 * Returns all adjacency data structures in the 
 * form of a List interface. or NULL if fails.
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_GraphC1_getAdjLists"

#ifdef __cplusplus
extern "C"
#endif
ex2_ListOps
impl_ex2_GraphC1_getAdjLists(
  /* in */ ex2_GraphC1 self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.GraphC1.getAdjLists) */
    struct ex2_GraphC1__data * dptr = ex2_GraphC1__get_data(self);
    ex2_ListOps_addRef(dptr->adjlists, _ex);
    return dptr->adjlists;
    /* DO-NOT-DELETE splicer.end(ex2.GraphC1.getAdjLists) */
  }
}

/*
 * Returns current vertex count
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_GraphC1_getVertCount"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_ex2_GraphC1_getVertCount(
  /* in */ ex2_GraphC1 self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.GraphC1.getVertCount) */
    struct ex2_GraphC1__data * dptr = ex2_GraphC1__get_data(self);
    return dptr->vcount;
    /* DO-NOT-DELETE splicer.end(ex2.GraphC1.getVertCount) */
  }
}

/*
 * Returns current edge count
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_GraphC1_getEdgeCount"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_ex2_GraphC1_getEdgeCount(
  /* in */ ex2_GraphC1 self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.GraphC1.getEdgeCount) */
    struct ex2_GraphC1__data * dptr = ex2_GraphC1__get_data(self);
    return dptr->ecount;
    /* DO-NOT-DELETE splicer.end(ex2.GraphC1.getEdgeCount) */
  }
}

/*
 * Returns true if the vertex is present in the graph, false otherwise
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_GraphC1_vertexExists"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_ex2_GraphC1_vertexExists(
  /* in */ ex2_GraphC1 self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.GraphC1.vertexExists) */
    struct ex2_GraphC1__data * dptr = ex2_GraphC1__get_data(self);
    ex2_ListNode elem,next;
    ex2_AdjList adjlist;
    elem = ex2_ListOps_getHead(dptr->adjlists, _ex); SIDL_REPORT(*_ex);
    while (elem){
      adjlist = ex2_ListNode_getData(elem, _ex); SIDL_REPORT(*_ex); 
      int compare_result = ex2_AdjList_compare(adjlist, d, _ex);
      if (compare_result == 0){
        ex2_ListNode_deleteRef(elem, _ex);
        break;
      }
      ex2_AdjList_deleteRef(adjlist,_ex); SIDL_REPORT(*_ex);
      next = ex2_ListNode_getNext(elem, _ex); SIDL_REPORT(*_ex);
      ex2_ListNode_deleteRef(elem, _ex); SIDL_REPORT(*_ex);
      elem = next; 
    }
    if (! elem){
      return 0;
    } 
    ex2_AdjList_deleteRef(adjlist, _ex);
    return 1;
  EXIT: return -1;
   
    /* DO-NOT-DELETE splicer.end(ex2.GraphC1.vertexExists) */
  }
}
/* Babel internal methods, Users should not edit below this line. */

/* DO-NOT-DELETE splicer.begin(_misc) */
/* Insert-Code-Here {_misc} (miscellaneous code) */

/* DO-NOT-DELETE splicer.end(_misc) */

