/*
 * File:          ex2_AdjListC_Skel.c
 * Symbol:        ex2.AdjListC-v0.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side glue code for ex2.AdjListC
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 */

#include "ex2_AdjListC_IOR.h"
#include "ex2_AdjListC.h"
#include <stddef.h>

#ifdef WITH_RMI
#ifndef included_ex2_Data_h
#include "ex2_Data.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_ex2_SetC_h
#include "ex2_SetC.h"
#endif
#ifndef included_ex2_ListOps_h
#include "ex2_ListOps.h"
#endif
#endif /* WITH_RMI */
extern
void
impl_ex2_AdjListC__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_AdjListC__ctor(
  /* in */ ex2_AdjListC self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_AdjListC__ctor2(
  /* in */ ex2_AdjListC self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_AdjListC__dtor(
  /* in */ ex2_AdjListC self,
  /* out */ sidl_BaseInterface *_ex);

#ifdef WITH_RMI
extern struct ex2_Data__object* impl_ex2_AdjListC_fconnect_ex2_Data(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_ex2_AdjListC_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct ex2_SetC__object* impl_ex2_AdjListC_fconnect_ex2_SetC(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ex2_ListOps__object* impl_ex2_AdjListC_fconnect_ex2_ListOps(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/
extern
void
impl_ex2_AdjListC_boccaForceUsePortInclude(
  /* in */ ex2_AdjListC self,
  /* in */ ex2_SetC dummy0,
  /* in */ ex2_ListOps dummy1,
  /* in */ ex2_Data dummy2,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_AdjListC_insert(
  /* in */ ex2_AdjListC self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_AdjListC_remove(
  /* in */ ex2_AdjListC self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_ex2_AdjListC_isMember(
  /* in */ ex2_AdjListC self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_AdjListC_clearSet(
  /* in */ ex2_AdjListC self,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_ex2_AdjListC_isEmpty(
  /* in */ ex2_AdjListC self,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_AdjListC_getSize(
  /* in */ ex2_AdjListC self,
  /* out */ sidl_BaseInterface *_ex);

extern
ex2_ListOps
impl_ex2_AdjListC_getList(
  /* in */ ex2_AdjListC self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_AdjListC_display(
  /* in */ ex2_AdjListC self,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_AdjListC_hashCode(
  /* in */ ex2_AdjListC self,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_AdjListC_compare(
  /* in */ ex2_AdjListC self,
  /* in */ ex2_Data data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_AdjListC_setData(
  /* in */ ex2_AdjListC self,
  /* in */ ex2_Data data,
  /* out */ sidl_BaseInterface *_ex);

extern
ex2_Data
impl_ex2_AdjListC_getVertex(
  /* in */ ex2_AdjListC self,
  /* out */ sidl_BaseInterface *_ex);

#ifdef WITH_RMI
extern struct ex2_Data__object* impl_ex2_AdjListC_fconnect_ex2_Data(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_ex2_AdjListC_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct ex2_SetC__object* impl_ex2_AdjListC_fconnect_ex2_SetC(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ex2_ListOps__object* impl_ex2_AdjListC_fconnect_ex2_ListOps(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/
#ifdef __cplusplus
extern "C" {
#endif

void
ex2_AdjListC__set_epv(struct ex2_AdjListC__epv *epv,
  struct ex2_AdjListC__pre_epv *pre_epv, 
  struct ex2_AdjListC__post_epv *post_epv
)
{
  epv->f__ctor = impl_ex2_AdjListC__ctor;
  epv->f__ctor2 = impl_ex2_AdjListC__ctor2;
  epv->f__dtor = impl_ex2_AdjListC__dtor;
  pre_epv->f_boccaForceUsePortInclude_pre = NULL;
  epv->f_boccaForceUsePortInclude = impl_ex2_AdjListC_boccaForceUsePortInclude;
  post_epv->f_boccaForceUsePortInclude_post = NULL;
  pre_epv->f_insert_pre = NULL;
  epv->f_insert = impl_ex2_AdjListC_insert;
  post_epv->f_insert_post = NULL;
  pre_epv->f_remove_pre = NULL;
  epv->f_remove = impl_ex2_AdjListC_remove;
  post_epv->f_remove_post = NULL;
  pre_epv->f_isMember_pre = NULL;
  epv->f_isMember = impl_ex2_AdjListC_isMember;
  post_epv->f_isMember_post = NULL;
  pre_epv->f_clearSet_pre = NULL;
  epv->f_clearSet = impl_ex2_AdjListC_clearSet;
  post_epv->f_clearSet_post = NULL;
  pre_epv->f_isEmpty_pre = NULL;
  epv->f_isEmpty = impl_ex2_AdjListC_isEmpty;
  post_epv->f_isEmpty_post = NULL;
  pre_epv->f_getSize_pre = NULL;
  epv->f_getSize = impl_ex2_AdjListC_getSize;
  post_epv->f_getSize_post = NULL;
  pre_epv->f_getList_pre = NULL;
  epv->f_getList = impl_ex2_AdjListC_getList;
  post_epv->f_getList_post = NULL;
  pre_epv->f_display_pre = NULL;
  epv->f_display = impl_ex2_AdjListC_display;
  post_epv->f_display_post = NULL;
  pre_epv->f_hashCode_pre = NULL;
  epv->f_hashCode = impl_ex2_AdjListC_hashCode;
  post_epv->f_hashCode_post = NULL;
  pre_epv->f_compare_pre = NULL;
  epv->f_compare = impl_ex2_AdjListC_compare;
  post_epv->f_compare_post = NULL;
  pre_epv->f_setData_pre = NULL;
  epv->f_setData = impl_ex2_AdjListC_setData;
  post_epv->f_setData_post = NULL;
  pre_epv->f_getVertex_pre = NULL;
  epv->f_getVertex = impl_ex2_AdjListC_getVertex;
  post_epv->f_getVertex_post = NULL;

}
#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
extern "C" {
#endif

void ex2_AdjListC__call_load(void) { 
  sidl_BaseInterface _throwaway_exception = NULL;
  impl_ex2_AdjListC__load(&_throwaway_exception);
}
#ifdef WITH_RMI
struct ex2_Data__object* skel_ex2_AdjListC_fconnect_ex2_Data(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) { 
  return ex2_Data__connectI(url, ar, _ex);
}

struct sidl_BaseInterface__object* 
  skel_ex2_AdjListC_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex) { 
  return sidl_BaseInterface__connectI(url, ar, _ex);
}

struct ex2_SetC__object* skel_ex2_AdjListC_fconnect_ex2_SetC(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) { 
  return ex2_SetC__connectI(url, ar, _ex);
}

struct ex2_ListOps__object* skel_ex2_AdjListC_fconnect_ex2_ListOps(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex) { 
  return ex2_ListOps__connectI(url, ar, _ex);
}

#endif /*WITH_RMI*/
struct ex2_AdjListC__data*
ex2_AdjListC__get_data(ex2_AdjListC self)
{
  return (struct ex2_AdjListC__data*)(self ? self->d_data : NULL);
}

void ex2_AdjListC__set_data(
  ex2_AdjListC self,
  struct ex2_AdjListC__data* data)
{
  if (self) {
    self->d_data = data;
  }
}
#ifdef __cplusplus
}
#endif
