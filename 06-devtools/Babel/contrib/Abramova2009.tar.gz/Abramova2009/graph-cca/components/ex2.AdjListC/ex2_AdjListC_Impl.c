/*
 * File:          ex2_AdjListC_Impl.c
 * Symbol:        ex2.AdjListC-v0.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for ex2.AdjListC
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "ex2.AdjListC" (version 0.0)
 */

#include "ex2_AdjListC_Impl.h"
#include "sidl_NotImplementedException.h"
#include "sidl_Exception.h"
#ifndef included_sidl_MemAllocException_h
#include "sidl_MemAllocException.h"
#endif

/* DO-NOT-DELETE splicer.begin(ex2.AdjListC._includes) */

/* Insert-UserCode-Here {ex2.AdjListC._includes} (includes and arbitrary code) */

/* Bocca generated code. bocca.protected.begin(ex2.AdjListC._includes) */
#include <stdlib.h>
#include <string.h>
#include "sidl_SIDLException.h"

#define _BOCCA_CTOR_MESSAGES 0

#ifdef _BOCCA_STDERR

#define BOCCA_FPRINTF fprintf
#include <stdio.h>
#include "sidl_String.h"
#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif /* _BOCCA_CTOR_PRINT */

#else /* _BOCCA_STDERR */
#define BOCCA_FPRINTF boccaPrintNothing
#endif /* _BOCCA_STDERR */

static int
boccaPrintNothing(void *v, const char * s, ...)
{
  (void)v; (void)s;
  return 0;
}
/* Bocca generated code. bocca.protected.end(ex2.AdjListC._includes) */

/* Insert-UserCode-Here {ex2.AdjListC._includes} (includes and arbitrary code) */

/* DO-NOT-DELETE splicer.end(ex2.AdjListC._includes) */

#define SIDL_IOR_MAJOR_VERSION 2
#define SIDL_IOR_MINOR_VERSION 0
/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_AdjListC__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_AdjListC__load(
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.AdjListC._load) */
    /* Insert-Code-Here {ex2.AdjListC._load} (static class initializer method) 
      */
    /*
     * This method has not been implemented
     */

    /* DO-DELETE-WHEN-IMPLEMENTING exception.begin(ex2.AdjListC._load) */
    SIDL_THROW(*_ex, sidl_NotImplementedException,     "This method has not been implemented");
  EXIT:;
    /* DO-DELETE-WHEN-IMPLEMENTING exception.end(ex2.AdjListC._load) */
    /* DO-NOT-DELETE splicer.end(ex2.AdjListC._load) */
  }
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_AdjListC__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_AdjListC__ctor(
  /* in */ ex2_AdjListC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.AdjListC._ctor) */

  /* Insert-UserDecl-Here {ex2.AdjListC._ctor} (constructor method) */
    
  /* bocca-default-code. User may edit or delete.begin(ex2.AdjListC._ctor) */
   struct ex2_AdjListC__data *dptr = 
       (struct ex2_AdjListC__data*)malloc(sizeof(struct ex2_AdjListC__data));
   if (dptr) {
      memset(dptr, 0, sizeof(struct ex2_AdjListC__data));
   }
   ex2_AdjListC__set_data(self, dptr);
   #if _BOCCA_CTOR_MESSAGES
     BOCCA_FPRINTF(stderr, 
        "CTOR ex2.AdjListC: %s constructed data %p in self %p\n", 
        __FUNC__, dptr, self);
   #endif /* _BOCCA_CTOR_MESSAGES */
  /* bocca-default-code. User may edit or delete.end(ex2.AdjListC._ctor) */

  /* initialize user elements of dptr here */
     ex2_SetC set = ex2_SetC__create(_ex);
     dptr->adjacent = ex2_SetOps__cast(set, _ex);
     ex2_SetC_deleteRef(set,_ex);
     dptr->vertex = NULL;
  /* Insert-UserCode-Here {ex2.AdjListC._ctor} (constructor method) */

    /* DO-NOT-DELETE splicer.end(ex2.AdjListC._ctor) */
  }
}

/*
 * Special Class constructor called when the user wants to wrap his own private data.
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_AdjListC__ctor2"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_AdjListC__ctor2(
  /* in */ ex2_AdjListC self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.AdjListC._ctor2) */
    /* Insert-Code-Here {ex2.AdjListC._ctor2} (special constructor method) */
    /*
     * This method has not been implemented
     */

    /* DO-DELETE-WHEN-IMPLEMENTING exception.begin(ex2.AdjListC._ctor2) */
    SIDL_THROW(*_ex, sidl_NotImplementedException,     "This method has not been implemented");
  EXIT:;
    /* DO-DELETE-WHEN-IMPLEMENTING exception.end(ex2.AdjListC._ctor2) */
    /* DO-NOT-DELETE splicer.end(ex2.AdjListC._ctor2) */
  }
}
/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_AdjListC__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_AdjListC__dtor(
  /* in */ ex2_AdjListC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.AdjListC._dtor) */

  /* deinitialize user elements of dptr here */
  /* Insert-UserCode-Here {ex2.AdjListC._dtor} (destructor method) */
    
  /* bocca-default-code. User may edit or delete.begin(ex2.AdjListC._dtor) */
   struct ex2_AdjListC__data *dptr = 
                ex2_AdjListC__get_data(self);
   if (dptr) {
     ex2_SetOps_deleteRef(dptr->adjacent, _ex); SIDL_REPORT(*_ex);
     ex2_Data_deleteRef(dptr->vertex, _ex); SIDL_REPORT(*_ex);
      free(dptr);
      ex2_AdjListC__set_data(self, NULL);
   }
  EXIT: ;
   #if _BOCCA_CTOR_MESSAGES
     BOCCA_FPRINTF(stderr, "DTOR ex2.AdjListC: %s freed data %p in self %p\n", 
                   __FUNC__, dptr, self);
   #endif /* _BOCCA_CTOR_MESSAGES */
  /* bocca-default-code. User may edit or delete.end(ex2.AdjListC._dtor) */

    /* DO-NOT-DELETE splicer.end(ex2.AdjListC._dtor) */
  }
}

/*
 *  This function should never be called, but helps babel generate better code. 
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_AdjListC_boccaForceUsePortInclude"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_AdjListC_boccaForceUsePortInclude(
  /* in */ ex2_AdjListC self,
  /* in */ ex2_SetC dummy0,
  /* in */ ex2_ListOps dummy1,
  /* in */ ex2_Data dummy2,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.AdjListC.boccaForceUsePortInclude) */
/* DO-NOT-EDIT-BOCCA */
  /* Bocca generated code. bocca.protected.begin(ex2.AdjListC.boccaForceUsePortInclude) */
    (void)self;
    (void)dummy0;
    (void)dummy1;
    (void)dummy2;

  /* Bocca generated code. bocca.protected.end(ex2.AdjListC.boccaForceUsePortInclude) */
    /* DO-NOT-DELETE splicer.end(ex2.AdjListC.boccaForceUsePortInclude) */
  }
}

/*
 *  
 * inserts Data element in the set. 
 * returns 0 if the insertion is successful,
 * 1 if the member  is already in the set. -1 otherwise
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_AdjListC_insert"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_ex2_AdjListC_insert(
  /* in */ ex2_AdjListC self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.AdjListC.insert) */
    /* Insert-Code-Here {ex2.AdjListC.insert} (insert method) */
    struct ex2_AdjListC__data *dptr = ex2_AdjListC__get_data(self);
    int result = ex2_SetOps_insert(dptr->adjacent, d, _ex); SIDL_REPORT(*_ex);
    return result;
  EXIT:
    return result;
    
    /* DO-NOT-DELETE splicer.end(ex2.AdjListC.insert) */
  }
}

/*
 * removes Data element from the set. 
 * returns 0 if the removal is successful, -1 otherwise
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_AdjListC_remove"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_ex2_AdjListC_remove(
  /* in */ ex2_AdjListC self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.AdjListC.remove) */
    struct ex2_AdjListC__data *dptr = ex2_AdjListC__get_data(self);
    int result = ex2_SetOps_remove(dptr->adjacent, d, _ex); SIDL_REPORT(*_ex);
    return result;
  EXIT:
    return result;
    /* DO-NOT-DELETE splicer.end(ex2.AdjListC.remove) */
  }
}

/*
 * returns true if the element exists in the set, false otherwise
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_AdjListC_isMember"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_ex2_AdjListC_isMember(
  /* in */ ex2_AdjListC self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.AdjListC.isMember) */
    struct ex2_AdjListC__data * dptr = ex2_AdjListC__get_data(self);
    int result = ex2_SetOps_isMember(dptr->adjacent, d, _ex); SIDL_REPORT(*_ex);
    return result;
  EXIT:
    return result;
    /* DO-NOT-DELETE splicer.end(ex2.AdjListC.isMember) */
  }
}

/*
 * Clears the set, decrements references to all elements in the set,
 * sets the set size to 0
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_AdjListC_clearSet"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_AdjListC_clearSet(
  /* in */ ex2_AdjListC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.AdjListC.clearSet) */
    struct ex2_AdjListC__data *dptr = ex2_AdjListC__get_data(self);
    ex2_SetOps_clearSet(dptr->adjacent, _ex); SIDL_REPORT(*_ex);
  EXIT:
    ;
    /* DO-NOT-DELETE splicer.end(ex2.AdjListC.clearSet) */
  }
}

/*
 * Tests whether the set is empty. Returns true if empty
 * false otherwise
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_AdjListC_isEmpty"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_ex2_AdjListC_isEmpty(
  /* in */ ex2_AdjListC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.AdjListC.isEmpty) */
    struct ex2_AdjListC__data *dptr = ex2_AdjListC__get_data(self);
    int result = ex2_SetOps_isEmpty(dptr->adjacent, _ex); SIDL_REPORT(*_ex);
    return result;
  EXIT:
    return result;
    /* DO-NOT-DELETE splicer.end(ex2.AdjListC.isEmpty) */
  }
}

/*
 * Returns the size of the set
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_AdjListC_getSize"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_ex2_AdjListC_getSize(
  /* in */ ex2_AdjListC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.AdjListC.getSize) */
     struct ex2_AdjListC__data *dptr = ex2_AdjListC__get_data(self);
     int size = ex2_SetOps_getSize(dptr->adjacent, _ex);
     return size; 
    /* DO-NOT-DELETE splicer.end(ex2.AdjListC.getSize) */
  }
}

/*
 *  
 * Returns the elements in the form of a list.
 * Actual elements are returned.
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_AdjListC_getList"

#ifdef __cplusplus
extern "C"
#endif
ex2_ListOps
impl_ex2_AdjListC_getList(
  /* in */ ex2_AdjListC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.AdjListC.getList) */
    struct ex2_AdjListC__data *dptr = ex2_AdjListC__get_data(self);
     return ex2_SetOps_getList(dptr->adjacent, _ex);
    /* DO-NOT-DELETE splicer.end(ex2.AdjListC.getList) */
  }
}

/*
 * Displays contents of the data if possible
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_AdjListC_display"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_AdjListC_display(
  /* in */ ex2_AdjListC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.AdjListC.display) */
   struct ex2_AdjListC__data *dptr = ex2_AdjListC__get_data(self);
    ex2_Data_display(dptr->vertex, _ex);
    /* DO-NOT-DELETE splicer.end(ex2.AdjListC.display) */
  }
}

/*
 * Computes and returns a unique integer id - 
 * simply returns value of the data ptr
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_AdjListC_hashCode"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_ex2_AdjListC_hashCode(
  /* in */ ex2_AdjListC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.AdjListC.hashCode) */
    struct ex2_AdjListC__data *dptr = ex2_AdjListC__get_data(self);
    return dptr;
    /* DO-NOT-DELETE splicer.end(ex2.AdjListC.hashCode) */
  }
}

/*
 * Compares the element with data parameter element, 
 * returns 1 if it's greater than data,
 * 0 if they are equal and -1 if it's less than data
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_AdjListC_compare"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_ex2_AdjListC_compare(
  /* in */ ex2_AdjListC self,
  /* in */ ex2_Data data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.AdjListC.compare) */
    struct ex2_AdjListC__data *dptr = ex2_AdjListC__get_data(self);
    //printf("AdjlistC got called\n");
    
    int result = ex2_Data_compare(dptr->vertex, data, _ex); SIDL_REPORT(*_ex);
    // printf("Compare got called and returned\n");
    return result;
  EXIT: 
    return result;
    /* DO-NOT-DELETE splicer.end(ex2.AdjListC.compare) */
  }
}

/*
 * Takes in another Data object and casts it to a 
 * corresponding type + sets internal data members
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_AdjListC_setData"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_AdjListC_setData(
  /* in */ ex2_AdjListC self,
  /* in */ ex2_Data data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.AdjListC.setData) */
    //printf("AdjListC setData got called\n");
    struct ex2_AdjListC__data *dptr = ex2_AdjListC__get_data(self);
    dptr->vertex = data;
    
    /* ex2_IntData d1 = ex2_IntData_create(_ex);
    ex2_IntData_setIntData(d1,4,_ex);
    ex2_IntData d2 = ex2_IntData_create(_ex);
    ex2_IntData_setIntData(d2, 5,_ex);
    ex2_Data dd = ex2_Data__cast(d1, _ex);
    ex2_Data dd2 = ex2_Data__cast(d2, _ex);
    //ex2_IntData_compare(d1, dd2, _ex);
    ex2_Data_compare(dd,dd2,_ex);*/
    
    ex2_Data_addRef(data, _ex); SIDL_REPORT(*_ex);
    //printf("AdjListC setData returned\n");
    return;
  EXIT:
    ;  
    /* DO-NOT-DELETE splicer.end(ex2.AdjListC.setData) */
  }
}

/*
 * Returns the Data object stored as a vertex
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_AdjListC_getVertex"

#ifdef __cplusplus
extern "C"
#endif
ex2_Data
impl_ex2_AdjListC_getVertex(
  /* in */ ex2_AdjListC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.AdjListC.getVertex) */
    /* Insert-Code-Here {ex2.AdjListC.getVertex} (getVertex method) */
    struct ex2_AdjListC__data *dptr = ex2_AdjListC__get_data(self);
    if (dptr->vertex) ex2_Data_addRef(dptr->vertex, _ex);
    return dptr->vertex;
    /* DO-NOT-DELETE splicer.end(ex2.AdjListC.getVertex) */
  }
}
/* Babel internal methods, Users should not edit below this line. */

/* DO-NOT-DELETE splicer.begin(_misc) */
/* Insert-Code-Here {_misc} (miscellaneous code) */
/* DO-NOT-DELETE splicer.end(_misc) */

