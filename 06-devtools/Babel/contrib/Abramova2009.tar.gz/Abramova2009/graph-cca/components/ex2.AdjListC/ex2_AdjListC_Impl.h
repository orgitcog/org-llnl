/*
 * File:          ex2_AdjListC_Impl.h
 * Symbol:        ex2.AdjListC-v0.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for ex2.AdjListC
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#ifndef included_ex2_AdjListC_Impl_h
#define included_ex2_AdjListC_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_ex2_AdjList_h
#include "ex2_AdjList.h"
#endif
#ifndef included_ex2_AdjListC_h
#include "ex2_AdjListC.h"
#endif
#ifndef included_ex2_Data_h
#include "ex2_Data.h"
#endif
#ifndef included_ex2_ListOps_h
#include "ex2_ListOps.h"
#endif
#ifndef included_ex2_SetC_h
#include "ex2_SetC.h"
#endif
#ifndef included_ex2_SetOps_h
#include "ex2_SetOps.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_PostViolation_h
#include "sidl_PostViolation.h"
#endif
#ifndef included_sidl_PreViolation_h
#include "sidl_PreViolation.h"
#endif
#ifndef included_sidl_RuntimeException_h
#include "sidl_RuntimeException.h"
#endif
/* DO-NOT-DELETE splicer.begin(ex2.AdjListC._hincludes) */
/* Insert-Code-Here {ex2.AdjListC._hincludes} (include files) */
/* DO-NOT-DELETE splicer.end(ex2.AdjListC._hincludes) */

/*
 * Private data for class ex2.AdjListC
 */

struct ex2_AdjListC__data {
  /* DO-NOT-DELETE splicer.begin(ex2.AdjListC._data) */
  /* Insert-Code-Here {ex2.AdjListC._data} (private data members) */
  ex2_SetOps adjacent;
  ex2_Data vertex;
  //int ignore; /* dummy to force non-empty struct; remove if you add data */
  /* DO-NOT-DELETE splicer.end(ex2.AdjListC._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct ex2_AdjListC__data*
ex2_AdjListC__get_data(
  ex2_AdjListC);

extern void
ex2_AdjListC__set_data(
  ex2_AdjListC,
  struct ex2_AdjListC__data*);

extern
void
impl_ex2_AdjListC__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_AdjListC__ctor(
  /* in */ ex2_AdjListC self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_AdjListC__ctor2(
  /* in */ ex2_AdjListC self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_AdjListC__dtor(
  /* in */ ex2_AdjListC self,
  /* out */ sidl_BaseInterface *_ex);

/*
 * User-defined object methods
 */

#ifdef WITH_RMI
extern struct ex2_Data__object* impl_ex2_AdjListC_fconnect_ex2_Data(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_ex2_AdjListC_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct ex2_SetC__object* impl_ex2_AdjListC_fconnect_ex2_SetC(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ex2_ListOps__object* impl_ex2_AdjListC_fconnect_ex2_ListOps(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/
extern
void
impl_ex2_AdjListC_boccaForceUsePortInclude(
  /* in */ ex2_AdjListC self,
  /* in */ ex2_SetC dummy0,
  /* in */ ex2_ListOps dummy1,
  /* in */ ex2_Data dummy2,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_AdjListC_insert(
  /* in */ ex2_AdjListC self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_AdjListC_remove(
  /* in */ ex2_AdjListC self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_ex2_AdjListC_isMember(
  /* in */ ex2_AdjListC self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_AdjListC_clearSet(
  /* in */ ex2_AdjListC self,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_ex2_AdjListC_isEmpty(
  /* in */ ex2_AdjListC self,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_AdjListC_getSize(
  /* in */ ex2_AdjListC self,
  /* out */ sidl_BaseInterface *_ex);

extern
ex2_ListOps
impl_ex2_AdjListC_getList(
  /* in */ ex2_AdjListC self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_AdjListC_display(
  /* in */ ex2_AdjListC self,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_AdjListC_hashCode(
  /* in */ ex2_AdjListC self,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_AdjListC_compare(
  /* in */ ex2_AdjListC self,
  /* in */ ex2_Data data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_AdjListC_setData(
  /* in */ ex2_AdjListC self,
  /* in */ ex2_Data data,
  /* out */ sidl_BaseInterface *_ex);

extern
ex2_Data
impl_ex2_AdjListC_getVertex(
  /* in */ ex2_AdjListC self,
  /* out */ sidl_BaseInterface *_ex);

#ifdef WITH_RMI
extern struct ex2_Data__object* impl_ex2_AdjListC_fconnect_ex2_Data(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_ex2_AdjListC_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct ex2_SetC__object* impl_ex2_AdjListC_fconnect_ex2_SetC(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ex2_ListOps__object* impl_ex2_AdjListC_fconnect_ex2_ListOps(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/

/* DO-NOT-DELETE splicer.begin(_hmisc) */
/* Insert-Code-Here {_hmisc} (miscellaneous things) */
/* DO-NOT-DELETE splicer.end(_hmisc) */

#ifdef __cplusplus
}
#endif
#endif
