/*
 * File:          ex2_BreadthFirstSrchJ_IOR.h
 * Symbol:        ex2.BreadthFirstSrchJ-v0.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Intermediate Object Representation for ex2.BreadthFirstSrchJ
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 */

#ifndef included_ex2_BreadthFirstSrchJ_IOR_h
#define included_ex2_BreadthFirstSrchJ_IOR_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
struct sidl_rmi_InstanceHandle__object;
#ifndef included_ex2_GraphSrchPort_IOR_h
#include "ex2_GraphSrchPort_IOR.h"
#endif
#ifndef included_gov_cca_Component_IOR_h
#include "gov_cca_Component_IOR.h"
#endif
#ifndef included_gov_cca_ComponentRelease_IOR_h
#include "gov_cca_ComponentRelease_IOR.h"
#endif
#ifndef included_gov_cca_Port_IOR_h
#include "gov_cca_Port_IOR.h"
#endif
#ifndef included_sidl_BaseClass_IOR_h
#include "sidl_BaseClass_IOR.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Symbol "ex2.BreadthFirstSrchJ" (version 0.0)
 */

struct ex2_BreadthFirstSrchJ__array;
struct ex2_BreadthFirstSrchJ__object;

/*
 * Forward references for external classes and interfaces.
 */

struct ex2_AdjList__array;
struct ex2_AdjList__object;
struct ex2_Data__array;
struct ex2_Data__object;
struct ex2_GraphOps__array;
struct ex2_GraphOps__object;
struct ex2_ListC__array;
struct ex2_ListC__object;
struct ex2_ListNode__array;
struct ex2_ListNode__object;
struct ex2_ListNodeC__array;
struct ex2_ListNodeC__object;
struct ex2_ListOps__array;
struct ex2_ListOps__object;
struct gov_cca_CCAException__array;
struct gov_cca_CCAException__object;
struct gov_cca_Services__array;
struct gov_cca_Services__object;
struct sidl_BaseException__array;
struct sidl_BaseException__object;
struct sidl_BaseInterface__array;
struct sidl_BaseInterface__object;
struct sidl_ClassInfo__array;
struct sidl_ClassInfo__object;
struct sidl_RuntimeException__array;
struct sidl_RuntimeException__object;
struct sidl_rmi_Call__array;
struct sidl_rmi_Call__object;
struct sidl_rmi_Return__array;
struct sidl_rmi_Return__object;

/*
 * Declare the method entry point vector.
 */

struct ex2_BreadthFirstSrchJ__epv {
  /* Implicit builtin methods */
  /* 0 */
  void* (*f__cast)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* in */ const char* name,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 1 */
  void (*f__delete)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 2 */
  void (*f__exec)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* in */ const char* methodName,
    /* in */ struct sidl_rmi_Call__object* inArgs,
    /* in */ struct sidl_rmi_Return__object* outArgs,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 3 */
  char* (*f__getURL)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 4 */
  void (*f__raddRef)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 5 */
  sidl_bool (*f__isRemote)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 6 */
  void (*f__set_hooks)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* in */ sidl_bool enable,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 7 */
  void (*f__set_contracts)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* in */ sidl_bool enable,
    /* in */ const char* enfFilename,
    /* in */ sidl_bool resetCounters,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 8 */
  void (*f__dump_stats)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* in */ const char* filename,
    /* in */ const char* prefix,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 9 */
  void (*f__ctor)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 10 */
  void (*f__ctor2)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* in */ void* private_data,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 11 */
  void (*f__dtor)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 12 */
  void (*f__load)(
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* Methods introduced in sidl.BaseInterface-v0.9.17 */
  void (*f_addRef)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_deleteRef)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  sidl_bool (*f_isSame)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* in */ struct sidl_BaseInterface__object* iobj,
    /* out */ struct sidl_BaseInterface__object **_ex);
  sidl_bool (*f_isType)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* in */ const char* name,
    /* out */ struct sidl_BaseInterface__object **_ex);
  struct sidl_ClassInfo__object* (*f_getClassInfo)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* Methods introduced in sidl.BaseClass-v0.9.17 */
  /* Methods introduced in gov.cca.Port-v0.8.5 */
  /* Methods introduced in ex2.GraphSrchPort-v0.0 */
  int32_t (*f_search)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* in */ struct ex2_GraphOps__object* graph,
    /* in */ struct ex2_Data__object* startNode,
    /* out */ struct ex2_ListOps__object** ordered,
    /* out array<int> */ struct sidl_int__array** hops,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* Methods introduced in gov.cca.Component-v0.8.5 */
  void (*f_setServices)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* in */ struct gov_cca_Services__object* services,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* Methods introduced in gov.cca.ComponentRelease-v0.8.5 */
  void (*f_releaseServices)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* in */ struct gov_cca_Services__object* services,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* Methods introduced in ex2.BreadthFirstSrchJ-v0.0 */
  void (*f_boccaSetServices)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* in */ struct gov_cca_Services__object* services,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_boccaReleaseServices)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* in */ struct gov_cca_Services__object* services,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_boccaForceUsePortInclude)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* in */ struct ex2_AdjList__object* dummy0,
    /* in */ struct ex2_ListNode__object* dummy1,
    /* in */ struct ex2_ListNodeC__object* dummy2,
    /* in */ struct ex2_ListC__object* dummy3,
    /* in */ struct ex2_ListOps__object* dummy4,
    /* out */ struct sidl_BaseInterface__object **_ex);
};

/*
 * Declare the method pre hooks entry point vector.
 */

struct ex2_BreadthFirstSrchJ__pre_epv {
  void (*f_boccaSetServices_pre)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* in */ struct gov_cca_Services__object* services,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_boccaReleaseServices_pre)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* in */ struct gov_cca_Services__object* services,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_boccaForceUsePortInclude_pre)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* in */ struct ex2_AdjList__object* dummy0,
    /* in */ struct ex2_ListNode__object* dummy1,
    /* in */ struct ex2_ListNodeC__object* dummy2,
    /* in */ struct ex2_ListC__object* dummy3,
    /* in */ struct ex2_ListOps__object* dummy4,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_setServices_pre)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* in */ struct gov_cca_Services__object* services,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_releaseServices_pre)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* in */ struct gov_cca_Services__object* services,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_search_pre)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* in */ struct ex2_GraphOps__object* graph,
    /* in */ struct ex2_Data__object* startNode,
    /* out */ struct sidl_BaseInterface__object **_ex);
};

/*
 * Declare the method post hooks entry point vector.
 */

struct ex2_BreadthFirstSrchJ__post_epv {
  void (*f_boccaSetServices_post)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* in */ struct gov_cca_Services__object* services,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_boccaReleaseServices_post)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* in */ struct gov_cca_Services__object* services,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_boccaForceUsePortInclude_post)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* in */ struct ex2_AdjList__object* dummy0,
    /* in */ struct ex2_ListNode__object* dummy1,
    /* in */ struct ex2_ListNodeC__object* dummy2,
    /* in */ struct ex2_ListC__object* dummy3,
    /* in */ struct ex2_ListOps__object* dummy4,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_setServices_post)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* in */ struct gov_cca_Services__object* services,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_releaseServices_post)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* in */ struct gov_cca_Services__object* services,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_search_post)(
    /* in */ struct ex2_BreadthFirstSrchJ__object* self,
    /* in */ struct ex2_GraphOps__object* graph,
    /* in */ struct ex2_Data__object* startNode,
    /* in */ struct ex2_ListOps__object* ordered,
    /* in array<int> */ struct sidl_int__array* hops,
    /* in */ int32_t _retval,
    /* out */ struct sidl_BaseInterface__object **_ex);
};

/*
 * Define the controls and statistics structure.
 */


struct ex2_BreadthFirstSrchJ__cstats {
  sidl_bool use_hooks;
};

/*
 * Define the class object structure.
 */

struct ex2_BreadthFirstSrchJ__object {
  struct sidl_BaseClass__object           d_sidl_baseclass;
  struct ex2_GraphSrchPort__object        d_ex2_graphsrchport;
  struct gov_cca_Component__object        d_gov_cca_component;
  struct gov_cca_ComponentRelease__object d_gov_cca_componentrelease;
  struct gov_cca_Port__object             d_gov_cca_port;
  struct ex2_BreadthFirstSrchJ__epv*      d_epv;
  struct ex2_BreadthFirstSrchJ__cstats    d_cstats;
  void*                                   d_data;
};

struct ex2_BreadthFirstSrchJ__external {
  struct ex2_BreadthFirstSrchJ__object*
  (*createObject)(void* ddata, struct sidl_BaseInterface__object **_ex);

  struct sidl_BaseClass__epv*(*getSuperEPV)(void);
  int d_ior_major_version;
  int d_ior_minor_version;
};

/*
 * This function returns a pointer to a static structure of
 * pointers to function entry points.  Its purpose is to provide
 * one-stop shopping for loading DLLs.
 */

const struct ex2_BreadthFirstSrchJ__external*
ex2_BreadthFirstSrchJ__externals(void);

extern struct ex2_BreadthFirstSrchJ__object*
ex2_BreadthFirstSrchJ__createObject(void* ddata,struct 
  sidl_BaseInterface__object ** _ex);

extern void ex2_BreadthFirstSrchJ__init(
  struct ex2_BreadthFirstSrchJ__object* self, void* ddata, struct 
    sidl_BaseInterface__object ** _ex);

extern void ex2_BreadthFirstSrchJ__getEPVs(
  struct sidl_BaseInterface__epv **s_arg_epv__sidl_baseinterface,
  struct sidl_BaseClass__epv **s_arg_epv__sidl_baseclass,
  struct ex2_GraphSrchPort__epv **s_arg_epv__ex2_graphsrchport,
  struct ex2_GraphSrchPort__epv **s_arg_epv_hooks__ex2_graphsrchport,
  struct gov_cca_Component__epv **s_arg_epv__gov_cca_component,
  struct gov_cca_Component__epv **s_arg_epv_hooks__gov_cca_component,
  struct gov_cca_ComponentRelease__epv **s_arg_epv__gov_cca_componentrelease,
  struct gov_cca_ComponentRelease__epv 
    **s_arg_epv_hooks__gov_cca_componentrelease,
  struct gov_cca_Port__epv **s_arg_epv__gov_cca_port,
  struct gov_cca_Port__epv **s_arg_epv_hooks__gov_cca_port,
  struct ex2_BreadthFirstSrchJ__epv **s_arg_epv__ex2_breadthfirstsrchj,
  struct ex2_BreadthFirstSrchJ__epv **s_arg_epv_hooks__ex2_breadthfirstsrchj);

extern void ex2_BreadthFirstSrchJ__fini(
  struct ex2_BreadthFirstSrchJ__object* self, struct sidl_BaseInterface__object 
    ** _ex);

extern void ex2_BreadthFirstSrchJ__IOR_version(int32_t *major, int32_t *minor);

struct ex2_GraphOps__object* skel_ex2_BreadthFirstSrchJ_fconnect_ex2_GraphOps(
  const char* url, sidl_bool ar, struct sidl_BaseInterface__object * *_ex);
struct ex2_ListNodeC__object* skel_ex2_BreadthFirstSrchJ_fconnect_ex2_ListNodeC(
  const char* url, sidl_bool ar, struct sidl_BaseInterface__object * *_ex);
struct gov_cca_Services__object* 
  skel_ex2_BreadthFirstSrchJ_fconnect_gov_cca_Services(const char* url, 
  sidl_bool ar, struct sidl_BaseInterface__object * *_ex);
struct ex2_Data__object* skel_ex2_BreadthFirstSrchJ_fconnect_ex2_Data(const 
  char* url, sidl_bool ar, struct sidl_BaseInterface__object * *_ex);
struct sidl_BaseInterface__object* 
  skel_ex2_BreadthFirstSrchJ_fconnect_sidl_BaseInterface(const char* url, 
  sidl_bool ar, struct sidl_BaseInterface__object * *_ex);
struct ex2_ListC__object* skel_ex2_BreadthFirstSrchJ_fconnect_ex2_ListC(const 
  char* url, sidl_bool ar, struct sidl_BaseInterface__object * *_ex);
struct ex2_ListOps__object* skel_ex2_BreadthFirstSrchJ_fconnect_ex2_ListOps(
  const char* url, sidl_bool ar, struct sidl_BaseInterface__object * *_ex);
struct ex2_ListNode__object* skel_ex2_BreadthFirstSrchJ_fconnect_ex2_ListNode(
  const char* url, sidl_bool ar, struct sidl_BaseInterface__object * *_ex);
struct ex2_AdjList__object* skel_ex2_BreadthFirstSrchJ_fconnect_ex2_AdjList(
  const char* url, sidl_bool ar, struct sidl_BaseInterface__object * *_ex);
struct ex2_BreadthFirstSrchJ__remote{
  int d_refcount;
  struct sidl_rmi_InstanceHandle__object *d_ih;
};

#ifdef __cplusplus
}
#endif
#endif
