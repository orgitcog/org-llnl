/*
 * File:          BreadthFirstSrchJ_Impl.java
 * Symbol:        ex2.BreadthFirstSrchJ-v0.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for ex2.BreadthFirstSrchJ
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

package ex2;

import ex2.AdjList;
import ex2.Data;
import ex2.GraphOps;
import ex2.GraphSrchPort;
import ex2.ListC;
import ex2.ListNode;
import ex2.ListNodeC;
import ex2.ListOps;
import gov.cca.CCAException;
import gov.cca.Component;
import gov.cca.ComponentRelease;
import gov.cca.Port;
import gov.cca.Services;
import sidl.BaseClass;
import sidl.BaseInterface;
import sidl.ClassInfo;
import sidl.RuntimeException;

// DO-NOT-DELETE splicer.begin(ex2.BreadthFirstSrchJ._imports)
// Insert-Code-Here {ex2.BreadthFirstSrchJ._imports} (additional imports)
// DO-NOT-DELETE splicer.end(ex2.BreadthFirstSrchJ._imports)

/**
 * Symbol "ex2.BreadthFirstSrchJ" (version 0.0)
 */
public class BreadthFirstSrchJ_Impl extends BreadthFirstSrchJ
{

  // DO-NOT-DELETE splicer.begin(ex2.BreadthFirstSrchJ._data)

    // Bocca generated code. bocca.protected.begin(ex2.BreadthFirstSrchJ._data)
    gov.cca.Services    d_services;
    public boolean bocca_print_errs = true;
    // Bocca generated code. bocca.protected.end(ex2.BreadthFirstSrchJ._data)
  // DO-NOT-DELETE splicer.end(ex2.BreadthFirstSrchJ._data)


  static { 
  // DO-NOT-DELETE splicer.begin(ex2.BreadthFirstSrchJ._load)
  // Insert-Code-Here {ex2.BreadthFirstSrchJ._load} (class initialization)
  // DO-NOT-DELETE splicer.end(ex2.BreadthFirstSrchJ._load)

  }

  /**
   * User defined constructor
   */
  public BreadthFirstSrchJ_Impl(long IORpointer){
    super(IORpointer);
    // DO-NOT-DELETE splicer.begin(ex2.BreadthFirstSrchJ.BreadthFirstSrchJ)
    // Insert-Code-Here {ex2.BreadthFirstSrchJ.BreadthFirstSrchJ} (constructor)
    // DO-NOT-DELETE splicer.end(ex2.BreadthFirstSrchJ.BreadthFirstSrchJ)

  }

  /**
   * Back door constructor
   */
  public BreadthFirstSrchJ_Impl(){
    d_ior = _wrap(this);
    // DO-NOT-DELETE splicer.begin(ex2.BreadthFirstSrchJ._wrap)
    // Insert-Code-Here {ex2.BreadthFirstSrchJ._wrap} (_wrap)
    // DO-NOT-DELETE splicer.end(ex2.BreadthFirstSrchJ._wrap)

  }

  /**
   * User defined destructing method
   */
  public void dtor() throws Throwable{
    // DO-NOT-DELETE splicer.begin(ex2.BreadthFirstSrchJ._dtor)
    // Insert-Code-Here {ex2.BreadthFirstSrchJ._dtor} (destructor)
    // DO-NOT-DELETE splicer.end(ex2.BreadthFirstSrchJ._dtor)

  }

  /**
   * finalize method (Only use this if you're sure you need it!)
   */
  public void finalize() throws Throwable{
    // DO-NOT-DELETE splicer.begin(ex2.BreadthFirstSrchJ.finalize)
    // Insert-Code-Here {ex2.BreadthFirstSrchJ.finalize} (finalize)
    // DO-NOT-DELETE splicer.end(ex2.BreadthFirstSrchJ.finalize)

  }

  // user defined static methods: (none)

  // user defined non-static methods:
  /**
   * Method:  boccaSetServices[]
   */
  public void boccaSetServices_Impl (
    /*in*/ gov.cca.Services services ) 
    throws gov.cca.CCAException.Wrapper, 
    sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(ex2.BreadthFirstSrchJ.boccaSetServices)
// DO-NOT-EDIT-BOCCA
// Bocca generated code. bocca.protected.begin(ex2.BreadthFirstSrchJ.boccaSetServices)

   gov.cca.TypeMap typeMap;
   gov.cca.Port    port;

   this.d_services = services;

   typeMap = this.d_services.createTypeMap();

   port = (gov.cca.Port)(this);


  // Provide a ex2.GraphSrchPort port with port name GraphSrchPort 
   try{
      this.d_services.addProvidesPort(port, // the implementing object
                                      "GraphSrchPort", // the name the user sees
                                      "ex2.GraphSrchPort", // the sidl name of the port type
                                      typeMap); // extra properties
   } catch ( gov.cca.CCAException.Wrapper ex )  {
      String msg = "Error calling addProvidesPort(port,\"GraphSrchPort\", "
          + "\"ex2.GraphSrchPort\", typeMap) ";
      ex.add(msg);
      throw ex;
   }    


   gov.cca.ComponentRelease cr = (gov.cca.ComponentRelease)this; // CAST
   this.d_services.registerForRelease(cr);
   return;
// Bocca generated code. bocca.protected.end(ex2.BreadthFirstSrchJ.boccaSetServices)
    // DO-NOT-DELETE splicer.end(ex2.BreadthFirstSrchJ.boccaSetServices)

  }

  /**
   * Method:  boccaReleaseServices[]
   */
  public void boccaReleaseServices_Impl (
    /*in*/ gov.cca.Services services ) 
    throws gov.cca.CCAException.Wrapper, 
    sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(ex2.BreadthFirstSrchJ.boccaReleaseServices)
  // Bocca generated code. bocca.protected.begin(ex2.BreadthFirstSrchJ.boccaReleaseServices)

   this.d_services=null;

  // Un-provide ex2.GraphSrchPort port with port name GraphSrchPort 
  try{
    services.removeProvidesPort("GraphSrchPort");
  } catch ( gov.cca.CCAException.Wrapper ex )  {
    if (bocca_print_errs) {
      System.err.print("ex2.BreadthFirstSrchJ: Error calling removeProvidesPort" 
          + "(\"GraphSrchPort\"): " + ex.getNote());
    }
  }

   return;
  // Bocca generated code. bocca.protected.end(ex2.BreadthFirstSrchJ.boccaReleaseServices)
    
    // DO-NOT-DELETE splicer.end(ex2.BreadthFirstSrchJ.boccaReleaseServices)

  }

  /**
   *  This function should never be called, but helps babel generate better code. 
   */
  public void boccaForceUsePortInclude_Impl (
    /*in*/ ex2.AdjList dummy0,
    /*in*/ ex2.ListNode dummy1,
    /*in*/ ex2.ListNodeC dummy2,
    /*in*/ ex2.ListC dummy3,
    /*in*/ ex2.ListOps dummy4 ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(ex2.BreadthFirstSrchJ.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(ex2.BreadthFirstSrchJ.boccaForceUsePortInclude)
    Object o;
    o = dummy0;
    o = dummy1;
    o = dummy2;
    o = dummy3;
    o = dummy4;

  // Bocca generated code. bocca.protected.end(ex2.BreadthFirstSrchJ.boccaForceUsePortInclude)
    // DO-NOT-DELETE splicer.end(ex2.BreadthFirstSrchJ.boccaForceUsePortInclude)

  }

  /**
   *  Starts up a component presence in the calling framework.
   * @param services the component instance's handle on the framework world.
   * Contracts concerning services and setServices:
   * 
   * The component interaction with the CCA framework
   * and Ports begins on the call to setServices by the framework.
   * 
   * This function is called exactly once for each instance created
   * by the framework.
   * 
   * The argument services will never be nil/null.
   * 
   * Those uses ports which are automatically connected by the framework
   * (so-called service-ports) may be obtained via getPort during
   * setServices.
   */
  public void setServices_Impl (
    /*in*/ gov.cca.Services services ) 
    throws gov.cca.CCAException.Wrapper, 
    sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(ex2.BreadthFirstSrchJ.setServices)

  // Insert-Code-Here {ex2.BreadthFirstSrchJ.setServices} (setServices method prolog)

  // bocca-default-code. User may edit or delete.begin(ex2.BreadthFirstSrchJ.setServices)
     boccaSetServices(services); 
  // bocca-default-code. User may edit or delete.end(ex2.BreadthFirstSrchJ.setServices)

  // Insert-Code-Here {ex2.BreadthFirstSrchJ.setServices} (setServices method epilog)

    // DO-NOT-DELETE splicer.end(ex2.BreadthFirstSrchJ.setServices)

  }

  /**
   * Shuts down a component presence in the calling framework.
   * @param services the component instance's handle on the framework world.
   * Contracts concerning services and setServices:
   * 
   * This function is called exactly once for each callback registered
   * through Services.
   * 
   * The argument services will never be nil/null.
   * The argument services will always be the same as that received in
   * setServices.
   * 
   * During this call the component should release any interfaces
   * acquired by getPort().
   * 
   * During this call the component should reset to nil any stored
   * reference to services.
   * 
   * After this call, the component instance will be removed from the
   * framework. If the component instance was created by the
   * framework, it will be destroyed, not recycled, The behavior of
   * any port references obtained from this component instance and
   * stored elsewhere becomes undefined.
   * 
   * Notes for the component implementor:
   * 1) The component writer may perform blocking activities
   * within releaseServices, such as waiting for remote computations
   * to shutdown.
   * 2) It is good practice during releaseServices for the component
   * writer to remove or unregister all the ports it defined.
   */
  public void releaseServices_Impl (
    /*in*/ gov.cca.Services services ) 
    throws gov.cca.CCAException.Wrapper, 
    sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(ex2.BreadthFirstSrchJ.releaseServices)

  // Insert-Code-Here {ex2.BreadthFirstSrchJ.releaseServices} (releaseServices method prolog)

  // bocca-default-code. User may edit or delete.end(ex2.BreadthFirstSrchJ.releaseServices)
     boccaReleaseServices(services); 
  // bocca-default-code. User may edit or delete.end(ex2.BreadthFirstSrchJ.releaseServices)

  // Insert-Code-Here {ex2.BreadthFirstSrchJ.releaseServices} (releaseServices method epilog)

    // DO-NOT-DELETE splicer.end(ex2.BreadthFirstSrchJ.releaseServices)

  }

  /**
   * Method:  search[]
   */
  public int search_Impl (
    /*in*/ ex2.GraphOps graph,
    /*in*/ ex2.Data startNode,
    /*out*/ ex2.ListOps.Holder ordered,
    /*out*/ sidl.Integer.Array1.Holder hops ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(ex2.BreadthFirstSrchJ.search)
    // Insert-Code-Here {ex2.BreadthFirstSrchJ.search} (search)
     java.util.Queue <ex2.AdjList> queue = new java.util.LinkedList <ex2.AdjList> ();
        
        java.util.HashMap <Integer, Integer> vertMap = new java.util.HashMap <Integer, Integer> ();	

        //now initialize hops and ordered with the result
        ex2.ListOps resultL = ordered.get();	
        if (resultL == null)  {
	    resultL = new ex2.ListC();
      	}
        
	
        sidl.Integer.Array1 resHops = hops.get();
        int arrSize = graph.getVertCount();
        if (resHops == null) resHops = new sidl.Integer.Array1(0,arrSize, false);
	int arrIndex = 0;
        //initialize BfsLists to adjacency lists and all of the vertices of the graph.
         ex2.ListNode elem;
	 ex2.ListOps graphAdjacencyLists;
	 graphAdjacencyLists =graph.getAdjLists();
	 elem = graphAdjacencyLists.getHead();	
	 try{
	 for (; elem!=null; elem = elem.getNext()){
	    ex2.AdjList adjListElem = (ex2.AdjList)(elem.getData())._cast2("ex2.AdjList");
            ex2.Data vert = adjListElem.getVertex();
	    Integer hopCnt;
	    
            if (vert.compare(startNode) == 0){ //meaning if this is the start vertex
		
		hopCnt=Integer.valueOf(0);
		//add the startNode and its hopcount of 0 to the result data structures
		resultL.insertNext(null, vert);
		resHops.set(arrIndex++, hopCnt);
		
	    }
	    else { //these are all the rest of vertices
		hopCnt = Integer.valueOf(-1);
		
	    }	    
	    vertMap.put(Integer.valueOf(vert.hashCode()), hopCnt);	    
	    
	 }
	 }catch (java.lang.Exception e){
	     e.printStackTrace();
	 }
	 
	
	//initialize the queue with the adjacency list of the first vertex
	ex2.AdjList adjl = graph.getAdjList(startNode);
      
	queue.offer(graph.getAdjList(startNode));
		
	//perform breadth-first search
	ex2.AdjList adjlist;
	while ((adjlist = queue.peek()) != null){
	    ex2.Data vert = adjlist.getVertex();	    
	    Integer hCnt = vertMap.get(Integer.valueOf(vert.hashCode()));	    
	    
	    //traverse each vertex in the current adjacency list
	    ex2.ListNode vertNode = adjlist.getList().getHead();
	    for (; vertNode!= null; vertNode = vertNode.getNext()){                
		ex2.Data adjVert = vertNode.getData();		
		Integer hCntAdj = vertMap.get(Integer.valueOf(adjVert.hashCode()));		
		if (hCntAdj == -1){
		    hCntAdj = hCnt + 1;		 
		    //initialize the result data structures
		    ex2.ListNode tail = resultL.getTail();
		    resultL.insertNext(tail, adjVert);
		    resHops.set(arrIndex++, hCntAdj);
		    vertMap.put(Integer.valueOf(adjVert.hashCode()), hCntAdj);
		    //insert the adjacency list of a vertex to the processing queue
		    queue.offer(graph.getAdjList(adjVert));
		}
	    }
	    queue.remove(adjlist);
	    
	    
	    
	}
	
        hops.set(resHops);
        ordered.set(resultL);
	return 0;
    // DO-NOT-DELETE splicer.end(ex2.BreadthFirstSrchJ.search)

  }


  // DO-NOT-DELETE splicer.begin(ex2.BreadthFirstSrchJ._misc)
  // Insert-Code-Here {ex2.BreadthFirstSrchJ._misc} (miscellaneous)
    
  // DO-NOT-DELETE splicer.end(ex2.BreadthFirstSrchJ._misc)

} // end class BreadthFirstSrchJ

