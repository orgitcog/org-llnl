/*
 * File:          ex2_SetC_Skel.c
 * Symbol:        ex2.SetC-v0.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side glue code for ex2.SetC
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 */

#include "ex2_SetC_IOR.h"
#include "ex2_SetC.h"
#include <stddef.h>

#ifdef WITH_RMI
#ifndef included_ex2_ListNodeC_h
#include "ex2_ListNodeC.h"
#endif
#ifndef included_ex2_Data_h
#include "ex2_Data.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_ex2_ListC_h
#include "ex2_ListC.h"
#endif
#ifndef included_ex2_ListNode_h
#include "ex2_ListNode.h"
#endif
#endif /* WITH_RMI */
extern
void
impl_ex2_SetC__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_SetC__ctor(
  /* in */ ex2_SetC self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_SetC__ctor2(
  /* in */ ex2_SetC self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_SetC__dtor(
  /* in */ ex2_SetC self,
  /* out */ sidl_BaseInterface *_ex);

#ifdef WITH_RMI
extern struct ex2_ListNodeC__object* impl_ex2_SetC_fconnect_ex2_ListNodeC(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ex2_Data__object* impl_ex2_SetC_fconnect_ex2_Data(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_ex2_SetC_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct ex2_ListC__object* impl_ex2_SetC_fconnect_ex2_ListC(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ex2_ListNode__object* impl_ex2_SetC_fconnect_ex2_ListNode(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/
extern
void
impl_ex2_SetC_boccaForceUsePortInclude(
  /* in */ ex2_SetC self,
  /* in */ ex2_ListNode dummy0,
  /* in */ ex2_ListC dummy1,
  /* in */ ex2_ListNodeC dummy2,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_SetC_insert(
  /* in */ ex2_SetC self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_SetC_remove(
  /* in */ ex2_SetC self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_ex2_SetC_isMember(
  /* in */ ex2_SetC self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_SetC_clearSet(
  /* in */ ex2_SetC self,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_ex2_SetC_isEmpty(
  /* in */ ex2_SetC self,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_SetC_getSize(
  /* in */ ex2_SetC self,
  /* out */ sidl_BaseInterface *_ex);

extern
ex2_ListOps
impl_ex2_SetC_getList(
  /* in */ ex2_SetC self,
  /* out */ sidl_BaseInterface *_ex);

#ifdef WITH_RMI
extern struct ex2_ListNodeC__object* impl_ex2_SetC_fconnect_ex2_ListNodeC(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ex2_Data__object* impl_ex2_SetC_fconnect_ex2_Data(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_ex2_SetC_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct ex2_ListC__object* impl_ex2_SetC_fconnect_ex2_ListC(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ex2_ListNode__object* impl_ex2_SetC_fconnect_ex2_ListNode(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/
#ifdef __cplusplus
extern "C" {
#endif

void
ex2_SetC__set_epv(struct ex2_SetC__epv *epv,
  struct ex2_SetC__pre_epv *pre_epv, 
  struct ex2_SetC__post_epv *post_epv
)
{
  epv->f__ctor = impl_ex2_SetC__ctor;
  epv->f__ctor2 = impl_ex2_SetC__ctor2;
  epv->f__dtor = impl_ex2_SetC__dtor;
  pre_epv->f_boccaForceUsePortInclude_pre = NULL;
  epv->f_boccaForceUsePortInclude = impl_ex2_SetC_boccaForceUsePortInclude;
  post_epv->f_boccaForceUsePortInclude_post = NULL;
  pre_epv->f_insert_pre = NULL;
  epv->f_insert = impl_ex2_SetC_insert;
  post_epv->f_insert_post = NULL;
  pre_epv->f_remove_pre = NULL;
  epv->f_remove = impl_ex2_SetC_remove;
  post_epv->f_remove_post = NULL;
  pre_epv->f_isMember_pre = NULL;
  epv->f_isMember = impl_ex2_SetC_isMember;
  post_epv->f_isMember_post = NULL;
  pre_epv->f_clearSet_pre = NULL;
  epv->f_clearSet = impl_ex2_SetC_clearSet;
  post_epv->f_clearSet_post = NULL;
  pre_epv->f_isEmpty_pre = NULL;
  epv->f_isEmpty = impl_ex2_SetC_isEmpty;
  post_epv->f_isEmpty_post = NULL;
  pre_epv->f_getSize_pre = NULL;
  epv->f_getSize = impl_ex2_SetC_getSize;
  post_epv->f_getSize_post = NULL;
  pre_epv->f_getList_pre = NULL;
  epv->f_getList = impl_ex2_SetC_getList;
  post_epv->f_getList_post = NULL;

}
#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
extern "C" {
#endif

void ex2_SetC__call_load(void) { 
  sidl_BaseInterface _throwaway_exception = NULL;
  impl_ex2_SetC__load(&_throwaway_exception);
}
#ifdef WITH_RMI
struct ex2_ListNodeC__object* skel_ex2_SetC_fconnect_ex2_ListNodeC(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex) { 
  return ex2_ListNodeC__connectI(url, ar, _ex);
}

struct ex2_Data__object* skel_ex2_SetC_fconnect_ex2_Data(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) { 
  return ex2_Data__connectI(url, ar, _ex);
}

struct sidl_BaseInterface__object* skel_ex2_SetC_fconnect_sidl_BaseInterface(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex) { 
  return sidl_BaseInterface__connectI(url, ar, _ex);
}

struct ex2_ListC__object* skel_ex2_SetC_fconnect_ex2_ListC(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) { 
  return ex2_ListC__connectI(url, ar, _ex);
}

struct ex2_ListNode__object* skel_ex2_SetC_fconnect_ex2_ListNode(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex) { 
  return ex2_ListNode__connectI(url, ar, _ex);
}

#endif /*WITH_RMI*/
struct ex2_SetC__data*
ex2_SetC__get_data(ex2_SetC self)
{
  return (struct ex2_SetC__data*)(self ? self->d_data : NULL);
}

void ex2_SetC__set_data(
  ex2_SetC self,
  struct ex2_SetC__data* data)
{
  if (self) {
    self->d_data = data;
  }
}
#ifdef __cplusplus
}
#endif
