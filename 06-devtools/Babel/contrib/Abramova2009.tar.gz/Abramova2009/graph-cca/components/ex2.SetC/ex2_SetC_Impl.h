/*
 * File:          ex2_SetC_Impl.h
 * Symbol:        ex2.SetC-v0.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for ex2.SetC
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#ifndef included_ex2_SetC_Impl_h
#define included_ex2_SetC_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_ex2_Data_h
#include "ex2_Data.h"
#endif
#ifndef included_ex2_ListC_h
#include "ex2_ListC.h"
#endif
#ifndef included_ex2_ListNode_h
#include "ex2_ListNode.h"
#endif
#ifndef included_ex2_ListNodeC_h
#include "ex2_ListNodeC.h"
#endif
#ifndef included_ex2_ListOps_h
#include "ex2_ListOps.h"
#endif
#ifndef included_ex2_SetC_h
#include "ex2_SetC.h"
#endif
#ifndef included_ex2_SetOps_h
#include "ex2_SetOps.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_PostViolation_h
#include "sidl_PostViolation.h"
#endif
#ifndef included_sidl_PreViolation_h
#include "sidl_PreViolation.h"
#endif
#ifndef included_sidl_RuntimeException_h
#include "sidl_RuntimeException.h"
#endif
/* DO-NOT-DELETE splicer.begin(ex2.SetC._hincludes) */
/* Insert-Code-Here {ex2.SetC._hincludes} (include files) */
/* DO-NOT-DELETE splicer.end(ex2.SetC._hincludes) */

/*
 * Private data for class ex2.SetC
 */

struct ex2_SetC__data {
  /* DO-NOT-DELETE splicer.begin(ex2.SetC._data) */
  /* Insert-Code-Here {ex2.SetC._data} (private data members) */
  ex2_ListOps list;
  //int ignore; /* dummy to force non-empty struct; remove if you add data */
  /* DO-NOT-DELETE splicer.end(ex2.SetC._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct ex2_SetC__data*
ex2_SetC__get_data(
  ex2_SetC);

extern void
ex2_SetC__set_data(
  ex2_SetC,
  struct ex2_SetC__data*);

extern
void
impl_ex2_SetC__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_SetC__ctor(
  /* in */ ex2_SetC self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_SetC__ctor2(
  /* in */ ex2_SetC self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_SetC__dtor(
  /* in */ ex2_SetC self,
  /* out */ sidl_BaseInterface *_ex);

/*
 * User-defined object methods
 */

#ifdef WITH_RMI
extern struct ex2_ListNodeC__object* impl_ex2_SetC_fconnect_ex2_ListNodeC(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ex2_Data__object* impl_ex2_SetC_fconnect_ex2_Data(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_ex2_SetC_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct ex2_ListC__object* impl_ex2_SetC_fconnect_ex2_ListC(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ex2_ListNode__object* impl_ex2_SetC_fconnect_ex2_ListNode(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/
extern
void
impl_ex2_SetC_boccaForceUsePortInclude(
  /* in */ ex2_SetC self,
  /* in */ ex2_ListNode dummy0,
  /* in */ ex2_ListC dummy1,
  /* in */ ex2_ListNodeC dummy2,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_SetC_insert(
  /* in */ ex2_SetC self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_SetC_remove(
  /* in */ ex2_SetC self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_ex2_SetC_isMember(
  /* in */ ex2_SetC self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_SetC_clearSet(
  /* in */ ex2_SetC self,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_ex2_SetC_isEmpty(
  /* in */ ex2_SetC self,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_SetC_getSize(
  /* in */ ex2_SetC self,
  /* out */ sidl_BaseInterface *_ex);

extern
ex2_ListOps
impl_ex2_SetC_getList(
  /* in */ ex2_SetC self,
  /* out */ sidl_BaseInterface *_ex);

#ifdef WITH_RMI
extern struct ex2_ListNodeC__object* impl_ex2_SetC_fconnect_ex2_ListNodeC(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ex2_Data__object* impl_ex2_SetC_fconnect_ex2_Data(const char* url,
  sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_ex2_SetC_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct ex2_ListC__object* impl_ex2_SetC_fconnect_ex2_ListC(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ex2_ListNode__object* impl_ex2_SetC_fconnect_ex2_ListNode(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/

/* DO-NOT-DELETE splicer.begin(_hmisc) */
/* Insert-Code-Here {_hmisc} (miscellaneous things) */
/* DO-NOT-DELETE splicer.end(_hmisc) */

#ifdef __cplusplus
}
#endif
#endif
