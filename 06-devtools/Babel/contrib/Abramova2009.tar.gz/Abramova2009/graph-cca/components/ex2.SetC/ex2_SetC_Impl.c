/*
 * File:          ex2_SetC_Impl.c
 * Symbol:        ex2.SetC-v0.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for ex2.SetC
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "ex2.SetC" (version 0.0)
 */

#include "ex2_SetC_Impl.h"
#include "sidl_NotImplementedException.h"
#include "sidl_Exception.h"
#ifndef included_sidl_MemAllocException_h
#include "sidl_MemAllocException.h"
#endif

/* DO-NOT-DELETE splicer.begin(ex2.SetC._includes) */

/* Insert-UserCode-Here {ex2.SetC._includes} (includes and arbitrary code) */

/* Bocca generated code. bocca.protected.begin(ex2.SetC._includes) */
#include <stdlib.h>
#include <string.h>
#include "sidl_SIDLException.h"

#define _BOCCA_CTOR_MESSAGES 0

#ifdef _BOCCA_STDERR

#define BOCCA_FPRINTF fprintf
#include <stdio.h>
#include "sidl_String.h"
#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif /* _BOCCA_CTOR_PRINT */

#else /* _BOCCA_STDERR */
#define BOCCA_FPRINTF boccaPrintNothing
#endif /* _BOCCA_STDERR */

static int
boccaPrintNothing(void *v, const char * s, ...)
{
  (void)v; (void)s;
  return 0;
}
/* Bocca generated code. bocca.protected.end(ex2.SetC._includes) */

/* Insert-UserCode-Here {ex2.SetC._includes} (includes and arbitrary code) */

/* DO-NOT-DELETE splicer.end(ex2.SetC._includes) */

#define SIDL_IOR_MAJOR_VERSION 2
#define SIDL_IOR_MINOR_VERSION 0
/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_SetC__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_SetC__load(
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.SetC._load) */
    /* Insert-Code-Here {ex2.SetC._load} (static class initializer method) */
    /*
     * This method has not been implemented
     */

    /* DO-DELETE-WHEN-IMPLEMENTING exception.begin(ex2.SetC._load) */
    SIDL_THROW(*_ex, sidl_NotImplementedException,     "This method has not been implemented");
  EXIT:;
    /* DO-DELETE-WHEN-IMPLEMENTING exception.end(ex2.SetC._load) */
    /* DO-NOT-DELETE splicer.end(ex2.SetC._load) */
  }
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_SetC__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_SetC__ctor(
  /* in */ ex2_SetC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.SetC._ctor) */

  /* Insert-UserDecl-Here {ex2.SetC._ctor} (constructor method) */
    
  /* bocca-default-code. User may edit or delete.begin(ex2.SetC._ctor) */
   struct ex2_SetC__data *dptr = 
       (struct ex2_SetC__data*)malloc(sizeof(struct ex2_SetC__data));
   if (dptr) {
      memset(dptr, 0, sizeof(struct ex2_SetC__data));
   }
   ex2_SetC__set_data(self, dptr);
   #if _BOCCA_CTOR_MESSAGES
     BOCCA_FPRINTF(stderr, 
        "CTOR ex2.SetC: %s constructed data %p in self %p\n", 
        __FUNC__, dptr, self);
   #endif /* _BOCCA_CTOR_MESSAGES */
  /* bocca-default-code. User may edit or delete.end(ex2.SetC._ctor) */

  /* initialize user elements of dptr here */
     ex2_ListC list = ex2_ListC__create(_ex);
     dptr->list = ex2_ListOps__cast(list, _ex);
     ex2_ListC_deleteRef(list, _ex);
  /* Insert-UserCode-Here {ex2.SetC._ctor} (constructor method) */

    /* DO-NOT-DELETE splicer.end(ex2.SetC._ctor) */
  }
}

/*
 * Special Class constructor called when the user wants to wrap his own private data.
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_SetC__ctor2"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_SetC__ctor2(
  /* in */ ex2_SetC self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.SetC._ctor2) */
    /* Insert-Code-Here {ex2.SetC._ctor2} (special constructor method) */
    /*
     * This method has not been implemented
     */

    /* DO-DELETE-WHEN-IMPLEMENTING exception.begin(ex2.SetC._ctor2) */
    SIDL_THROW(*_ex, sidl_NotImplementedException,     "This method has not been implemented");
  EXIT:;
    /* DO-DELETE-WHEN-IMPLEMENTING exception.end(ex2.SetC._ctor2) */
    /* DO-NOT-DELETE splicer.end(ex2.SetC._ctor2) */
  }
}
/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_SetC__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_SetC__dtor(
  /* in */ ex2_SetC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.SetC._dtor) */

  /* deinitialize user elements of dptr here */
  /* Insert-UserCode-Here {ex2.SetC._dtor} (destructor method) */
    
  /* bocca-default-code. User may edit or delete.begin(ex2.SetC._dtor) */
   struct ex2_SetC__data *dptr = 
                ex2_SetC__get_data(self);
   if (dptr) {
     ex2_ListOps_deleteRef(dptr->list, _ex);
      free(dptr);
      ex2_SetC__set_data(self, NULL);
   }
   #if _BOCCA_CTOR_MESSAGES
     BOCCA_FPRINTF(stderr, "DTOR ex2.SetC: %s freed data %p in self %p\n", 
                   __FUNC__, dptr, self);
   #endif /* _BOCCA_CTOR_MESSAGES */
  /* bocca-default-code. User may edit or delete.end(ex2.SetC._dtor) */

    /* DO-NOT-DELETE splicer.end(ex2.SetC._dtor) */
  }
}

/*
 *  This function should never be called, but helps babel generate better code. 
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_SetC_boccaForceUsePortInclude"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_SetC_boccaForceUsePortInclude(
  /* in */ ex2_SetC self,
  /* in */ ex2_ListNode dummy0,
  /* in */ ex2_ListC dummy1,
  /* in */ ex2_ListNodeC dummy2,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.SetC.boccaForceUsePortInclude) */
/* DO-NOT-EDIT-BOCCA */
  /* Bocca generated code. bocca.protected.begin(ex2.SetC.boccaForceUsePortInclude) */
    (void)self;
    (void)dummy0;
    (void)dummy1;
    (void)dummy2;

  /* Bocca generated code. bocca.protected.end(ex2.SetC.boccaForceUsePortInclude) */
    /* DO-NOT-DELETE splicer.end(ex2.SetC.boccaForceUsePortInclude) */
  }
}

/*
 *  
 * inserts Data element in the set. 
 * returns 0 if the insertion is successful,
 * 1 if the member  is already in the set. -1 otherwise
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_SetC_insert"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_ex2_SetC_insert(
  /* in */ ex2_SetC self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.SetC.insert) */
    struct ex2_SetC__data * dptr = ex2_SetC__get_data(self);
    if (ex2_SetC_isMember(self,d, _ex)) {
      //check to see if it's member of the set
      SIDL_REPORT(*_ex);
      //no insertion, return 1
      return 1;
    }
    ex2_ListNode tail = ex2_ListOps_getTail(dptr->list, _ex); SIDL_REPORT(*_ex);
    ex2_ListOps_insertNext(dptr->list, tail, d, _ex); SIDL_REPORT(*_ex);
    if (tail) ex2_ListNode_deleteRef(tail, _ex); SIDL_REPORT(*_ex);
    //successful insertion
    return 0;
  EXIT: return -1; //insertion failed
    /* DO-NOT-DELETE splicer.end(ex2.SetC.insert) */
  }
}

/*
 * removes Data element from the set. 
 * returns 0 if the removal is successful, -1 otherwise
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_SetC_remove"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_ex2_SetC_remove(
  /* in */ ex2_SetC self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.SetC.remove) */
    struct ex2_SetC__data * dptr = ex2_SetC__get_data(self);
    ex2_ListNode elem, next, prev = NULL;
    ex2_Data elem_data;
    elem = ex2_ListOps_getHead(dptr->list,_ex);SIDL_REPORT(*_ex);
    while (elem){
      elem_data = ex2_ListNode_getData(elem, _ex); SIDL_REPORT(*_ex);
      if (!ex2_Data_compare(elem_data, d, _ex)){
        break;
      }
      ex2_Data_deleteRef(elem_data, _ex); SIDL_REPORT(*_ex);
      next = ex2_ListNode_getNext(elem, _ex); SIDL_REPORT(*_ex);
      if (prev) ex2_ListNode_deleteRef(prev, _ex); SIDL_REPORT(*_ex);
      prev = elem;
     
      elem = next;
    }
    if (! elem){ //element not found
      if (prev) ex2_ListNode_deleteRef(prev, _ex); SIDL_REPORT(*_ex);
      return -1; 
    }
    ex2_Data_deleteRef(elem_data, _ex); SIDL_REPORT(*_ex);
    ex2_ListOps_removeNext(dptr->list, prev, &elem_data, _ex); SIDL_REPORT(*_ex);
    ex2_Data_deleteRef(elem_data, _ex); SIDL_REPORT(*_ex); 
    ex2_ListNode_deleteRef(elem, _ex); SIDL_REPORT(*_ex);

    if (prev) ex2_ListNode_deleteRef(prev, _ex); SIDL_REPORT(*_ex);
    // if (prev) graph_Node_deleteRef(prev, _ex); SIDL_REPORT(*_ex);
    return 0;
  EXIT: return -1;
    /* DO-NOT-DELETE splicer.end(ex2.SetC.remove) */
  }
}

/*
 * returns true if the element exists in the set, false otherwise
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_SetC_isMember"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_ex2_SetC_isMember(
  /* in */ ex2_SetC self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.SetC.isMember) */
    struct ex2_SetC__data * dptr = ex2_SetC__get_data(self);
    ex2_ListNode elem, next;
    ex2_Data elem_data;
    elem = ex2_ListOps_getHead(dptr->list,_ex);SIDL_REPORT(*_ex);
    while (elem){
      elem_data = ex2_ListNode_getData(elem, _ex); SIDL_REPORT(*_ex);
      int result = ex2_Data_compare(elem_data,d,_ex);
      if (result == 0){
        ex2_Data_deleteRef(elem_data, _ex); SIDL_REPORT(*_ex);
        ex2_ListNode_deleteRef(elem, _ex); SIDL_REPORT(*_ex);
        return 1;
      }
      ex2_Data_deleteRef(elem_data, _ex); SIDL_REPORT(*_ex);
      next = ex2_ListNode_getNext(elem, _ex); SIDL_REPORT(*_ex);
      ex2_ListNode_deleteRef(elem, _ex); SIDL_REPORT(*_ex);
      elem = next;
    }
    return 0;
  EXIT: return 0;
    /* DO-NOT-DELETE splicer.end(ex2.SetC.isMember) */
  }
}

/*
 * Clears the set, decrements references to all elements in the set,
 * sets the set size to 0
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_SetC_clearSet"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_SetC_clearSet(
  /* in */ ex2_SetC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.SetC.clearSet) */
    struct ex2_SetC__data * dptr = ex2_SetC__get_data(self);
    ex2_Data temp;
    int size; 
    while (size = ex2_ListOps_getSize(dptr->list, _ex) > 0){
      ex2_ListOps_removeNext(dptr->list, NULL, &temp, _ex); SIDL_REPORT(*_ex);
      ex2_Data_deleteRef(temp, _ex); SIDL_REPORT(*_ex);
    }
  EXIT: ;
    /* DO-NOT-DELETE splicer.end(ex2.SetC.clearSet) */
  }
}

/*
 * Tests whether the set is empty. Returns true if empty
 * false otherwise
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_SetC_isEmpty"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_ex2_SetC_isEmpty(
  /* in */ ex2_SetC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.SetC.isEmpty) */
   struct ex2_SetC__data * dptr = ex2_SetC__get_data(self);
   int size = ex2_ListOps_getSize(dptr->list, _ex); SIDL_REPORT(*_ex);
    if (size==0) return 1;
    else return 0; 
  EXIT: return 0;
    /* DO-NOT-DELETE splicer.end(ex2.SetC.isEmpty) */
  }
}

/*
 * Returns the size of the set
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_SetC_getSize"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_ex2_SetC_getSize(
  /* in */ ex2_SetC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.SetC.getSize) */
     struct ex2_SetC__data * dptr = ex2_SetC__get_data(self);
    int size = ex2_ListOps_getSize(dptr->list, _ex); SIDL_REPORT(*_ex);
    return size;
  EXIT: return NULL;   
    /* DO-NOT-DELETE splicer.end(ex2.SetC.getSize) */
  }
}

/*
 *  
 * Returns the elements in the form of a list.
 * Actual elements are returned.
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_SetC_getList"

#ifdef __cplusplus
extern "C"
#endif
ex2_ListOps
impl_ex2_SetC_getList(
  /* in */ ex2_SetC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.SetC.getList) */
     struct ex2_SetC__data * dptr = ex2_SetC__get_data(self);
     if (dptr->list) ex2_ListOps_addRef(dptr->list, _ex);
     //ex2_ListOps listops = ex2_ListOps__cast(dptr->list, _ex);
     return dptr->list;
    /* DO-NOT-DELETE splicer.end(ex2.SetC.getList) */
  }
}
/* Babel internal methods, Users should not edit below this line. */

/* DO-NOT-DELETE splicer.begin(_misc) */
/* Insert-Code-Here {_misc} (miscellaneous code) */
/* DO-NOT-DELETE splicer.end(_misc) */

