/*
 * File:          ex2_GraphC1_IOR.h
 * Symbol:        ex2.GraphC1-v0.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * sidl Created:  20090805 11:15:46 PDT
 * Generated:     20090805 11:15:49 PDT
 * Description:   Intermediate Object Representation for ex2.GraphC1
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 * source-url = /export/tmp-abramova1/cint/components/sidl/ex2.GraphC1.sidl
 */

#ifndef included_ex2_GraphC1_IOR_h
#define included_ex2_GraphC1_IOR_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
struct sidl_rmi_InstanceHandle__object;
#ifndef included_sidlAsserts_h
#include "sidlAsserts.h"
#endif
#ifndef included_ex2_GraphOps_IOR_h
#include "ex2_GraphOps_IOR.h"
#endif
#ifndef included_sidl_BaseClass_IOR_h
#include "sidl_BaseClass_IOR.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Symbol "ex2.GraphC1" (version 0.0)
 */

struct ex2_GraphC1__array;
struct ex2_GraphC1__object;

/*
 * Forward references for external classes and interfaces.
 */

struct ex2_AdjList__array;
struct ex2_AdjList__object;
struct ex2_AdjListC__array;
struct ex2_AdjListC__object;
struct ex2_Data__array;
struct ex2_Data__object;
struct ex2_ListC__array;
struct ex2_ListC__object;
struct ex2_ListNode__array;
struct ex2_ListNode__object;
struct ex2_ListOps__array;
struct ex2_ListOps__object;
struct sidl_BaseException__array;
struct sidl_BaseException__object;
struct sidl_BaseInterface__array;
struct sidl_BaseInterface__object;
struct sidl_ClassInfo__array;
struct sidl_ClassInfo__object;
struct sidl_PostViolation__array;
struct sidl_PostViolation__object;
struct sidl_PreViolation__array;
struct sidl_PreViolation__object;
struct sidl_RuntimeException__array;
struct sidl_RuntimeException__object;
struct sidl_rmi_Call__array;
struct sidl_rmi_Call__object;
struct sidl_rmi_Return__array;
struct sidl_rmi_Return__object;

/*
 * Define invariant clause data for interface contract enforcement.
 */

static struct ex2_GraphC1__inv_desc {
  int    inv_complexity;
  double inv_exec_time;
} s_ior_ex2_GraphC1_inv = {
  0, 0.0,
};

/*
 * Define method description data for interface contract enforcement.
 */

static const int32_t s_IOR_EX2_GRAPHC1_BOCCAFORCEUSEPORTINCLUDE    = 0;
static const int32_t s_IOR_EX2_GRAPHC1_ADDREF                      = 1;
static const int32_t s_IOR_EX2_GRAPHC1_DELETEREF                   = 2;
static const int32_t s_IOR_EX2_GRAPHC1_ISSAME                      = 3;
static const int32_t s_IOR_EX2_GRAPHC1_ISTYPE                      = 4;
static const int32_t s_IOR_EX2_GRAPHC1_GETCLASSINFO                = 5;
static const int32_t s_IOR_EX2_GRAPHC1_INSVERTEX                   = 6;
static const int32_t s_IOR_EX2_GRAPHC1_REMVERTEX                   = 7;
static const int32_t s_IOR_EX2_GRAPHC1_INSEDGE                     = 8;
static const int32_t s_IOR_EX2_GRAPHC1_REMEDGE                     = 9;
static const int32_t s_IOR_EX2_GRAPHC1_GETADJLIST                  = 10;
static const int32_t s_IOR_EX2_GRAPHC1_ISADJACENT                  = 11;
static const int32_t s_IOR_EX2_GRAPHC1_GETADJLISTS                 = 12;
static const int32_t s_IOR_EX2_GRAPHC1_GETVERTCOUNT                = 13;
static const int32_t s_IOR_EX2_GRAPHC1_GETEDGECOUNT                = 14;
static const int32_t s_IOR_EX2_GRAPHC1_VERTEXEXISTS                = 15;
static const int32_t s_IOR_EX2_GRAPHC1_MIN                         = 0;
static const int32_t s_IOR_EX2_GRAPHC1_MAX                         = 15;

static struct ex2_GraphC1__method_desc {
  char*     name;
  sidl_bool is_static;
  long      est_interval;
  int       pre_complexity;
  int       post_complexity;
  double    meth_exec_time;
  double    pre_exec_time;
  double    post_exec_time;
} s_ior_ex2_GraphC1_method[] = {
  {"boccaForceUsePortInclude", 0, 0, 0, 0, 0.0, 0.0, 0.0},
  {"addRef", 0, 0, 0, 0, 0.0, 0.0, 0.0},
  {"deleteRef", 0, 0, 0, 0, 0.0, 0.0, 0.0},
  {"isSame", 0, 0, 0, 0, 0.0, 0.0, 0.0},
  {"isType", 0, 0, 0, 0, 0.0, 0.0, 0.0},
  {"getClassInfo", 0, 0, 0, 0, 0.0, 0.0, 0.0},
  {"insVertex", 0, 0, 0, 0, 0.0, 0.0, 0.0},
  {"remVertex", 0, 0, 0, 0, 0.0, 0.0, 0.0},
  {"insEdge", 0, 0, 0, 0, 0.0, 0.0, 0.0},
  {"remEdge", 0, 0, 0, 0, 0.0, 0.0, 0.0},
  {"getAdjList", 0, 0, 0, 0, 0.0, 0.0, 0.0},
  {"isAdjacent", 0, 0, 0, 0, 0.0, 0.0, 0.0},
  {"getAdjLists", 0, 0, 0, 0, 0.0, 0.0, 0.0},
  {"getVertCount", 0, 0, 0, 0, 0.0, 0.0, 0.0},
  {"getEdgeCount", 0, 0, 0, 0, 0.0, 0.0, 0.0},
  {"vertexExists", 0, 0, 0, 0, 0.0, 0.0, 0.0},
};

/*
 * Declare the method entry point vector.
 */

struct ex2_GraphC1__epv {
  /* Implicit builtin methods */
  /* 0 */
  void* (*f__cast)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ const char* name,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 1 */
  void (*f__delete)(
    /* in */ struct ex2_GraphC1__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 2 */
  void (*f__exec)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ const char* methodName,
    /* in */ struct sidl_rmi_Call__object* inArgs,
    /* in */ struct sidl_rmi_Return__object* outArgs,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 3 */
  char* (*f__getURL)(
    /* in */ struct ex2_GraphC1__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 4 */
  void (*f__raddRef)(
    /* in */ struct ex2_GraphC1__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 5 */
  sidl_bool (*f__isRemote)(
    /* in */ struct ex2_GraphC1__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 6 */
  void (*f__set_hooks)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ sidl_bool enable,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 7 */
  void (*f__set_contracts)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ sidl_bool enable,
    /* in */ const char* enfFilename,
    /* in */ sidl_bool resetCounters,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 8 */
  void (*f__dump_stats)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ const char* filename,
    /* in */ const char* prefix,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 9 */
  void (*f__ctor)(
    /* in */ struct ex2_GraphC1__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 10 */
  void (*f__ctor2)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ void* private_data,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 11 */
  void (*f__dtor)(
    /* in */ struct ex2_GraphC1__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 12 */
  void (*f__load)(
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* Methods introduced in sidl.BaseInterface-v0.9.17 */
  void (*f_addRef)(
    /* in */ struct ex2_GraphC1__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_deleteRef)(
    /* in */ struct ex2_GraphC1__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  sidl_bool (*f_isSame)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ struct sidl_BaseInterface__object* iobj,
    /* out */ struct sidl_BaseInterface__object **_ex);
  sidl_bool (*f_isType)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ const char* name,
    /* out */ struct sidl_BaseInterface__object **_ex);
  struct sidl_ClassInfo__object* (*f_getClassInfo)(
    /* in */ struct ex2_GraphC1__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* Methods introduced in sidl.BaseClass-v0.9.17 */
  /* Methods introduced in ex2.GraphOps-v0.0 */
  int32_t (*f_insVertex)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ struct ex2_Data__object* d,
    /* out */ struct sidl_BaseInterface__object **_ex);
  int32_t (*f_remVertex)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ struct ex2_Data__object* d,
    /* out */ struct sidl_BaseInterface__object **_ex);
  int32_t (*f_insEdge)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ struct ex2_Data__object* d1,
    /* in */ struct ex2_Data__object* d2,
    /* out */ struct sidl_BaseInterface__object **_ex);
  int32_t (*f_remEdge)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ struct ex2_Data__object* d1,
    /* in */ struct ex2_Data__object* d2,
    /* out */ struct sidl_BaseInterface__object **_ex);
  struct ex2_AdjList__object* (*f_getAdjList)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ struct ex2_Data__object* d,
    /* out */ struct sidl_BaseInterface__object **_ex);
  int32_t (*f_isAdjacent)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ struct ex2_Data__object* d1,
    /* in */ struct ex2_Data__object* d2,
    /* out */ struct sidl_BaseInterface__object **_ex);
  struct ex2_ListOps__object* (*f_getAdjLists)(
    /* in */ struct ex2_GraphC1__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  int32_t (*f_getVertCount)(
    /* in */ struct ex2_GraphC1__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  int32_t (*f_getEdgeCount)(
    /* in */ struct ex2_GraphC1__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  sidl_bool (*f_vertexExists)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ struct ex2_Data__object* d,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* Methods introduced in ex2.GraphC1-v0.0 */
  void (*f_boccaForceUsePortInclude)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ struct ex2_AdjList__object* dummy0,
    /* in */ struct ex2_ListOps__object* dummy1,
    /* in */ struct ex2_AdjListC__object* dummy2,
    /* in */ struct ex2_Data__object* dummy3,
    /* in */ struct ex2_ListC__object* dummy4,
    /* in */ struct ex2_ListNode__object* dummy5,
    /* out */ struct sidl_BaseInterface__object **_ex);
};

/*
 * Declare the method pre hooks entry point vector.
 */

struct ex2_GraphC1__pre_epv {
  void (*f_boccaForceUsePortInclude_pre)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ struct ex2_AdjList__object* dummy0,
    /* in */ struct ex2_ListOps__object* dummy1,
    /* in */ struct ex2_AdjListC__object* dummy2,
    /* in */ struct ex2_Data__object* dummy3,
    /* in */ struct ex2_ListC__object* dummy4,
    /* in */ struct ex2_ListNode__object* dummy5,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_insVertex_pre)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ struct ex2_Data__object* d,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_remVertex_pre)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ struct ex2_Data__object* d,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_insEdge_pre)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ struct ex2_Data__object* d1,
    /* in */ struct ex2_Data__object* d2,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_remEdge_pre)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ struct ex2_Data__object* d1,
    /* in */ struct ex2_Data__object* d2,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_getAdjList_pre)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ struct ex2_Data__object* d,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_isAdjacent_pre)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ struct ex2_Data__object* d1,
    /* in */ struct ex2_Data__object* d2,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_getAdjLists_pre)(
    /* in */ struct ex2_GraphC1__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_getVertCount_pre)(
    /* in */ struct ex2_GraphC1__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_getEdgeCount_pre)(
    /* in */ struct ex2_GraphC1__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_vertexExists_pre)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ struct ex2_Data__object* d,
    /* out */ struct sidl_BaseInterface__object **_ex);
};

/*
 * Declare the method post hooks entry point vector.
 */

struct ex2_GraphC1__post_epv {
  void (*f_boccaForceUsePortInclude_post)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ struct ex2_AdjList__object* dummy0,
    /* in */ struct ex2_ListOps__object* dummy1,
    /* in */ struct ex2_AdjListC__object* dummy2,
    /* in */ struct ex2_Data__object* dummy3,
    /* in */ struct ex2_ListC__object* dummy4,
    /* in */ struct ex2_ListNode__object* dummy5,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_insVertex_post)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ struct ex2_Data__object* d,
    /* in */ int32_t _retval,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_remVertex_post)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ struct ex2_Data__object* d,
    /* in */ int32_t _retval,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_insEdge_post)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ struct ex2_Data__object* d1,
    /* in */ struct ex2_Data__object* d2,
    /* in */ int32_t _retval,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_remEdge_post)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ struct ex2_Data__object* d1,
    /* in */ struct ex2_Data__object* d2,
    /* in */ int32_t _retval,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_getAdjList_post)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ struct ex2_Data__object* d,
    /* in */ struct ex2_AdjList__object* _retval,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_isAdjacent_post)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ struct ex2_Data__object* d1,
    /* in */ struct ex2_Data__object* d2,
    /* in */ int32_t _retval,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_getAdjLists_post)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ struct ex2_ListOps__object* _retval,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_getVertCount_post)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ int32_t _retval,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_getEdgeCount_post)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ int32_t _retval,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_vertexExists_post)(
    /* in */ struct ex2_GraphC1__object* self,
    /* in */ struct ex2_Data__object* d,
    /* in */ sidl_bool _retval,
    /* out */ struct sidl_BaseInterface__object **_ex);
};

/*
 * Define the controls and statistics structure.
 */


struct ex2_GraphC1__cstats {
  sidl_bool use_hooks;
  sidl_bool enabled;
  struct ex2_GraphC1__method_cstats {
    int32_t tries;
    int32_t successes;
    int32_t failures;
    int32_t nonvio_exceptions;
  } method_cstats[16];
};

/*
 * Define the class object structure.
 */

struct ex2_GraphC1__object {
  struct sidl_BaseClass__object d_sidl_baseclass;
  struct ex2_GraphOps__object   d_ex2_graphops;
  struct ex2_GraphC1__epv*      d_epv;
  struct ex2_GraphC1__cstats    d_cstats;
  void*                         d_data;
};

struct ex2_GraphC1__external {
  struct ex2_GraphC1__object*
  (*createObject)(void* ddata, struct sidl_BaseInterface__object **_ex);

  struct sidl_BaseClass__epv*(*getSuperEPV)(void);
  int d_ior_major_version;
  int d_ior_minor_version;
};

/*
 * This function returns a pointer to a static structure of
 * pointers to function entry points.  Its purpose is to provide
 * one-stop shopping for loading DLLs.
 */

const struct ex2_GraphC1__external*
ex2_GraphC1__externals(void);

extern struct ex2_GraphC1__object*
ex2_GraphC1__createObject(void* ddata,struct sidl_BaseInterface__object ** _ex);

extern void ex2_GraphC1__init(
  struct ex2_GraphC1__object* self, void* ddata, struct 
    sidl_BaseInterface__object ** _ex);

extern void ex2_GraphC1__getEPVs(
  struct sidl_BaseInterface__epv **s_arg_epv__sidl_baseinterface,
  struct sidl_BaseClass__epv **s_arg_epv__sidl_baseclass,
  struct ex2_GraphOps__epv **s_arg_epv__ex2_graphops,
  struct ex2_GraphOps__epv **s_arg_epv_hooks__ex2_graphops,
  struct ex2_GraphC1__epv **s_arg_epv__ex2_graphc1,
  struct ex2_GraphC1__epv **s_arg_epv_hooks__ex2_graphc1);

extern void ex2_GraphC1__fini(
  struct ex2_GraphC1__object* self, struct sidl_BaseInterface__object ** _ex);

extern void ex2_GraphC1__IOR_version(int32_t *major, int32_t *minor);

struct ex2_Data__object* skel_ex2_GraphC1_fconnect_ex2_Data(const char* url, 
  sidl_bool ar, struct sidl_BaseInterface__object * *_ex);
struct sidl_BaseInterface__object* skel_ex2_GraphC1_fconnect_sidl_BaseInterface(
  const char* url, sidl_bool ar, struct sidl_BaseInterface__object * *_ex);
struct ex2_ListC__object* skel_ex2_GraphC1_fconnect_ex2_ListC(const char* url, 
  sidl_bool ar, struct sidl_BaseInterface__object * *_ex);
struct ex2_AdjListC__object* skel_ex2_GraphC1_fconnect_ex2_AdjListC(const char* 
  url, sidl_bool ar, struct sidl_BaseInterface__object * *_ex);
struct ex2_ListOps__object* skel_ex2_GraphC1_fconnect_ex2_ListOps(const char* 
  url, sidl_bool ar, struct sidl_BaseInterface__object * *_ex);
struct ex2_ListNode__object* skel_ex2_GraphC1_fconnect_ex2_ListNode(const char* 
  url, sidl_bool ar, struct sidl_BaseInterface__object * *_ex);
struct ex2_AdjList__object* skel_ex2_GraphC1_fconnect_ex2_AdjList(const char* 
  url, sidl_bool ar, struct sidl_BaseInterface__object * *_ex);
struct ex2_GraphC1__remote{
  int d_refcount;
  struct sidl_rmi_InstanceHandle__object *d_ih;
};

#ifdef __cplusplus
}
#endif
#endif
