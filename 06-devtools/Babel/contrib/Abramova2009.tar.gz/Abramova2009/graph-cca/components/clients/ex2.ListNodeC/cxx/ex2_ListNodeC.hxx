// 
// File:          ex2_ListNodeC.hxx
// Symbol:        ex2.ListNodeC-v0.0
// Symbol Type:   class
// Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
// sidl Created:  20090805 11:13:13 PDT
// Generated:     20090805 11:13:17 PDT
// Description:   Client-side glue code for ex2.ListNodeC
// 
// WARNING: Automatically generated; changes will be lost
// 
// source-url = /export/tmp-abramova1/cint/components/sidl/ex2.ListNodeC.sidl
// 

#ifndef included_ex2_ListNodeC_hxx
#define included_ex2_ListNodeC_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
// declare class before main #includes
// (this alleviates circular #include guard problems)[BUG#393]
namespace ex2 { 

  class ListNodeC;
} // end namespace ex2

// Some compilers need to define array template before the specializations
namespace sidl {
  template<>
  class array< ::ex2::ListNodeC >;
}
// 
// Forward declarations for method dependencies.
// 
namespace ex2 { 

  class Data;
} // end namespace ex2

namespace ex2 { 

  class ListNode;
} // end namespace ex2

namespace sidl { 

  class RuntimeException;
} // end namespace sidl

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_ex2_ListNodeC_IOR_h
#include "ex2_ListNodeC_IOR.h"
#endif
#ifndef included_ex2_ListNode_hxx
#include "ex2_ListNode.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
namespace sidl {
  namespace rmi {
    class Call;
    class Return;
    class Ticket;
  }
  namespace rmi {
    class InstanceHandle;
  }
}
namespace ex2 { 

  /**
   * Symbol "ex2.ListNodeC" (version 0.0)
   */
  class ListNodeC: public virtual ::ex2::ListNode, public virtual 
    ::sidl::BaseClass {

    //////////////////////////////////////////////////
    // 
    // Special methods for throwing exceptions
    // 

  private:
    static 
    void
    throwException0(
      const char* methodName,
      struct sidl_BaseInterface__object *_exception
    )
      // throws:
    ;

    //////////////////////////////////////////////////
    // 
    // User Defined Methods
    // 

  public:

    /**
     *  This function should never be called, but helps babel generate better code. 
     */
    void
    boccaForceUsePortInclude() ;


    /**
     * Sets the data pointer to point to data object
     */
    void
    setData (
      /* in */const ::ex2::Data& d
    )
    ;



    /**
     * Returns Data object pointed by the Data pointer
     */
    ::ex2::Data
    getData() ;


    /**
     * Sets the Node pointer to point to the next Node object
     */
    void
    setNext (
      /* in */const ::ex2::ListNode& n
    )
    ;



    /**
     * Returns the Node pointed to by the Node pointer
     */
    ::ex2::ListNode
    getNext() ;


    //////////////////////////////////////////////////
    // 
    // End User Defined Methods
    // (everything else in this file is specific to
    //  Babel's C++ bindings)
    // 

  public:
    typedef struct ex2_ListNodeC__object ior_t;
    typedef struct ex2_ListNodeC__external ext_t;
    typedef struct ex2_ListNodeC__sepv sepv_t;

    // default constructor
    ListNodeC() { }
    // static constructor
    static ::ex2::ListNodeC _create();


#ifdef WITH_RMI

    // RMI constructor
    static ::ex2::ListNodeC _create( /*in*/ const std::string& url );

    // RMI connect
    static inline ::ex2::ListNodeC _connect( /*in*/ const std::string& url ) { 
      return _connect(url, true);
    }

    // RMI connect 2
    static ::ex2::ListNodeC _connect( /*in*/ const std::string& url, /*in*/ 
      const bool ar  );


#endif /*WITH_RMI*/

    // default destructor
    virtual ~ListNodeC () { }

    // copy constructor
    ListNodeC ( const ListNodeC& original );

    // assignment operator
    ListNodeC& operator= ( const ListNodeC& rhs );


    protected:
    // Internal data wrapping method
    static ior_t*  _wrapObj(void* private_data);


    public:
    // conversion from ior to C++ class
    ListNodeC ( ListNodeC::ior_t* ior );

    // Alternate constructor: does not call addRef()
    // (sets d_weak_reference=isWeak)
    // For internal use by Impls (fixes bug#275)
    ListNodeC ( ListNodeC::ior_t* ior, bool isWeak );

    inline ior_t* _get_ior() const throw() {
      return reinterpret_cast< ior_t*>(d_self);
    }

    inline void _set_ior( ior_t* ptr ) throw () { 
      if(d_self == ptr) {return;}
      d_self = reinterpret_cast< void*>(ptr);

      if( ptr != NULL ) {
        ex2_ListNode_IORCache = &((*ptr).d_ex2_listnode);
      } else {
        ex2_ListNode_IORCache = NULL;
      }
    }

    virtual int _set_ior_typesafe( struct sidl_BaseInterface__object *obj,
                                   const ::std::type_info &argtype );

    bool _is_nil() const throw () { return (d_self==0); }

    bool _not_nil() const throw () { return (d_self!=0); }

    bool operator !() const throw () { return (d_self==0); }

    static inline const char * type_name() throw () { return "ex2.ListNodeC";}

    static struct ex2_ListNodeC__object* _cast(const void* src);

    // execute member function by name
    void _exec(const std::string& methodName,
               ::sidl::rmi::Call& inArgs,
               ::sidl::rmi::Return& outArgs);

    /**
     * Get the URL of the Implementation of this object (for RMI)
     */
    ::std::string
    _getURL() // throws:
    //    ::sidl::RuntimeException
    ;


    /**
     * Method to enable/disable method hooks invocation.
     */
    void
    _set_hooks (
      /* in */bool enable
    )
    // throws:
    //    ::sidl::RuntimeException
    ;


    /**
     * Method to enable/disable interface contract enforcement.
     */
    void
    _set_contracts (
      /* in */bool enable,
      /* in */const ::std::string& enfFilename,
      /* in */bool resetCounters
    )
    // throws:
    //    ::sidl::RuntimeException
    ;


    /**
     * Method to dump contract enforcement statistics.
     */
    void
    _dump_stats (
      /* in */const ::std::string& filename,
      /* in */const ::std::string& prefix
    )
    // throws:
    //    ::sidl::RuntimeException
    ;

    // return true iff object is remote
    bool _isRemote() const { 
      ior_t* self = const_cast<ior_t*>(_get_ior() );
      struct sidl_BaseInterface__object *throwaway_exception;
      return (*self->d_epv->f__isRemote)(self, &throwaway_exception) == TRUE;
    }

    // return true iff object is local
    bool _isLocal() const {
      return !_isRemote();
    }

  protected:
    // Pointer to external (DLL loadable) symbols (shared among instances)
    static const ext_t * s_ext;

  public:
    static const ext_t * _get_ext() throw ( ::sidl::NullIORException );

  }; // end class ListNodeC
} // end namespace ex2

extern "C" {


#pragma weak ex2_ListNodeC__connectI

  /**
   * RMI connector function for the class. (no addref)
   */
  struct ex2_ListNodeC__object*
  ex2_ListNodeC__connectI(const char * url, sidl_bool ar, struct 
    sidl_BaseInterface__object **_ex);


} // end extern "C"
namespace sidl {
  // traits specialization
  template<>
  struct array_traits< ::ex2::ListNodeC > {
    typedef array< ::ex2::ListNodeC > cxx_array_t;
    typedef ::ex2::ListNodeC cxx_item_t;
    typedef struct ex2_ListNodeC__array ior_array_t;
    typedef sidl_interface__array ior_array_internal_t;
    typedef struct ex2_ListNodeC__object ior_item_t;
    typedef cxx_item_t value_type;
    typedef value_type reference;
    typedef value_type* pointer;
    typedef const value_type const_reference;
    typedef const value_type* const_pointer;
    typedef array_iter< array_traits< ::ex2::ListNodeC > > iterator;
    typedef const_array_iter< array_traits< ::ex2::ListNodeC > > const_iterator;
  };

  // array specialization
  template<>
  class array< ::ex2::ListNodeC >: public interface_array< array_traits< 
    ::ex2::ListNodeC > > {
  public:
    typedef interface_array< array_traits< ::ex2::ListNodeC > > Base;
    typedef array_traits< ::ex2::ListNodeC >::cxx_array_t          cxx_array_t;
    typedef array_traits< ::ex2::ListNodeC >::cxx_item_t           cxx_item_t;
    typedef array_traits< ::ex2::ListNodeC >::ior_array_t          ior_array_t;
    typedef array_traits< ::ex2::ListNodeC >::ior_array_internal_t 
      ior_array_internal_t;
    typedef array_traits< ::ex2::ListNodeC >::ior_item_t           ior_item_t;

    /**
     * conversion from ior to C++ class
     * (constructor/casting operator)
     */
    array( struct ex2_ListNodeC__array* src = 0) : Base(src) {}

    /**
     * copy constructor
     */
    array( const array< ::ex2::ListNodeC >&src) : Base(src) {}

    /**
     * assignment
     */
    array< ::ex2::ListNodeC >&
    operator =( const array< ::ex2::ListNodeC >&rhs ) { 
      if (d_array != rhs._get_baseior()) {
        if (d_array) deleteRef();
        d_array = const_cast<sidl__array *>(rhs._get_baseior());
        if (d_array) addRef();
      }
      return *this;
    }

  };
}

#ifndef included_ex2_Data_hxx
#include "ex2_Data.hxx"
#endif
#endif
