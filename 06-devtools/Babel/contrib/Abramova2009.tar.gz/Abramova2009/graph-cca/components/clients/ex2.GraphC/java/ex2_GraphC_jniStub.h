/*
 * File:          ex2_GraphC_jniStub.h
 * Symbol:        ex2.GraphC-v0.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * sidl Created:  20090805 11:15:15 PDT
 * Generated:     20090805 11:15:19 PDT
 * Description:   Client-side header code for ex2.GraphC
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 * source-url = /export/tmp-abramova1/cint/components/sidl/ex2.GraphC.sidl
 */

#ifndef included_ex2_GraphC_jniStub_h
#define included_ex2_GraphC_jniStub_h

/**
 * Symbol "ex2.GraphC" (version 0.0)
 */

#ifndef included_ex2_GraphC_IOR_h
#include "ex2_GraphC_IOR.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif


#pragma weak ex2_GraphC__connectI

/**
 * RMI connector function for the class. (no addref)
 */
struct ex2_GraphC__object*
ex2_GraphC__connectI(const char * url, sidl_bool ar, struct 
  sidl_BaseInterface__object **_ex);

#ifdef __cplusplus
}
#endif
#endif
