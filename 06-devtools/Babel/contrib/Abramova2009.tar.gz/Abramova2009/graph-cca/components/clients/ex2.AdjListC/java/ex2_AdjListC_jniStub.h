/*
 * File:          ex2_AdjListC_jniStub.h
 * Symbol:        ex2.AdjListC-v0.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * sidl Created:  20090805 11:13:54 PDT
 * Generated:     20090805 11:13:57 PDT
 * Description:   Client-side header code for ex2.AdjListC
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 * source-url = /export/tmp-abramova1/cint/components/sidl/ex2.AdjListC.sidl
 */

#ifndef included_ex2_AdjListC_jniStub_h
#define included_ex2_AdjListC_jniStub_h

/**
 * Symbol "ex2.AdjListC" (version 0.0)
 */

#ifndef included_ex2_AdjListC_IOR_h
#include "ex2_AdjListC_IOR.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif


#pragma weak ex2_AdjListC__connectI

/**
 * RMI connector function for the class. (no addref)
 */
struct ex2_AdjListC__object*
ex2_AdjListC__connectI(const char * url, sidl_bool ar, struct 
  sidl_BaseInterface__object **_ex);

#ifdef __cplusplus
}
#endif
#endif
