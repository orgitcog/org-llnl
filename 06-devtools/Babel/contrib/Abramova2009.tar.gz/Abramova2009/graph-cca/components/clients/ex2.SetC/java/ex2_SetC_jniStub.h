/*
 * File:          ex2_SetC_jniStub.h
 * Symbol:        ex2.SetC-v0.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * sidl Created:  20090805 11:14:19 PDT
 * Generated:     20090805 11:14:23 PDT
 * Description:   Client-side header code for ex2.SetC
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 * source-url = /export/tmp-abramova1/cint/components/sidl/ex2.SetC.sidl
 */

#ifndef included_ex2_SetC_jniStub_h
#define included_ex2_SetC_jniStub_h

/**
 * Symbol "ex2.SetC" (version 0.0)
 */

#ifndef included_ex2_SetC_IOR_h
#include "ex2_SetC_IOR.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif


#pragma weak ex2_SetC__connectI

/**
 * RMI connector function for the class. (no addref)
 */
struct ex2_SetC__object*
ex2_SetC__connectI(const char * url, sidl_bool ar, struct 
  sidl_BaseInterface__object **_ex);

#ifdef __cplusplus
}
#endif
#endif
