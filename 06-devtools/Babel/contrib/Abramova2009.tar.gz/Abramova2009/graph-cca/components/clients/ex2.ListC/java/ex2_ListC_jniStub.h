/*
 * File:          ex2_ListC_jniStub.h
 * Symbol:        ex2.ListC-v0.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * sidl Created:  20090805 11:14:08 PDT
 * Generated:     20090805 11:14:12 PDT
 * Description:   Client-side header code for ex2.ListC
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 * source-url = /export/tmp-abramova1/cint/components/sidl/ex2.ListC.sidl
 */

#ifndef included_ex2_ListC_jniStub_h
#define included_ex2_ListC_jniStub_h

/**
 * Symbol "ex2.ListC" (version 0.0)
 */

#ifndef included_ex2_ListC_IOR_h
#include "ex2_ListC_IOR.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif


#pragma weak ex2_ListC__connectI

/**
 * RMI connector function for the class. (no addref)
 */
struct ex2_ListC__object*
ex2_ListC__connectI(const char * url, sidl_bool ar, struct 
  sidl_BaseInterface__object **_ex);

#ifdef __cplusplus
}
#endif
#endif
