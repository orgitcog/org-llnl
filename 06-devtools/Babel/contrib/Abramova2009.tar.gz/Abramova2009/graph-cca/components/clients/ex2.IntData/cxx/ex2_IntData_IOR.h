/*
 * File:          ex2_IntData_IOR.h
 * Symbol:        ex2.IntData-v0.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * sidl Created:  20090805 11:16:55 PDT
 * Generated:     20090805 11:16:58 PDT
 * Description:   Intermediate Object Representation for ex2.IntData
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 * source-url = /export/tmp-abramova1/cint/components/sidl/ex2.IntData.sidl
 */

#ifndef included_ex2_IntData_IOR_h
#define included_ex2_IntData_IOR_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
struct sidl_rmi_InstanceHandle__object;
#ifndef included_ex2_Data_IOR_h
#include "ex2_Data_IOR.h"
#endif
#ifndef included_sidl_BaseClass_IOR_h
#include "sidl_BaseClass_IOR.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Symbol "ex2.IntData" (version 0.0)
 * 
 * This is a simple Data class wrapping an integer.
 */

struct ex2_IntData__array;
struct ex2_IntData__object;

/*
 * Forward references for external classes and interfaces.
 */

struct sidl_BaseException__array;
struct sidl_BaseException__object;
struct sidl_BaseInterface__array;
struct sidl_BaseInterface__object;
struct sidl_ClassInfo__array;
struct sidl_ClassInfo__object;
struct sidl_RuntimeException__array;
struct sidl_RuntimeException__object;
struct sidl_rmi_Call__array;
struct sidl_rmi_Call__object;
struct sidl_rmi_Return__array;
struct sidl_rmi_Return__object;

/*
 * Declare the method entry point vector.
 */

struct ex2_IntData__epv {
  /* Implicit builtin methods */
  /* 0 */
  void* (*f__cast)(
    /* in */ struct ex2_IntData__object* self,
    /* in */ const char* name,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 1 */
  void (*f__delete)(
    /* in */ struct ex2_IntData__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 2 */
  void (*f__exec)(
    /* in */ struct ex2_IntData__object* self,
    /* in */ const char* methodName,
    /* in */ struct sidl_rmi_Call__object* inArgs,
    /* in */ struct sidl_rmi_Return__object* outArgs,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 3 */
  char* (*f__getURL)(
    /* in */ struct ex2_IntData__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 4 */
  void (*f__raddRef)(
    /* in */ struct ex2_IntData__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 5 */
  sidl_bool (*f__isRemote)(
    /* in */ struct ex2_IntData__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 6 */
  void (*f__set_hooks)(
    /* in */ struct ex2_IntData__object* self,
    /* in */ sidl_bool enable,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 7 */
  void (*f__set_contracts)(
    /* in */ struct ex2_IntData__object* self,
    /* in */ sidl_bool enable,
    /* in */ const char* enfFilename,
    /* in */ sidl_bool resetCounters,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 8 */
  void (*f__dump_stats)(
    /* in */ struct ex2_IntData__object* self,
    /* in */ const char* filename,
    /* in */ const char* prefix,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 9 */
  void (*f__ctor)(
    /* in */ struct ex2_IntData__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 10 */
  void (*f__ctor2)(
    /* in */ struct ex2_IntData__object* self,
    /* in */ void* private_data,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 11 */
  void (*f__dtor)(
    /* in */ struct ex2_IntData__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 12 */
  void (*f__load)(
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* Methods introduced in sidl.BaseInterface-v0.9.17 */
  void (*f_addRef)(
    /* in */ struct ex2_IntData__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_deleteRef)(
    /* in */ struct ex2_IntData__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  sidl_bool (*f_isSame)(
    /* in */ struct ex2_IntData__object* self,
    /* in */ struct sidl_BaseInterface__object* iobj,
    /* out */ struct sidl_BaseInterface__object **_ex);
  sidl_bool (*f_isType)(
    /* in */ struct ex2_IntData__object* self,
    /* in */ const char* name,
    /* out */ struct sidl_BaseInterface__object **_ex);
  struct sidl_ClassInfo__object* (*f_getClassInfo)(
    /* in */ struct ex2_IntData__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* Methods introduced in sidl.BaseClass-v0.9.17 */
  /* Methods introduced in ex2.Data-v0.0 */
  void (*f_display)(
    /* in */ struct ex2_IntData__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  int32_t (*f_hashCode)(
    /* in */ struct ex2_IntData__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  int32_t (*f_compare)(
    /* in */ struct ex2_IntData__object* self,
    /* in */ struct ex2_Data__object* data,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_setData)(
    /* in */ struct ex2_IntData__object* self,
    /* in */ struct ex2_Data__object* data,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* Methods introduced in ex2.IntData-v0.0 */
  int32_t (*f_getIntData)(
    /* in */ struct ex2_IntData__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_setIntData)(
    /* in */ struct ex2_IntData__object* self,
    /* in */ int32_t val,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_boccaForceUsePortInclude)(
    /* in */ struct ex2_IntData__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
};

/*
 * Declare the method pre hooks entry point vector.
 */

struct ex2_IntData__pre_epv {
  void (*f_getIntData_pre)(
    /* in */ struct ex2_IntData__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_setIntData_pre)(
    /* in */ struct ex2_IntData__object* self,
    /* in */ int32_t val,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_boccaForceUsePortInclude_pre)(
    /* in */ struct ex2_IntData__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_display_pre)(
    /* in */ struct ex2_IntData__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_hashCode_pre)(
    /* in */ struct ex2_IntData__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_compare_pre)(
    /* in */ struct ex2_IntData__object* self,
    /* in */ struct ex2_Data__object* data,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_setData_pre)(
    /* in */ struct ex2_IntData__object* self,
    /* in */ struct ex2_Data__object* data,
    /* out */ struct sidl_BaseInterface__object **_ex);
};

/*
 * Declare the method post hooks entry point vector.
 */

struct ex2_IntData__post_epv {
  void (*f_getIntData_post)(
    /* in */ struct ex2_IntData__object* self,
    /* in */ int32_t _retval,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_setIntData_post)(
    /* in */ struct ex2_IntData__object* self,
    /* in */ int32_t val,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_boccaForceUsePortInclude_post)(
    /* in */ struct ex2_IntData__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_display_post)(
    /* in */ struct ex2_IntData__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_hashCode_post)(
    /* in */ struct ex2_IntData__object* self,
    /* in */ int32_t _retval,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_compare_post)(
    /* in */ struct ex2_IntData__object* self,
    /* in */ struct ex2_Data__object* data,
    /* in */ int32_t _retval,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_setData_post)(
    /* in */ struct ex2_IntData__object* self,
    /* in */ struct ex2_Data__object* data,
    /* out */ struct sidl_BaseInterface__object **_ex);
};

/*
 * Define the controls and statistics structure.
 */


struct ex2_IntData__cstats {
  sidl_bool use_hooks;
};

/*
 * Define the class object structure.
 */

struct ex2_IntData__object {
  struct sidl_BaseClass__object d_sidl_baseclass;
  struct ex2_Data__object       d_ex2_data;
  struct ex2_IntData__epv*      d_epv;
  struct ex2_IntData__cstats    d_cstats;
  void*                         d_data;
};

struct ex2_IntData__external {
  struct ex2_IntData__object*
  (*createObject)(void* ddata, struct sidl_BaseInterface__object **_ex);

  struct sidl_BaseClass__epv*(*getSuperEPV)(void);
  int d_ior_major_version;
  int d_ior_minor_version;
};

/*
 * This function returns a pointer to a static structure of
 * pointers to function entry points.  Its purpose is to provide
 * one-stop shopping for loading DLLs.
 */

const struct ex2_IntData__external*
ex2_IntData__externals(void);

extern struct ex2_IntData__object*
ex2_IntData__createObject(void* ddata,struct sidl_BaseInterface__object ** _ex);

extern void ex2_IntData__init(
  struct ex2_IntData__object* self, void* ddata, struct 
    sidl_BaseInterface__object ** _ex);

extern void ex2_IntData__getEPVs(
  struct sidl_BaseInterface__epv **s_arg_epv__sidl_baseinterface,
  struct sidl_BaseClass__epv **s_arg_epv__sidl_baseclass,
  struct ex2_Data__epv **s_arg_epv__ex2_data,
  struct ex2_Data__epv **s_arg_epv_hooks__ex2_data,
  struct ex2_IntData__epv **s_arg_epv__ex2_intdata,
  struct ex2_IntData__epv **s_arg_epv_hooks__ex2_intdata);

extern void ex2_IntData__fini(
  struct ex2_IntData__object* self, struct sidl_BaseInterface__object ** _ex);

extern void ex2_IntData__IOR_version(int32_t *major, int32_t *minor);

struct ex2_Data__object* skel_ex2_IntData_fconnect_ex2_Data(const char* url, 
  sidl_bool ar, struct sidl_BaseInterface__object * *_ex);
struct sidl_BaseInterface__object* skel_ex2_IntData_fconnect_sidl_BaseInterface(
  const char* url, sidl_bool ar, struct sidl_BaseInterface__object * *_ex);
struct ex2_IntData__remote{
  int d_refcount;
  struct sidl_rmi_InstanceHandle__object *d_ih;
};

#ifdef __cplusplus
}
#endif
#endif
