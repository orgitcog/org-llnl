/*
 * File:          ex2_ListC_Skel.c
 * Symbol:        ex2.ListC-v0.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side glue code for ex2.ListC
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 */

#include "ex2_ListC_IOR.h"
#include "ex2_ListC.h"
#include <stddef.h>

#ifdef WITH_RMI
#ifndef included_ex2_ListNodeC_h
#include "ex2_ListNodeC.h"
#endif
#ifndef included_ex2_Data_h
#include "ex2_Data.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_ex2_ListNode_h
#include "ex2_ListNode.h"
#endif
#endif /* WITH_RMI */
extern
void
impl_ex2_ListC__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_ListC__ctor(
  /* in */ ex2_ListC self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_ListC__ctor2(
  /* in */ ex2_ListC self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_ListC__dtor(
  /* in */ ex2_ListC self,
  /* out */ sidl_BaseInterface *_ex);

#ifdef WITH_RMI
extern struct ex2_ListNodeC__object* impl_ex2_ListC_fconnect_ex2_ListNodeC(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ex2_Data__object* impl_ex2_ListC_fconnect_ex2_Data(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_ex2_ListC_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct ex2_ListNode__object* impl_ex2_ListC_fconnect_ex2_ListNode(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/
extern
void
impl_ex2_ListC_boccaForceUsePortInclude(
  /* in */ ex2_ListC self,
  /* in */ ex2_ListNodeC dummy0,
  /* in */ ex2_ListNode dummy1,
  /* in */ ex2_Data dummy2,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_ListC_insertNext(
  /* in */ ex2_ListC self,
  /* in */ ex2_ListNode n,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_ListC_removeNext(
  /* in */ ex2_ListC self,
  /* in */ ex2_ListNode n,
  /* out */ ex2_Data* d,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_ListC_getSize(
  /* in */ ex2_ListC self,
  /* out */ sidl_BaseInterface *_ex);

extern
ex2_Data
impl_ex2_ListC_getDataAt(
  /* in */ ex2_ListC self,
  /* in */ int32_t index,
  /* out */ sidl_BaseInterface *_ex);

extern
ex2_ListNode
impl_ex2_ListC_getHead(
  /* in */ ex2_ListC self,
  /* out */ sidl_BaseInterface *_ex);

extern
ex2_ListNode
impl_ex2_ListC_getTail(
  /* in */ ex2_ListC self,
  /* out */ sidl_BaseInterface *_ex);

#ifdef WITH_RMI
extern struct ex2_ListNodeC__object* impl_ex2_ListC_fconnect_ex2_ListNodeC(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct ex2_Data__object* impl_ex2_ListC_fconnect_ex2_Data(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_ex2_ListC_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct ex2_ListNode__object* impl_ex2_ListC_fconnect_ex2_ListNode(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/
#ifdef __cplusplus
extern "C" {
#endif

void
ex2_ListC__set_epv(struct ex2_ListC__epv *epv,
  struct ex2_ListC__pre_epv *pre_epv, 
  struct ex2_ListC__post_epv *post_epv
)
{
  epv->f__ctor = impl_ex2_ListC__ctor;
  epv->f__ctor2 = impl_ex2_ListC__ctor2;
  epv->f__dtor = impl_ex2_ListC__dtor;
  pre_epv->f_boccaForceUsePortInclude_pre = NULL;
  epv->f_boccaForceUsePortInclude = impl_ex2_ListC_boccaForceUsePortInclude;
  post_epv->f_boccaForceUsePortInclude_post = NULL;
  pre_epv->f_insertNext_pre = NULL;
  epv->f_insertNext = impl_ex2_ListC_insertNext;
  post_epv->f_insertNext_post = NULL;
  pre_epv->f_removeNext_pre = NULL;
  epv->f_removeNext = impl_ex2_ListC_removeNext;
  post_epv->f_removeNext_post = NULL;
  pre_epv->f_getSize_pre = NULL;
  epv->f_getSize = impl_ex2_ListC_getSize;
  post_epv->f_getSize_post = NULL;
  pre_epv->f_getDataAt_pre = NULL;
  epv->f_getDataAt = impl_ex2_ListC_getDataAt;
  post_epv->f_getDataAt_post = NULL;
  pre_epv->f_getHead_pre = NULL;
  epv->f_getHead = impl_ex2_ListC_getHead;
  post_epv->f_getHead_post = NULL;
  pre_epv->f_getTail_pre = NULL;
  epv->f_getTail = impl_ex2_ListC_getTail;
  post_epv->f_getTail_post = NULL;

}
#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
extern "C" {
#endif

void ex2_ListC__call_load(void) { 
  sidl_BaseInterface _throwaway_exception = NULL;
  impl_ex2_ListC__load(&_throwaway_exception);
}
#ifdef WITH_RMI
struct ex2_ListNodeC__object* skel_ex2_ListC_fconnect_ex2_ListNodeC(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex) { 
  return ex2_ListNodeC__connectI(url, ar, _ex);
}

struct ex2_Data__object* skel_ex2_ListC_fconnect_ex2_Data(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) { 
  return ex2_Data__connectI(url, ar, _ex);
}

struct sidl_BaseInterface__object* skel_ex2_ListC_fconnect_sidl_BaseInterface(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex) { 
  return sidl_BaseInterface__connectI(url, ar, _ex);
}

struct ex2_ListNode__object* skel_ex2_ListC_fconnect_ex2_ListNode(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex) { 
  return ex2_ListNode__connectI(url, ar, _ex);
}

#endif /*WITH_RMI*/
struct ex2_ListC__data*
ex2_ListC__get_data(ex2_ListC self)
{
  return (struct ex2_ListC__data*)(self ? self->d_data : NULL);
}

void ex2_ListC__set_data(
  ex2_ListC self,
  struct ex2_ListC__data* data)
{
  if (self) {
    self->d_data = data;
  }
}
#ifdef __cplusplus
}
#endif
