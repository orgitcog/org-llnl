/*
 * File:          ex2_ListC_Impl.c
 * Symbol:        ex2.ListC-v0.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for ex2.ListC
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "ex2.ListC" (version 0.0)
 */

#include "ex2_ListC_Impl.h"
#include "sidl_NotImplementedException.h"
#include "sidl_Exception.h"
#ifndef included_sidl_MemAllocException_h
#include "sidl_MemAllocException.h"
#endif

/* DO-NOT-DELETE splicer.begin(ex2.ListC._includes) */

/* Insert-UserCode-Here {ex2.ListC._includes} (includes and arbitrary code) */

/* Bocca generated code. bocca.protected.begin(ex2.ListC._includes) */
#include <stdlib.h>
#include <string.h>
#include "sidl_SIDLException.h"

#define _BOCCA_CTOR_MESSAGES 0

#ifdef _BOCCA_STDERR

#define BOCCA_FPRINTF fprintf
#include <stdio.h>
#include "sidl_String.h"
#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif /* _BOCCA_CTOR_PRINT */

#else /* _BOCCA_STDERR */
#define BOCCA_FPRINTF boccaPrintNothing
#endif /* _BOCCA_STDERR */

static int
boccaPrintNothing(void *v, const char * s, ...)
{
  (void)v; (void)s;
  return 0;
}
/* Bocca generated code. bocca.protected.end(ex2.ListC._includes) */

/* Insert-UserCode-Here {ex2.ListC._includes} (includes and arbitrary code) */

/* DO-NOT-DELETE splicer.end(ex2.ListC._includes) */

#define SIDL_IOR_MAJOR_VERSION 2
#define SIDL_IOR_MINOR_VERSION 0
/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_ListC__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_ListC__load(
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.ListC._load) */
    /* Insert-Code-Here {ex2.ListC._load} (static class initializer method) */
    /*
     * This method has not been implemented
     */

    /* DO-DELETE-WHEN-IMPLEMENTING exception.begin(ex2.ListC._load) */
    SIDL_THROW(*_ex, sidl_NotImplementedException,     "This method has not been implemented");
  EXIT:;
    /* DO-DELETE-WHEN-IMPLEMENTING exception.end(ex2.ListC._load) */
    /* DO-NOT-DELETE splicer.end(ex2.ListC._load) */
  }
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_ListC__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_ListC__ctor(
  /* in */ ex2_ListC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.ListC._ctor) */

  /* Insert-UserDecl-Here {ex2.ListC._ctor} (constructor method) */
    
  /* bocca-default-code. User may edit or delete.begin(ex2.ListC._ctor) */
   struct ex2_ListC__data *dptr = 
       (struct ex2_ListC__data*)malloc(sizeof(struct ex2_ListC__data));
   if (dptr) {
      memset(dptr, 0, sizeof(struct ex2_ListC__data));
   }
   ex2_ListC__set_data(self, dptr);
   #if _BOCCA_CTOR_MESSAGES
     BOCCA_FPRINTF(stderr, 
        "CTOR ex2.ListC: %s constructed data %p in self %p\n", 
        __FUNC__, dptr, self);
   #endif /* _BOCCA_CTOR_MESSAGES */
  /* bocca-default-code. User may edit or delete.end(ex2.ListC._ctor) */

  /* initialize user elements of dptr here */
        dptr->size = 0;
        dptr->head = NULL;
        dptr->tail = NULL;
        //printf("listC constructor called\n");
  /* Insert-UserCode-Here {ex2.ListC._ctor} (constructor method) */

    /* DO-NOT-DELETE splicer.end(ex2.ListC._ctor) */
  }
}

/*
 * Special Class constructor called when the user wants to wrap his own private data.
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_ListC__ctor2"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_ListC__ctor2(
  /* in */ ex2_ListC self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.ListC._ctor2) */
    /* Insert-Code-Here {ex2.ListC._ctor2} (special constructor method) */
    /*
     * This method has not been implemented
     */

    /* DO-DELETE-WHEN-IMPLEMENTING exception.begin(ex2.ListC._ctor2) */
    SIDL_THROW(*_ex, sidl_NotImplementedException,     "This method has not been implemented");
  EXIT:;
    /* DO-DELETE-WHEN-IMPLEMENTING exception.end(ex2.ListC._ctor2) */
    /* DO-NOT-DELETE splicer.end(ex2.ListC._ctor2) */
  }
}
/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_ListC__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_ListC__dtor(
  /* in */ ex2_ListC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.ListC._dtor) */

  /* deinitialize user elements of dptr here */
  /* Insert-UserCode-Here {ex2.ListC._dtor} (destructor method) */
    
  /* bocca-default-code. User may edit or delete.begin(ex2.ListC._dtor) */
   struct ex2_ListC__data *dptr = 
                ex2_ListC__get_data(self);
   ex2_Data temp;
   if (dptr) {
      while (dptr->size > 0){
	ex2_ListC_removeNext(self, NULL,&temp,_ex);// SIDL_REPORT(*_ex);
	ex2_Data_deleteRef(temp, _ex); //SIDL_REPORT(*_ex);
	}
        
      free(dptr);
      ex2_ListC__set_data(self, NULL);
   }
   #if _BOCCA_CTOR_MESSAGES
     BOCCA_FPRINTF(stderr, "DTOR ex2.ListC: %s freed data %p in self %p\n", 
                   __FUNC__, dptr, self);
   #endif /* _BOCCA_CTOR_MESSAGES */
     
  /* bocca-default-code. User may edit or delete.end(ex2.ListC._dtor) */

    /* DO-NOT-DELETE splicer.end(ex2.ListC._dtor) */
  }
}

/*
 *  This function should never be called, but helps babel generate better code. 
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_ListC_boccaForceUsePortInclude"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_ListC_boccaForceUsePortInclude(
  /* in */ ex2_ListC self,
  /* in */ ex2_ListNodeC dummy0,
  /* in */ ex2_ListNode dummy1,
  /* in */ ex2_Data dummy2,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.ListC.boccaForceUsePortInclude) */
/* DO-NOT-EDIT-BOCCA */
  /* Bocca generated code. bocca.protected.begin(ex2.ListC.boccaForceUsePortInclude) */
    (void)self;
    (void)dummy0;
    (void)dummy1;
    (void)dummy2;

  /* Bocca generated code. bocca.protected.end(ex2.ListC.boccaForceUsePortInclude) */
    /* DO-NOT-DELETE splicer.end(ex2.ListC.boccaForceUsePortInclude) */
  }
}

/*
 * Inserts element of type Data after the specified Node
 * returns 0 if inserting is successful, -1 otherwise
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_ListC_insertNext"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_ex2_ListC_insertNext(
  /* in */ ex2_ListC self,
  /* in */ ex2_ListNode n,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.ListC.insertNext) */
     ex2_ListNodeC new_nodeC;
     new_nodeC = ex2_ListNodeC__create(_ex); SIDL_REPORT(*_ex);
     ex2_ListNode new_node = ex2_ListNode__cast(new_nodeC, _ex); 
     ex2_ListNodeC_deleteRef(new_nodeC, _ex);
    ex2_ListNode_setData(new_node, d, _ex); SIDL_REPORT(*_ex);
    //printf(" ListC after setData ");
    struct ex2_ListC__data *dptr = ex2_ListC__get_data(self);
    if (n == NULL){
      //handle insertion at the head of the list
      if (dptr->size == 0)
	    dptr->tail = new_node;

      ex2_ListNode_setNext(new_node,dptr->head, _ex); SIDL_REPORT(*_ex);
      //printf(" empty 1 ");
      // ex2_Node_addRef(new_node, _ex); SIDL_REPORT(*_ex);
      if (dptr->head) ex2_ListNode_deleteRef(dptr->head, _ex); SIDL_REPORT(*_ex);
      //printf(" empty 2 ");
      dptr->head = new_node;
    }
    else {
      //ex2_ListNodeC nn = ex2_ListNodeC__cast(n, _ex);
      ex2_ListNode nextel = ex2_ListNode_getNext(n,_ex); SIDL_REPORT(*_ex);
      //printf(" 1 ");
      if (nextel == NULL)
	dptr->tail = new_node;
      ex2_ListNode_setNext(new_node, nextel, _ex); SIDL_REPORT(*_ex);
      //printf(" 2 ");
      ex2_ListNode_setNext(n, new_node, _ex); SIDL_REPORT(*_ex);
      //printf(" 3 ");
      if (new_node) ex2_ListNode_deleteRef(new_node, _ex); SIDL_REPORT(*_ex);
      //printf(" 4 ");
      if (nextel) ex2_ListNode_deleteRef(nextel, _ex); SIDL_REPORT(*_ex);
      //printf(" 5 ");
      if (nextel) ex2_ListNode_deleteRef(nextel, _ex); SIDL_REPORT(*_ex);
      //if (nn) ex2_ListNodeC_deleteRef(nn, _ex); SIDL_REPORT(*_ex);
      //printf(" 6 ");
    }
    dptr->size++;
    return 0;

    EXIT:
    return -1;
    /* DO-NOT-DELETE splicer.end(ex2.ListC.insertNext) */
  }
}

/*
 * Removes element after the specified Node element
 * returns 0 if the removal was successful, -1 otherwise
 * the Data object that is removed is returned in d
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_ListC_removeNext"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_ex2_ListC_removeNext(
  /* in */ ex2_ListC self,
  /* in */ ex2_ListNode n,
  /* out */ ex2_Data* d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.ListC.removeNext) */
    ex2_ListNode  old_element;
    ex2_Data temp;
    struct ex2_ListC__data *dptr = ex2_ListC__get_data(self);
    if (dptr->size == 0)
      return -1;
    if (n == NULL){
      //handle removal from the head of the list
      temp = ex2_ListNode_getData(dptr->head, _ex); SIDL_REPORT(*_ex);
      old_element = dptr->head;
      dptr->head =  ex2_ListNode_getNext(dptr->head, _ex); SIDL_REPORT(*_ex);
      if (old_element)  ex2_ListNode_deleteRef(old_element, _ex);
      //ex2_ListNode_deleteRef(old_element, _ex);

      if (dptr->size == 1)
	dptr->tail = NULL;
    }
    else {
      //handle removal from somewhere other than the head
      //ex2_ListNodeC nn = ex2_ListNodeC__cast(n, _ex);
      ex2_ListNode nextel = ex2_ListNode_getNext(n,_ex);
      if (nextel == NULL){
	return -1;
      }
      temp = ex2_ListNode_getData(nextel, _ex); SIDL_REPORT(*_ex);
      old_element = nextel;
      ex2_ListNode next_nextel = ex2_ListNode_getNext(nextel, _ex); SIDL_REPORT(*_ex);
      ex2_ListNode_setNext(n, next_nextel, _ex); SIDL_REPORT(*_ex);

      if (next_nextel == NULL){
	dptr->tail = n;
        
      }
      ex2_ListNode_deleteRef(nextel,_ex); SIDL_REPORT(*_ex);
      ex2_ListNode_deleteRef(nextel,_ex); SIDL_REPORT(*_ex);
      if (next_nextel)
        ex2_ListNode_deleteRef(next_nextel, _ex); SIDL_REPORT(*_ex);
      //if (nn) ex2_ListNodeC_deleteRef(nn, _ex);
    }

    dptr->size--;
    *d = temp;
    return 0;

  EXIT: ;
    /* DO-NOT-DELETE splicer.end(ex2.ListC.removeNext) */
  }
}

/*
 * Returns the number of elements currently present in a list
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_ListC_getSize"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_ex2_ListC_getSize(
  /* in */ ex2_ListC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.ListC.getSize) */
      struct ex2_ListC__data *dptr = ex2_ListC__get_data(self);
      return dptr->size;
    /* DO-NOT-DELETE splicer.end(ex2.ListC.getSize) */
  }
}

/*
 * Returns Data stored in the element at indexed position
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_ListC_getDataAt"

#ifdef __cplusplus
extern "C"
#endif
ex2_Data
impl_ex2_ListC_getDataAt(
  /* in */ ex2_ListC self,
  /* in */ int32_t index,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.ListC.getDataAt) */
 
    struct ex2_ListC__data *dptr = ex2_ListC__get_data(self);
    ex2_Data result;
    int i = 0;
    ex2_ListNode elem = ex2_ListC_getHead(self, _ex);
    ex2_ListNode next;
    while(elem && i<= index){
      if (i == index && elem){        
	result = ex2_ListNode_getData(elem, _ex); SIDL_REPORT(*_ex);
	ex2_ListNode_deleteRef(elem, _ex);
        return result;
      }
     
      next = ex2_ListNode_getNext(elem, _ex); SIDL_REPORT(*_ex);
      ex2_ListNode_deleteRef(elem, _ex); SIDL_REPORT(*_ex);
      elem = next;
      i++;
    }
    return result;
  EXIT: 
    
    return NULL;
    
    /* DO-NOT-DELETE splicer.end(ex2.ListC.getDataAt) */
  }
}

/*
 * Returns the pointer to the head Node
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_ListC_getHead"

#ifdef __cplusplus
extern "C"
#endif
ex2_ListNode
impl_ex2_ListC_getHead(
  /* in */ ex2_ListC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.ListC.getHead) */
      struct ex2_ListC__data *dptr = ex2_ListC__get_data(self);
      //printf("ListC getHead got called \n");
      if (dptr->head)
        ex2_ListNode_addRef(dptr->head, _ex); SIDL_REPORT(*_ex);
      // ex2_ListNode n = ex2_ListNode__cast(dptr->head, _ex);
      return dptr->head;
  EXIT:
      return NULL;
    
    /* DO-NOT-DELETE splicer.end(ex2.ListC.getHead) */
  }
}

/*
 * Returns the pointer to the tail Node
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_ListC_getTail"

#ifdef __cplusplus
extern "C"
#endif
ex2_ListNode
impl_ex2_ListC_getTail(
  /* in */ ex2_ListC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.ListC.getTail) */
      struct ex2_ListC__data *dptr = ex2_ListC__get_data(self);
      if (dptr->tail)
        ex2_ListNode_addRef(dptr->tail, _ex); SIDL_REPORT(*_ex);
      return dptr->tail;
  EXIT:
      return NULL;
   
    /* DO-NOT-DELETE splicer.end(ex2.ListC.getTail) */
  }
}
/* Babel internal methods, Users should not edit below this line. */

/* DO-NOT-DELETE splicer.begin(_misc) */
/* Insert-Code-Here {_misc} (miscellaneous code) */
/* DO-NOT-DELETE splicer.end(_misc) */

