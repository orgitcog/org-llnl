/*
 * File:          ex2_ListC_IOR.c
 * Symbol:        ex2.ListC-v0.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Intermediate Object Representation for ex2.ListC
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 */

/*
 * Begin: RMI includes
 */

#include "sidl_rmi_InstanceHandle.h"
#include "sidl_rmi_InstanceRegistry.h"
#include "sidl_rmi_ServerRegistry.h"
#include "sidl_rmi_Call.h"
#include "sidl_rmi_Return.h"
#include "sidl_Exception.h"
#include "sidl_exec_err.h"
#include "sidl_PreViolation.h"
#include "sidl_NotImplementedException.h"
#include <stdio.h>
/*
 * End: RMI includes
 */

#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <stdio.h>
#if TIME_WITH_SYS_TIME
#  include <sys/time.h>
#  include <time.h>
#else
#  if HAVE_SYS_TIME_H
#    include <sys/time.h>
#  else
#    include <time.h>
#  endif
#endif
#include "sidlAsserts.h"
#include "sidl_Enforcer.h"

#define SIDL_NO_DISPATCH_ON_VIOLATION 1
#define SIDL_SIM_TRACE 1
#ifdef SIDL_SIM_TRACE
#include <stdio.h>
#include <string.h>
#endif /* SIDL_SIM_TRACE */

#ifndef included_sidlOps_h
#include "sidlOps.h"
#endif
#include "ex2_ListC_IOR.h"
#ifndef included_sidl_BaseClass_Impl_h
#include "sidl_BaseClass_Impl.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_ClassInfoI_h
#include "sidl_ClassInfoI.h"
#endif

#ifndef NULL
#define NULL 0
#endif

#include "sidl_thread.h"
#ifdef HAVE_PTHREAD
static struct sidl_recursive_mutex_t ex2_ListC__mutex= SIDL_RECURSIVE_MUTEX_INITIALIZER;
#define LOCK_STATIC_GLOBALS sidl_recursive_mutex_lock( &ex2_ListC__mutex )
#define UNLOCK_STATIC_GLOBALS sidl_recursive_mutex_unlock( &ex2_ListC__mutex )
/* #define HAVE_LOCKED_STATIC_GLOBALS (sidl_recursive_mutex_trylock( &ex2_ListC__mutex )==EDEADLOCK) */
#else
#define LOCK_STATIC_GLOBALS
#define UNLOCK_STATIC_GLOBALS
/* #define HAVE_LOCKED_STATIC_GLOBALS (1) */
#endif

#define RESETCD(MD) { \
  if (MD) { (MD)->est_interval = sidl_Enforcer_getEstimatesInterval(); } \
}
#ifdef SIDL_SIM_TRACE
#define TRACE(CN, MD, MID, PRC, POC, INC, MT, PRT, POT, IT1, IT2) { \
  if (MD) { sidl_Enforcer_logTrace(CN, (MD)->name, MID, PRC, POC, INC, MT, PRT, POT, IT1, IT2); } \
}
#else /* !SIDL_SIM_TRACE */
#define TRACE(CN, MD, MID, PRC, POC, INC, MT, PRT, POT, IT1, IT2)
#endif /* SIDL_SIM_TRACE */

/*
 * Static variables to hold version of IOR
 */

static const int32_t s_IOR_MAJOR_VERSION = 2;
static const int32_t s_IOR_MINOR_VERSION = 0;

/*
 * Static variable to hold shared ClassInfo interface.
 */

static sidl_ClassInfo s_classInfo  = NULL;

/*
 * Static variable to make sure _load called no more than once.
 */

static int s_load_called = 0;

/*
 * Static variables for managing EPV initialization.
 */

static int s_method_initialized = 0;

static struct ex2_ListC__epv s_my_epv__ex2_listc;

static struct ex2_ListC__epv s_my_epv_contracts__ex2_listc;

static struct ex2_ListC__epv s_my_epv_hooks__ex2_listc;

static struct ex2_ListOps__epv s_my_epv__ex2_listops;
static struct ex2_ListOps__epv s_my_epv_hooks__ex2_listops;

static struct sidl_BaseClass__epv  s_my_epv__sidl_baseclass;
static struct sidl_BaseClass__epv* s_par_epv__sidl_baseclass;

static struct sidl_BaseInterface__epv  s_my_epv__sidl_baseinterface;
static struct sidl_BaseInterface__epv* s_par_epv__sidl_baseinterface;

/*
 * Static file for interface contract enforcement statistics.
 */

static FILE* s_dump_fptr = NULL;

static struct ex2_ListC__pre_epv s_preEPV;
static struct ex2_ListC__post_epv s_postEPV;

/*
 * Declare EPV routines defined in the skeleton file.
 */

#ifdef __cplusplus
extern "C" {
#endif

extern void ex2_ListC__set_epv(
  struct ex2_ListC__epv* epv,
    struct ex2_ListC__pre_epv* pre_epv,
    struct ex2_ListC__post_epv* post_epv);

extern void ex2_ListC__call_load(void);
#ifdef __cplusplus
}
#endif

static void
ex2_ListC_boccaForceUsePortInclude__exec(
        struct ex2_ListC__object* self,
        struct sidl_rmi_Call__object* inArgs,
        struct sidl_rmi_Return__object* outArgs,
        struct sidl_BaseInterface__object ** _ex) {
  /* stack space for arguments */
  char* dummy0_str = NULL;
#ifndef WITH_RMI
  sidl_BaseClass dummy0_bc = NULL;
#endif /* WITH_RMI */
  struct ex2_ListNodeC__object* dummy0 = NULL;
  char* dummy1_str = NULL;
#ifndef WITH_RMI
  sidl_BaseClass dummy1_bc = NULL;
#endif /* WITH_RMI */
  struct ex2_ListNode__object* dummy1 = NULL;
  char* dummy2_str = NULL;
#ifndef WITH_RMI
  sidl_BaseClass dummy2_bc = NULL;
#endif /* WITH_RMI */
  struct ex2_Data__object* dummy2 = NULL;
  sidl_BaseInterface _throwaway_exception = NULL;
  sidl_BaseInterface _ex3   = NULL;
  sidl_BaseException _SIDLex = NULL;
  /* unpack in and inout argments */
  sidl_rmi_Call_unpackString( inArgs, "dummy0", &dummy0_str, _ex);SIDL_CHECK(
    *_ex);
#ifdef WITH_RMI

  dummy0 = skel_ex2_ListC_fconnect_ex2_ListNodeC(dummy0_str, TRUE, 
    _ex);SIDL_CHECK(*_ex);
#else
  dummy0_bc = sidl_rmi_InstanceRegistry_getInstanceByString(dummy0_str, 
    _ex);SIDL_CHECK(*_ex);
  if(dummy0_bc != NULL) {
    dummy0= (struct ex2_ListC__object*) (*dummy0_bc->d_epv->f__cast)(dummy0_bc, 
      "ex2.ListC", _ex);
    if(dummy0 != NULL) {
      (((struct sidl_BaseInterface__object*)(dummy0))->d_epv->f_deleteRef)(((
        struct sidl_BaseInterface__object*)dummy0)->d_object, _ex); SIDL_CHECK(
        *_ex);
    } else {
      (*dummy0_bc->d_epv->f_deleteRef)(dummy0_bc, _ex);
    }
  }
#endif /* WITH_RMI */
  sidl_rmi_Call_unpackString( inArgs, "dummy1", &dummy1_str, _ex);SIDL_CHECK(
    *_ex);
#ifdef WITH_RMI

  dummy1 = skel_ex2_ListC_fconnect_ex2_ListNode(dummy1_str, TRUE, 
    _ex);SIDL_CHECK(*_ex);
#else
  dummy1_bc = sidl_rmi_InstanceRegistry_getInstanceByString(dummy1_str, 
    _ex);SIDL_CHECK(*_ex);
  if(dummy1_bc != NULL) {
    dummy1= (struct ex2_ListC__object*) (*dummy1_bc->d_epv->f__cast)(dummy1_bc, 
      "ex2.ListC", _ex);
    if(dummy1 != NULL) {
      (((struct sidl_BaseInterface__object*)(dummy1))->d_epv->f_deleteRef)(((
        struct sidl_BaseInterface__object*)dummy1)->d_object, _ex); SIDL_CHECK(
        *_ex);
    } else {
      (*dummy1_bc->d_epv->f_deleteRef)(dummy1_bc, _ex);
    }
  }
#endif /* WITH_RMI */
  sidl_rmi_Call_unpackString( inArgs, "dummy2", &dummy2_str, _ex);SIDL_CHECK(
    *_ex);
#ifdef WITH_RMI

  dummy2 = skel_ex2_ListC_fconnect_ex2_Data(dummy2_str, TRUE, _ex);SIDL_CHECK(
    *_ex);
#else
  dummy2_bc = sidl_rmi_InstanceRegistry_getInstanceByString(dummy2_str, 
    _ex);SIDL_CHECK(*_ex);
  if(dummy2_bc != NULL) {
    dummy2= (struct ex2_ListC__object*) (*dummy2_bc->d_epv->f__cast)(dummy2_bc, 
      "ex2.ListC", _ex);
    if(dummy2 != NULL) {
      (((struct sidl_BaseInterface__object*)(dummy2))->d_epv->f_deleteRef)(((
        struct sidl_BaseInterface__object*)dummy2)->d_object, _ex); SIDL_CHECK(
        *_ex);
    } else {
      (*dummy2_bc->d_epv->f_deleteRef)(dummy2_bc, _ex);
    }
  }
#endif /* WITH_RMI */

  /* make the call */
  (self->d_epv->f_boccaForceUsePortInclude)(
    self,
    dummy0,
    dummy1,
    dummy2,
    _ex);  SIDL_CHECK(*_ex);

  /* pack return value */
  /* pack out and inout argments */
  EXIT:
  /* clean-up dangling references */
  if(dummy0_str) {free(dummy0_str);}
  if(dummy0) {
    sidl_BaseInterface_deleteRef((sidl_BaseInterface)dummy0, &_ex3); EXEC_CHECK(
      _ex3);
  }
  if(dummy1_str) {free(dummy1_str);}
  if(dummy1) {
    sidl_BaseInterface_deleteRef((sidl_BaseInterface)dummy1, &_ex3); EXEC_CHECK(
      _ex3);
  }
  if(dummy2_str) {free(dummy2_str);}
  if(dummy2) {
    sidl_BaseInterface_deleteRef((sidl_BaseInterface)dummy2, &_ex3); EXEC_CHECK(
      _ex3);
  }
  EXEC_ERR:
  if(*_ex) { 
    _SIDLex = sidl_BaseException__cast(*_ex,&_throwaway_exception);
    sidl_rmi_Return_throwException(outArgs, _SIDLex, &_throwaway_exception); 
    if(_throwaway_exception) {
      /* Throwing failed, throw _ex up the stack then. */
      sidl_BaseInterface_deleteRef(_throwaway_exception, &_throwaway_exception);
      return;
    }
    sidl_BaseException_deleteRef(_SIDLex, &_throwaway_exception);
    sidl_BaseInterface_deleteRef(*_ex, &_throwaway_exception);
    *_ex = NULL;
    if(_ex3) { 
      sidl_BaseInterface_deleteRef(_ex3, &_throwaway_exception);
      _ex3 = NULL;
    }
  } else if(_ex3) {
    _SIDLex = sidl_BaseException__cast(_ex3,&_throwaway_exception);
    sidl_rmi_Return_throwException(outArgs, _SIDLex, &_throwaway_exception); 
    if(_throwaway_exception) {
      /* Throwing failed throw _ex3 up the stack then. */
      sidl_BaseInterface_deleteRef(_throwaway_exception, &_throwaway_exception);
      return;
    }
    sidl_BaseException_deleteRef(_SIDLex, &_throwaway_exception);
    sidl_BaseInterface_deleteRef(_ex3, &_throwaway_exception);
    _ex3 = NULL;
  }
}

static void
ex2_ListC_addRef__exec(
        struct ex2_ListC__object* self,
        struct sidl_rmi_Call__object* inArgs,
        struct sidl_rmi_Return__object* outArgs,
        struct sidl_BaseInterface__object ** _ex) {
  /* stack space for arguments */
  sidl_BaseInterface _throwaway_exception = NULL;
  sidl_BaseInterface _ex3   = NULL;
  sidl_BaseException _SIDLex = NULL;
  /* unpack in and inout argments */

  /* make the call */
  (self->d_epv->f_addRef)(
    self,
    _ex);  SIDL_CHECK(*_ex);

  /* pack return value */
  /* pack out and inout argments */
  EXIT:
  /* clean-up dangling references */
  if(*_ex) { 
    _SIDLex = sidl_BaseException__cast(*_ex,&_throwaway_exception);
    sidl_rmi_Return_throwException(outArgs, _SIDLex, &_throwaway_exception); 
    if(_throwaway_exception) {
      /* Throwing failed, throw _ex up the stack then. */
      sidl_BaseInterface_deleteRef(_throwaway_exception, &_throwaway_exception);
      return;
    }
    sidl_BaseException_deleteRef(_SIDLex, &_throwaway_exception);
    sidl_BaseInterface_deleteRef(*_ex, &_throwaway_exception);
    *_ex = NULL;
    if(_ex3) { 
      sidl_BaseInterface_deleteRef(_ex3, &_throwaway_exception);
      _ex3 = NULL;
    }
  } else if(_ex3) {
    _SIDLex = sidl_BaseException__cast(_ex3,&_throwaway_exception);
    sidl_rmi_Return_throwException(outArgs, _SIDLex, &_throwaway_exception); 
    if(_throwaway_exception) {
      /* Throwing failed throw _ex3 up the stack then. */
      sidl_BaseInterface_deleteRef(_throwaway_exception, &_throwaway_exception);
      return;
    }
    sidl_BaseException_deleteRef(_SIDLex, &_throwaway_exception);
    sidl_BaseInterface_deleteRef(_ex3, &_throwaway_exception);
    _ex3 = NULL;
  }
}

static void
ex2_ListC_deleteRef__exec(
        struct ex2_ListC__object* self,
        struct sidl_rmi_Call__object* inArgs,
        struct sidl_rmi_Return__object* outArgs,
        struct sidl_BaseInterface__object ** _ex) {
  /* stack space for arguments */
  sidl_BaseInterface _throwaway_exception = NULL;
  sidl_BaseInterface _ex3   = NULL;
  sidl_BaseException _SIDLex = NULL;
  /* unpack in and inout argments */

  /* make the call */
  (self->d_epv->f_deleteRef)(
    self,
    _ex);  SIDL_CHECK(*_ex);

  /* pack return value */
  /* pack out and inout argments */
  EXIT:
  /* clean-up dangling references */
  if(*_ex) { 
    _SIDLex = sidl_BaseException__cast(*_ex,&_throwaway_exception);
    sidl_rmi_Return_throwException(outArgs, _SIDLex, &_throwaway_exception); 
    if(_throwaway_exception) {
      /* Throwing failed, throw _ex up the stack then. */
      sidl_BaseInterface_deleteRef(_throwaway_exception, &_throwaway_exception);
      return;
    }
    sidl_BaseException_deleteRef(_SIDLex, &_throwaway_exception);
    sidl_BaseInterface_deleteRef(*_ex, &_throwaway_exception);
    *_ex = NULL;
    if(_ex3) { 
      sidl_BaseInterface_deleteRef(_ex3, &_throwaway_exception);
      _ex3 = NULL;
    }
  } else if(_ex3) {
    _SIDLex = sidl_BaseException__cast(_ex3,&_throwaway_exception);
    sidl_rmi_Return_throwException(outArgs, _SIDLex, &_throwaway_exception); 
    if(_throwaway_exception) {
      /* Throwing failed throw _ex3 up the stack then. */
      sidl_BaseInterface_deleteRef(_throwaway_exception, &_throwaway_exception);
      return;
    }
    sidl_BaseException_deleteRef(_SIDLex, &_throwaway_exception);
    sidl_BaseInterface_deleteRef(_ex3, &_throwaway_exception);
    _ex3 = NULL;
  }
}

static void
ex2_ListC_isSame__exec(
        struct ex2_ListC__object* self,
        struct sidl_rmi_Call__object* inArgs,
        struct sidl_rmi_Return__object* outArgs,
        struct sidl_BaseInterface__object ** _ex) {
  /* stack space for arguments */
  char* iobj_str = NULL;
#ifndef WITH_RMI
  sidl_BaseClass iobj_bc = NULL;
#endif /* WITH_RMI */
  struct sidl_BaseInterface__object* iobj = NULL;
  sidl_bool _retval = FALSE;
  sidl_BaseInterface _throwaway_exception = NULL;
  sidl_BaseInterface _ex3   = NULL;
  sidl_BaseException _SIDLex = NULL;
  /* unpack in and inout argments */
  sidl_rmi_Call_unpackString( inArgs, "iobj", &iobj_str, _ex);SIDL_CHECK(*_ex);
#ifdef WITH_RMI

  iobj = skel_ex2_ListC_fconnect_sidl_BaseInterface(iobj_str, TRUE, 
    _ex);SIDL_CHECK(*_ex);
#else
  iobj_bc = sidl_rmi_InstanceRegistry_getInstanceByString(iobj_str, 
    _ex);SIDL_CHECK(*_ex);
  if(iobj_bc != NULL) {
    iobj= (struct ex2_ListC__object*) (*iobj_bc->d_epv->f__cast)(iobj_bc, 
      "ex2.ListC", _ex);
    if(iobj != NULL) {
      (((struct sidl_BaseInterface__object*)(iobj))->d_epv->f_deleteRef)(((
        struct sidl_BaseInterface__object*)iobj)->d_object, _ex); SIDL_CHECK(
        *_ex);
    } else {
      (*iobj_bc->d_epv->f_deleteRef)(iobj_bc, _ex);
    }
  }
#endif /* WITH_RMI */

  /* make the call */
  _retval = (self->d_epv->f_isSame)(
    self,
    iobj,
    _ex);  SIDL_CHECK(*_ex);

  /* pack return value */
  sidl_rmi_Return_packBool( outArgs, "_retval", _retval, _ex);SIDL_CHECK(*_ex);
  /* pack out and inout argments */
  EXIT:
  /* clean-up dangling references */
  if(iobj_str) {free(iobj_str);}
  if(iobj) {
    sidl_BaseInterface_deleteRef((sidl_BaseInterface)iobj, &_ex3); EXEC_CHECK(
      _ex3);
  }
  EXEC_ERR:
  if(*_ex) { 
    _SIDLex = sidl_BaseException__cast(*_ex,&_throwaway_exception);
    sidl_rmi_Return_throwException(outArgs, _SIDLex, &_throwaway_exception); 
    if(_throwaway_exception) {
      /* Throwing failed, throw _ex up the stack then. */
      sidl_BaseInterface_deleteRef(_throwaway_exception, &_throwaway_exception);
      return;
    }
    sidl_BaseException_deleteRef(_SIDLex, &_throwaway_exception);
    sidl_BaseInterface_deleteRef(*_ex, &_throwaway_exception);
    *_ex = NULL;
    if(_ex3) { 
      sidl_BaseInterface_deleteRef(_ex3, &_throwaway_exception);
      _ex3 = NULL;
    }
  } else if(_ex3) {
    _SIDLex = sidl_BaseException__cast(_ex3,&_throwaway_exception);
    sidl_rmi_Return_throwException(outArgs, _SIDLex, &_throwaway_exception); 
    if(_throwaway_exception) {
      /* Throwing failed throw _ex3 up the stack then. */
      sidl_BaseInterface_deleteRef(_throwaway_exception, &_throwaway_exception);
      return;
    }
    sidl_BaseException_deleteRef(_SIDLex, &_throwaway_exception);
    sidl_BaseInterface_deleteRef(_ex3, &_throwaway_exception);
    _ex3 = NULL;
  }
}

static void
ex2_ListC_isType__exec(
        struct ex2_ListC__object* self,
        struct sidl_rmi_Call__object* inArgs,
        struct sidl_rmi_Return__object* outArgs,
        struct sidl_BaseInterface__object ** _ex) {
  /* stack space for arguments */
  char* name= NULL;
  sidl_bool _retval = FALSE;
  sidl_BaseInterface _throwaway_exception = NULL;
  sidl_BaseInterface _ex3   = NULL;
  sidl_BaseException _SIDLex = NULL;
  /* unpack in and inout argments */
  sidl_rmi_Call_unpackString( inArgs, "name", &name, _ex);SIDL_CHECK(*_ex);

  /* make the call */
  _retval = (self->d_epv->f_isType)(
    self,
    name,
    _ex);  SIDL_CHECK(*_ex);

  /* pack return value */
  sidl_rmi_Return_packBool( outArgs, "_retval", _retval, _ex);SIDL_CHECK(*_ex);
  /* pack out and inout argments */
  EXIT:
  /* clean-up dangling references */
  if(name) {free(name);}
  if(*_ex) { 
    _SIDLex = sidl_BaseException__cast(*_ex,&_throwaway_exception);
    sidl_rmi_Return_throwException(outArgs, _SIDLex, &_throwaway_exception); 
    if(_throwaway_exception) {
      /* Throwing failed, throw _ex up the stack then. */
      sidl_BaseInterface_deleteRef(_throwaway_exception, &_throwaway_exception);
      return;
    }
    sidl_BaseException_deleteRef(_SIDLex, &_throwaway_exception);
    sidl_BaseInterface_deleteRef(*_ex, &_throwaway_exception);
    *_ex = NULL;
    if(_ex3) { 
      sidl_BaseInterface_deleteRef(_ex3, &_throwaway_exception);
      _ex3 = NULL;
    }
  } else if(_ex3) {
    _SIDLex = sidl_BaseException__cast(_ex3,&_throwaway_exception);
    sidl_rmi_Return_throwException(outArgs, _SIDLex, &_throwaway_exception); 
    if(_throwaway_exception) {
      /* Throwing failed throw _ex3 up the stack then. */
      sidl_BaseInterface_deleteRef(_throwaway_exception, &_throwaway_exception);
      return;
    }
    sidl_BaseException_deleteRef(_SIDLex, &_throwaway_exception);
    sidl_BaseInterface_deleteRef(_ex3, &_throwaway_exception);
    _ex3 = NULL;
  }
}

static void
ex2_ListC_getClassInfo__exec(
        struct ex2_ListC__object* self,
        struct sidl_rmi_Call__object* inArgs,
        struct sidl_rmi_Return__object* outArgs,
        struct sidl_BaseInterface__object ** _ex) {
  /* stack space for arguments */
  struct sidl_ClassInfo__object* _retval = NULL;
  sidl_BaseInterface _throwaway_exception = NULL;
  sidl_BaseInterface _ex3   = NULL;
  sidl_BaseException _SIDLex = NULL;
  /* unpack in and inout argments */

  /* make the call */
  _retval = (self->d_epv->f_getClassInfo)(
    self,
    _ex);  SIDL_CHECK(*_ex);

  /* pack return value */
  if(_retval){
    char* _url = sidl_BaseInterface__getURL((sidl_BaseInterface)_retval, 
      _ex);SIDL_CHECK(*_ex);
    sidl_rmi_Return_packString( outArgs, "_retval", _url, _ex);SIDL_CHECK(*_ex);
    free((void*)_url);
  } else {
    sidl_rmi_Return_packString( outArgs, "_retval", NULL, _ex);SIDL_CHECK(*_ex);
  }
  /* pack out and inout argments */
  EXIT:
  /* clean-up dangling references */
  if(_retval && sidl_BaseInterface__isRemote((sidl_BaseInterface)_retval, 
    &_throwaway_exception)) {
    (*((sidl_BaseInterface)_retval)->d_epv->f__raddRef)(((
      sidl_BaseInterface)_retval)->d_object, &_ex3); EXEC_CHECK(_ex3);
    sidl_BaseInterface_deleteRef((sidl_BaseInterface)_retval, &_ex3); 
      EXEC_CHECK(_ex3);
  }
  EXEC_ERR:
  if(*_ex) { 
    _SIDLex = sidl_BaseException__cast(*_ex,&_throwaway_exception);
    sidl_rmi_Return_throwException(outArgs, _SIDLex, &_throwaway_exception); 
    if(_throwaway_exception) {
      /* Throwing failed, throw _ex up the stack then. */
      sidl_BaseInterface_deleteRef(_throwaway_exception, &_throwaway_exception);
      return;
    }
    sidl_BaseException_deleteRef(_SIDLex, &_throwaway_exception);
    sidl_BaseInterface_deleteRef(*_ex, &_throwaway_exception);
    *_ex = NULL;
    if(_ex3) { 
      sidl_BaseInterface_deleteRef(_ex3, &_throwaway_exception);
      _ex3 = NULL;
    }
  } else if(_ex3) {
    _SIDLex = sidl_BaseException__cast(_ex3,&_throwaway_exception);
    sidl_rmi_Return_throwException(outArgs, _SIDLex, &_throwaway_exception); 
    if(_throwaway_exception) {
      /* Throwing failed throw _ex3 up the stack then. */
      sidl_BaseInterface_deleteRef(_throwaway_exception, &_throwaway_exception);
      return;
    }
    sidl_BaseException_deleteRef(_SIDLex, &_throwaway_exception);
    sidl_BaseInterface_deleteRef(_ex3, &_throwaway_exception);
    _ex3 = NULL;
  }
}

static void
ex2_ListC_insertNext__exec(
        struct ex2_ListC__object* self,
        struct sidl_rmi_Call__object* inArgs,
        struct sidl_rmi_Return__object* outArgs,
        struct sidl_BaseInterface__object ** _ex) {
  /* stack space for arguments */
  char* n_str = NULL;
#ifndef WITH_RMI
  sidl_BaseClass n_bc = NULL;
#endif /* WITH_RMI */
  struct ex2_ListNode__object* n = NULL;
  char* d_str = NULL;
#ifndef WITH_RMI
  sidl_BaseClass d_bc = NULL;
#endif /* WITH_RMI */
  struct ex2_Data__object* d = NULL;
  int32_t _retval = 0;
  sidl_BaseInterface _throwaway_exception = NULL;
  sidl_BaseInterface _ex3   = NULL;
  sidl_BaseException _SIDLex = NULL;
  /* unpack in and inout argments */
  sidl_rmi_Call_unpackString( inArgs, "n", &n_str, _ex);SIDL_CHECK(*_ex);
#ifdef WITH_RMI

  n = skel_ex2_ListC_fconnect_ex2_ListNode(n_str, TRUE, _ex);SIDL_CHECK(*_ex);
#else
  n_bc = sidl_rmi_InstanceRegistry_getInstanceByString(n_str, _ex);SIDL_CHECK(
    *_ex);
  if(n_bc != NULL) {
    n= (struct ex2_ListC__object*) (*n_bc->d_epv->f__cast)(n_bc, "ex2.ListC", 
      _ex);
    if(n != NULL) {
      (((struct sidl_BaseInterface__object*)(n))->d_epv->f_deleteRef)(((struct 
        sidl_BaseInterface__object*)n)->d_object, _ex); SIDL_CHECK(*_ex);
    } else {
      (*n_bc->d_epv->f_deleteRef)(n_bc, _ex);
    }
  }
#endif /* WITH_RMI */
  sidl_rmi_Call_unpackString( inArgs, "d", &d_str, _ex);SIDL_CHECK(*_ex);
#ifdef WITH_RMI

  d = skel_ex2_ListC_fconnect_ex2_Data(d_str, TRUE, _ex);SIDL_CHECK(*_ex);
#else
  d_bc = sidl_rmi_InstanceRegistry_getInstanceByString(d_str, _ex);SIDL_CHECK(
    *_ex);
  if(d_bc != NULL) {
    d= (struct ex2_ListC__object*) (*d_bc->d_epv->f__cast)(d_bc, "ex2.ListC", 
      _ex);
    if(d != NULL) {
      (((struct sidl_BaseInterface__object*)(d))->d_epv->f_deleteRef)(((struct 
        sidl_BaseInterface__object*)d)->d_object, _ex); SIDL_CHECK(*_ex);
    } else {
      (*d_bc->d_epv->f_deleteRef)(d_bc, _ex);
    }
  }
#endif /* WITH_RMI */

  /* make the call */
  _retval = (self->d_epv->f_insertNext)(
    self,
    n,
    d,
    _ex);  SIDL_CHECK(*_ex);

  /* pack return value */
  sidl_rmi_Return_packInt( outArgs, "_retval", _retval, _ex);SIDL_CHECK(*_ex);
  /* pack out and inout argments */
  EXIT:
  /* clean-up dangling references */
  if(n_str) {free(n_str);}
  if(n) {
    sidl_BaseInterface_deleteRef((sidl_BaseInterface)n, &_ex3); EXEC_CHECK(
      _ex3);
  }
  if(d_str) {free(d_str);}
  if(d) {
    sidl_BaseInterface_deleteRef((sidl_BaseInterface)d, &_ex3); EXEC_CHECK(
      _ex3);
  }
  EXEC_ERR:
  if(*_ex) { 
    _SIDLex = sidl_BaseException__cast(*_ex,&_throwaway_exception);
    sidl_rmi_Return_throwException(outArgs, _SIDLex, &_throwaway_exception); 
    if(_throwaway_exception) {
      /* Throwing failed, throw _ex up the stack then. */
      sidl_BaseInterface_deleteRef(_throwaway_exception, &_throwaway_exception);
      return;
    }
    sidl_BaseException_deleteRef(_SIDLex, &_throwaway_exception);
    sidl_BaseInterface_deleteRef(*_ex, &_throwaway_exception);
    *_ex = NULL;
    if(_ex3) { 
      sidl_BaseInterface_deleteRef(_ex3, &_throwaway_exception);
      _ex3 = NULL;
    }
  } else if(_ex3) {
    _SIDLex = sidl_BaseException__cast(_ex3,&_throwaway_exception);
    sidl_rmi_Return_throwException(outArgs, _SIDLex, &_throwaway_exception); 
    if(_throwaway_exception) {
      /* Throwing failed throw _ex3 up the stack then. */
      sidl_BaseInterface_deleteRef(_throwaway_exception, &_throwaway_exception);
      return;
    }
    sidl_BaseException_deleteRef(_SIDLex, &_throwaway_exception);
    sidl_BaseInterface_deleteRef(_ex3, &_throwaway_exception);
    _ex3 = NULL;
  }
}

static void
ex2_ListC_removeNext__exec(
        struct ex2_ListC__object* self,
        struct sidl_rmi_Call__object* inArgs,
        struct sidl_rmi_Return__object* outArgs,
        struct sidl_BaseInterface__object ** _ex) {
  /* stack space for arguments */
  char* n_str = NULL;
#ifndef WITH_RMI
  sidl_BaseClass n_bc = NULL;
#endif /* WITH_RMI */
  struct ex2_ListNode__object* n = NULL;
  struct ex2_Data__object* d_data = NULL;
  struct ex2_Data__object** d = &d_data;
  int32_t _retval = 0;
  sidl_BaseInterface _throwaway_exception = NULL;
  sidl_BaseInterface _ex3   = NULL;
  sidl_BaseException _SIDLex = NULL;
  /* unpack in and inout argments */
  sidl_rmi_Call_unpackString( inArgs, "n", &n_str, _ex);SIDL_CHECK(*_ex);
#ifdef WITH_RMI

  n = skel_ex2_ListC_fconnect_ex2_ListNode(n_str, TRUE, _ex);SIDL_CHECK(*_ex);
#else
  n_bc = sidl_rmi_InstanceRegistry_getInstanceByString(n_str, _ex);SIDL_CHECK(
    *_ex);
  if(n_bc != NULL) {
    n= (struct ex2_ListC__object*) (*n_bc->d_epv->f__cast)(n_bc, "ex2.ListC", 
      _ex);
    if(n != NULL) {
      (((struct sidl_BaseInterface__object*)(n))->d_epv->f_deleteRef)(((struct 
        sidl_BaseInterface__object*)n)->d_object, _ex); SIDL_CHECK(*_ex);
    } else {
      (*n_bc->d_epv->f_deleteRef)(n_bc, _ex);
    }
  }
#endif /* WITH_RMI */

  /* make the call */
  _retval = (self->d_epv->f_removeNext)(
    self,
    n,
    d,
    _ex);  SIDL_CHECK(*_ex);

  /* pack return value */
  sidl_rmi_Return_packInt( outArgs, "_retval", _retval, _ex);SIDL_CHECK(*_ex);
  /* pack out and inout argments */
  if(*d){
    char* _url = sidl_BaseInterface__getURL((sidl_BaseInterface)*d, 
      _ex);SIDL_CHECK(*_ex);
    sidl_rmi_Return_packString( outArgs, "d", _url, _ex);SIDL_CHECK(*_ex);
    free((void*)_url);
  } else {
    sidl_rmi_Return_packString( outArgs, "d", NULL, _ex);SIDL_CHECK(*_ex);
  }
  EXIT:
  /* clean-up dangling references */
  if(n_str) {free(n_str);}
  if(n) {
    sidl_BaseInterface_deleteRef((sidl_BaseInterface)n, &_ex3); EXEC_CHECK(
      _ex3);
  }
  if(*d && sidl_BaseInterface__isRemote((sidl_BaseInterface)*d, 
    &_throwaway_exception)) {
    (*((sidl_BaseInterface)*d)->d_epv->f__raddRef)(((
      sidl_BaseInterface)*d)->d_object, &_ex3); EXEC_CHECK(_ex3);
    sidl_BaseInterface_deleteRef((sidl_BaseInterface)*d, &_ex3); EXEC_CHECK(
      _ex3);
  }
  EXEC_ERR:
  if(*_ex) { 
    _SIDLex = sidl_BaseException__cast(*_ex,&_throwaway_exception);
    sidl_rmi_Return_throwException(outArgs, _SIDLex, &_throwaway_exception); 
    if(_throwaway_exception) {
      /* Throwing failed, throw _ex up the stack then. */
      sidl_BaseInterface_deleteRef(_throwaway_exception, &_throwaway_exception);
      return;
    }
    sidl_BaseException_deleteRef(_SIDLex, &_throwaway_exception);
    sidl_BaseInterface_deleteRef(*_ex, &_throwaway_exception);
    *_ex = NULL;
    if(_ex3) { 
      sidl_BaseInterface_deleteRef(_ex3, &_throwaway_exception);
      _ex3 = NULL;
    }
  } else if(_ex3) {
    _SIDLex = sidl_BaseException__cast(_ex3,&_throwaway_exception);
    sidl_rmi_Return_throwException(outArgs, _SIDLex, &_throwaway_exception); 
    if(_throwaway_exception) {
      /* Throwing failed throw _ex3 up the stack then. */
      sidl_BaseInterface_deleteRef(_throwaway_exception, &_throwaway_exception);
      return;
    }
    sidl_BaseException_deleteRef(_SIDLex, &_throwaway_exception);
    sidl_BaseInterface_deleteRef(_ex3, &_throwaway_exception);
    _ex3 = NULL;
  }
}

static void
ex2_ListC_getSize__exec(
        struct ex2_ListC__object* self,
        struct sidl_rmi_Call__object* inArgs,
        struct sidl_rmi_Return__object* outArgs,
        struct sidl_BaseInterface__object ** _ex) {
  /* stack space for arguments */
  int32_t _retval = 0;
  sidl_BaseInterface _throwaway_exception = NULL;
  sidl_BaseInterface _ex3   = NULL;
  sidl_BaseException _SIDLex = NULL;
  /* unpack in and inout argments */

  /* make the call */
  _retval = (self->d_epv->f_getSize)(
    self,
    _ex);  SIDL_CHECK(*_ex);

  /* pack return value */
  sidl_rmi_Return_packInt( outArgs, "_retval", _retval, _ex);SIDL_CHECK(*_ex);
  /* pack out and inout argments */
  EXIT:
  /* clean-up dangling references */
  if(*_ex) { 
    _SIDLex = sidl_BaseException__cast(*_ex,&_throwaway_exception);
    sidl_rmi_Return_throwException(outArgs, _SIDLex, &_throwaway_exception); 
    if(_throwaway_exception) {
      /* Throwing failed, throw _ex up the stack then. */
      sidl_BaseInterface_deleteRef(_throwaway_exception, &_throwaway_exception);
      return;
    }
    sidl_BaseException_deleteRef(_SIDLex, &_throwaway_exception);
    sidl_BaseInterface_deleteRef(*_ex, &_throwaway_exception);
    *_ex = NULL;
    if(_ex3) { 
      sidl_BaseInterface_deleteRef(_ex3, &_throwaway_exception);
      _ex3 = NULL;
    }
  } else if(_ex3) {
    _SIDLex = sidl_BaseException__cast(_ex3,&_throwaway_exception);
    sidl_rmi_Return_throwException(outArgs, _SIDLex, &_throwaway_exception); 
    if(_throwaway_exception) {
      /* Throwing failed throw _ex3 up the stack then. */
      sidl_BaseInterface_deleteRef(_throwaway_exception, &_throwaway_exception);
      return;
    }
    sidl_BaseException_deleteRef(_SIDLex, &_throwaway_exception);
    sidl_BaseInterface_deleteRef(_ex3, &_throwaway_exception);
    _ex3 = NULL;
  }
}

static void
ex2_ListC_getDataAt__exec(
        struct ex2_ListC__object* self,
        struct sidl_rmi_Call__object* inArgs,
        struct sidl_rmi_Return__object* outArgs,
        struct sidl_BaseInterface__object ** _ex) {
  /* stack space for arguments */
  int32_t index = 0;
  struct ex2_Data__object* _retval = NULL;
  sidl_BaseInterface _throwaway_exception = NULL;
  sidl_BaseInterface _ex3   = NULL;
  sidl_BaseException _SIDLex = NULL;
  /* unpack in and inout argments */
  sidl_rmi_Call_unpackInt( inArgs, "index", &index, _ex);SIDL_CHECK(*_ex);

  /* make the call */
  _retval = (self->d_epv->f_getDataAt)(
    self,
    index,
    _ex);  SIDL_CHECK(*_ex);

  /* pack return value */
  if(_retval){
    char* _url = sidl_BaseInterface__getURL((sidl_BaseInterface)_retval, 
      _ex);SIDL_CHECK(*_ex);
    sidl_rmi_Return_packString( outArgs, "_retval", _url, _ex);SIDL_CHECK(*_ex);
    free((void*)_url);
  } else {
    sidl_rmi_Return_packString( outArgs, "_retval", NULL, _ex);SIDL_CHECK(*_ex);
  }
  /* pack out and inout argments */
  EXIT:
  /* clean-up dangling references */
  if(_retval && sidl_BaseInterface__isRemote((sidl_BaseInterface)_retval, 
    &_throwaway_exception)) {
    (*((sidl_BaseInterface)_retval)->d_epv->f__raddRef)(((
      sidl_BaseInterface)_retval)->d_object, &_ex3); EXEC_CHECK(_ex3);
    sidl_BaseInterface_deleteRef((sidl_BaseInterface)_retval, &_ex3); 
      EXEC_CHECK(_ex3);
  }
  EXEC_ERR:
  if(*_ex) { 
    _SIDLex = sidl_BaseException__cast(*_ex,&_throwaway_exception);
    sidl_rmi_Return_throwException(outArgs, _SIDLex, &_throwaway_exception); 
    if(_throwaway_exception) {
      /* Throwing failed, throw _ex up the stack then. */
      sidl_BaseInterface_deleteRef(_throwaway_exception, &_throwaway_exception);
      return;
    }
    sidl_BaseException_deleteRef(_SIDLex, &_throwaway_exception);
    sidl_BaseInterface_deleteRef(*_ex, &_throwaway_exception);
    *_ex = NULL;
    if(_ex3) { 
      sidl_BaseInterface_deleteRef(_ex3, &_throwaway_exception);
      _ex3 = NULL;
    }
  } else if(_ex3) {
    _SIDLex = sidl_BaseException__cast(_ex3,&_throwaway_exception);
    sidl_rmi_Return_throwException(outArgs, _SIDLex, &_throwaway_exception); 
    if(_throwaway_exception) {
      /* Throwing failed throw _ex3 up the stack then. */
      sidl_BaseInterface_deleteRef(_throwaway_exception, &_throwaway_exception);
      return;
    }
    sidl_BaseException_deleteRef(_SIDLex, &_throwaway_exception);
    sidl_BaseInterface_deleteRef(_ex3, &_throwaway_exception);
    _ex3 = NULL;
  }
}

static void
ex2_ListC_getHead__exec(
        struct ex2_ListC__object* self,
        struct sidl_rmi_Call__object* inArgs,
        struct sidl_rmi_Return__object* outArgs,
        struct sidl_BaseInterface__object ** _ex) {
  /* stack space for arguments */
  struct ex2_ListNode__object* _retval = NULL;
  sidl_BaseInterface _throwaway_exception = NULL;
  sidl_BaseInterface _ex3   = NULL;
  sidl_BaseException _SIDLex = NULL;
  /* unpack in and inout argments */

  /* make the call */
  _retval = (self->d_epv->f_getHead)(
    self,
    _ex);  SIDL_CHECK(*_ex);

  /* pack return value */
  if(_retval){
    char* _url = sidl_BaseInterface__getURL((sidl_BaseInterface)_retval, 
      _ex);SIDL_CHECK(*_ex);
    sidl_rmi_Return_packString( outArgs, "_retval", _url, _ex);SIDL_CHECK(*_ex);
    free((void*)_url);
  } else {
    sidl_rmi_Return_packString( outArgs, "_retval", NULL, _ex);SIDL_CHECK(*_ex);
  }
  /* pack out and inout argments */
  EXIT:
  /* clean-up dangling references */
  if(_retval && sidl_BaseInterface__isRemote((sidl_BaseInterface)_retval, 
    &_throwaway_exception)) {
    (*((sidl_BaseInterface)_retval)->d_epv->f__raddRef)(((
      sidl_BaseInterface)_retval)->d_object, &_ex3); EXEC_CHECK(_ex3);
    sidl_BaseInterface_deleteRef((sidl_BaseInterface)_retval, &_ex3); 
      EXEC_CHECK(_ex3);
  }
  EXEC_ERR:
  if(*_ex) { 
    _SIDLex = sidl_BaseException__cast(*_ex,&_throwaway_exception);
    sidl_rmi_Return_throwException(outArgs, _SIDLex, &_throwaway_exception); 
    if(_throwaway_exception) {
      /* Throwing failed, throw _ex up the stack then. */
      sidl_BaseInterface_deleteRef(_throwaway_exception, &_throwaway_exception);
      return;
    }
    sidl_BaseException_deleteRef(_SIDLex, &_throwaway_exception);
    sidl_BaseInterface_deleteRef(*_ex, &_throwaway_exception);
    *_ex = NULL;
    if(_ex3) { 
      sidl_BaseInterface_deleteRef(_ex3, &_throwaway_exception);
      _ex3 = NULL;
    }
  } else if(_ex3) {
    _SIDLex = sidl_BaseException__cast(_ex3,&_throwaway_exception);
    sidl_rmi_Return_throwException(outArgs, _SIDLex, &_throwaway_exception); 
    if(_throwaway_exception) {
      /* Throwing failed throw _ex3 up the stack then. */
      sidl_BaseInterface_deleteRef(_throwaway_exception, &_throwaway_exception);
      return;
    }
    sidl_BaseException_deleteRef(_SIDLex, &_throwaway_exception);
    sidl_BaseInterface_deleteRef(_ex3, &_throwaway_exception);
    _ex3 = NULL;
  }
}

static void
ex2_ListC_getTail__exec(
        struct ex2_ListC__object* self,
        struct sidl_rmi_Call__object* inArgs,
        struct sidl_rmi_Return__object* outArgs,
        struct sidl_BaseInterface__object ** _ex) {
  /* stack space for arguments */
  struct ex2_ListNode__object* _retval = NULL;
  sidl_BaseInterface _throwaway_exception = NULL;
  sidl_BaseInterface _ex3   = NULL;
  sidl_BaseException _SIDLex = NULL;
  /* unpack in and inout argments */

  /* make the call */
  _retval = (self->d_epv->f_getTail)(
    self,
    _ex);  SIDL_CHECK(*_ex);

  /* pack return value */
  if(_retval){
    char* _url = sidl_BaseInterface__getURL((sidl_BaseInterface)_retval, 
      _ex);SIDL_CHECK(*_ex);
    sidl_rmi_Return_packString( outArgs, "_retval", _url, _ex);SIDL_CHECK(*_ex);
    free((void*)_url);
  } else {
    sidl_rmi_Return_packString( outArgs, "_retval", NULL, _ex);SIDL_CHECK(*_ex);
  }
  /* pack out and inout argments */
  EXIT:
  /* clean-up dangling references */
  if(_retval && sidl_BaseInterface__isRemote((sidl_BaseInterface)_retval, 
    &_throwaway_exception)) {
    (*((sidl_BaseInterface)_retval)->d_epv->f__raddRef)(((
      sidl_BaseInterface)_retval)->d_object, &_ex3); EXEC_CHECK(_ex3);
    sidl_BaseInterface_deleteRef((sidl_BaseInterface)_retval, &_ex3); 
      EXEC_CHECK(_ex3);
  }
  EXEC_ERR:
  if(*_ex) { 
    _SIDLex = sidl_BaseException__cast(*_ex,&_throwaway_exception);
    sidl_rmi_Return_throwException(outArgs, _SIDLex, &_throwaway_exception); 
    if(_throwaway_exception) {
      /* Throwing failed, throw _ex up the stack then. */
      sidl_BaseInterface_deleteRef(_throwaway_exception, &_throwaway_exception);
      return;
    }
    sidl_BaseException_deleteRef(_SIDLex, &_throwaway_exception);
    sidl_BaseInterface_deleteRef(*_ex, &_throwaway_exception);
    *_ex = NULL;
    if(_ex3) { 
      sidl_BaseInterface_deleteRef(_ex3, &_throwaway_exception);
      _ex3 = NULL;
    }
  } else if(_ex3) {
    _SIDLex = sidl_BaseException__cast(_ex3,&_throwaway_exception);
    sidl_rmi_Return_throwException(outArgs, _SIDLex, &_throwaway_exception); 
    if(_throwaway_exception) {
      /* Throwing failed throw _ex3 up the stack then. */
      sidl_BaseInterface_deleteRef(_throwaway_exception, &_throwaway_exception);
      return;
    }
    sidl_BaseException_deleteRef(_SIDLex, &_throwaway_exception);
    sidl_BaseInterface_deleteRef(_ex3, &_throwaway_exception);
    _ex3 = NULL;
  }
}

static void
ex2_ListC__cast__exec(
        struct ex2_ListC__object* self,
        struct sidl_rmi_Call__object* inArgs,
        struct sidl_rmi_Return__object* outArgs,
        struct sidl_BaseInterface__object ** _ex) {
  /* stack space for arguments */
  char* name= NULL;
  void* _retval = 0;
  sidl_BaseInterface _throwaway_exception = NULL;
  sidl_BaseInterface _ex3   = NULL;
  sidl_BaseException _SIDLex = NULL;
  /* unpack in and inout argments */
  sidl_rmi_Call_unpackString( inArgs, "name", &name, _ex);SIDL_CHECK(*_ex);

  /* make the call */
  _retval = (self->d_epv->f__cast)(
    self,
    name,
    _ex);  SIDL_CHECK(*_ex);

  /* pack return value */
  sidl_rmi_Return_packOpaque( outArgs, "_retval", _retval, _ex);SIDL_CHECK(
    *_ex);
  /* pack out and inout argments */
  EXIT:
  /* clean-up dangling references */
  if(name) {free(name);}
  if(*_ex) { 
    _SIDLex = sidl_BaseException__cast(*_ex,&_throwaway_exception);
    sidl_rmi_Return_throwException(outArgs, _SIDLex, &_throwaway_exception); 
    if(_throwaway_exception) {
      /* Throwing failed, throw _ex up the stack then. */
      sidl_BaseInterface_deleteRef(_throwaway_exception, &_throwaway_exception);
      return;
    }
    sidl_BaseException_deleteRef(_SIDLex, &_throwaway_exception);
    sidl_BaseInterface_deleteRef(*_ex, &_throwaway_exception);
    *_ex = NULL;
    if(_ex3) { 
      sidl_BaseInterface_deleteRef(_ex3, &_throwaway_exception);
      _ex3 = NULL;
    }
  } else if(_ex3) {
    _SIDLex = sidl_BaseException__cast(_ex3,&_throwaway_exception);
    sidl_rmi_Return_throwException(outArgs, _SIDLex, &_throwaway_exception); 
    if(_throwaway_exception) {
      /* Throwing failed throw _ex3 up the stack then. */
      sidl_BaseInterface_deleteRef(_throwaway_exception, &_throwaway_exception);
      return;
    }
    sidl_BaseException_deleteRef(_SIDLex, &_throwaway_exception);
    sidl_BaseInterface_deleteRef(_ex3, &_throwaway_exception);
    _ex3 = NULL;
  }
}

/*
 * CHECKS: Enable/disable contract enforcement.
 */

static void ior_ex2_ListC__set_contracts(
  struct ex2_ListC__object* self,
  sidl_bool   enable,
  const char* enfFilename,
  sidl_bool   resetCounters,
  struct sidl_BaseInterface__object **_ex)
{
  *_ex  = NULL;
  {
    struct ex2_ListC__method_desc *md;
    struct ex2_ListC__inv_desc *invd= 
      &s_ior_ex2_ListC_inv;
    struct ex2_ListC__method_cstats *ms;

    char*  filename = (enfFilename) ? enfFilename
                    : "ex2_ListC.dat";
    FILE*  fptr   = NULL;
    int    ind, invc, prec, posc;
    double invt, mt, pret, post;

    self->d_cstats.enabled = enable;

    if (filename) {
      fptr = fopen(filename, "r");
      if (fptr == NULL) {
        printf("WARNING: Cannot open %s to read contract enforcement metrics\n",
          filename);
      } else {
        /*
         * The first line is assumed to contain the invariant complexity and average enforcement cost.
         */

        if (fscanf(fptr, "%d %lf\n", &invc, &invt) != EOF) {
          invd->inv_complexity = invc;
          invd->inv_exec_time  = invt;
        }

        while (fscanf(fptr, "%d %d %d %lf %lf %lf\n",
          &ind, &prec, &posc, &mt, &pret, &post) != EOF)
        {
          if (  (s_IOR_EX2_LISTC_MIN <= ind)
             && (ind <= s_IOR_EX2_LISTC_MAX) ) {
            md = &s_ior_ex2_ListC_method[ind];
            md->pre_complexity  = prec;
            md->post_complexity = posc;
            md->meth_exec_time  = mt;
            md->pre_exec_time   = pret;
            md->post_exec_time  = post;
          } else {
            printf("Invalid method index, %d, in contract  metrics file %s\n",
              ind, filename);
            return;
          }
        }
        fclose(fptr);
      }
    }

    if (resetCounters) {
      int i;
      for (i =s_IOR_EX2_LISTC_MIN;
           i<=s_IOR_EX2_LISTC_MAX; i++) {
        ms = &self->d_cstats.method_cstats[i];
        ms->tries          = 0;
        ms->successes      = 0;
        ms->failures       = 0;
        ms->nonvio_exceptions = 0;

        md = &s_ior_ex2_ListC_method[i];
        RESETCD(md);
      }
    }

    /* Ensure the EPVs are set properly. */
    if (enable) {
      self->d_epv               = &s_my_epv_contracts__ex2_listc;
    } else {
      self->d_epv               = &s_my_epv__ex2_listc;
    }
  }
}

/*
 * DUMP: Dump interface contract enforcement statistics.
 */

static void ior_ex2_ListC__dump_stats(
  struct ex2_ListC__object* self,
  const char* filename,
  const char* prefix,
  struct sidl_BaseInterface__object **_ex)
{
  *_ex = NULL;
  {
    struct ex2_ListC__method_cstats *ms;

    int       i;
    sidl_bool firstTime = FALSE;
    sidl_bool reported  = FALSE;
    char*     fname     = (filename) ? filename : "ContractStats.out";

    if (s_dump_fptr == NULL) {
      firstTime = TRUE;
      if ((s_dump_fptr=fopen(fname,"w")) == NULL) {
        printf("Cannot open file %s to dump the interface contract enforcement statistics.\n",fname);
        return;
      }
    }

    if (firstTime) {
      sidl_Enforcer_dumpStatsHeader(s_dump_fptr, FALSE);
      fprintf(s_dump_fptr, "; Method; Checked; Okay; Violated; MethExcepts\n\n");
    }

    for (i = s_IOR_EX2_LISTC_MIN;
         i<=s_IOR_EX2_LISTC_MAX; i++) {
      ms = &self->d_cstats.method_cstats[i];
      if (  (!s_ior_ex2_ListC_method[i].is_static) 
         && (ms->tries > 0) ) {
        reported = TRUE;
        sidl_Enforcer_dumpStatsData(s_dump_fptr, prefix, FALSE);
        fprintf(s_dump_fptr, "; %s; %d; %d; %d; %d\n",
            s_ior_ex2_ListC_method[i].name,
            ms->tries,
            ms->successes,
            ms->failures,
            ms->nonvio_exceptions);
      }
    }

    if (reported) {
      fprintf(s_dump_fptr, "\n");
    } else {
      sidl_Enforcer_dumpStatsData(s_dump_fptr, prefix, FALSE);
      fprintf(s_dump_fptr, "; No attempts to enforce contracts detected\n\n");
    }

    fflush(s_dump_fptr);
    return;
  }
}

/*
 * Check relevant contracts, if any, before and after the method call.
 */

static void check_ex2_ListC_boccaForceUsePortInclude(
  /* in */ struct ex2_ListC__object* self,
  /* in */ struct ex2_ListNodeC__object* dummy0,
  /* in */ struct ex2_ListNode__object* dummy1,
  /* in */ struct ex2_Data__object* dummy2,
  /* out */ struct sidl_BaseInterface__object **_ex)
{
  struct ex2_ListC__epv* epv = &s_my_epv__ex2_listc;

  (epv->f_boccaForceUsePortInclude)(
      self,
      dummy0,
      dummy1,
      dummy2,
      _ex);
}

/*
 * Check relevant contracts, if any, before and after the method call.
 */

static void check_ex2_ListC_addRef(
  /* in */ struct ex2_ListC__object* self,
  /* out */ struct sidl_BaseInterface__object **_ex)
{
  struct ex2_ListC__epv* epv = &s_my_epv__ex2_listc;

  (epv->f_addRef)(
      self,
      _ex);
}

/*
 * Check relevant contracts, if any, before and after the method call.
 */

static void check_ex2_ListC_deleteRef(
  /* in */ struct ex2_ListC__object* self,
  /* out */ struct sidl_BaseInterface__object **_ex)
{
  struct ex2_ListC__epv* epv = &s_my_epv__ex2_listc;

  (epv->f_deleteRef)(
      self,
      _ex);
}

/*
 * Check relevant contracts, if any, before and after the method call.
 */

static sidl_bool check_ex2_ListC_isSame(
  /* in */ struct ex2_ListC__object* self,
  /* in */ struct sidl_BaseInterface__object* iobj,
  /* out */ struct sidl_BaseInterface__object **_ex)
{
  sidl_bool _retval = FALSE;
  struct ex2_ListC__epv* epv = &s_my_epv__ex2_listc;

  _retval = (epv->f_isSame)(
      self,
      iobj,
      _ex);

  return _retval;
}

/*
 * Check relevant contracts, if any, before and after the method call.
 */

static sidl_bool check_ex2_ListC_isType(
  /* in */ struct ex2_ListC__object* self,
  /* in */ const char* name,
  /* out */ struct sidl_BaseInterface__object **_ex)
{
  sidl_bool _retval = FALSE;
  struct ex2_ListC__epv* epv = &s_my_epv__ex2_listc;

  _retval = (epv->f_isType)(
      self,
      name,
      _ex);

  return _retval;
}

/*
 * Check relevant contracts, if any, before and after the method call.
 */

static struct sidl_ClassInfo__object* check_ex2_ListC_getClassInfo(
  /* in */ struct ex2_ListC__object* self,
  /* out */ struct sidl_BaseInterface__object **_ex)
{
  struct sidl_ClassInfo__object* _retval = 0;
  struct ex2_ListC__epv* epv = &s_my_epv__ex2_listc;

  _retval = (epv->f_getClassInfo)(
      self,
      _ex);

  return _retval;
}

/*
 * Check relevant contracts, if any, before and after the method call.
 */

static int32_t check_ex2_ListC_insertNext(
  /* in */ struct ex2_ListC__object* self,
  /* in */ struct ex2_ListNode__object* n,
  /* in */ struct ex2_Data__object* d,
  /* out */ struct sidl_BaseInterface__object **_ex)
{
  int32_t _retval = 0;
  struct ex2_ListC__epv* epv = &s_my_epv__ex2_listc;

  _retval = (epv->f_insertNext)(
      self,
      n,
      d,
      _ex);

  return _retval;
}

/*
 * Check relevant contracts, if any, before and after the method call.
 */

static int32_t check_ex2_ListC_removeNext(
  /* in */ struct ex2_ListC__object* self,
  /* in */ struct ex2_ListNode__object* n,
  /* out */ struct ex2_Data__object** d,
  /* out */ struct sidl_BaseInterface__object **_ex)
{
  int32_t _retval = 0;
  struct ex2_ListC__epv* epv = &s_my_epv__ex2_listc;

  int     cOkay    = 1;

  double  methAvg = 0.0;
  double  cAvg    = 0.0;
  int     cComp   = 0;

  struct sidl_BaseInterface__object *tae = NULL;

  char*   cName = "ex2_ListC";

  struct sidl_PreViolation__object *pre_err;
  struct timeval ts0, ts1, ts2;


  struct ex2_ListC__method_cstats *ms = 
    &self->d_cstats.method_cstats[s_IOR_EX2_LISTC_REMOVENEXT];
  struct ex2_ListC__method_desc *md = 
    &s_ior_ex2_ListC_method[s_IOR_EX2_LISTC_REMOVENEXT];
  (*_ex)  = NULL;

  if (md->est_interval > 1) {
    methAvg = md->meth_exec_time;
    cAvg    = md->pre_exec_time;
    cComp   = md->pre_complexity;
    if (sidl_Enforcer_enforceClause(TRUE, sidl_ClauseType_PRECONDITION, cComp, 
      TRUE, FALSE, methAvg, cAvg)) {
      (ms->tries) += 1;
      if (!( ((self->d_epv->f_getSize)(self, _ex)) > (0) )) {
        cOkay  = 0;
        if ((*_ex) == NULL) {
          pre_err = sidl_PreViolation__create(&tae);
          sidl_PreViolation_setNote(pre_err,
            "REQUIRE VIOLATION: .ex2.ListOps: removeNext: not_empty: getSize() > 0.", 
            &tae);
          (*_ex) = sidl_BaseInterface__cast(pre_err, &tae);
          sidl_PreViolation_deleteRef(pre_err, &tae);
        }
      }

      SIDL_INCR_IF_THEN(cOkay,ms->successes,ms->failures)
    }


#ifdef SIDL_NO_DISPATCH_ON_VIOLATION
    if (cOkay) {
#endif /* SIDL_NO_DISPATCH_ON_VIOLATION */
      _retval = (epv->f_removeNext)(
          self,
          n,
          d,
          _ex);
      if ((*_ex) != NULL) {
        (ms->nonvio_exceptions) += 1;
        return _retval;
      }

#ifdef SIDL_NO_DISPATCH_ON_VIOLATION
    }
#endif /* SIDL_NO_DISPATCH_ON_VIOLATION */


    (md->est_interval) -= 1;
  } else {
    gettimeofday(&ts0, NULL);
    methAvg = md->meth_exec_time;
    cAvg    = md->pre_exec_time;
    cComp   = md->pre_complexity;
    if (sidl_Enforcer_enforceClause(TRUE, sidl_ClauseType_PRECONDITION, cComp, 
      TRUE, FALSE, methAvg, cAvg)) {
      (ms->tries) += 1;
      if (!( ((self->d_epv->f_getSize)(self, _ex)) > (0) )) {
        cOkay  = 0;
        if ((*_ex) == NULL) {
          pre_err = sidl_PreViolation__create(&tae);
          sidl_PreViolation_setNote(pre_err,
            "REQUIRE VIOLATION: .ex2.ListOps: removeNext: not_empty: getSize() > 0.", 
            &tae);
          (*_ex) = sidl_BaseInterface__cast(pre_err, &tae);
          sidl_PreViolation_deleteRef(pre_err, &tae);
        }
      }

      SIDL_INCR_IF_THEN(cOkay,ms->successes,ms->failures)
    }

    gettimeofday(&ts1, NULL);

#ifdef SIDL_NO_DISPATCH_ON_VIOLATION
    if (cOkay) {
#endif /* SIDL_NO_DISPATCH_ON_VIOLATION */
      _retval = (epv->f_removeNext)(
          self,
          n,
          d,
          _ex);
      if ((*_ex) != NULL) {
        (ms->nonvio_exceptions) += 1;
        gettimeofday(&ts2, NULL);
        if (!sidl_Enforcer_areTracing()) {
          md->pre_exec_time = SIDL_DIFF_MICROSECONDS(ts1, ts0);
          md->meth_exec_time = SIDL_DIFF_MICROSECONDS(ts2, ts1);
          md->post_exec_time = 0.0;
        } else {
          TRACE(cName, md, s_IOR_EX2_LISTC_REMOVENEXT, 0, 0, 0, 
            SIDL_DIFF_MICROSECONDS(ts2, ts1), SIDL_DIFF_MICROSECONDS(ts1, ts0), 
            0.0, 0.0, 0.0);
        }

        return _retval;
      }

#ifdef SIDL_NO_DISPATCH_ON_VIOLATION
    }
#endif /* SIDL_NO_DISPATCH_ON_VIOLATION */

    gettimeofday(&ts2, NULL);

    if (!sidl_Enforcer_areTracing()) {
      md->pre_exec_time = SIDL_DIFF_MICROSECONDS(ts1, ts0);
      md->meth_exec_time = SIDL_DIFF_MICROSECONDS(ts2, ts1);
      md->post_exec_time = 0.0;
    } else {
      TRACE(cName, md, s_IOR_EX2_LISTC_REMOVENEXT, 0, 0, 0, 
        SIDL_DIFF_MICROSECONDS(ts2, ts1), SIDL_DIFF_MICROSECONDS(ts1, ts0), 0.0,
        0.0, 0.0);
    }
    RESETCD(md)
  }

  return _retval;
}

/*
 * Check relevant contracts, if any, before and after the method call.
 */

static int32_t check_ex2_ListC_getSize(
  /* in */ struct ex2_ListC__object* self,
  /* out */ struct sidl_BaseInterface__object **_ex)
{
  int32_t _retval = 0;
  struct ex2_ListC__epv* epv = &s_my_epv__ex2_listc;

  _retval = (epv->f_getSize)(
      self,
      _ex);

  return _retval;
}

/*
 * Check relevant contracts, if any, before and after the method call.
 */

static struct ex2_Data__object* check_ex2_ListC_getDataAt(
  /* in */ struct ex2_ListC__object* self,
  /* in */ int32_t index,
  /* out */ struct sidl_BaseInterface__object **_ex)
{
  struct ex2_Data__object* _retval = 0;
  struct ex2_ListC__epv* epv = &s_my_epv__ex2_listc;

  int     cOkay    = 1;

  double  methAvg = 0.0;
  double  cAvg    = 0.0;
  int     cComp   = 0;

  struct sidl_BaseInterface__object *tae = NULL;

  char*   cName = "ex2_ListC";

  struct sidl_PreViolation__object *pre_err;
  struct timeval ts0, ts1, ts2;


  struct ex2_ListC__method_cstats *ms = 
    &self->d_cstats.method_cstats[s_IOR_EX2_LISTC_GETDATAAT];
  struct ex2_ListC__method_desc *md = 
    &s_ior_ex2_ListC_method[s_IOR_EX2_LISTC_GETDATAAT];
  (*_ex)  = NULL;

  if (md->est_interval > 1) {
    methAvg = md->meth_exec_time;
    cAvg    = md->pre_exec_time;
    cComp   = md->pre_complexity;
    if (sidl_Enforcer_enforceClause(TRUE, sidl_ClauseType_PRECONDITION, cComp, 
      TRUE, FALSE, methAvg, cAvg)) {
      (ms->tries) += 1;
      if (!( (index) < ((self->d_epv->f_getSize)(self, _ex)) )) {
        cOkay  = 0;
        if ((*_ex) == NULL) {
          pre_err = sidl_PreViolation__create(&tae);
          sidl_PreViolation_setNote(pre_err,
            "REQUIRE VIOLATION: .ex2.ListOps: getDataAt: valid_index: index < getSize().", 
            &tae);
          (*_ex) = sidl_BaseInterface__cast(pre_err, &tae);
          sidl_PreViolation_deleteRef(pre_err, &tae);
        }
      }

      SIDL_INCR_IF_THEN(cOkay,ms->successes,ms->failures)
    }


#ifdef SIDL_NO_DISPATCH_ON_VIOLATION
    if (cOkay) {
#endif /* SIDL_NO_DISPATCH_ON_VIOLATION */
      _retval = (epv->f_getDataAt)(
          self,
          index,
          _ex);
      if ((*_ex) != NULL) {
        (ms->nonvio_exceptions) += 1;
        return _retval;
      }

#ifdef SIDL_NO_DISPATCH_ON_VIOLATION
    }
#endif /* SIDL_NO_DISPATCH_ON_VIOLATION */


    (md->est_interval) -= 1;
  } else {
    gettimeofday(&ts0, NULL);
    methAvg = md->meth_exec_time;
    cAvg    = md->pre_exec_time;
    cComp   = md->pre_complexity;
    if (sidl_Enforcer_enforceClause(TRUE, sidl_ClauseType_PRECONDITION, cComp, 
      TRUE, FALSE, methAvg, cAvg)) {
      (ms->tries) += 1;
      if (!( (index) < ((self->d_epv->f_getSize)(self, _ex)) )) {
        cOkay  = 0;
        if ((*_ex) == NULL) {
          pre_err = sidl_PreViolation__create(&tae);
          sidl_PreViolation_setNote(pre_err,
            "REQUIRE VIOLATION: .ex2.ListOps: getDataAt: valid_index: index < getSize().", 
            &tae);
          (*_ex) = sidl_BaseInterface__cast(pre_err, &tae);
          sidl_PreViolation_deleteRef(pre_err, &tae);
        }
      }

      SIDL_INCR_IF_THEN(cOkay,ms->successes,ms->failures)
    }

    gettimeofday(&ts1, NULL);

#ifdef SIDL_NO_DISPATCH_ON_VIOLATION
    if (cOkay) {
#endif /* SIDL_NO_DISPATCH_ON_VIOLATION */
      _retval = (epv->f_getDataAt)(
          self,
          index,
          _ex);
      if ((*_ex) != NULL) {
        (ms->nonvio_exceptions) += 1;
        gettimeofday(&ts2, NULL);
        if (!sidl_Enforcer_areTracing()) {
          md->pre_exec_time = SIDL_DIFF_MICROSECONDS(ts1, ts0);
          md->meth_exec_time = SIDL_DIFF_MICROSECONDS(ts2, ts1);
          md->post_exec_time = 0.0;
        } else {
          TRACE(cName, md, s_IOR_EX2_LISTC_GETDATAAT, 0, 0, 0, 
            SIDL_DIFF_MICROSECONDS(ts2, ts1), SIDL_DIFF_MICROSECONDS(ts1, ts0), 
            0.0, 0.0, 0.0);
        }

        return _retval;
      }

#ifdef SIDL_NO_DISPATCH_ON_VIOLATION
    }
#endif /* SIDL_NO_DISPATCH_ON_VIOLATION */

    gettimeofday(&ts2, NULL);

    if (!sidl_Enforcer_areTracing()) {
      md->pre_exec_time = SIDL_DIFF_MICROSECONDS(ts1, ts0);
      md->meth_exec_time = SIDL_DIFF_MICROSECONDS(ts2, ts1);
      md->post_exec_time = 0.0;
    } else {
      TRACE(cName, md, s_IOR_EX2_LISTC_GETDATAAT, 0, 0, 0, 
        SIDL_DIFF_MICROSECONDS(ts2, ts1), SIDL_DIFF_MICROSECONDS(ts1, ts0), 0.0,
        0.0, 0.0);
    }
    RESETCD(md)
  }

  return _retval;
}

/*
 * Check relevant contracts, if any, before and after the method call.
 */

static struct ex2_ListNode__object* check_ex2_ListC_getHead(
  /* in */ struct ex2_ListC__object* self,
  /* out */ struct sidl_BaseInterface__object **_ex)
{
  struct ex2_ListNode__object* _retval = 0;
  struct ex2_ListC__epv* epv = &s_my_epv__ex2_listc;

  _retval = (epv->f_getHead)(
      self,
      _ex);

  return _retval;
}

/*
 * Check relevant contracts, if any, before and after the method call.
 */

static struct ex2_ListNode__object* check_ex2_ListC_getTail(
  /* in */ struct ex2_ListC__object* self,
  /* out */ struct sidl_BaseInterface__object **_ex)
{
  struct ex2_ListNode__object* _retval = 0;
  struct ex2_ListC__epv* epv = &s_my_epv__ex2_listc;

  _retval = (epv->f_getTail)(
      self,
      _ex);

  return _retval;
}

static void ior_ex2_ListC__ensure_load_called(void) {
  /*
   * assert( HAVE_LOCKED_STATIC_GLOBALS );
   */

  if (! s_load_called ) {
    s_load_called=1;
    ex2_ListC__call_load();
  }
}

/* CAST: dynamic type casting support. */
static void* ior_ex2_ListC__cast(
  struct ex2_ListC__object* self,
  const char* name, sidl_BaseInterface* _ex)
{
  int cmp;
  void* cast = NULL;
  *_ex = NULL; /* default to no exception */
  cmp = strcmp(name, "sidl.BaseClass");
  if (!cmp) {
    (*self->d_epv->f_addRef)(self, _ex); SIDL_CHECK(*_ex);
    cast = ((struct sidl_BaseClass__object*)self);
    return cast;
  }
  else if (cmp < 0) {
    cmp = strcmp(name, "ex2.ListOps");
    if (!cmp) {
      (*self->d_epv->f_addRef)(self, _ex); SIDL_CHECK(*_ex);
      cast = &((*self).d_ex2_listops);
      return cast;
    }
    else if (cmp < 0) {
      cmp = strcmp(name, "ex2.ListC");
      if (!cmp) {
        (*self->d_epv->f_addRef)(self, _ex); SIDL_CHECK(*_ex);
        cast = ((struct ex2_ListC__object*)self);
        return cast;
      }
    }
  }
  else if (cmp > 0) {
    cmp = strcmp(name, "sidl.BaseInterface");
    if (!cmp) {
      (*self->d_epv->f_addRef)(self, _ex); SIDL_CHECK(*_ex);
      cast = &((*self).d_sidl_baseclass.d_sidl_baseinterface);
      return cast;
    }
  }
  return cast;
  EXIT:
  return NULL;
}

/*
 * HOOKS: Enable/disable hooks.
 */

static void ior_ex2_ListC__set_hooks(
  struct ex2_ListC__object* self,
  sidl_bool enable, struct sidl_BaseInterface__object **_ex )
{
  *_ex  = NULL;
  /*
   * Nothing else to do since hook methods not generated.
   */

}

/*
 * DELETE: call destructor and free object memory.
 */

static void ior_ex2_ListC__delete(
  struct ex2_ListC__object* self, struct sidl_BaseInterface__object **_ex)
{
  *_ex  = NULL; /* default to no exception */
  ex2_ListC__fini(self, _ex);
  memset((void*)self, 0, sizeof(struct ex2_ListC__object));
  free((void*) self);
}

static char*
ior_ex2_ListC__getURL(
  struct ex2_ListC__object* self,
  struct sidl_BaseInterface__object **_ex)
{
  char* ret  = NULL;
  char* objid = sidl_rmi_InstanceRegistry_getInstanceByClass((sidl_BaseClass)self, _ex); SIDL_CHECK(*_ex);
  if (!objid) {
    objid = sidl_rmi_InstanceRegistry_registerInstance((sidl_BaseClass)self, _ex); SIDL_CHECK(*_ex);
  }
#ifdef WITH_RMI

  ret = sidl_rmi_ServerRegistry_getServerURL(objid, _ex); SIDL_CHECK(*_ex);

#else

  ret = objid;

#endif /*WITH_RMI*/
  return ret;
  EXIT:
  return NULL;
}
static void
ior_ex2_ListC__raddRef(
    struct ex2_ListC__object* self, sidl_BaseInterface* _ex) {
  sidl_BaseInterface_addRef((sidl_BaseInterface)self, _ex);
}

static sidl_bool
ior_ex2_ListC__isRemote(
    struct ex2_ListC__object* self, sidl_BaseInterface* _ex) {
  *_ex  = NULL; /* default to no exception */
  return FALSE;
}

struct ex2_ListC__method {
  const char *d_name;
  void (*d_func)(struct ex2_ListC__object*,
    struct sidl_rmi_Call__object *,
    struct sidl_rmi_Return__object *,
    struct sidl_BaseInterface__object **);
};

static void
ior_ex2_ListC__exec(
  struct ex2_ListC__object* self,
  const char* methodName,
  struct sidl_rmi_Call__object* inArgs,
  struct sidl_rmi_Return__object* outArgs,
  struct sidl_BaseInterface__object **_ex )
{
  static const struct ex2_ListC__method  s_methods[] = {
    { "_cast", ex2_ListC__cast__exec },
    { "addRef", ex2_ListC_addRef__exec },
    { "boccaForceUsePortInclude", ex2_ListC_boccaForceUsePortInclude__exec },
    { "deleteRef", ex2_ListC_deleteRef__exec },
    { "getClassInfo", ex2_ListC_getClassInfo__exec },
    { "getDataAt", ex2_ListC_getDataAt__exec },
    { "getHead", ex2_ListC_getHead__exec },
    { "getSize", ex2_ListC_getSize__exec },
    { "getTail", ex2_ListC_getTail__exec },
    { "insertNext", ex2_ListC_insertNext__exec },
    { "isSame", ex2_ListC_isSame__exec },
    { "isType", ex2_ListC_isType__exec },
    { "removeNext", ex2_ListC_removeNext__exec }
  };
  int i, cmp, l = 0;
  int u = sizeof(s_methods)/sizeof(struct ex2_ListC__method);
  *_ex  = NULL; /* default to no exception */

  if (methodName) {
    /* Use binary search to locate method */
    while (l < u) {
      i = (l + u) >> 1;
      if (!(cmp=strcmp(methodName, s_methods[i].d_name))) {
        (s_methods[i].d_func)(self, inArgs, outArgs, _ex); SIDL_CHECK(*_ex);
        return;
      }
      else if (cmp < 0) u = i;
      else l = i + 1;
    }
  }
  /* TODO: add code for method not found */
  SIDL_THROW(*_ex, sidl_PreViolation, "method name not found");
  EXIT:
  return;
}
/*
 * EPV: create method entry point vector (EPV) structure.
 */

static void ex2_ListC__init_epv(void)
{
/*
 * assert( HAVE_LOCKED_STATIC_GLOBALS );
 */

  struct ex2_ListC__epv*          epv  = &s_my_epv__ex2_listc;
  struct ex2_ListC__epv*          cepv = &s_my_epv_contracts__ex2_listc;
  struct ex2_ListOps__epv*        e0   = &s_my_epv__ex2_listops;
  struct sidl_BaseClass__epv*     e1   = &s_my_epv__sidl_baseclass;
  struct sidl_BaseInterface__epv* e2   = &s_my_epv__sidl_baseinterface;

  struct sidl_BaseClass__epv* s1 = NULL;

  /*
   * Get my parent's EPVs so I can start with their functions.
   */

  sidl_BaseClass__getEPVs(
    &s_par_epv__sidl_baseinterface,
    &s_par_epv__sidl_baseclass);


  /*
   * Alias the static epvs to some handy small names.
   */

  s1  =  s_par_epv__sidl_baseclass;

  epv->f__cast                    = ior_ex2_ListC__cast;
  epv->f__delete                  = ior_ex2_ListC__delete;
  epv->f__exec                    = ior_ex2_ListC__exec;
  epv->f__getURL                  = ior_ex2_ListC__getURL;
  epv->f__raddRef                 = ior_ex2_ListC__raddRef;
  epv->f__isRemote                = ior_ex2_ListC__isRemote;
  epv->f__set_hooks               = ior_ex2_ListC__set_hooks;
  epv->f__set_contracts           = ior_ex2_ListC__set_contracts;
  epv->f__dump_stats              = ior_ex2_ListC__dump_stats;
  epv->f__ctor                    = NULL;
  epv->f__ctor2                   = NULL;
  epv->f__dtor                    = NULL;
  epv->f_boccaForceUsePortInclude = NULL;
  epv->f_addRef                   = (void (*)(struct ex2_ListC__object*,struct sidl_BaseInterface__object **)) s1->f_addRef;
  epv->f_deleteRef                = (void (*)(struct ex2_ListC__object*,struct sidl_BaseInterface__object **)) s1->f_deleteRef;
  epv->f_isSame                   = (sidl_bool (*)(struct ex2_ListC__object*,struct sidl_BaseInterface__object*,struct sidl_BaseInterface__object **)) s1->f_isSame;
  epv->f_isType                   = (sidl_bool (*)(struct ex2_ListC__object*,const char*,struct sidl_BaseInterface__object **)) s1->f_isType;
  epv->f_getClassInfo             = (struct sidl_ClassInfo__object* (*)(struct ex2_ListC__object*,struct sidl_BaseInterface__object **)) s1->f_getClassInfo;
  epv->f_insertNext               = NULL;
  epv->f_removeNext               = NULL;
  epv->f_getSize                  = NULL;
  epv->f_getDataAt                = NULL;
  epv->f_getHead                  = NULL;
  epv->f_getTail                  = NULL;

  ex2_ListC__set_epv(epv, &s_preEPV, &s_postEPV);

  memcpy((void*)cepv, epv, sizeof(struct ex2_ListC__epv));
  cepv->f_boccaForceUsePortInclude = check_ex2_ListC_boccaForceUsePortInclude;
  cepv->f_insertNext               = check_ex2_ListC_insertNext;
  cepv->f_removeNext               = check_ex2_ListC_removeNext;
  cepv->f_getSize                  = check_ex2_ListC_getSize;
  cepv->f_getDataAt                = check_ex2_ListC_getDataAt;
  cepv->f_getHead                  = check_ex2_ListC_getHead;
  cepv->f_getTail                  = check_ex2_ListC_getTail;

  /*
   * Override function pointers for ex2.ListOps with mine, as needed.
   */

  e0->f__cast                 = (void* (*)(void*,const char*, struct sidl_BaseInterface__object**))epv->f__cast;
  e0->f__delete               = (void (*)(void*, struct sidl_BaseInterface__object **)) epv->f__delete;
  e0->f__getURL               = (char* (*)(void*, struct sidl_BaseInterface__object **)) epv->f__getURL;
  e0->f__raddRef              = (void (*)(void*, struct sidl_BaseInterface__object **)) epv->f__raddRef;
  e0->f__isRemote             = (sidl_bool (*)(void*, struct sidl_BaseInterface__object **)) epv->f__isRemote;
  e0->f__exec                 = (void (*)(void*,const char*,struct sidl_rmi_Call__object*,struct sidl_rmi_Return__object*,struct sidl_BaseInterface__object **)) epv->f__exec;
  e0->f_insertNext            = (int32_t (*)(void*,struct ex2_ListNode__object*,struct ex2_Data__object*,struct sidl_BaseInterface__object **)) epv->f_insertNext;
  e0->f_removeNext            = (int32_t (*)(void*,struct ex2_ListNode__object*,struct ex2_Data__object**,struct sidl_BaseInterface__object **)) epv->f_removeNext;
  e0->f_getSize               = (int32_t (*)(void*,struct sidl_BaseInterface__object **)) epv->f_getSize;
  e0->f_getDataAt             = (struct ex2_Data__object* (*)(void*,int32_t,struct sidl_BaseInterface__object **)) epv->f_getDataAt;
  e0->f_getHead               = (struct ex2_ListNode__object* (*)(void*,struct sidl_BaseInterface__object **)) epv->f_getHead;
  e0->f_getTail               = (struct ex2_ListNode__object* (*)(void*,struct sidl_BaseInterface__object **)) epv->f_getTail;
  e0->f_addRef                = (void (*)(void*,struct sidl_BaseInterface__object **)) epv->f_addRef;
  e0->f_deleteRef             = (void (*)(void*,struct sidl_BaseInterface__object **)) epv->f_deleteRef;
  e0->f_isSame                = (sidl_bool (*)(void*,struct sidl_BaseInterface__object*,struct sidl_BaseInterface__object **)) epv->f_isSame;
  e0->f_isType                = (sidl_bool (*)(void*,const char*,struct sidl_BaseInterface__object **)) epv->f_isType;
  e0->f_getClassInfo          = (struct sidl_ClassInfo__object* (*)(void*,struct sidl_BaseInterface__object **)) epv->f_getClassInfo;


  /*
   * Override function pointers for sidl.BaseClass with mine, as needed.
   */

  e1->f__cast                 = (void* (*)(struct sidl_BaseClass__object*,const char*, struct sidl_BaseInterface__object**))epv->f__cast;
  e1->f__delete               = (void (*)(struct sidl_BaseClass__object*, struct sidl_BaseInterface__object **)) epv->f__delete;
  e1->f__getURL               = (char* (*)(struct sidl_BaseClass__object*, struct sidl_BaseInterface__object **)) epv->f__getURL;
  e1->f__raddRef              = (void (*)(struct sidl_BaseClass__object*, struct sidl_BaseInterface__object **)) epv->f__raddRef;
  e1->f__isRemote             = (sidl_bool (*)(struct sidl_BaseClass__object*, struct sidl_BaseInterface__object **)) epv->f__isRemote;
  e1->f__exec                 = (void (*)(struct sidl_BaseClass__object*,const char*,struct sidl_rmi_Call__object*,struct sidl_rmi_Return__object*,struct sidl_BaseInterface__object **)) epv->f__exec;
  e1->f_addRef                = (void (*)(struct sidl_BaseClass__object*,struct sidl_BaseInterface__object **)) epv->f_addRef;
  e1->f_deleteRef             = (void (*)(struct sidl_BaseClass__object*,struct sidl_BaseInterface__object **)) epv->f_deleteRef;
  e1->f_isSame                = (sidl_bool (*)(struct sidl_BaseClass__object*,struct sidl_BaseInterface__object*,struct sidl_BaseInterface__object **)) epv->f_isSame;
  e1->f_isType                = (sidl_bool (*)(struct sidl_BaseClass__object*,const char*,struct sidl_BaseInterface__object **)) epv->f_isType;
  e1->f_getClassInfo          = (struct sidl_ClassInfo__object* (*)(struct sidl_BaseClass__object*,struct sidl_BaseInterface__object **)) epv->f_getClassInfo;


  /*
   * Override function pointers for sidl.BaseInterface with mine, as needed.
   */

  e2->f__cast                 = (void* (*)(void*,const char*, struct sidl_BaseInterface__object**))epv->f__cast;
  e2->f__delete               = (void (*)(void*, struct sidl_BaseInterface__object **)) epv->f__delete;
  e2->f__getURL               = (char* (*)(void*, struct sidl_BaseInterface__object **)) epv->f__getURL;
  e2->f__raddRef              = (void (*)(void*, struct sidl_BaseInterface__object **)) epv->f__raddRef;
  e2->f__isRemote             = (sidl_bool (*)(void*, struct sidl_BaseInterface__object **)) epv->f__isRemote;
  e2->f__exec                 = (void (*)(void*,const char*,struct sidl_rmi_Call__object*,struct sidl_rmi_Return__object*,struct sidl_BaseInterface__object **)) epv->f__exec;
  e2->f_addRef                = (void (*)(void*,struct sidl_BaseInterface__object **)) epv->f_addRef;
  e2->f_deleteRef             = (void (*)(void*,struct sidl_BaseInterface__object **)) epv->f_deleteRef;
  e2->f_isSame                = (sidl_bool (*)(void*,struct sidl_BaseInterface__object*,struct sidl_BaseInterface__object **)) epv->f_isSame;
  e2->f_isType                = (sidl_bool (*)(void*,const char*,struct sidl_BaseInterface__object **)) epv->f_isType;
  e2->f_getClassInfo          = (struct sidl_ClassInfo__object* (*)(void*,struct sidl_BaseInterface__object **)) epv->f_getClassInfo;


  s_method_initialized = 1;
  ior_ex2_ListC__ensure_load_called();
}

/*
 * ex2_ListC__getEPVs: Get my version of all relevant EPVs.
 */

void ex2_ListC__getEPVs (
  struct sidl_BaseInterface__epv **s_arg_epv__sidl_baseinterface,
  struct sidl_BaseClass__epv **s_arg_epv__sidl_baseclass,
  struct ex2_ListOps__epv **s_arg_epv__ex2_listops,
  struct ex2_ListOps__epv **s_arg_epv_hooks__ex2_listops,
  struct ex2_ListC__epv **s_arg_epv__ex2_listc,
  struct ex2_ListC__epv **s_arg_epv_hooks__ex2_listc)
{
  LOCK_STATIC_GLOBALS;
  if (!s_method_initialized) {
    ex2_ListC__init_epv();
  }
  UNLOCK_STATIC_GLOBALS;

  *s_arg_epv__sidl_baseinterface = &s_my_epv__sidl_baseinterface;
  *s_arg_epv__sidl_baseclass = &s_my_epv__sidl_baseclass;
  *s_arg_epv__ex2_listops = &s_my_epv__ex2_listops;
  *s_arg_epv_hooks__ex2_listops = &s_my_epv_hooks__ex2_listops;
  *s_arg_epv__ex2_listc = &s_my_epv__ex2_listc;
  *s_arg_epv_hooks__ex2_listc = &s_my_epv_hooks__ex2_listc;
}
/*
 * __getSuperEPV: returns parent's non-overrided EPV
 */

static struct sidl_BaseClass__epv* ex2_ListC__getSuperEPV(void) {
  return s_par_epv__sidl_baseclass;
}

/*
 * initClassInfo: create a ClassInfo interface if necessary.
 */

static void
initClassInfo(sidl_ClassInfo *info, struct sidl_BaseInterface__object **_ex)
{
  LOCK_STATIC_GLOBALS;
  *_ex  = NULL; /* default to no exception */

  if (!s_classInfo) {
    sidl_ClassInfoI impl;
    impl = sidl_ClassInfoI__create(_ex);
    s_classInfo = sidl_ClassInfo__cast(impl,_ex);
    if (impl) {
      sidl_ClassInfoI_setName(impl, "ex2.ListC", _ex);
      sidl_ClassInfoI_setVersion(impl, "0.0", _ex);
      sidl_ClassInfoI_setIORVersion(impl, s_IOR_MAJOR_VERSION,
        s_IOR_MINOR_VERSION, _ex);
      sidl_ClassInfoI_deleteRef(impl,_ex);
      sidl_atexit(sidl_deleteRef_atexit, &s_classInfo);
    }
  }
  UNLOCK_STATIC_GLOBALS;
  if (s_classInfo) {
    if (*info) {
      sidl_ClassInfo_deleteRef(*info,_ex);
    }
    *info = s_classInfo;
    sidl_ClassInfo_addRef(*info,_ex);
  }
}

/*
 * initMetadata: store IOR version & class in sidl.BaseClass's data
 */

static void
initMetadata(struct ex2_ListC__object* self, sidl_BaseInterface* _ex)
{
  *_ex = 0; /* default no exception */
  if (self) {
    struct sidl_BaseClass__data *data = (struct sidl_BaseClass__data*)((*self).d_sidl_baseclass.d_data);
    if (data) {
      data->d_IOR_major_version = s_IOR_MAJOR_VERSION;
      data->d_IOR_minor_version = s_IOR_MINOR_VERSION;
      initClassInfo(&(data->d_classinfo),_ex); SIDL_CHECK(*_ex);
    }
  }
EXIT:
return;
}

/*
 * ex2_ListC__createObject: Allocate the object and initialize it.
 */

struct ex2_ListC__object*
ex2_ListC__createObject(void* ddata, struct sidl_BaseInterface__object ** _ex)
{
  struct ex2_ListC__object* self =
    (struct ex2_ListC__object*) sidl_malloc(
      sizeof(struct ex2_ListC__object),
      "Object allocation failed for struct ex2_ListC__object",
        __FILE__, __LINE__, "ex2_ListC__createObject", _ex);
  if (!self) goto EXIT;
  ex2_ListC__init(self, ddata, _ex); SIDL_CHECK(*_ex);
  initMetadata(self, _ex); SIDL_CHECK(*_ex);

  {
    struct sidl_BaseInterface__object *tae;
    ior_ex2_ListC__set_contracts(self,sidl_Enforcer_areEnforcing(), 
      NULL, TRUE, &tae);
  }
  return self;

  EXIT:
  return NULL;
}

/*
 * INIT: initialize a new instance of the class object.
 */

void ex2_ListC__init(
  struct ex2_ListC__object* self,
   void* ddata,
  struct sidl_BaseInterface__object **_ex)
{
  struct ex2_ListC__object*      s0 = self;
  struct sidl_BaseClass__object* s1 = &s0->d_sidl_baseclass;

  *_ex = 0; /* default no exception */
  LOCK_STATIC_GLOBALS;
  if (!s_method_initialized) {
    ex2_ListC__init_epv();
  }
  UNLOCK_STATIC_GLOBALS;

  sidl_BaseClass__init(s1, NULL, _ex); SIDL_CHECK(*_ex);

  s1->d_sidl_baseinterface.d_epv = &s_my_epv__sidl_baseinterface;
  s1->d_epv                      = &s_my_epv__sidl_baseclass;

  s0->d_ex2_listops.d_epv = &s_my_epv__ex2_listops;
  s0->d_epv               = &s_my_epv__ex2_listc;

  s0->d_ex2_listops.d_object = self;

  s0->d_data = NULL;

  if (ddata) {
    self->d_data = ddata;
    (*(self->d_epv->f__ctor2))(self,ddata,_ex); SIDL_CHECK(*_ex);
  } else { 
    (*(self->d_epv->f__ctor))(self,_ex); SIDL_CHECK(*_ex);
  }
  EXIT:
  return;
}

/*
 * FINI: deallocate a class instance (destructor).
 */

void ex2_ListC__fini(
  struct ex2_ListC__object* self,
  struct sidl_BaseInterface__object **_ex)
{
  struct ex2_ListC__object*      s0 = self;
  struct sidl_BaseClass__object* s1 = &s0->d_sidl_baseclass;

  *_ex  = NULL; /* default to no exception */

  if (sidl_Enforcer_areEnforcing()) {
    (*(s0->d_epv->f__dump_stats))(s0, "", "FINI",_ex); SIDL_CHECK(*_ex);
  }

  (*(s0->d_epv->f__dtor))(s0,_ex); SIDL_CHECK(*_ex);

  s1->d_sidl_baseinterface.d_epv = s_par_epv__sidl_baseinterface;
  s1->d_epv                      = s_par_epv__sidl_baseclass;

  sidl_BaseClass__fini(s1, _ex); SIDL_CHECK(*_ex);

  EXIT:
  return;
}

/*
 * VERSION: Return the version of the IOR used to generate this IOR.
 */

void
ex2_ListC__IOR_version(int32_t *major, int32_t *minor)
{
  *major = s_IOR_MAJOR_VERSION;
  *minor = s_IOR_MINOR_VERSION;
}

static const struct ex2_ListC__external
s_externalEntryPoints = {
  ex2_ListC__createObject,
  ex2_ListC__getSuperEPV,
  2, 
  0
};

/*
 * This function returns a pointer to a static structure of
 * pointers to function entry points.  Its purpose is to provide
 * one-stop shopping for loading DLLs.
 */

const struct ex2_ListC__external*
ex2_ListC__externals(void)
{
  return &s_externalEntryPoints;
}

