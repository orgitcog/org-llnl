/*
 * File:          ex2_ListNodeC_Impl.h
 * Symbol:        ex2.ListNodeC-v0.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for ex2.ListNodeC
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#ifndef included_ex2_ListNodeC_Impl_h
#define included_ex2_ListNodeC_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_ex2_Data_h
#include "ex2_Data.h"
#endif
#ifndef included_ex2_ListNode_h
#include "ex2_ListNode.h"
#endif
#ifndef included_ex2_ListNodeC_h
#include "ex2_ListNodeC.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_RuntimeException_h
#include "sidl_RuntimeException.h"
#endif
/* DO-NOT-DELETE splicer.begin(ex2.ListNodeC._hincludes) */
/* Insert-Code-Here {ex2.ListNodeC._hincludes} (include files) */
/* DO-NOT-DELETE splicer.end(ex2.ListNodeC._hincludes) */

/*
 * Private data for class ex2.ListNodeC
 */

struct ex2_ListNodeC__data {
  /* DO-NOT-DELETE splicer.begin(ex2.ListNodeC._data) */
  /* Insert-Code-Here {ex2.ListNodeC._data} (private data members) */
  ex2_Data data;
  ex2_ListNode node;
  //int ignore; /* dummy to force non-empty struct; remove if you add data */
  /* DO-NOT-DELETE splicer.end(ex2.ListNodeC._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct ex2_ListNodeC__data*
ex2_ListNodeC__get_data(
  ex2_ListNodeC);

extern void
ex2_ListNodeC__set_data(
  ex2_ListNodeC,
  struct ex2_ListNodeC__data*);

extern
void
impl_ex2_ListNodeC__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_ListNodeC__ctor(
  /* in */ ex2_ListNodeC self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_ListNodeC__ctor2(
  /* in */ ex2_ListNodeC self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_ListNodeC__dtor(
  /* in */ ex2_ListNodeC self,
  /* out */ sidl_BaseInterface *_ex);

/*
 * User-defined object methods
 */

#ifdef WITH_RMI
extern struct ex2_Data__object* impl_ex2_ListNodeC_fconnect_ex2_Data(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_ex2_ListNodeC_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct ex2_ListNode__object* impl_ex2_ListNodeC_fconnect_ex2_ListNode(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/
extern
void
impl_ex2_ListNodeC_boccaForceUsePortInclude(
  /* in */ ex2_ListNodeC self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_ListNodeC_setData(
  /* in */ ex2_ListNodeC self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex);

extern
ex2_Data
impl_ex2_ListNodeC_getData(
  /* in */ ex2_ListNodeC self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_ListNodeC_setNext(
  /* in */ ex2_ListNodeC self,
  /* in */ ex2_ListNode n,
  /* out */ sidl_BaseInterface *_ex);

extern
ex2_ListNode
impl_ex2_ListNodeC_getNext(
  /* in */ ex2_ListNodeC self,
  /* out */ sidl_BaseInterface *_ex);

#ifdef WITH_RMI
extern struct ex2_Data__object* impl_ex2_ListNodeC_fconnect_ex2_Data(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_ex2_ListNodeC_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct ex2_ListNode__object* impl_ex2_ListNodeC_fconnect_ex2_ListNode(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/

/* DO-NOT-DELETE splicer.begin(_hmisc) */
/* Insert-Code-Here {_hmisc} (miscellaneous things) */
/* DO-NOT-DELETE splicer.end(_hmisc) */

#ifdef __cplusplus
}
#endif
#endif
