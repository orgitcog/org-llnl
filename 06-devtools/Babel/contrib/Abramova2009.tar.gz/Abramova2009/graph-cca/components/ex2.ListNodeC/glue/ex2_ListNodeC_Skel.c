/*
 * File:          ex2_ListNodeC_Skel.c
 * Symbol:        ex2.ListNodeC-v0.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side glue code for ex2.ListNodeC
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 */

#include "ex2_ListNodeC_IOR.h"
#include "ex2_ListNodeC.h"
#include <stddef.h>

#ifdef WITH_RMI
#ifndef included_ex2_Data_h
#include "ex2_Data.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_ex2_ListNode_h
#include "ex2_ListNode.h"
#endif
#endif /* WITH_RMI */
extern
void
impl_ex2_ListNodeC__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_ListNodeC__ctor(
  /* in */ ex2_ListNodeC self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_ListNodeC__ctor2(
  /* in */ ex2_ListNodeC self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_ListNodeC__dtor(
  /* in */ ex2_ListNodeC self,
  /* out */ sidl_BaseInterface *_ex);

#ifdef WITH_RMI
extern struct ex2_Data__object* impl_ex2_ListNodeC_fconnect_ex2_Data(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_ex2_ListNodeC_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct ex2_ListNode__object* impl_ex2_ListNodeC_fconnect_ex2_ListNode(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/
extern
void
impl_ex2_ListNodeC_boccaForceUsePortInclude(
  /* in */ ex2_ListNodeC self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_ListNodeC_setData(
  /* in */ ex2_ListNodeC self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex);

extern
ex2_Data
impl_ex2_ListNodeC_getData(
  /* in */ ex2_ListNodeC self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_ListNodeC_setNext(
  /* in */ ex2_ListNodeC self,
  /* in */ ex2_ListNode n,
  /* out */ sidl_BaseInterface *_ex);

extern
ex2_ListNode
impl_ex2_ListNodeC_getNext(
  /* in */ ex2_ListNodeC self,
  /* out */ sidl_BaseInterface *_ex);

#ifdef WITH_RMI
extern struct ex2_Data__object* impl_ex2_ListNodeC_fconnect_ex2_Data(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_ex2_ListNodeC_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct ex2_ListNode__object* impl_ex2_ListNodeC_fconnect_ex2_ListNode(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/
#ifdef __cplusplus
extern "C" {
#endif

void
ex2_ListNodeC__set_epv(struct ex2_ListNodeC__epv *epv,
  struct ex2_ListNodeC__pre_epv *pre_epv, 
  struct ex2_ListNodeC__post_epv *post_epv
)
{
  epv->f__ctor = impl_ex2_ListNodeC__ctor;
  epv->f__ctor2 = impl_ex2_ListNodeC__ctor2;
  epv->f__dtor = impl_ex2_ListNodeC__dtor;
  pre_epv->f_boccaForceUsePortInclude_pre = NULL;
  epv->f_boccaForceUsePortInclude = impl_ex2_ListNodeC_boccaForceUsePortInclude;
  post_epv->f_boccaForceUsePortInclude_post = NULL;
  pre_epv->f_setData_pre = NULL;
  epv->f_setData = impl_ex2_ListNodeC_setData;
  post_epv->f_setData_post = NULL;
  pre_epv->f_getData_pre = NULL;
  epv->f_getData = impl_ex2_ListNodeC_getData;
  post_epv->f_getData_post = NULL;
  pre_epv->f_setNext_pre = NULL;
  epv->f_setNext = impl_ex2_ListNodeC_setNext;
  post_epv->f_setNext_post = NULL;
  pre_epv->f_getNext_pre = NULL;
  epv->f_getNext = impl_ex2_ListNodeC_getNext;
  post_epv->f_getNext_post = NULL;

}
#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
extern "C" {
#endif

void ex2_ListNodeC__call_load(void) { 
  sidl_BaseInterface _throwaway_exception = NULL;
  impl_ex2_ListNodeC__load(&_throwaway_exception);
}
#ifdef WITH_RMI
struct ex2_Data__object* skel_ex2_ListNodeC_fconnect_ex2_Data(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) { 
  return ex2_Data__connectI(url, ar, _ex);
}

struct sidl_BaseInterface__object* 
  skel_ex2_ListNodeC_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex) { 
  return sidl_BaseInterface__connectI(url, ar, _ex);
}

struct ex2_ListNode__object* skel_ex2_ListNodeC_fconnect_ex2_ListNode(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex) { 
  return ex2_ListNode__connectI(url, ar, _ex);
}

#endif /*WITH_RMI*/
struct ex2_ListNodeC__data*
ex2_ListNodeC__get_data(ex2_ListNodeC self)
{
  return (struct ex2_ListNodeC__data*)(self ? self->d_data : NULL);
}

void ex2_ListNodeC__set_data(
  ex2_ListNodeC self,
  struct ex2_ListNodeC__data* data)
{
  if (self) {
    self->d_data = data;
  }
}
#ifdef __cplusplus
}
#endif
