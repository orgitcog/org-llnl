// 
// File:          ex2_Driver_Impl.cxx
// Symbol:        ex2.Driver-v0.0
// Symbol Type:   class
// Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
// Description:   Server-side implementation for ex2.Driver
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "ex2_Driver_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_ex2_GraphOps_hxx
#include "ex2_GraphOps.hxx"
#endif
#ifndef included_ex2_GraphSource_hxx
#include "ex2_GraphSource.hxx"
#endif
#ifndef included_ex2_GraphSrchPort_hxx
#include "ex2_GraphSrchPort.hxx"
#endif
#ifndef included_ex2_InitGraphPort_hxx
#include "ex2_InitGraphPort.hxx"
#endif
#ifndef included_ex2_IntData_hxx
#include "ex2_IntData.hxx"
#endif
#ifndef included_ex2_ListC_hxx
#include "ex2_ListC.hxx"
#endif
#ifndef included_ex2_ListNode_hxx
#include "ex2_ListNode.hxx"
#endif
#ifndef included_ex2_ListNodeC_hxx
#include "ex2_ListNodeC.hxx"
#endif
#ifndef included_ex2_ListOps_hxx
#include "ex2_ListOps.hxx"
#endif
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
// DO-NOT-DELETE splicer.begin(ex2.Driver._includes)

  // Insert-UserCode-Here {ex2.Driver._includes:prolog} (additional includes or code)
#include "sidl_EnfPolicy.hxx"
#include "sidl_Exception.h"
#include "sidl_Enforcer.h"
#include "sidl_PreViolation.hxx"
#include "sidl_PostViolation.hxx"
  // Bocca generated code. bocca.protected.begin(ex2.Driver._includes)

#define _BOCCA_CTOR_MESSAGES 0
  // If -D_BOCCA_STDERR is given to the compiler, diagnostics print to stderr.
  // In production use, probably want not to use -D_BOCCA_STDERR.
#ifdef _BOCCA_STDERR

#include <iostream>

#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif // _BOCCA_CTOR_PRINT 
#else  // _BOCCA_STDERR


#endif // _BOCCA_STDERR



  // If -D_BOCCA_BOOST is given to the compiler, exceptions and diagnostics 
  // will include function names for boost-understood compilers.
  // If boost is not available (and therefore ccaffeine is not in use), 
  // -D_BOCCA_BOOST can be omitted and function names will not be included in 
  // messages.
#ifndef _BOCCA_BOOST
#define BOOST_CURRENT_FUNCTION ""
#else
#include <boost/current_function.hpp>
#endif

  // This is intended to simplify exception throwing as SIDL_THROW does for C.
#define BOCCA_THROW_CXX(EX_CLS, MSG) \
{ \
    EX_CLS ex = EX_CLS::_create(); \
    ex.setNote( MSG ); \
    ex.add(__FILE__, __LINE__, BOOST_CURRENT_FUNCTION); \
    throw ex; \
}

  // This simplifies exception extending and rethrowing in c++, like 
  // SIDL_CHECK in C. EX_OBJ must be the caught exception and is extended with 
  // msg and file/line/func added. Continuing the throw is up to the user.
#define BOCCA_EXTEND_THROW_CXX(EX_OBJ, MSG, LINEOFFSET) \
{ \
  std::string msg = std::string(MSG) + std::string(BOOST_CURRENT_FUNCTION); \
  EX_OBJ.add(__FILE__,__LINE__ + LINEOFFSET, msg); \
}


  // Bocca generated code. bocca.protected.end(ex2.Driver._includes)

  // Insert-UserCode-Here {ex2.Driver._includes:epilog} (additional includes or code)

// DO-NOT-DELETE splicer.end(ex2.Driver._includes)

// special constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
ex2::Driver_impl::Driver_impl() : StubBase(reinterpret_cast< void*>(
  ::ex2::Driver::_wrapObj(reinterpret_cast< void*>(this))),false) , _wrapped(
  true){ 
  // DO-NOT-DELETE splicer.begin(ex2.Driver._ctor2)
  // Insert-Code-Here {ex2.Driver._ctor2} (ctor2)
  // DO-NOT-DELETE splicer.end(ex2.Driver._ctor2)
}

// user defined constructor
void ex2::Driver_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(ex2.Driver._ctor)
    
  // Insert-UserCode-Here {ex2.Driver._ctor:prolog} (constructor method) 

  // bocca-default-code. User may edit or delete.begin(ex2.Driver._ctor)
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "CTOR ex2.Driver: " << BOOST_CURRENT_FUNCTION 
               << " constructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES
  // bocca-default-code. User may edit or delete.end(ex2.Driver._ctor)

  // Insert-UserCode-Here {ex2.Driver._ctor:epilog} (constructor method)

  // DO-NOT-DELETE splicer.end(ex2.Driver._ctor)
}

// user defined destructor
void ex2::Driver_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(ex2.Driver._dtor)
  // Insert-UserCode-Here {ex2.Driver._dtor} (destructor method) 
    
  // bocca-default-code. User may edit or delete.begin(ex2.Driver._dtor) 
   #if _BOCCA_CTOR_MESSAGES

     std::cerr << "DTOR ex2.Driver: " << BOOST_CURRENT_FUNCTION 
               << " destructing " << this << std::endl;

   #endif // _BOCCA_CTOR_MESSAGES 
  // bocca-default-code. User may edit or delete.end(ex2.Driver._dtor) 

  // DO-NOT-DELETE splicer.end(ex2.Driver._dtor)
}

// static class initializer
void ex2::Driver_impl::_load() {
  // DO-NOT-DELETE splicer.begin(ex2.Driver._load)
  // Insert-Code-Here {ex2.Driver._load} (class initialization)
  // DO-NOT-DELETE splicer.end(ex2.Driver._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  boccaSetServices[]
 */
void
ex2::Driver_impl::boccaSetServices_impl (
  /* in */::gov::cca::Services& services ) 
// throws:
//    ::gov::cca::CCAException
//    ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(ex2.Driver.boccaSetServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(ex2.Driver.boccaSetServices)

  gov::cca::TypeMap typeMap;
  gov::cca::Port    port;

  this->d_services = services;

  typeMap = this->d_services.createTypeMap();

  port = ::babel_cast< gov::cca::Port>(*this);
  if (port._is_nil()) {
    BOCCA_THROW_CXX( ::sidl::SIDLException , 
                     "ex2.Driver: Error casting self to gov::cca::Port");
  } 


  // Provide a gov.cca.ports.GoPort port with port name run 
  try{
    this->d_services.addProvidesPort(
                   port,              // implementing object
                   "run", // port instance name
                   "gov.cca.ports.GoPort",     // full sidl type of port
                   typeMap);          // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex, 
        "ex2.Driver: Error calling addProvidesPort(port,"
        "\"run\", \"gov.cca.ports.GoPort\", typeMap) ", -2);
    throw;
  }    

  // Use a ex2.GraphSource port with port name grSource 
  try{
    this->d_services.registerUsesPort(
                   "grSource", // port instance name
                   "ex2.GraphSource",     // full sidl type of port
                    typeMap);         // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex,
       "ex2.Driver: Error calling registerUsesPort(\"grSource\", "
       "\"ex2.GraphSource\", typeMap) ", -2);
    throw;
  }

  // Use a ex2.InitGraphPort port with port name initPort 
  try{
    this->d_services.registerUsesPort(
                   "initPort", // port instance name
                   "ex2.InitGraphPort",     // full sidl type of port
                    typeMap);         // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex,
       "ex2.Driver: Error calling registerUsesPort(\"initPort\", "
       "\"ex2.InitGraphPort\", typeMap) ", -2);
    throw;
  }

  // Use a ex2.GraphSrchPort port with port name grSrchPrt 
  try{
    this->d_services.registerUsesPort(
                   "grSrchPrt", // port instance name
                   "ex2.GraphSrchPort",     // full sidl type of port
                    typeMap);         // properties for the port
  } catch ( ::gov::cca::CCAException ex )  {
    BOCCA_EXTEND_THROW_CXX(ex,
       "ex2.Driver: Error calling registerUsesPort(\"grSrchPrt\", "
       "\"ex2.GraphSrchPort\", typeMap) ", -2);
    throw;
  }


  gov::cca::ComponentRelease cr = 
        ::babel_cast< gov::cca::ComponentRelease>(*this);
  this->d_services.registerForRelease(cr);
  return;
  // Bocca generated code. bocca.protected.end(ex2.Driver.boccaSetServices)
    
  // DO-NOT-DELETE splicer.end(ex2.Driver.boccaSetServices)
}

/**
 * Method:  boccaReleaseServices[]
 */
void
ex2::Driver_impl::boccaReleaseServices_impl (
  /* in */::gov::cca::Services& services ) 
// throws:
//    ::gov::cca::CCAException
//    ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(ex2.Driver.boccaReleaseServices)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(ex2.Driver.boccaReleaseServices)
  this->d_services=0;


  // Un-provide gov.cca.ports.GoPort port with port name run 
  try{
    services.removeProvidesPort("run");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "ex2.Driver: Error calling removeProvidesPort("
              << "\"run\") at " 
              << __FILE__ << ": " << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  // Release ex2.GraphSource port with port name grSource 
  try{
    services.unregisterUsesPort("grSource");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "ex2.Driver: Error calling unregisterUsesPort("
              << "\"grSource\") at " 
              << __FILE__ << ":" << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  // Release ex2.InitGraphPort port with port name initPort 
  try{
    services.unregisterUsesPort("initPort");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "ex2.Driver: Error calling unregisterUsesPort("
              << "\"initPort\") at " 
              << __FILE__ << ":" << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  // Release ex2.GraphSrchPort port with port name grSrchPrt 
  try{
    services.unregisterUsesPort("grSrchPrt");
  } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
    std::cerr << "ex2.Driver: Error calling unregisterUsesPort("
              << "\"grSrchPrt\") at " 
              << __FILE__ << ":" << __LINE__ -4 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }

  return;
  // Bocca generated code. bocca.protected.end(ex2.Driver.boccaReleaseServices)
    
  // DO-NOT-DELETE splicer.end(ex2.Driver.boccaReleaseServices)
}

/**
 *  This function should never be called, but helps babel generate better code. 
 */
void
ex2::Driver_impl::boccaForceUsePortInclude_impl (
  /* in */::ex2::GraphSource& dummy0,
  /* in */::ex2::InitGraphPort& dummy1,
  /* in */::ex2::GraphSrchPort& dummy2,
  /* in */::ex2::GraphOps& dummy3,
  /* in */::ex2::IntData& dummy4,
  /* in */::ex2::ListNodeC& dummy5,
  /* in */::ex2::ListC& dummy6,
  /* in */::ex2::ListOps& dummy7,
  /* in */::ex2::ListNode& dummy8 ) 
{
  // DO-NOT-DELETE splicer.begin(ex2.Driver.boccaForceUsePortInclude)
  // DO-NOT-EDIT-BOCCA
  // Bocca generated code. bocca.protected.begin(ex2.Driver.boccaForceUsePortInclude)
    (void)dummy0;
    (void)dummy1;
    (void)dummy2;
    (void)dummy3;
    (void)dummy4;
    (void)dummy5;
    (void)dummy6;
    (void)dummy7;
    (void)dummy8;

  // Bocca generated code. bocca.protected.end(ex2.Driver.boccaForceUsePortInclude)
  // DO-NOT-DELETE splicer.end(ex2.Driver.boccaForceUsePortInclude)
}

/**
 *  Starts up a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * The component interaction with the CCA framework
 * and Ports begins on the call to setServices by the framework.
 * 
 * This function is called exactly once for each instance created
 * by the framework.
 * 
 * The argument services will never be nil/null.
 * 
 * Those uses ports which are automatically connected by the framework
 * (so-called service-ports) may be obtained via getPort during
 * setServices.
 */
void
ex2::Driver_impl::setServices_impl (
  /* in */::gov::cca::Services& services ) 
// throws:
//    ::gov::cca::CCAException
//    ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(ex2.Driver.setServices)

  // Insert-UserCode-Here{ex2.Driver.setServices:prolog}

  // bocca-default-code. User may edit or delete.begin(ex2.Driver.setServices)
     boccaSetServices(services); 
  // bocca-default-code. User may edit or delete.end(ex2.Driver.setServices)
  
  // Insert-UserCode-Here{ex2.Driver.setServices:epilog}

  // DO-NOT-DELETE splicer.end(ex2.Driver.setServices)
}

/**
 * Shuts down a component presence in the calling framework.
 * @param services the component instance's handle on the framework world.
 * Contracts concerning services and setServices:
 * 
 * This function is called exactly once for each callback registered
 * through Services.
 * 
 * The argument services will never be nil/null.
 * The argument services will always be the same as that received in
 * setServices.
 * 
 * During this call the component should release any interfaces
 * acquired by getPort().
 * 
 * During this call the component should reset to nil any stored
 * reference to services.
 * 
 * After this call, the component instance will be removed from the
 * framework. If the component instance was created by the
 * framework, it will be destroyed, not recycled, The behavior of
 * any port references obtained from this component instance and
 * stored elsewhere becomes undefined.
 * 
 * Notes for the component implementor:
 * 1) The component writer may perform blocking activities
 * within releaseServices, such as waiting for remote computations
 * to shutdown.
 * 2) It is good practice during releaseServices for the component
 * writer to remove or unregister all the ports it defined.
 */
void
ex2::Driver_impl::releaseServices_impl (
  /* in */::gov::cca::Services& services ) 
// throws:
//    ::gov::cca::CCAException
//    ::sidl::RuntimeException
{
  // DO-NOT-DELETE splicer.begin(ex2.Driver.releaseServices)

  // Insert-UserCode-Here {ex2.Driver.releaseServices} 

  // bocca-default-code. User may edit or delete.begin(ex2.Driver.releaseServices)
     boccaReleaseServices(services);
  // bocca-default-code. User may edit or delete.end(ex2.Driver.releaseServices)
    
  // DO-NOT-DELETE splicer.end(ex2.Driver.releaseServices)
}

/**
 *  
 * Execute some encapsulated functionality on the component. 
 * Return 0 if ok, -1 if internal error but component may be 
 * used further, and -2 if error so severe that component cannot
 * be further used safely.
 */
int32_t
ex2::Driver_impl::go_impl () 

{
  // DO-NOT-DELETE splicer.begin(ex2.Driver.go)
// User editable portion is in the middle at the next Insert-UserCode-Here line.


// Bocca generated code. bocca.protected.begin(ex2.Driver.go:boccaGoProlog)
  int bocca_status = 0;
  // The user's code should set bocca_status 0 if computation proceeded ok.
  // The user's code should set bocca_status -1 if computation failed but might
  // succeed on another call to go(), e.g. when a required port is not yet 
  // connected.
  // The user's code should set bocca_status -2 if the computation failed and 
  // can never succeed in a future call.
  // The user's code should NOT use return in this function.
  // Exceptions that are not caught in user code will be converted to 
  // status -2.

  gov::cca::Port port;

  // nil if not fetched and cast successfully:
  ex2::GraphSource grSource; 
  // True when releasePort is needed (even if cast fails):
  bool grSource_fetched = false; 
  // nil if not fetched and cast successfully:
  ex2::InitGraphPort initPort; 
  // True when releasePort is needed (even if cast fails):
  bool initPort_fetched = false; 
  // nil if not fetched and cast successfully:
  ex2::GraphSrchPort grSrchPrt; 
  // True when releasePort is needed (even if cast fails):
  bool grSrchPrt_fetched = false; 
  // Use a ex2.GraphSource port with port name grSource 
  try{
    port = this->d_services.getPort("grSource");
  } catch ( ::gov::cca::CCAException ex )  {
    // we will continue with port nil (never successfully assigned) and 
    // set a flag.

#ifdef _BOCCA_STDERR
    std::cerr << "ex2.Driver: Error calling getPort(\"grSource\") "
              " at " << __FILE__ << ":" << __LINE__ -5 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }
  if ( port._not_nil() ) {
    // even if the next cast fails, must release.
    grSource_fetched = true; 
    grSource = ::babel_cast< ex2::GraphSource >(port);
    if (grSource._is_nil()) {

#ifdef _BOCCA_STDERR
      std::cerr << "ex2.Driver: Error casting gov::cca::Port "
                << "grSource to type "
                << "ex2::GraphSource" << std::endl;
#endif //_BOCCA_STDERR

      goto BOCCAEXIT; // we cannot correctly continue. clean up and leave.
    } 
  } 

  // Use a ex2.InitGraphPort port with port name initPort 
  try{
    port = this->d_services.getPort("initPort");
  } catch ( ::gov::cca::CCAException ex )  {
    // we will continue with port nil (never successfully assigned) and 
    // set a flag.

#ifdef _BOCCA_STDERR
    std::cerr << "ex2.Driver: Error calling getPort(\"initPort\") "
              " at " << __FILE__ << ":" << __LINE__ -5 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }
  if ( port._not_nil() ) {
    // even if the next cast fails, must release.
    initPort_fetched = true; 
    initPort = ::babel_cast< ex2::InitGraphPort >(port);
    if (initPort._is_nil()) {

#ifdef _BOCCA_STDERR
      std::cerr << "ex2.Driver: Error casting gov::cca::Port "
                << "initPort to type "
                << "ex2::InitGraphPort" << std::endl;
#endif //_BOCCA_STDERR

      goto BOCCAEXIT; // we cannot correctly continue. clean up and leave.
    } 
  } 

  // Use a ex2.GraphSrchPort port with port name grSrchPrt 
  try{
    port = this->d_services.getPort("grSrchPrt");
  } catch ( ::gov::cca::CCAException ex )  {
    // we will continue with port nil (never successfully assigned) and 
    // set a flag.

#ifdef _BOCCA_STDERR
    std::cerr << "ex2.Driver: Error calling getPort(\"grSrchPrt\") "
              " at " << __FILE__ << ":" << __LINE__ -5 << ": " << ex.getNote() 
              << std::endl;
#endif // _BOCCA_STDERR

  }
  if ( port._not_nil() ) {
    // even if the next cast fails, must release.
    grSrchPrt_fetched = true; 
    grSrchPrt = ::babel_cast< ex2::GraphSrchPort >(port);
    if (grSrchPrt._is_nil()) {

#ifdef _BOCCA_STDERR
      std::cerr << "ex2.Driver: Error casting gov::cca::Port "
                << "grSrchPrt to type "
                << "ex2::GraphSrchPort" << std::endl;
#endif //_BOCCA_STDERR

      goto BOCCAEXIT; // we cannot correctly continue. clean up and leave.
    } 
  } 


// Bocca generated code. bocca.protected.end(ex2.Driver.go:boccaGoProlog)



  // When this try/catch block is rewritten by the user, we will not change it.
  try {

    // All port instances should be rechecked for ._not_nil before calling in 
    // user code. Not all ports need be connected in arbitrary use.
    // The uses ports appear as local variables here named exactly as on the 
    // bocca commandline.

    // Insert-UserCode-Here {ex2.Driver.go} 
    ::sidl::EnfPolicy policy = ::sidl::EnfPolicy::_create();
    policy.setEnforceAll(::sidl::ContractClass_ALLCLASSES, true);
    std::cout<<"Policy enforcement:" << policy.areEnforcing()<<std::endl;
    std::cout<<"Enforcer "<<sidl_Enforcer_areEnforcing()<<std::endl;
    ::ex2::GraphOps graph;
    ::ex2::IntData idata;
    if (grSource._not_nil()){
      graph = grSource.createGraph();
      idata = ::ex2::IntData::_create();
      idata.setIntData(5);
      
      
      try{
	int result= 0;
	do{
	  // the start node is inserted in a loop just to make sure that
	  // in case of the flawed graph implementation the vertex does
          // exist
	  // this is important only for the breadth first search
          result = graph.insVertex(idata);
	}while (result != 0);
      bool exists = graph.vertexExists(idata);
      
      
      
      }catch (::sidl::PreViolation preExc){
	std::string enote = preExc.getNote();
	::std::cerr<<enote;
      }catch(::sidl::PostViolation postViol){
	std::string enote = postViol.getNote();
	std::cerr<<enote;
      }
    }else std::cout<<"Graph Source Port is null";
    if (initPort._not_nil()){
      //initialize the graph from a file
      initPort.initFromFile(graph, "setup");
    }else std::cout<<"Init Graph Port is null";
    int ecount = graph.getEdgeCount();
    int vcount = graph.getVertCount();
    std::cout<<"Ecount = "<<ecount<<std::endl;
    std::cout<<"Vcount = "<<vcount<<std::endl;
    if (grSrchPrt._not_nil()){
      //list of vertices and array of hops used for the search algorithm
      ::ex2::ListOps orderedlist;
      ::sidl::array<int32_t> arr;
      grSrchPrt.search(graph, idata, orderedlist, arr);
      if (orderedlist._not_nil()){
	//display results
	::ex2::ListNode elem=orderedlist.getHead();
	int i=0;
	while(elem._not_nil()){
	  ::ex2::Data d = elem.getData();
	  d.display();
	  if (arr) ::std::cout<<" "<<arr.get(i)<<::std::endl;
	  i++;
	  elem=elem.getNext();
	}
      }
      
      
    }
    
  } 
  // If unknown exceptions in the user code are tolerable and restart is ok, 
  // return -1 instead. -2 means the component is so confused that it and 
  // probably the application should be destroyed.
  // babel requires exact exception catching due to c++ binding of interfaces.
  catch (gov::cca::CCAException ex) {
    bocca_status = -2;
    std::string enote = ex.getNote();

#ifdef _BOCCA_STDERR
    std::cerr << "CCAException in user go code: " << enote << std::endl;
    std::cerr << "Returning -2 from go()" << std::endl;;
#endif

  }
  catch (sidl::RuntimeException ex) {
    bocca_status = -2;
    std::string enote = ex.getNote();

#ifdef _BOCCA_STDERR
    std::cerr << "RuntimeException in user go code: " << enote << std::endl;
    std::cerr << "Returning -2 from go()" << std::endl;;
#endif

  }
  catch (sidl::SIDLException ex) {
    bocca_status = -2;
    std::string enote = ex.getNote();

#ifdef _BOCCA_STDERR
    std::cerr << "SIDLException in user go code: " << enote << std::endl;
    std::cerr << "Returning -2 from go()" << std::endl;;
#endif

  }
  catch (sidl::BaseException ex) {
    bocca_status = -2;
    std::string enote = ex.getNote();

#ifdef _BOCCA_STDERR
    std::cerr << "BaseException in user go code: " << enote << std::endl;
    std::cerr << "Returning -2 from go()" << std::endl;;
#endif

  }
  catch (std::exception ex) {
    bocca_status = -2;

#ifdef _BOCCA_STDERR
    std::cerr << "C++ exception in user go code: " << ex.what() << std::endl;
    std::cerr << "Returning -2 from go()"  << std::endl;
#endif

  }
  catch (...) {
    bocca_status = -2;

#ifdef _BOCCA_STDERR
    std::cerr << "Odd exception in user go code " << std::endl;
    std::cerr << "Returning -2 from go()" << std::endl;
#endif

  }


  BOCCAEXIT:; // target point for error and regular cleanup. do not delete.
// Bocca generated code. bocca.protected.begin(ex2.Driver.go:boccaGoEpilog)

  // release grSource 
  if (grSource_fetched) {
    grSource_fetched = false;
    try{
      this->d_services.releasePort("grSource");
    } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
      std::cerr << "ex2.Driver: Error calling releasePort("
                << "\"grSource\") at " 
                << __FILE__ << ":" << __LINE__ -4 << ": " << ex.getNote() 
                << std::endl;
#endif // _BOCCA_STDERR

    }
    // c++ port reference will be dropped when function exits, but we 
    // must tell framework.
  }

  // release initPort 
  if (initPort_fetched) {
    initPort_fetched = false;
    try{
      this->d_services.releasePort("initPort");
    } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
      std::cerr << "ex2.Driver: Error calling releasePort("
                << "\"initPort\") at " 
                << __FILE__ << ":" << __LINE__ -4 << ": " << ex.getNote() 
                << std::endl;
#endif // _BOCCA_STDERR

    }
    // c++ port reference will be dropped when function exits, but we 
    // must tell framework.
  }

  // release grSrchPrt 
  if (grSrchPrt_fetched) {
    grSrchPrt_fetched = false;
    try{
      this->d_services.releasePort("grSrchPrt");
    } catch ( ::gov::cca::CCAException ex )  {

#ifdef _BOCCA_STDERR
      std::cerr << "ex2.Driver: Error calling releasePort("
                << "\"grSrchPrt\") at " 
                << __FILE__ << ":" << __LINE__ -4 << ": " << ex.getNote() 
                << std::endl;
#endif // _BOCCA_STDERR

    }
    // c++ port reference will be dropped when function exits, but we 
    // must tell framework.
  }


  return bocca_status;
// Bocca generated code. bocca.protected.end(ex2.Driver.go:boccaGoEpilog)

  // 
  // This method has not been implemented
  // 
  // DO-NOT-DELETE splicer.end(ex2.Driver.go)
}


// DO-NOT-DELETE splicer.begin(ex2.Driver._misc)
// Insert-Code-Here {ex2.Driver._misc} (miscellaneous code)
// DO-NOT-DELETE splicer.end(ex2.Driver._misc)

