// 
// File:          ex2_Driver_Skel.cxx
// Symbol:        ex2.Driver-v0.0
// Symbol Type:   class
// Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
// Description:   Server-side glue code for ex2.Driver
// 
// WARNING: Automatically generated; changes will be lost
// 
// 
#ifndef included_ex2_Driver_Impl_hxx
#include "ex2_Driver_Impl.hxx"
#endif
#ifndef included_ex2_Driver_IOR_h
#include "ex2_Driver_IOR.h"
#endif
#ifndef included_sidl_BaseException_hxx
#include "sidl_BaseException.hxx"
#endif
#ifndef included_sidl_LangSpecificException_hxx
#include "sidl_LangSpecificException.hxx"
#endif
// 
// Includes for all method dependencies.
// 
#ifndef included_ex2_GraphOps_hxx
#include "ex2_GraphOps.hxx"
#endif
#ifndef included_ex2_GraphSource_hxx
#include "ex2_GraphSource.hxx"
#endif
#ifndef included_ex2_GraphSrchPort_hxx
#include "ex2_GraphSrchPort.hxx"
#endif
#ifndef included_ex2_InitGraphPort_hxx
#include "ex2_InitGraphPort.hxx"
#endif
#ifndef included_ex2_IntData_hxx
#include "ex2_IntData.hxx"
#endif
#ifndef included_ex2_ListC_hxx
#include "ex2_ListC.hxx"
#endif
#ifndef included_ex2_ListNode_hxx
#include "ex2_ListNode.hxx"
#endif
#ifndef included_ex2_ListNodeC_hxx
#include "ex2_ListNodeC.hxx"
#endif
#ifndef included_ex2_ListOps_hxx
#include "ex2_ListOps.hxx"
#endif
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif
#include "sidl_String.h"
#include <stddef.h>
#include <cstring>

extern "C" {

  static void
  skel_ex2_Driver_boccaSetServices( 
  /* in */ struct ex2_Driver__object* self, /* in */ struct 
    gov_cca_Services__object* services, sidl_BaseInterface__object ** 
    _exception )
  {
    // pack args to dispatch to impl
    ::ex2::Driver_impl *_this = reinterpret_cast< ::ex2::Driver_impl*>(
      self->d_data);
    ::gov::cca::Services  _local_services(services);
    *_exception = 0;//init just to be safe

    // dispatch to impl
    try { 
      _this->boccaSetServices_impl( /* in */ _local_services );
    } catch ( ::sidl::BaseException _ex ) { 
      sidl_BaseInterface _throwaway_exception;
      (_ex._get_ior()->d_epv->f_add) (_ex._get_ior()->d_object,  __FILE__, __LINE__,"C++ skeleton for boccaSetServices.", &_throwaway_exception);
      _ex.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _ex._get_ior());

    } catch (...) {
      // Convert all other exceptions to LangSpecific
      ::sidl::LangSpecificException _unexpected = 
        ::sidl::LangSpecificException::_create();
      sidl_BaseInterface _throwaway_exception;
      (_unexpected._get_ior()->d_epv->f_setNote) (_unexpected._get_ior(),
        "Unexpected C++ exception", &_throwaway_exception);
      _unexpected.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _unexpected._get_ior());

    }
    // unpack results and cleanup

  }

  static void
  skel_ex2_Driver_boccaReleaseServices( 
  /* in */ struct ex2_Driver__object* self, /* in */ struct 
    gov_cca_Services__object* services, sidl_BaseInterface__object ** 
    _exception )
  {
    // pack args to dispatch to impl
    ::ex2::Driver_impl *_this = reinterpret_cast< ::ex2::Driver_impl*>(
      self->d_data);
    ::gov::cca::Services  _local_services(services);
    *_exception = 0;//init just to be safe

    // dispatch to impl
    try { 
      _this->boccaReleaseServices_impl( /* in */ _local_services );
    } catch ( ::sidl::BaseException _ex ) { 
      sidl_BaseInterface _throwaway_exception;
      (_ex._get_ior()->d_epv->f_add) (_ex._get_ior()->d_object,  __FILE__, __LINE__,"C++ skeleton for boccaReleaseServices.", &_throwaway_exception);
      _ex.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _ex._get_ior());

    } catch (...) {
      // Convert all other exceptions to LangSpecific
      ::sidl::LangSpecificException _unexpected = 
        ::sidl::LangSpecificException::_create();
      sidl_BaseInterface _throwaway_exception;
      (_unexpected._get_ior()->d_epv->f_setNote) (_unexpected._get_ior(),
        "Unexpected C++ exception", &_throwaway_exception);
      _unexpected.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _unexpected._get_ior());

    }
    // unpack results and cleanup

  }

  static void
  skel_ex2_Driver_boccaForceUsePortInclude( 
  /* in */ struct ex2_Driver__object* self, /* in */ struct 
    ex2_GraphSource__object* dummy0,/* in */ struct ex2_InitGraphPort__object* 
    dummy1,/* in */ struct ex2_GraphSrchPort__object* dummy2,/* in */ struct 
    ex2_GraphOps__object* dummy3,/* in */ struct ex2_IntData__object* dummy4,/* 
    in */ struct ex2_ListNodeC__object* dummy5,/* in */ struct 
    ex2_ListC__object* dummy6,/* in */ struct ex2_ListOps__object* dummy7,/* in 
    */ struct ex2_ListNode__object* dummy8, sidl_BaseInterface__object ** 
    _exception )
  {
    // pack args to dispatch to impl
    ::ex2::Driver_impl *_this = reinterpret_cast< ::ex2::Driver_impl*>(
      self->d_data);
    ::ex2::GraphSource  _local_dummy0(dummy0);
    ::ex2::InitGraphPort  _local_dummy1(dummy1);
    ::ex2::GraphSrchPort  _local_dummy2(dummy2);
    ::ex2::GraphOps  _local_dummy3(dummy3);
    ::ex2::IntData  _local_dummy4(dummy4);
    ::ex2::ListNodeC  _local_dummy5(dummy5);
    ::ex2::ListC  _local_dummy6(dummy6);
    ::ex2::ListOps  _local_dummy7(dummy7);
    ::ex2::ListNode  _local_dummy8(dummy8);
    *_exception = 0;//init just to be safe

    // dispatch to impl
    try { 
      _this->boccaForceUsePortInclude_impl( /* in */ _local_dummy0, /* in */ 
        _local_dummy1, /* in */ _local_dummy2, /* in */ _local_dummy3, /* in */ 
        _local_dummy4, /* in */ _local_dummy5, /* in */ _local_dummy6, /* in */ 
        _local_dummy7, /* in */ _local_dummy8 );
    } catch ( ::sidl::RuntimeException _ex ) { 
      sidl_BaseInterface _throwaway_exception;
      (_ex._get_ior()->d_epv->f_add) (_ex._get_ior()->d_object,  __FILE__, __LINE__,"C++ skeleton for boccaForceUsePortInclude.", &_throwaway_exception);
      _ex.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _ex._get_ior());

    } catch (...) {
      // Convert all other exceptions to LangSpecific
      ::sidl::LangSpecificException _unexpected = 
        ::sidl::LangSpecificException::_create();
      sidl_BaseInterface _throwaway_exception;
      (_unexpected._get_ior()->d_epv->f_setNote) (_unexpected._get_ior(),
        "Unexpected C++ exception", &_throwaway_exception);
      _unexpected.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _unexpected._get_ior());

    }
    // unpack results and cleanup

  }

  static void
  skel_ex2_Driver_setServices( 
  /* in */ struct ex2_Driver__object* self, /* in */ struct 
    gov_cca_Services__object* services, sidl_BaseInterface__object ** 
    _exception )
  {
    // pack args to dispatch to impl
    ::ex2::Driver_impl *_this = reinterpret_cast< ::ex2::Driver_impl*>(
      self->d_data);
    ::gov::cca::Services  _local_services(services);
    *_exception = 0;//init just to be safe

    // dispatch to impl
    try { 
      _this->setServices_impl( /* in */ _local_services );
    } catch ( ::sidl::BaseException _ex ) { 
      sidl_BaseInterface _throwaway_exception;
      (_ex._get_ior()->d_epv->f_add) (_ex._get_ior()->d_object,  __FILE__, __LINE__,"C++ skeleton for setServices.", &_throwaway_exception);
      _ex.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _ex._get_ior());

    } catch (...) {
      // Convert all other exceptions to LangSpecific
      ::sidl::LangSpecificException _unexpected = 
        ::sidl::LangSpecificException::_create();
      sidl_BaseInterface _throwaway_exception;
      (_unexpected._get_ior()->d_epv->f_setNote) (_unexpected._get_ior(),
        "Unexpected C++ exception", &_throwaway_exception);
      _unexpected.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _unexpected._get_ior());

    }
    // unpack results and cleanup

  }

  static void
  skel_ex2_Driver_releaseServices( 
  /* in */ struct ex2_Driver__object* self, /* in */ struct 
    gov_cca_Services__object* services, sidl_BaseInterface__object ** 
    _exception )
  {
    // pack args to dispatch to impl
    ::ex2::Driver_impl *_this = reinterpret_cast< ::ex2::Driver_impl*>(
      self->d_data);
    ::gov::cca::Services  _local_services(services);
    *_exception = 0;//init just to be safe

    // dispatch to impl
    try { 
      _this->releaseServices_impl( /* in */ _local_services );
    } catch ( ::sidl::BaseException _ex ) { 
      sidl_BaseInterface _throwaway_exception;
      (_ex._get_ior()->d_epv->f_add) (_ex._get_ior()->d_object,  __FILE__, __LINE__,"C++ skeleton for releaseServices.", &_throwaway_exception);
      _ex.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _ex._get_ior());

    } catch (...) {
      // Convert all other exceptions to LangSpecific
      ::sidl::LangSpecificException _unexpected = 
        ::sidl::LangSpecificException::_create();
      sidl_BaseInterface _throwaway_exception;
      (_unexpected._get_ior()->d_epv->f_setNote) (_unexpected._get_ior(),
        "Unexpected C++ exception", &_throwaway_exception);
      _unexpected.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _unexpected._get_ior());

    }
    // unpack results and cleanup

  }

  static int32_t
  skel_ex2_Driver_go( 
  /* in */ struct ex2_Driver__object* self, sidl_BaseInterface__object ** 
    _exception )
  {
    // pack args to dispatch to impl
    int32_t _result = 0;
    ::ex2::Driver_impl *_this = reinterpret_cast< ::ex2::Driver_impl*>(
      self->d_data);
    *_exception = 0;//init just to be safe

    // dispatch to impl
    try { 
      _result = _this->go_impl(  );
    } catch ( ::sidl::RuntimeException _ex ) { 
      sidl_BaseInterface _throwaway_exception;
      (_ex._get_ior()->d_epv->f_add) (_ex._get_ior()->d_object,  __FILE__, __LINE__,"C++ skeleton for go.", &_throwaway_exception);
      _ex.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _ex._get_ior());

      return _result;
    } catch (...) {
      // Convert all other exceptions to LangSpecific
      ::sidl::LangSpecificException _unexpected = 
        ::sidl::LangSpecificException::_create();
      sidl_BaseInterface _throwaway_exception;
      (_unexpected._get_ior()->d_epv->f_setNote) (_unexpected._get_ior(),
        "Unexpected C++ exception", &_throwaway_exception);
      _unexpected.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _unexpected._get_ior());

      return _result;
    }
    // unpack results and cleanup

    return _result;
  }

#ifdef WITH_RMI
  struct ex2_GraphOps__object* skel_ex2_Driver_fconnect_ex2_GraphOps(const 
    char* url, sidl_bool ar, sidl_BaseInterface *_ex) { 
    return ex2_GraphOps__connectI(url, ar, _ex);
  }

  struct ex2_ListNodeC__object* skel_ex2_Driver_fconnect_ex2_ListNodeC(const 
    char* url, sidl_bool ar, sidl_BaseInterface *_ex) { 
    return ex2_ListNodeC__connectI(url, ar, _ex);
  }

  struct gov_cca_Services__object* skel_ex2_Driver_fconnect_gov_cca_Services(
    const char* url, sidl_bool ar, sidl_BaseInterface *_ex) { 
    return gov_cca_Services__connectI(url, ar, _ex);
  }

  struct ex2_GraphSource__object* skel_ex2_Driver_fconnect_ex2_GraphSource(
    const char* url, sidl_bool ar, sidl_BaseInterface *_ex) { 
    return ex2_GraphSource__connectI(url, ar, _ex);
  }

  struct sidl_BaseInterface__object* 
    skel_ex2_Driver_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
    sidl_BaseInterface *_ex) { 
    return sidl_BaseInterface__connectI(url, ar, _ex);
  }

  struct ex2_GraphSrchPort__object* skel_ex2_Driver_fconnect_ex2_GraphSrchPort(
    const char* url, sidl_bool ar, sidl_BaseInterface *_ex) { 
    return ex2_GraphSrchPort__connectI(url, ar, _ex);
  }

  struct ex2_ListC__object* skel_ex2_Driver_fconnect_ex2_ListC(const char* url, 
    sidl_bool ar, sidl_BaseInterface *_ex) { 
    return ex2_ListC__connectI(url, ar, _ex);
  }

  struct ex2_IntData__object* skel_ex2_Driver_fconnect_ex2_IntData(const char* 
    url, sidl_bool ar, sidl_BaseInterface *_ex) { 
    return ex2_IntData__connectI(url, ar, _ex);
  }

  struct ex2_ListOps__object* skel_ex2_Driver_fconnect_ex2_ListOps(const char* 
    url, sidl_bool ar, sidl_BaseInterface *_ex) { 
    return ex2_ListOps__connectI(url, ar, _ex);
  }

  struct ex2_ListNode__object* skel_ex2_Driver_fconnect_ex2_ListNode(const 
    char* url, sidl_bool ar, sidl_BaseInterface *_ex) { 
    return ex2_ListNode__connectI(url, ar, _ex);
  }

  struct ex2_InitGraphPort__object* skel_ex2_Driver_fconnect_ex2_InitGraphPort(
    const char* url, sidl_bool ar, sidl_BaseInterface *_ex) { 
    return ex2_InitGraphPort__connectI(url, ar, _ex);
  }

#endif /*WITH_RMI*/
  void
  ex2_Driver__call_load(void) {::ex2::Driver_impl::_load();}

  static void
  skel_ex2_Driver__ctor(struct ex2_Driver__object* self, struct 
    sidl_BaseInterface__object **_ex ) { 
    try {
      self->d_data = reinterpret_cast< void*>(new ::ex2::Driver_impl(self));
    } catch ( ::sidl::RuntimeException _exc ) {
      sidl_BaseInterface _throwaway_exception;
      (_exc._get_ior()->d_epv->f_add) (_exc._get_ior()->d_object, __FILE__, __LINE__," C++ skeleton for _ctor.", &_throwaway_exception);
      _exc.addRef();
      *_ex = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _exc._get_ior());
    } catch (...) {
      // Convert all other exceptions to LangSpecific
      ::sidl::LangSpecificException _unexpected = 
        ::sidl::LangSpecificException::_create();
      _unexpected.setNote("Unexpected C++ exception in _ctor.");
      _unexpected.addRef();
      *_ex = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _unexpected._get_ior());
    }
  }

  static void
  skel_ex2_Driver__ctor2(struct ex2_Driver__object* self, void* private_data, 
    struct sidl_BaseInterface__object **_ex ) { 
    *_ex = NULL;
  }

  static void
  skel_ex2_Driver__dtor(struct ex2_Driver__object* self, struct 
    sidl_BaseInterface__object **_ex ) { 
    try {
      ::ex2::Driver_impl* loc_data = reinterpret_cast< ::ex2::Driver_impl*>(
        self->d_data);
      if(!loc_data->_isWrapped()) {
        delete (loc_data);
      }
    } catch ( ::sidl::RuntimeException _exc ) {
      sidl_BaseInterface _throwaway_exception;
      (_exc._get_ior()->d_epv->f_add) (_exc._get_ior()->d_object, __FILE__, __LINE__," C++ skeleton for _dtor.", &_throwaway_exception);
      _exc.addRef();
      *_ex = reinterpret_cast< struct sidl_BaseInterface__object * >(_exc._get_ior());
    } catch (...) {
      // Convert all other exceptions to LangSpecific
      ::sidl::LangSpecificException _unexpected = ::sidl::LangSpecificException::_create();
      _unexpected.setNote("Unexpected C++ exception in _dtor.");
      _unexpected.addRef();
      *_ex = reinterpret_cast< struct sidl_BaseInterface__object * >(_unexpected._get_ior());
    }
  }

  void
  ex2_Driver__set_epv(struct ex2_Driver__epv *epv,
  struct ex2_Driver__pre_epv *pre_epv, struct ex2_Driver__post_epv *post_epv){
    // initialize builtin methods
    epv->f__ctor = skel_ex2_Driver__ctor;
    epv->f__ctor2 = skel_ex2_Driver__ctor2;
    epv->f__dtor = skel_ex2_Driver__dtor;
    // initialize local methods
    pre_epv->f_boccaSetServices_pre = NULL;
    epv->f_boccaSetServices = skel_ex2_Driver_boccaSetServices;
    post_epv->f_boccaSetServices_post = NULL;
    pre_epv->f_boccaReleaseServices_pre = NULL;
    epv->f_boccaReleaseServices = skel_ex2_Driver_boccaReleaseServices;
    post_epv->f_boccaReleaseServices_post = NULL;
    pre_epv->f_boccaForceUsePortInclude_pre = NULL;
    epv->f_boccaForceUsePortInclude = skel_ex2_Driver_boccaForceUsePortInclude;
    post_epv->f_boccaForceUsePortInclude_post = NULL;
    pre_epv->f_setServices_pre = NULL;
    epv->f_setServices = skel_ex2_Driver_setServices;
    post_epv->f_setServices_post = NULL;
    pre_epv->f_releaseServices_pre = NULL;
    epv->f_releaseServices = skel_ex2_Driver_releaseServices;
    post_epv->f_releaseServices_post = NULL;
    pre_epv->f_go_pre = NULL;
    epv->f_go = skel_ex2_Driver_go;
    post_epv->f_go_post = NULL;
  }


} // end extern "C"
