
/*
 * File:          ex2_GraphC2_Impl.c
 * Symbol:        ex2.GraphC2-v0.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for ex2.GraphC2
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "ex2.GraphC2" (version 0.0)
 */

#include "ex2_GraphC2_Impl.h"
#include "sidl_NotImplementedException.h"
#include "sidl_Exception.h"
#ifndef included_sidl_MemAllocException_h
#include "sidl_MemAllocException.h"
#endif

/* DO-NOT-DELETE splicer.begin(ex2.GraphC2._includes) */

/* Insert-UserCode-Here {ex2.GraphC2._includes} (includes and arbitrary code) */

/* Bocca generated code. bocca.protected.begin(ex2.GraphC2._includes) */
#include <stdlib.h>
#include <string.h>
#include "sidl_SIDLException.h"

#define _BOCCA_CTOR_MESSAGES 0

#ifdef _BOCCA_STDERR

#define BOCCA_FPRINTF fprintf
#include <stdio.h>
#include "sidl_String.h"
#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif /* _BOCCA_CTOR_PRINT */

#else /* _BOCCA_STDERR */
#define BOCCA_FPRINTF boccaPrintNothing
#endif /* _BOCCA_STDERR */

static int
boccaPrintNothing(void *v, const char * s, ...)
{
  (void)v; (void)s;
  return 0;
}
/* Bocca generated code. bocca.protected.end(ex2.GraphC2._includes) */

/* Insert-UserCode-Here {ex2.GraphC2._includes} (includes and arbitrary code) */

/* DO-NOT-DELETE splicer.end(ex2.GraphC2._includes) */

#define SIDL_IOR_MAJOR_VERSION 2
#define SIDL_IOR_MINOR_VERSION 0
/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_GraphC2__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_GraphC2__load(
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.GraphC2._load) */
    /* Insert-Code-Here {ex2.GraphC2._load} (static class initializer method) */
    /*
     * This method has not been implemented
     */

    /* DO-DELETE-WHEN-IMPLEMENTING exception.begin(ex2.GraphC2._load) */
    SIDL_THROW(*_ex, sidl_NotImplementedException,     "This method has not been implemented");
  EXIT:;
    /* DO-DELETE-WHEN-IMPLEMENTING exception.end(ex2.GraphC2._load) */
    /* DO-NOT-DELETE splicer.end(ex2.GraphC2._load) */
  }
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_GraphC2__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_GraphC2__ctor(
  /* in */ ex2_GraphC2 self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(ex2.GraphC2._ctor) */

  /* Insert-UserDecl-Here {ex2.GraphC2._ctor} (constructor method) */
    
  /* bocca-default-code. User may edit or delete.begin(ex2.GraphC2._ctor) */
   struct ex2_GraphC2__data *dptr = 
       (struct ex2_GraphC2__data*)malloc(sizeof(struct ex2_GraphC2__data));
   if (dptr) {
      memset(dptr, 0, sizeof(struct ex2_GraphC2__data));
   }
   ex2_GraphC2__set_data(self, dptr);
   #if _BOCCA_CTOR_MESSAGES
     BOCCA_FPRINTF(stderr, 
        "CTOR ex2.GraphC2: %s constructed data %p in self %p\n", 
        __FUNC__, dptr, self);
   #endif /* _BOCCA_CTOR_MESSAGES */
  /* bocca-default-code. User may edit or delete.end(ex2.GraphC2._ctor) */

  /* initialize user elements of dptr here */
  /* Insert-UserCode-Here {ex2.GraphC2._ctor} (constructor method) */

  /* DO-NOT-DELETE splicer.end(ex2.GraphC2._ctor) */
  }
}

/*
 * Special Class constructor called when the user wants to wrap his own private data.
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_GraphC2__ctor2"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_GraphC2__ctor2(
  /* in */ ex2_GraphC2 self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.GraphC2._ctor2) */
    /* Insert-Code-Here {ex2.GraphC2._ctor2} (special constructor method) */
    /*
     * This method has not been implemented
     */

    /* DO-DELETE-WHEN-IMPLEMENTING exception.begin(ex2.GraphC2._ctor2) */
    SIDL_THROW(*_ex, sidl_NotImplementedException,     "This method has not been implemented");
  EXIT:;
    /* DO-DELETE-WHEN-IMPLEMENTING exception.end(ex2.GraphC2._ctor2) */
    /* DO-NOT-DELETE splicer.end(ex2.GraphC2._ctor2) */
  }
}
/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_GraphC2__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_GraphC2__dtor(
  /* in */ ex2_GraphC2 self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(ex2.GraphC2._dtor) */

  /* deinitialize user elements of dptr here */
  /* Insert-UserCode-Here {ex2.GraphC2._dtor} (destructor method) */
    
  /* bocca-default-code. User may edit or delete.begin(ex2.GraphC2._dtor) */
   struct ex2_GraphC2__data *dptr = 
                ex2_GraphC2__get_data(self);
   if (dptr) {
      free(dptr);
      ex2_GraphC2__set_data(self, NULL);
   }
   #if _BOCCA_CTOR_MESSAGES
     BOCCA_FPRINTF(stderr, "DTOR ex2.GraphC2: %s freed data %p in self %p\n", 
                   __FUNC__, dptr, self);
   #endif /* _BOCCA_CTOR_MESSAGES */
  /* bocca-default-code. User may edit or delete.end(ex2.GraphC2._dtor) */

  /* DO-NOT-DELETE splicer.end(ex2.GraphC2._dtor) */
  }
}

/*
 *  This function should never be called, but helps babel generate better code. 
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_GraphC2_boccaForceUsePortInclude"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_GraphC2_boccaForceUsePortInclude(
  /* in */ ex2_GraphC2 self,
  /* in */ ex2_AdjList dummy0,
  /* in */ ex2_ListOps dummy1,
  /* in */ ex2_AdjListC dummy2,
  /* in */ ex2_Data dummy3,
  /* in */ ex2_ListC dummy4,
  /* in */ ex2_ListNode dummy5,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  /* DO-NOT-DELETE splicer.begin(ex2.GraphC2.boccaForceUsePortInclude) */
/* DO-NOT-EDIT-BOCCA */
  /* Bocca generated code. bocca.protected.begin(ex2.GraphC2.boccaForceUsePortInclude) */
    (void)self;
    (void)dummy0;
    (void)dummy1;
    (void)dummy2;
    (void)dummy3;
    (void)dummy4;
    (void)dummy5;

  /* Bocca generated code. bocca.protected.end(ex2.GraphC2.boccaForceUsePortInclude) */
  /* DO-NOT-DELETE splicer.end(ex2.GraphC2.boccaForceUsePortInclude) */
  }
}

/*
 * Inserts a vertex into a graph. 
 * returns 0 if the insertion is successful, 
 * 1 if the vertex already exists. -1 otherwise
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_GraphC2_insVertex"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_ex2_GraphC2_insVertex(
  /* in */ ex2_GraphC2 self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.GraphC2.insVertex) */
    /* Insert-Code-Here {ex2.GraphC2.insVertex} (insVertex method) */
    /*
     * This method has not been implemented
     */

    /* DO-DELETE-WHEN-IMPLEMENTING exception.begin(ex2.GraphC2.insVertex) */
    SIDL_THROW(*_ex, sidl_NotImplementedException,     "This method has not been implemented");
  EXIT:;
    /* DO-DELETE-WHEN-IMPLEMENTING exception.end(ex2.GraphC2.insVertex) */
    /* DO-NOT-DELETE splicer.end(ex2.GraphC2.insVertex) */
  }
}

/*
 * Removes vertex from a graph. 
 * returns 0 if removal was successful, 
 * -1 otherwise 
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_GraphC2_remVertex"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_ex2_GraphC2_remVertex(
  /* in */ ex2_GraphC2 self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.GraphC2.remVertex) */
    /* Insert-Code-Here {ex2.GraphC2.remVertex} (remVertex method) */
    /*
     * This method has not been implemented
     */

    /* DO-DELETE-WHEN-IMPLEMENTING exception.begin(ex2.GraphC2.remVertex) */
    SIDL_THROW(*_ex, sidl_NotImplementedException,     "This method has not been implemented");
  EXIT:;
    /* DO-DELETE-WHEN-IMPLEMENTING exception.end(ex2.GraphC2.remVertex) */
    /* DO-NOT-DELETE splicer.end(ex2.GraphC2.remVertex) */
  }
}

/*
 * Inserts an edge specified by vertices d1 and d2. 
 * Both vertices must have been inserted previously. 
 * The new edge is represented by pointer to d2 
 * in the adjacency list of d1. To enter an edge 
 * into an undirected graph, call this operation 
 * twice, once to insert an edge from d1 to d2, 
 * and again to insert an edge from d2 to d1. 
 * Method returns 0 if the insertion was successful,
 * 1 if the edge already exists and -1 otherwise.
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_GraphC2_insEdge"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_ex2_GraphC2_insEdge(
  /* in */ ex2_GraphC2 self,
  /* in */ ex2_Data d1,
  /* in */ ex2_Data d2,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.GraphC2.insEdge) */
    /* Insert-Code-Here {ex2.GraphC2.insEdge} (insEdge method) */
    /*
     * This method has not been implemented
     */

    /* DO-DELETE-WHEN-IMPLEMENTING exception.begin(ex2.GraphC2.insEdge) */
    SIDL_THROW(*_ex, sidl_NotImplementedException,     "This method has not been implemented");
  EXIT:;
    /* DO-DELETE-WHEN-IMPLEMENTING exception.end(ex2.GraphC2.insEdge) */
    /* DO-NOT-DELETE splicer.end(ex2.GraphC2.insEdge) */
  }
}

/*
 * Removes the edge from d1 to d2. returns 0 
 * if removing of edge was successful, -1 otherwise.
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_GraphC2_remEdge"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_ex2_GraphC2_remEdge(
  /* in */ ex2_GraphC2 self,
  /* in */ ex2_Data d1,
  /* in */ ex2_Data d2,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.GraphC2.remEdge) */
    /* Insert-Code-Here {ex2.GraphC2.remEdge} (remEdge method) */
    /*
     * This method has not been implemented
     */

    /* DO-DELETE-WHEN-IMPLEMENTING exception.begin(ex2.GraphC2.remEdge) */
    SIDL_THROW(*_ex, sidl_NotImplementedException,     "This method has not been implemented");
  EXIT:;
    /* DO-DELETE-WHEN-IMPLEMENTING exception.end(ex2.GraphC2.remEdge) */
    /* DO-NOT-DELETE splicer.end(ex2.GraphC2.remEdge) */
  }
}

/*
 *  
 * Returns vertices that are adjacent to Data d.
 * The vertices are returned in the form of actual 
 * AdjList data structure with vertex data member pointing to d.
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_GraphC2_getAdjList"

#ifdef __cplusplus
extern "C"
#endif
ex2_AdjList
impl_ex2_GraphC2_getAdjList(
  /* in */ ex2_GraphC2 self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.GraphC2.getAdjList) */
    /* Insert-Code-Here {ex2.GraphC2.getAdjList} (getAdjList method) */
    /*
     * This method has not been implemented
     */

    /* DO-DELETE-WHEN-IMPLEMENTING exception.begin(ex2.GraphC2.getAdjList) */
    SIDL_THROW(*_ex, sidl_NotImplementedException,     "This method has not been implemented");
  EXIT:;
    /* DO-DELETE-WHEN-IMPLEMENTING exception.end(ex2.GraphC2.getAdjList) */
    /* DO-NOT-DELETE splicer.end(ex2.GraphC2.getAdjList) */
  }
}

/*
 * Determines whether the vertex specified by d2
 * is adjacent to the vertex specified by d1 in graph.
 * Returns 1 if the second vertex is adjacent to the 
 * first vertex, or 0 otherwise
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_GraphC2_isAdjacent"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_ex2_GraphC2_isAdjacent(
  /* in */ ex2_GraphC2 self,
  /* in */ ex2_Data d1,
  /* in */ ex2_Data d2,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.GraphC2.isAdjacent) */
    /* Insert-Code-Here {ex2.GraphC2.isAdjacent} (isAdjacent method) */
    /*
     * This method has not been implemented
     */

    /* DO-DELETE-WHEN-IMPLEMENTING exception.begin(ex2.GraphC2.isAdjacent) */
    SIDL_THROW(*_ex, sidl_NotImplementedException,     "This method has not been implemented");
  EXIT:;
    /* DO-DELETE-WHEN-IMPLEMENTING exception.end(ex2.GraphC2.isAdjacent) */
    /* DO-NOT-DELETE splicer.end(ex2.GraphC2.isAdjacent) */
  }
}

/*
 * Returns all adjacency data structures in the 
 * form of a List interface. or NULL if fails.
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_GraphC2_getAdjLists"

#ifdef __cplusplus
extern "C"
#endif
ex2_ListOps
impl_ex2_GraphC2_getAdjLists(
  /* in */ ex2_GraphC2 self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.GraphC2.getAdjLists) */
    /* Insert-Code-Here {ex2.GraphC2.getAdjLists} (getAdjLists method) */
    /*
     * This method has not been implemented
     */

    /* DO-DELETE-WHEN-IMPLEMENTING exception.begin(ex2.GraphC2.getAdjLists) */
    SIDL_THROW(*_ex, sidl_NotImplementedException,     "This method has not been implemented");
  EXIT:;
    /* DO-DELETE-WHEN-IMPLEMENTING exception.end(ex2.GraphC2.getAdjLists) */
    /* DO-NOT-DELETE splicer.end(ex2.GraphC2.getAdjLists) */
  }
}

/*
 * Returns current vertex count
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_GraphC2_getVertCount"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_ex2_GraphC2_getVertCount(
  /* in */ ex2_GraphC2 self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.GraphC2.getVertCount) */
    /* Insert-Code-Here {ex2.GraphC2.getVertCount} (getVertCount method) */
    /*
     * This method has not been implemented
     */

    /* DO-DELETE-WHEN-IMPLEMENTING exception.begin(ex2.GraphC2.getVertCount) */
    SIDL_THROW(*_ex, sidl_NotImplementedException,     "This method has not been implemented");
  EXIT:;
    /* DO-DELETE-WHEN-IMPLEMENTING exception.end(ex2.GraphC2.getVertCount) */
    /* DO-NOT-DELETE splicer.end(ex2.GraphC2.getVertCount) */
  }
}

/*
 * Returns current edge count
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_GraphC2_getEdgeCount"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_ex2_GraphC2_getEdgeCount(
  /* in */ ex2_GraphC2 self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.GraphC2.getEdgeCount) */
    /* Insert-Code-Here {ex2.GraphC2.getEdgeCount} (getEdgeCount method) */
    /*
     * This method has not been implemented
     */

    /* DO-DELETE-WHEN-IMPLEMENTING exception.begin(ex2.GraphC2.getEdgeCount) */
    SIDL_THROW(*_ex, sidl_NotImplementedException,     "This method has not been implemented");
  EXIT:;
    /* DO-DELETE-WHEN-IMPLEMENTING exception.end(ex2.GraphC2.getEdgeCount) */
    /* DO-NOT-DELETE splicer.end(ex2.GraphC2.getEdgeCount) */
  }
}

/*
 * Returns true if the vertex is present in the graph, false otherwise
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_GraphC2_vertexExists"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_ex2_GraphC2_vertexExists(
  /* in */ ex2_GraphC2 self,
  /* in */ ex2_Data d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.GraphC2.vertexExists) */
    /* Insert-Code-Here {ex2.GraphC2.vertexExists} (vertexExists method) */
    /*
     * This method has not been implemented
     */

    /* DO-DELETE-WHEN-IMPLEMENTING exception.begin(ex2.GraphC2.vertexExists) */
    SIDL_THROW(*_ex, sidl_NotImplementedException,     "This method has not been implemented");
  EXIT:;
    /* DO-DELETE-WHEN-IMPLEMENTING exception.end(ex2.GraphC2.vertexExists) */
    /* DO-NOT-DELETE splicer.end(ex2.GraphC2.vertexExists) */
  }
}
/* Babel internal methods, Users should not edit below this line. */

/* DO-NOT-DELETE splicer.begin(_misc) */
/* Insert-Code-Here {_misc} (miscellaneous code) */
/* DO-NOT-DELETE splicer.end(_misc) */

