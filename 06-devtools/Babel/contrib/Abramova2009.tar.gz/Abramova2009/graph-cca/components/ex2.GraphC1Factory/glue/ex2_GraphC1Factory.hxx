// 
// File:          ex2_GraphC1Factory.hxx
// Symbol:        ex2.GraphC1Factory-v0.0
// Symbol Type:   class
// Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
// Description:   Client-side glue code for ex2.GraphC1Factory
// 
// WARNING: Automatically generated; changes will be lost
// 
// 

#ifndef included_ex2_GraphC1Factory_hxx
#define included_ex2_GraphC1Factory_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
// declare class before main #includes
// (this alleviates circular #include guard problems)[BUG#393]
namespace ex2 { 

  class GraphC1Factory;
} // end namespace ex2

// Some compilers need to define array template before the specializations
namespace sidl {
  template<>
  class array< ::ex2::GraphC1Factory >;
}
// 
// Forward declarations for method dependencies.
// 
namespace ex2 { 

  class GraphC1;
} // end namespace ex2

namespace ex2 { 

  class GraphOps;
} // end namespace ex2

namespace gov { 
  namespace cca { 

    class CCAException;
  } // end namespace cca
} // end namespace gov

namespace gov { 
  namespace cca { 

    class Services;
  } // end namespace cca
} // end namespace gov

namespace sidl { 

  class RuntimeException;
} // end namespace sidl

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_ex2_GraphC1Factory_IOR_h
#include "ex2_GraphC1Factory_IOR.h"
#endif
#ifndef included_ex2_GraphSource_hxx
#include "ex2_GraphSource.hxx"
#endif
#ifndef included_gov_cca_Component_hxx
#include "gov_cca_Component.hxx"
#endif
#ifndef included_gov_cca_ComponentRelease_hxx
#include "gov_cca_ComponentRelease.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
namespace sidl {
  namespace rmi {
    class Call;
    class Return;
    class Ticket;
  }
  namespace rmi {
    class InstanceHandle;
  }
}
namespace ex2 { 

  /**
   * Symbol "ex2.GraphC1Factory" (version 0.0)
   */
  class GraphC1Factory: public virtual ::ex2::GraphSource, public virtual 
    ::gov::cca::Component, public virtual ::gov::cca::ComponentRelease, public 
    virtual ::sidl::BaseClass {

    //////////////////////////////////////////////////
    // 
    // Special methods for throwing exceptions
    // 

  private:
    static 
    void
    throwException1(
      const char* methodName,
      struct sidl_BaseInterface__object *_exception
    )
      // throws:
    ;
    static 
    void
    throwException0(
      const char* methodName,
      struct sidl_BaseInterface__object *_exception
    )
      // throws:
      //    ::gov::cca::CCAException
      //    ::sidl::RuntimeException
    ;

    //////////////////////////////////////////////////
    // 
    // User Defined Methods
    // 

  public:
    /**
     * user defined non-static method
     */
    void
    boccaSetServices (
      /* in */const ::gov::cca::Services& services
    )
    // throws:
    //    ::gov::cca::CCAException
    //    ::sidl::RuntimeException
    ;


    /**
     * user defined non-static method
     */
    void
    boccaReleaseServices (
      /* in */const ::gov::cca::Services& services
    )
    // throws:
    //    ::gov::cca::CCAException
    //    ::sidl::RuntimeException
    ;



    /**
     *  This function should never be called, but helps babel generate better code. 
     */
    void
    boccaForceUsePortInclude (
      /* in */const ::ex2::GraphC1& dummy0
    )
    ;



    /**
     *  Starts up a component presence in the calling framework.
     * @param services the component instance's handle on the framework world.
     * Contracts concerning services and setServices:
     * 
     * The component interaction with the CCA framework
     * and Ports begins on the call to setServices by the framework.
     * 
     * This function is called exactly once for each instance created
     * by the framework.
     * 
     * The argument services will never be nil/null.
     * 
     * Those uses ports which are automatically connected by the framework
     * (so-called service-ports) may be obtained via getPort during
     * setServices.
     */
    void
    setServices (
      /* in */const ::gov::cca::Services& services
    )
    // throws:
    //    ::gov::cca::CCAException
    //    ::sidl::RuntimeException
    ;



    /**
     * Shuts down a component presence in the calling framework.
     * @param services the component instance's handle on the framework world.
     * Contracts concerning services and setServices:
     * 
     * This function is called exactly once for each callback registered
     * through Services.
     * 
     * The argument services will never be nil/null.
     * The argument services will always be the same as that received in
     * setServices.
     * 
     * During this call the component should release any interfaces
     * acquired by getPort().
     * 
     * During this call the component should reset to nil any stored
     * reference to services.
     * 
     * After this call, the component instance will be removed from the
     * framework. If the component instance was created by the
     * framework, it will be destroyed, not recycled, The behavior of
     * any port references obtained from this component instance and
     * stored elsewhere becomes undefined.
     * 
     * Notes for the component implementor:
     * 1) The component writer may perform blocking activities
     * within releaseServices, such as waiting for remote computations
     * to shutdown.
     * 2) It is good practice during releaseServices for the component
     * writer to remove or unregister all the ports it defined.
     */
    void
    releaseServices (
      /* in */const ::gov::cca::Services& services
    )
    // throws:
    //    ::gov::cca::CCAException
    //    ::sidl::RuntimeException
    ;


    /**
     * user defined non-static method
     */
    ::ex2::GraphOps
    createGraph() ;


    //////////////////////////////////////////////////
    // 
    // End User Defined Methods
    // (everything else in this file is specific to
    //  Babel's C++ bindings)
    // 

  public:
    typedef struct ex2_GraphC1Factory__object ior_t;
    typedef struct ex2_GraphC1Factory__external ext_t;
    typedef struct ex2_GraphC1Factory__sepv sepv_t;

    // default constructor
    GraphC1Factory() { }
    // static constructor
    static ::ex2::GraphC1Factory _create();


#ifdef WITH_RMI

    // RMI constructor
    static ::ex2::GraphC1Factory _create( /*in*/ const std::string& url );

    // RMI connect
    static inline ::ex2::GraphC1Factory _connect( /*in*/ const std::string& url 
      ) { 
      return _connect(url, true);
    }

    // RMI connect 2
    static ::ex2::GraphC1Factory _connect( /*in*/ const std::string& url, 
      /*in*/ const bool ar  );


#endif /*WITH_RMI*/

    // default destructor
    virtual ~GraphC1Factory () { }

    // copy constructor
    GraphC1Factory ( const GraphC1Factory& original );

    // assignment operator
    GraphC1Factory& operator= ( const GraphC1Factory& rhs );


    protected:
    // Internal data wrapping method
    static ior_t*  _wrapObj(void* private_data);


    public:
    // conversion from ior to C++ class
    GraphC1Factory ( GraphC1Factory::ior_t* ior );

    // Alternate constructor: does not call addRef()
    // (sets d_weak_reference=isWeak)
    // For internal use by Impls (fixes bug#275)
    GraphC1Factory ( GraphC1Factory::ior_t* ior, bool isWeak );

    inline ior_t* _get_ior() const throw() {
      return reinterpret_cast< ior_t*>(d_self);
    }

    inline void _set_ior( ior_t* ptr ) throw () { 
      if(d_self == ptr) {return;}
      d_self = reinterpret_cast< void*>(ptr);

      if( ptr != NULL ) {
        gov_cca_Port_IORCache = &((*ptr).d_gov_cca_port);
        ex2_GraphSource_IORCache = &((*ptr).d_ex2_graphsource);
        gov_cca_ComponentRelease_IORCache = &((
          *ptr).d_gov_cca_componentrelease);
        gov_cca_Component_IORCache = &((*ptr).d_gov_cca_component);
      } else {
        gov_cca_Port_IORCache = NULL;
        ex2_GraphSource_IORCache = NULL;
        gov_cca_ComponentRelease_IORCache = NULL;
        gov_cca_Component_IORCache = NULL;
      }
    }

    virtual int _set_ior_typesafe( struct sidl_BaseInterface__object *obj,
                                   const ::std::type_info &argtype );

    bool _is_nil() const throw () { return (d_self==0); }

    bool _not_nil() const throw () { return (d_self!=0); }

    bool operator !() const throw () { return (d_self==0); }

    static inline const char * type_name() throw () { return 
      "ex2.GraphC1Factory";}

    static struct ex2_GraphC1Factory__object* _cast(const void* src);

    // execute member function by name
    void _exec(const std::string& methodName,
               ::sidl::rmi::Call& inArgs,
               ::sidl::rmi::Return& outArgs);

    /**
     * Get the URL of the Implementation of this object (for RMI)
     */
    ::std::string
    _getURL() // throws:
    //    ::sidl::RuntimeException
    ;


    /**
     * Method to enable/disable method hooks invocation.
     */
    void
    _set_hooks (
      /* in */bool enable
    )
    // throws:
    //    ::sidl::RuntimeException
    ;


    /**
     * Method to enable/disable interface contract enforcement.
     */
    void
    _set_contracts (
      /* in */bool enable,
      /* in */const ::std::string& enfFilename,
      /* in */bool resetCounters
    )
    // throws:
    //    ::sidl::RuntimeException
    ;


    /**
     * Method to dump contract enforcement statistics.
     */
    void
    _dump_stats (
      /* in */const ::std::string& filename,
      /* in */const ::std::string& prefix
    )
    // throws:
    //    ::sidl::RuntimeException
    ;

    // return true iff object is remote
    bool _isRemote() const { 
      ior_t* self = const_cast<ior_t*>(_get_ior() );
      struct sidl_BaseInterface__object *throwaway_exception;
      return (*self->d_epv->f__isRemote)(self, &throwaway_exception) == TRUE;
    }

    // return true iff object is local
    bool _isLocal() const {
      return !_isRemote();
    }

  protected:
    // Pointer to external (DLL loadable) symbols (shared among instances)
    static const ext_t * s_ext;

  public:
    static const ext_t * _get_ext() throw ( ::sidl::NullIORException );

  }; // end class GraphC1Factory
} // end namespace ex2

extern "C" {


#pragma weak ex2_GraphC1Factory__connectI

  /**
   * RMI connector function for the class. (no addref)
   */
  struct ex2_GraphC1Factory__object*
  ex2_GraphC1Factory__connectI(const char * url, sidl_bool ar, struct 
    sidl_BaseInterface__object **_ex);


} // end extern "C"
namespace sidl {
  // traits specialization
  template<>
  struct array_traits< ::ex2::GraphC1Factory > {
    typedef array< ::ex2::GraphC1Factory > cxx_array_t;
    typedef ::ex2::GraphC1Factory cxx_item_t;
    typedef struct ex2_GraphC1Factory__array ior_array_t;
    typedef sidl_interface__array ior_array_internal_t;
    typedef struct ex2_GraphC1Factory__object ior_item_t;
    typedef cxx_item_t value_type;
    typedef value_type reference;
    typedef value_type* pointer;
    typedef const value_type const_reference;
    typedef const value_type* const_pointer;
    typedef array_iter< array_traits< ::ex2::GraphC1Factory > > iterator;
    typedef const_array_iter< array_traits< ::ex2::GraphC1Factory > > 
      const_iterator;
  };

  // array specialization
  template<>
  class array< ::ex2::GraphC1Factory >: public interface_array< array_traits< 
    ::ex2::GraphC1Factory > > {
  public:
    typedef interface_array< array_traits< ::ex2::GraphC1Factory > > Base;
    typedef array_traits< ::ex2::GraphC1Factory >::cxx_array_t          
      cxx_array_t;
    typedef array_traits< ::ex2::GraphC1Factory >::cxx_item_t           
      cxx_item_t;
    typedef array_traits< ::ex2::GraphC1Factory >::ior_array_t          
      ior_array_t;
    typedef array_traits< ::ex2::GraphC1Factory >::ior_array_internal_t 
      ior_array_internal_t;
    typedef array_traits< ::ex2::GraphC1Factory >::ior_item_t           
      ior_item_t;

    /**
     * conversion from ior to C++ class
     * (constructor/casting operator)
     */
    array( struct ex2_GraphC1Factory__array* src = 0) : Base(src) {}

    /**
     * copy constructor
     */
    array( const array< ::ex2::GraphC1Factory >&src) : Base(src) {}

    /**
     * assignment
     */
    array< ::ex2::GraphC1Factory >&
    operator =( const array< ::ex2::GraphC1Factory >&rhs ) { 
      if (d_array != rhs._get_baseior()) {
        if (d_array) deleteRef();
        d_array = const_cast<sidl__array *>(rhs._get_baseior());
        if (d_array) addRef();
      }
      return *this;
    }

  };
}

#ifndef included_ex2_GraphC1_hxx
#include "ex2_GraphC1.hxx"
#endif
#ifndef included_ex2_GraphOps_hxx
#include "ex2_GraphOps.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#endif
