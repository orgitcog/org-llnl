// 
// File:          ex2_GraphC1Factory_Skel.cxx
// Symbol:        ex2.GraphC1Factory-v0.0
// Symbol Type:   class
// Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
// Description:   Server-side glue code for ex2.GraphC1Factory
// 
// WARNING: Automatically generated; changes will be lost
// 
// 
#ifndef included_ex2_GraphC1Factory_Impl_hxx
#include "ex2_GraphC1Factory_Impl.hxx"
#endif
#ifndef included_ex2_GraphC1Factory_IOR_h
#include "ex2_GraphC1Factory_IOR.h"
#endif
#ifndef included_sidl_BaseException_hxx
#include "sidl_BaseException.hxx"
#endif
#ifndef included_sidl_LangSpecificException_hxx
#include "sidl_LangSpecificException.hxx"
#endif
// 
// Includes for all method dependencies.
// 
#ifndef included_ex2_GraphC1_hxx
#include "ex2_GraphC1.hxx"
#endif
#ifndef included_ex2_GraphOps_hxx
#include "ex2_GraphOps.hxx"
#endif
#ifndef included_gov_cca_CCAException_hxx
#include "gov_cca_CCAException.hxx"
#endif
#ifndef included_gov_cca_Services_hxx
#include "gov_cca_Services.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_RuntimeException_hxx
#include "sidl_RuntimeException.hxx"
#endif
#include "sidl_String.h"
#include <stddef.h>
#include <cstring>

extern "C" {

  static void
  skel_ex2_GraphC1Factory_boccaSetServices( 
  /* in */ struct ex2_GraphC1Factory__object* self, /* in */ struct 
    gov_cca_Services__object* services, sidl_BaseInterface__object ** 
    _exception )
  {
    // pack args to dispatch to impl
    ::ex2::GraphC1Factory_impl *_this = reinterpret_cast< 
      ::ex2::GraphC1Factory_impl*>(self->d_data);
    ::gov::cca::Services  _local_services(services);
    *_exception = 0;//init just to be safe

    // dispatch to impl
    try { 
      _this->boccaSetServices_impl( /* in */ _local_services );
    } catch ( ::sidl::BaseException _ex ) { 
      sidl_BaseInterface _throwaway_exception;
      (_ex._get_ior()->d_epv->f_add) (_ex._get_ior()->d_object,  __FILE__, __LINE__,"C++ skeleton for boccaSetServices.", &_throwaway_exception);
      _ex.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _ex._get_ior());

    } catch (...) {
      // Convert all other exceptions to LangSpecific
      ::sidl::LangSpecificException _unexpected = 
        ::sidl::LangSpecificException::_create();
      sidl_BaseInterface _throwaway_exception;
      (_unexpected._get_ior()->d_epv->f_setNote) (_unexpected._get_ior(),
        "Unexpected C++ exception", &_throwaway_exception);
      _unexpected.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _unexpected._get_ior());

    }
    // unpack results and cleanup

  }

  static void
  skel_ex2_GraphC1Factory_boccaReleaseServices( 
  /* in */ struct ex2_GraphC1Factory__object* self, /* in */ struct 
    gov_cca_Services__object* services, sidl_BaseInterface__object ** 
    _exception )
  {
    // pack args to dispatch to impl
    ::ex2::GraphC1Factory_impl *_this = reinterpret_cast< 
      ::ex2::GraphC1Factory_impl*>(self->d_data);
    ::gov::cca::Services  _local_services(services);
    *_exception = 0;//init just to be safe

    // dispatch to impl
    try { 
      _this->boccaReleaseServices_impl( /* in */ _local_services );
    } catch ( ::sidl::BaseException _ex ) { 
      sidl_BaseInterface _throwaway_exception;
      (_ex._get_ior()->d_epv->f_add) (_ex._get_ior()->d_object,  __FILE__, __LINE__,"C++ skeleton for boccaReleaseServices.", &_throwaway_exception);
      _ex.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _ex._get_ior());

    } catch (...) {
      // Convert all other exceptions to LangSpecific
      ::sidl::LangSpecificException _unexpected = 
        ::sidl::LangSpecificException::_create();
      sidl_BaseInterface _throwaway_exception;
      (_unexpected._get_ior()->d_epv->f_setNote) (_unexpected._get_ior(),
        "Unexpected C++ exception", &_throwaway_exception);
      _unexpected.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _unexpected._get_ior());

    }
    // unpack results and cleanup

  }

  static void
  skel_ex2_GraphC1Factory_boccaForceUsePortInclude( 
  /* in */ struct ex2_GraphC1Factory__object* self, /* in */ struct 
    ex2_GraphC1__object* dummy0, sidl_BaseInterface__object ** _exception )
  {
    // pack args to dispatch to impl
    ::ex2::GraphC1Factory_impl *_this = reinterpret_cast< 
      ::ex2::GraphC1Factory_impl*>(self->d_data);
    ::ex2::GraphC1  _local_dummy0(dummy0);
    *_exception = 0;//init just to be safe

    // dispatch to impl
    try { 
      _this->boccaForceUsePortInclude_impl( /* in */ _local_dummy0 );
    } catch ( ::sidl::RuntimeException _ex ) { 
      sidl_BaseInterface _throwaway_exception;
      (_ex._get_ior()->d_epv->f_add) (_ex._get_ior()->d_object,  __FILE__, __LINE__,"C++ skeleton for boccaForceUsePortInclude.", &_throwaway_exception);
      _ex.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _ex._get_ior());

    } catch (...) {
      // Convert all other exceptions to LangSpecific
      ::sidl::LangSpecificException _unexpected = 
        ::sidl::LangSpecificException::_create();
      sidl_BaseInterface _throwaway_exception;
      (_unexpected._get_ior()->d_epv->f_setNote) (_unexpected._get_ior(),
        "Unexpected C++ exception", &_throwaway_exception);
      _unexpected.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _unexpected._get_ior());

    }
    // unpack results and cleanup

  }

  static void
  skel_ex2_GraphC1Factory_setServices( 
  /* in */ struct ex2_GraphC1Factory__object* self, /* in */ struct 
    gov_cca_Services__object* services, sidl_BaseInterface__object ** 
    _exception )
  {
    // pack args to dispatch to impl
    ::ex2::GraphC1Factory_impl *_this = reinterpret_cast< 
      ::ex2::GraphC1Factory_impl*>(self->d_data);
    ::gov::cca::Services  _local_services(services);
    *_exception = 0;//init just to be safe

    // dispatch to impl
    try { 
      _this->setServices_impl( /* in */ _local_services );
    } catch ( ::sidl::BaseException _ex ) { 
      sidl_BaseInterface _throwaway_exception;
      (_ex._get_ior()->d_epv->f_add) (_ex._get_ior()->d_object,  __FILE__, __LINE__,"C++ skeleton for setServices.", &_throwaway_exception);
      _ex.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _ex._get_ior());

    } catch (...) {
      // Convert all other exceptions to LangSpecific
      ::sidl::LangSpecificException _unexpected = 
        ::sidl::LangSpecificException::_create();
      sidl_BaseInterface _throwaway_exception;
      (_unexpected._get_ior()->d_epv->f_setNote) (_unexpected._get_ior(),
        "Unexpected C++ exception", &_throwaway_exception);
      _unexpected.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _unexpected._get_ior());

    }
    // unpack results and cleanup

  }

  static void
  skel_ex2_GraphC1Factory_releaseServices( 
  /* in */ struct ex2_GraphC1Factory__object* self, /* in */ struct 
    gov_cca_Services__object* services, sidl_BaseInterface__object ** 
    _exception )
  {
    // pack args to dispatch to impl
    ::ex2::GraphC1Factory_impl *_this = reinterpret_cast< 
      ::ex2::GraphC1Factory_impl*>(self->d_data);
    ::gov::cca::Services  _local_services(services);
    *_exception = 0;//init just to be safe

    // dispatch to impl
    try { 
      _this->releaseServices_impl( /* in */ _local_services );
    } catch ( ::sidl::BaseException _ex ) { 
      sidl_BaseInterface _throwaway_exception;
      (_ex._get_ior()->d_epv->f_add) (_ex._get_ior()->d_object,  __FILE__, __LINE__,"C++ skeleton for releaseServices.", &_throwaway_exception);
      _ex.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _ex._get_ior());

    } catch (...) {
      // Convert all other exceptions to LangSpecific
      ::sidl::LangSpecificException _unexpected = 
        ::sidl::LangSpecificException::_create();
      sidl_BaseInterface _throwaway_exception;
      (_unexpected._get_ior()->d_epv->f_setNote) (_unexpected._get_ior(),
        "Unexpected C++ exception", &_throwaway_exception);
      _unexpected.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _unexpected._get_ior());

    }
    // unpack results and cleanup

  }

  static struct ex2_GraphOps__object*
  skel_ex2_GraphC1Factory_createGraph( 
  /* in */ struct ex2_GraphC1Factory__object* self, sidl_BaseInterface__object 
    ** _exception )
  {
    // pack args to dispatch to impl
    struct ex2_GraphOps__object* _result = 0;
    ::ex2::GraphOps _local_result;
    ::ex2::GraphC1Factory_impl *_this = reinterpret_cast< 
      ::ex2::GraphC1Factory_impl*>(self->d_data);
    *_exception = 0;//init just to be safe

    // dispatch to impl
    try { 
      _local_result = _this->createGraph_impl(  );
    } catch ( ::sidl::RuntimeException _ex ) { 
      sidl_BaseInterface _throwaway_exception;
      (_ex._get_ior()->d_epv->f_add) (_ex._get_ior()->d_object,  __FILE__, __LINE__,"C++ skeleton for createGraph.", &_throwaway_exception);
      _ex.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _ex._get_ior());

      return _result;
    } catch (...) {
      // Convert all other exceptions to LangSpecific
      ::sidl::LangSpecificException _unexpected = 
        ::sidl::LangSpecificException::_create();
      sidl_BaseInterface _throwaway_exception;
      (_unexpected._get_ior()->d_epv->f_setNote) (_unexpected._get_ior(),
        "Unexpected C++ exception", &_throwaway_exception);
      _unexpected.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _unexpected._get_ior());

      return _result;
    }
    // unpack results and cleanup
    if ( _local_result._not_nil() ) {
      _local_result.addRef();
    }
    _result = (struct ex2_GraphOps__object*) 
      _local_result.::ex2::GraphOps::_get_ior();
    return _result;
  }

#ifdef WITH_RMI
  struct ex2_GraphC1__object* skel_ex2_GraphC1Factory_fconnect_ex2_GraphC1(
    const char* url, sidl_bool ar, sidl_BaseInterface *_ex) { 
    return ex2_GraphC1__connectI(url, ar, _ex);
  }

  struct gov_cca_Services__object* 
    skel_ex2_GraphC1Factory_fconnect_gov_cca_Services(const char* url, 
    sidl_bool ar, sidl_BaseInterface *_ex) { 
    return gov_cca_Services__connectI(url, ar, _ex);
  }

  struct sidl_BaseInterface__object* 
    skel_ex2_GraphC1Factory_fconnect_sidl_BaseInterface(const char* url, 
    sidl_bool ar, sidl_BaseInterface *_ex) { 
    return sidl_BaseInterface__connectI(url, ar, _ex);
  }

#endif /*WITH_RMI*/
  void
  ex2_GraphC1Factory__call_load(void) {::ex2::GraphC1Factory_impl::_load();}

  static void
  skel_ex2_GraphC1Factory__ctor(struct ex2_GraphC1Factory__object* self, struct 
    sidl_BaseInterface__object **_ex ) { 
    try {
      self->d_data = reinterpret_cast< void*>(new ::ex2::GraphC1Factory_impl(
        self));
    } catch ( ::sidl::RuntimeException _exc ) {
      sidl_BaseInterface _throwaway_exception;
      (_exc._get_ior()->d_epv->f_add) (_exc._get_ior()->d_object, __FILE__, __LINE__," C++ skeleton for _ctor.", &_throwaway_exception);
      _exc.addRef();
      *_ex = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _exc._get_ior());
    } catch (...) {
      // Convert all other exceptions to LangSpecific
      ::sidl::LangSpecificException _unexpected = 
        ::sidl::LangSpecificException::_create();
      _unexpected.setNote("Unexpected C++ exception in _ctor.");
      _unexpected.addRef();
      *_ex = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _unexpected._get_ior());
    }
  }

  static void
  skel_ex2_GraphC1Factory__ctor2(struct ex2_GraphC1Factory__object* self, void* 
    private_data, struct sidl_BaseInterface__object **_ex ) { 
    *_ex = NULL;
  }

  static void
  skel_ex2_GraphC1Factory__dtor(struct ex2_GraphC1Factory__object* self, struct 
    sidl_BaseInterface__object **_ex ) { 
    try {
      ::ex2::GraphC1Factory_impl* loc_data = reinterpret_cast< 
        ::ex2::GraphC1Factory_impl*>(self->d_data);
      if(!loc_data->_isWrapped()) {
        delete (loc_data);
      }
    } catch ( ::sidl::RuntimeException _exc ) {
      sidl_BaseInterface _throwaway_exception;
      (_exc._get_ior()->d_epv->f_add) (_exc._get_ior()->d_object, __FILE__, __LINE__," C++ skeleton for _dtor.", &_throwaway_exception);
      _exc.addRef();
      *_ex = reinterpret_cast< struct sidl_BaseInterface__object * >(_exc._get_ior());
    } catch (...) {
      // Convert all other exceptions to LangSpecific
      ::sidl::LangSpecificException _unexpected = ::sidl::LangSpecificException::_create();
      _unexpected.setNote("Unexpected C++ exception in _dtor.");
      _unexpected.addRef();
      *_ex = reinterpret_cast< struct sidl_BaseInterface__object * >(_unexpected._get_ior());
    }
  }

  void
  ex2_GraphC1Factory__set_epv(struct ex2_GraphC1Factory__epv *epv,
  struct ex2_GraphC1Factory__pre_epv *pre_epv, struct ex2_GraphC1Factory__post_epv *post_epv){
    // initialize builtin methods
    epv->f__ctor = skel_ex2_GraphC1Factory__ctor;
    epv->f__ctor2 = skel_ex2_GraphC1Factory__ctor2;
    epv->f__dtor = skel_ex2_GraphC1Factory__dtor;
    // initialize local methods
    pre_epv->f_boccaSetServices_pre = NULL;
    epv->f_boccaSetServices = skel_ex2_GraphC1Factory_boccaSetServices;
    post_epv->f_boccaSetServices_post = NULL;
    pre_epv->f_boccaReleaseServices_pre = NULL;
    epv->f_boccaReleaseServices = skel_ex2_GraphC1Factory_boccaReleaseServices;
    post_epv->f_boccaReleaseServices_post = NULL;
    pre_epv->f_boccaForceUsePortInclude_pre = NULL;
    epv->f_boccaForceUsePortInclude = skel_ex2_GraphC1Factory_boccaForceUsePortInclude;
    post_epv->f_boccaForceUsePortInclude_post = NULL;
    pre_epv->f_setServices_pre = NULL;
    epv->f_setServices = skel_ex2_GraphC1Factory_setServices;
    post_epv->f_setServices_post = NULL;
    pre_epv->f_releaseServices_pre = NULL;
    epv->f_releaseServices = skel_ex2_GraphC1Factory_releaseServices;
    post_epv->f_releaseServices_post = NULL;
    pre_epv->f_createGraph_pre = NULL;
    epv->f_createGraph = skel_ex2_GraphC1Factory_createGraph;
    post_epv->f_createGraph_post = NULL;
  }


} // end extern "C"
