/*
 * File:          ex2_IntData_Impl.c
 * Symbol:        ex2.IntData-v0.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for ex2.IntData
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "ex2.IntData" (version 0.0)
 * 
 * This is a simple Data class wrapping an integer.
 */

#include "ex2_IntData_Impl.h"
#include "sidl_NotImplementedException.h"
#include "sidl_Exception.h"
#ifndef included_sidl_MemAllocException_h
#include "sidl_MemAllocException.h"
#endif

/* DO-NOT-DELETE splicer.begin(ex2.IntData._includes) */

/* Insert-UserCode-Here {ex2.IntData._includes} (includes and arbitrary code) */

/* Bocca generated code. bocca.protected.begin(ex2.IntData._includes) */
#include <stdlib.h>
#include <string.h>
#include "sidl_SIDLException.h"

#define _BOCCA_CTOR_MESSAGES 0

#ifdef _BOCCA_STDERR

#define BOCCA_FPRINTF fprintf
#include <stdio.h>
#include "sidl_String.h"
#ifdef _BOCCA_CTOR_PRINT
#undef _BOCCA_CTOR_MESSAGES
#define _BOCCA_CTOR_MESSAGES 1
#endif /* _BOCCA_CTOR_PRINT */

#else /* _BOCCA_STDERR */
#define BOCCA_FPRINTF boccaPrintNothing
#endif /* _BOCCA_STDERR */

static int
boccaPrintNothing(void *v, const char * s, ...)
{
  (void)v; (void)s;
  return 0;
}
/* Bocca generated code. bocca.protected.end(ex2.IntData._includes) */

/* Insert-UserCode-Here {ex2.IntData._includes} (includes and arbitrary code) */

/* DO-NOT-DELETE splicer.end(ex2.IntData._includes) */

#define SIDL_IOR_MAJOR_VERSION 2
#define SIDL_IOR_MINOR_VERSION 0
/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_IntData__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_IntData__load(
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.IntData._load) */
    /* Insert-Code-Here {ex2.IntData._load} (static class initializer method) */
    /*
     * This method has not been implemented
     */

    /* DO-DELETE-WHEN-IMPLEMENTING exception.begin(ex2.IntData._load) */
    SIDL_THROW(*_ex, sidl_NotImplementedException,     "This method has not been implemented");
  EXIT:;
    /* DO-DELETE-WHEN-IMPLEMENTING exception.end(ex2.IntData._load) */
    /* DO-NOT-DELETE splicer.end(ex2.IntData._load) */
  }
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_IntData__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_IntData__ctor(
  /* in */ ex2_IntData self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.IntData._ctor) */

  /* Insert-UserDecl-Here {ex2.IntData._ctor} (constructor method) */
    
  /* bocca-default-code. User may edit or delete.begin(ex2.IntData._ctor) */
   struct ex2_IntData__data *dptr = 
       (struct ex2_IntData__data*)malloc(sizeof(struct ex2_IntData__data));
   if (dptr) {
      memset(dptr, 0, sizeof(struct ex2_IntData__data));
      dptr->num = 0;
   }
   ex2_IntData__set_data(self, dptr);
   #if _BOCCA_CTOR_MESSAGES
     BOCCA_FPRINTF(stderr, 
        "CTOR ex2.IntData: %s constructed data %p in self %p\n", 
        __FUNC__, dptr, self);
   #endif /* _BOCCA_CTOR_MESSAGES */
  /* bocca-default-code. User may edit or delete.end(ex2.IntData._ctor) */

  /* initialize user elements of dptr here */
  /* Insert-UserCode-Here {ex2.IntData._ctor} (constructor method) */

    /* DO-NOT-DELETE splicer.end(ex2.IntData._ctor) */
  }
}

/*
 * Special Class constructor called when the user wants to wrap his own private data.
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_IntData__ctor2"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_IntData__ctor2(
  /* in */ ex2_IntData self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.IntData._ctor2) */
    /* Insert-Code-Here {ex2.IntData._ctor2} (special constructor method) */
    /*
     * This method has not been implemented
     */

    /* DO-DELETE-WHEN-IMPLEMENTING exception.begin(ex2.IntData._ctor2) */
    SIDL_THROW(*_ex, sidl_NotImplementedException,     "This method has not been implemented");
  EXIT:;
    /* DO-DELETE-WHEN-IMPLEMENTING exception.end(ex2.IntData._ctor2) */
    /* DO-NOT-DELETE splicer.end(ex2.IntData._ctor2) */
  }
}
/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_IntData__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_IntData__dtor(
  /* in */ ex2_IntData self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.IntData._dtor) */

  /* deinitialize user elements of dptr here */
  /* Insert-UserCode-Here {ex2.IntData._dtor} (destructor method) */
    
  /* bocca-default-code. User may edit or delete.begin(ex2.IntData._dtor) */
   struct ex2_IntData__data *dptr = 
                ex2_IntData__get_data(self);
   if (dptr) {
      free(dptr);
      ex2_IntData__set_data(self, NULL);
   }
   #if _BOCCA_CTOR_MESSAGES
     BOCCA_FPRINTF(stderr, "DTOR ex2.IntData: %s freed data %p in self %p\n", 
                   __FUNC__, dptr, self);
   #endif /* _BOCCA_CTOR_MESSAGES */
  /* bocca-default-code. User may edit or delete.end(ex2.IntData._dtor) */

    /* DO-NOT-DELETE splicer.end(ex2.IntData._dtor) */
  }
}

/*
 * Returns the integer data member
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_IntData_getIntData"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_ex2_IntData_getIntData(
  /* in */ ex2_IntData self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.IntData.getIntData) */
    /* Insert-Code-Here {ex2.IntData.getIntData} (getIntData method) */
    struct ex2_IntData__data *dptr = ex2_IntData__get_data(self);
    return dptr->num;
    /* DO-NOT-DELETE splicer.end(ex2.IntData.getIntData) */
  }
}

/*
 * Sets the integer data member
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_IntData_setIntData"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_IntData_setIntData(
  /* in */ ex2_IntData self,
  /* in */ int32_t val,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.IntData.setIntData) */
    /* Insert-Code-Here {ex2.IntData.setIntData} (setIntData method) */
    struct ex2_IntData__data *dptr = ex2_IntData__get_data(self);
    dptr->num = val;
    /* DO-NOT-DELETE splicer.end(ex2.IntData.setIntData) */
  }
}

/*
 *  This function should never be called, but helps babel generate better code. 
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_IntData_boccaForceUsePortInclude"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_IntData_boccaForceUsePortInclude(
  /* in */ ex2_IntData self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.IntData.boccaForceUsePortInclude) */
/* DO-NOT-EDIT-BOCCA */
  /* Bocca generated code. bocca.protected.begin(ex2.IntData.boccaForceUsePortInclude) */
    (void)self;

  /* Bocca generated code. bocca.protected.end(ex2.IntData.boccaForceUsePortInclude) */
    /* DO-NOT-DELETE splicer.end(ex2.IntData.boccaForceUsePortInclude) */
  }
}

/*
 * Displays contents of the data if possible
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_IntData_display"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_IntData_display(
  /* in */ ex2_IntData self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.IntData.display) */
    struct ex2_IntData__data *dptr = ex2_IntData__get_data(self);
    printf(" %d ", dptr->num);
    /* DO-NOT-DELETE splicer.end(ex2.IntData.display) */
  }
}

/*
 * Computes and returns a unique integer id - 
 * simply returns value of the data ptr
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_IntData_hashCode"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_ex2_IntData_hashCode(
  /* in */ ex2_IntData self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.IntData.hashCode) */
    struct ex2_IntData__data *dptr = ex2_IntData__get_data(self);
    return dptr;
    /* DO-NOT-DELETE splicer.end(ex2.IntData.hashCode) */
  }
}

/*
 * Compares the element with data parameter element, 
 * returns 1 if it's greater than data,
 * 0 if they are equal and -1 if it's less than data
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_IntData_compare"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_ex2_IntData_compare(
  /* in */ ex2_IntData self,
  /* in */ ex2_Data data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.IntData.compare) */
    struct ex2_IntData__data *dptr = ex2_IntData__get_data(self);
    //printf("IntData compare called\n\n");
    ex2_IntData idata = ex2_IntData__cast(data, _ex);
    int32_t num2 = ex2_IntData_getIntData(idata,_ex); SIDL_REPORT(*_ex);
    ex2_IntData_deleteRef(idata, _ex);
    int32_t num1 = dptr->num;
    if (num1 > num2) return 1;
    if (num1 == num2) return 0;
    if (num1 < num2) return -1;
  EXIT:return -2;
   
    /* DO-NOT-DELETE splicer.end(ex2.IntData.compare) */
  }
}

/*
 * Takes in another Data object and casts it to a 
 * corresponding type + sets internal data members
 */

#undef __FUNC__
#define __FUNC__ "impl_ex2_IntData_setData"

#ifdef __cplusplus
extern "C"
#endif
void
impl_ex2_IntData_setData(
  /* in */ ex2_IntData self,
  /* in */ ex2_Data data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(ex2.IntData.setData) */
     ex2_IntData i_data = ex2_IntData__cast(data, _ex); SIDL_REPORT(*_ex);
    int num = ex2_IntData_getIntData(i_data, _ex); SIDL_REPORT(*_ex);
    ex2_IntData_deleteRef(i_data, _ex); SIDL_REPORT(*_ex);
    ex2_IntData_setIntData(self, data, _ex); SIDL_REPORT(*_ex);
    return;
  EXIT: ;
    /* DO-NOT-DELETE splicer.end(ex2.IntData.setData) */
  }
}
/* Babel internal methods, Users should not edit below this line. */

/* DO-NOT-DELETE splicer.begin(_misc) */
/* Insert-Code-Here {_misc} (miscellaneous code) */
/* DO-NOT-DELETE splicer.end(_misc) */

