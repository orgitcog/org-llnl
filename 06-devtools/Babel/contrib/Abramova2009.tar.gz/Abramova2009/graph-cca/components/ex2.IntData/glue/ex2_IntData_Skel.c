/*
 * File:          ex2_IntData_Skel.c
 * Symbol:        ex2.IntData-v0.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side glue code for ex2.IntData
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 */

#include "ex2_IntData_IOR.h"
#include "ex2_IntData.h"
#include <stddef.h>

#ifdef WITH_RMI
#ifndef included_ex2_Data_h
#include "ex2_Data.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#endif /* WITH_RMI */
extern
void
impl_ex2_IntData__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_IntData__ctor(
  /* in */ ex2_IntData self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_IntData__ctor2(
  /* in */ ex2_IntData self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_IntData__dtor(
  /* in */ ex2_IntData self,
  /* out */ sidl_BaseInterface *_ex);

#ifdef WITH_RMI
extern struct ex2_Data__object* impl_ex2_IntData_fconnect_ex2_Data(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_ex2_IntData_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/
extern
int32_t
impl_ex2_IntData_getIntData(
  /* in */ ex2_IntData self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_IntData_setIntData(
  /* in */ ex2_IntData self,
  /* in */ int32_t val,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_IntData_boccaForceUsePortInclude(
  /* in */ ex2_IntData self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_IntData_display(
  /* in */ ex2_IntData self,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_IntData_hashCode(
  /* in */ ex2_IntData self,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_ex2_IntData_compare(
  /* in */ ex2_IntData self,
  /* in */ ex2_Data data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_ex2_IntData_setData(
  /* in */ ex2_IntData self,
  /* in */ ex2_Data data,
  /* out */ sidl_BaseInterface *_ex);

#ifdef WITH_RMI
extern struct ex2_Data__object* impl_ex2_IntData_fconnect_ex2_Data(const char* 
  url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_ex2_IntData_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/
#ifdef __cplusplus
extern "C" {
#endif

void
ex2_IntData__set_epv(struct ex2_IntData__epv *epv,
  struct ex2_IntData__pre_epv *pre_epv, 
  struct ex2_IntData__post_epv *post_epv
)
{
  epv->f__ctor = impl_ex2_IntData__ctor;
  epv->f__ctor2 = impl_ex2_IntData__ctor2;
  epv->f__dtor = impl_ex2_IntData__dtor;
  pre_epv->f_getIntData_pre = NULL;
  epv->f_getIntData = impl_ex2_IntData_getIntData;
  post_epv->f_getIntData_post = NULL;
  pre_epv->f_setIntData_pre = NULL;
  epv->f_setIntData = impl_ex2_IntData_setIntData;
  post_epv->f_setIntData_post = NULL;
  pre_epv->f_boccaForceUsePortInclude_pre = NULL;
  epv->f_boccaForceUsePortInclude = impl_ex2_IntData_boccaForceUsePortInclude;
  post_epv->f_boccaForceUsePortInclude_post = NULL;
  pre_epv->f_display_pre = NULL;
  epv->f_display = impl_ex2_IntData_display;
  post_epv->f_display_post = NULL;
  pre_epv->f_hashCode_pre = NULL;
  epv->f_hashCode = impl_ex2_IntData_hashCode;
  post_epv->f_hashCode_post = NULL;
  pre_epv->f_compare_pre = NULL;
  epv->f_compare = impl_ex2_IntData_compare;
  post_epv->f_compare_post = NULL;
  pre_epv->f_setData_pre = NULL;
  epv->f_setData = impl_ex2_IntData_setData;
  post_epv->f_setData_post = NULL;

}
#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
extern "C" {
#endif

void ex2_IntData__call_load(void) { 
  sidl_BaseInterface _throwaway_exception = NULL;
  impl_ex2_IntData__load(&_throwaway_exception);
}
#ifdef WITH_RMI
struct ex2_Data__object* skel_ex2_IntData_fconnect_ex2_Data(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) { 
  return ex2_Data__connectI(url, ar, _ex);
}

struct sidl_BaseInterface__object* skel_ex2_IntData_fconnect_sidl_BaseInterface(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex) { 
  return sidl_BaseInterface__connectI(url, ar, _ex);
}

#endif /*WITH_RMI*/
struct ex2_IntData__data*
ex2_IntData__get_data(ex2_IntData self)
{
  return (struct ex2_IntData__data*)(self ? self->d_data : NULL);
}

void ex2_IntData__set_data(
  ex2_IntData self,
  struct ex2_IntData__data* data)
{
  if (self) {
    self->d_data = data;
  }
}
#ifdef __cplusplus
}
#endif
