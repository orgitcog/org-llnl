import graph.ListOps;
import graph.ListNode;
import graph.Data;
import graph.IntData;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.FileReader;

public class DFS {
    
    InitGraph ig;
    DfsSearch d;
    public DFS() {
	ig = new InitGraph();
	d = new DfsSearch();
    }

    //this is a main routine for the depth first search client
    //graph is initialized from a file whose name is stored in a file "setup"
    //file name with graph settings is read from "setup"
    //as well as true/false parameter for making graph undirected or directed
    //and true/false parameter for enabling/disabling enforcement policy

    public static void main(String args[]){
	//fname - name of the file that stores vertices and edges
        String fname;

	//used to get some input from user and pause the execution
	String str;

	//String value of a boolean that is read from a file and determines 
        //whether to insert vertices one way as in the file
        //of whether make the graph undirected and for every edge, insert it twice
	String undirected;

	//String value of a boolean read from a file that determines
	//whether the contract policy should be enabled or not
	String policyEnf;
	boolean undir, policyEnbl;
	
	DFS dfs = new DFS();

	try {
	    String setup = "setup";
	    BufferedReader in = new BufferedReader(new FileReader(setup));
	    fname = in.readLine();
	    undirected = in.readLine();
	    policyEnf = in.readLine();
	    undir = new Boolean(undirected).booleanValue();
	    policyEnbl = new Boolean(policyEnf).booleanValue();
	    in.close();

	} catch (java.io.IOException e){
	    fname = "graphS";
            undir = false;
	    policyEnbl = false;
	}


        //turn on contract enforcement
        sidl.EnfPolicy policy = new sidl.EnfPolicy();
	if (policyEnbl) policy.setEnforceAll(sidl.ContractClass.ALLCLASSES, true);
	else policy.setEnforceNone(true);

        //instantiate a graph with a correct implementation
        graph.GraphC graphC = new graph.GraphC();
	
	dfs.initAndSearch(graphC, fname, undir);
	int ecount1 = graphC.getEdgeCount();
	int vcount1 = graphC.getVertCount();
	System.out.println("Edge count = " + ecount1 + "Vertex count = "+ vcount1);

        //pause and wait for some input from the user
        try {
	str = new BufferedReader(new InputStreamReader(System.in)).readLine(); 
	}catch (java.io.IOException e){}

        //instantiate a graph with a flawed implementation
	graph.GraphC1 gr1 = new graph.GraphC1();
	
	dfs.initAndSearch(gr1, fname, undir);
	int ecount2 = gr1.getEdgeCount();
	int vcount2 = gr1.getVertCount();
	System.out.println("Edge count = " + ecount2 + "Vertex count = "+ vcount2);
	//pause and wait for some input from the user
        try {
	str = new BufferedReader(new InputStreamReader(System.in)).readLine(); 
	}catch (java.io.IOException e){}

        //instantiate a graph with a flawed insVertex implementation
	graph.GraphC2 gr2 = new graph.GraphC2();
	
	dfs.initAndSearch(gr2, fname, undir);
	int ecount3 = gr2.getEdgeCount();
	int vcount3 = gr2.getVertCount();
	System.out.println("Edge count = " + ecount3 + "Vertex count = "+ vcount3);


        
	policy.dumpStats("stats.out", true, "",false); 
		


    }
    void initAndSearch(graph.GraphOps testGraph, String fname, boolean undir){        

	//initialize a graph from a file
        ig.initFromFile(testGraph, fname, undir);

      
 	java.util.List <graph.Data> ordered = new java.util.LinkedList <graph.Data> ();
	java.util.Date date1 = new java.util.Date();
        long time1=date1.getTime();

        //perform depth first search
      	d.dfs(testGraph, ordered);

        //iterate over the results
	for (graph.Data elem:ordered){
	    elem.display();
	}
	ordered = null;
	
	testGraph = null;

        java.util.Date date2 = new java.util.Date();
	long time2 = date2.getTime();
	time2 = time2 - time1;
        System.out.println("Time taken " + (time2) + "milliseconds");
    }

}


