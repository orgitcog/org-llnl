import graph.ListOps;
import graph.ListNode;
import graph.Data;
import graph.IntData;


public class InitGraph {
    public void initFromFile(graph.GraphOps g, String fileName, boolean undirected){
    try {
        java.io.BufferedReader in =new  java.io.BufferedReader(new java.io.FileReader(fileName));

        String str;
       
	str = in.readLine();
            if (str.equals("vertices")){
		while (! (str = in.readLine()).equals("edges") ){
                java.util.StringTokenizer Tok = new java.util.StringTokenizer(str);
                while (Tok.hasMoreElements()){
		    int n = java.lang.Integer.parseInt(Tok.nextToken());
                    graph.IntData d = new graph.IntData();
                    d.setIntData(n);
		    
		    int insertResult = -1;
		    try{
			insertResult = g.insVertex(d);
		    }catch (sidl.PreViolation preExc){
			System.out.println(preExc.getNote());
			
		    }
		    catch (sidl.PostViolation postViol){
			System.out.println(postViol.getNote());
			
		    }catch (java.lang.Exception e){
			e.printStackTrace();
			
		    }
		    
		    d = null;
		    if (insertResult == 0) System.out.println("Inserted vertex "+n + " result = "+insertResult);
                  
		}
	       }

	    }
	    if (str.equals("edges")){
                while ((str = in.readLine())!= null){
		    java.util.StringTokenizer Tok = new java.util.StringTokenizer(str);
		    graph.Data startV = null, endV = null;
                    int e1 = java.lang.Integer.parseInt(Tok.nextToken());
                    int e2 = java.lang.Integer.parseInt(Tok.nextToken());
                    graph.IntData d1 = new graph.IntData();
                    d1.setIntData(e1);
                    graph.IntData d2 = new graph.IntData();
                    d2.setIntData(e2);
		    
                    graph.AdjList adjlist = g.getAdjList(d1);
		    if (adjlist!=null){
			startV = adjlist.getVertex();
		    }
                    graph.AdjList adjlist2 = g.getAdjList(d2);
                    if (adjlist2 != null){
			endV = adjlist2.getVertex();
		    }
		    // System.out.println("something's null");
		    int insertResult = -1;
		    try {
			if ((startV!=null) && (endV != null)){
			    insertResult = g.insEdge(startV, endV);
			    if (undirected) g.insEdge(endV, startV);
			}
                    }catch  (sidl.PreViolation preExc){
			System.out.println(preExc.getNote());
			
		    }
		    catch (sidl.PostViolation postViol){
			System.out.println(postViol.getNote());
			
		    }catch (java.lang.Exception e){
			e.printStackTrace();
			
		    }
		    adjlist = adjlist2 = null;
                    startV = endV = null;
                    d1 = d2 = null;
		    if (insertResult == 0)  System.out.println("Inserting edge between " + e1 + " and " + e2+ " result = "+ insertResult);
                    
		}
	    }
	   
        in.close();
    } catch (java.io.IOException e) {
	e.printStackTrace();
    }
    }

}
