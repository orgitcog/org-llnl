import graph.GraphOps;
import graph.Data;
import graph.AdjList;
import graph.ListNode;
import graph.ListOps;



public class DfsSearch {

     public int dfs(graph.GraphOps graph, java.util.List <graph.Data> ordered){

          java.util.HashMap <Integer, VertexColor> vertMap = new java.util.HashMap <Integer, VertexColor> ();

        
	

        //initialize vertMap to all of the vertices of the graph.
         graph.ListNode elem;
	 

	 graph.ListOps graphAdjacencyLists;
	 graphAdjacencyLists = graph.getAdjLists();
	 elem =  graphAdjacencyLists.getHead();
	 for (; elem!= null; elem = elem.getNext()){
	    graph.AdjList adjListElem = (graph.AdjList)elem.getData()._cast2("graph.AdjList");
            graph.Data vert = adjListElem.getVertex();
	    vertMap.put(Integer.valueOf(vert.hashCode()), VertexColor.white);	    
	}
	
	//ensure that every component of unconnected graph is searched
	 elem =  graphAdjacencyLists.getHead();
	 for (; elem!= null; elem = elem.getNext()){

	    graph.AdjList adjListElem = (graph.AdjList)elem.getData()._cast2("graph.AdjList");
            graph.Data vert = adjListElem.getVertex();	
	    VertexColor vertColor = vertMap.get(Integer.valueOf(vert.hashCode()));

	    if (vertColor == VertexColor.white){
		dfs_main(graph, adjListElem, ordered, vertMap);
	    }
	 }
	 return 0;
    }

    public int dfs_main(graph.GraphOps graph, graph.AdjList adjlist, java.util.List <graph.Data> ordered, java.util.HashMap<Integer, VertexColor> vertMap){
	graph.Data vertex = adjlist.getVertex();
	//mark vertex as visited
	VertexColor vColor = vertMap.get(vertex.hashCode());
	vColor = VertexColor.gray;
	vertMap.put(Integer.valueOf(vertex.hashCode()), vColor);

	//now search deeper
	graph.ListNode elem = adjlist.getList().getHead();
	for (; elem != null; elem = elem.getNext()){
	    graph.Data adjVert = elem.getData();	    
	    VertexColor vcolor2  = vertMap.get(Integer.valueOf(adjVert.hashCode()));
	    if (vcolor2 == VertexColor.white){
		graph.AdjList adjacent = graph.getAdjList(adjVert);
		dfs_main(graph, adjacent, ordered, vertMap);
	    }
	}
	
	ordered.add(0, vertex);
	return 0;
    }
   
    
}
