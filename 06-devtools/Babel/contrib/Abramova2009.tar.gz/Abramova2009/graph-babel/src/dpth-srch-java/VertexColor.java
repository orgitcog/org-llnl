public enum VertexColor {white, gray}
