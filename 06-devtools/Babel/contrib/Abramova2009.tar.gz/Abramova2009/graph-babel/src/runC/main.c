#include <stdio.h>
#include "graph_ListNode.h"
#include "graph_ListC.h"
#include "graph_ListOps.h"
#include "graph_SetOps.h"
#include "graph_Data.h"
#include "graph_SetC.h"
#include "graph_GraphOps.h"
#include "graph_GraphC.h"
#include "graph_GraphC1.h"
#include "graph_GraphC2.h"
#include "graph_IntData.h"
#include "sidl_BaseInterface.h"
#include "sidl_Exception.h"
#include "sidl_ContractClass.h"
#include "sidl_EnfPolicy.h"

int main(int argc, char** argv){

sidl_BaseInterface ex;
graph_IntData int_data;
graph_Data data;
graph_ListC list;
graph_ListNode elem, next;
  
 int count = 0;
 sidl_EnfPolicy senf;
 printf("Creating and testing the list\n");
 sidl_EnfPolicy_setEnforceAll(sidl_ContractClass_ALLCLASSES, TRUE,
                              &ex); SIDL_CHECK(ex);
 list = graph_ListC__create(&ex);  SIDL_CHECK(ex);
 graph_ListOps listops = graph_ListOps__cast(list, &ex);
 graph_ListC_deleteRef(list, &ex);
 for (; count < 20; count ++){
 int_data = graph_IntData__create(&ex); SIDL_CHECK(ex);
 graph_IntData_setIntData(int_data, count + 5 , &ex); SIDL_CHECK(ex);
 //printf("int_data_set to %d\n", count +5);
 
 // printf("casting the int data to data obj\n");
 data = graph_Data__cast(int_data, &ex);  SIDL_CHECK(ex);
 
 //printf("calling deleteRef on int_data\n");
 graph_IntData_deleteRef(int_data, &ex); SIDL_CHECK(ex);
 
 
if (count == 0){
    printf("Inserting data object at the head of the list \n");
    graph_ListOps_insertNext(listops, NULL,data, &ex);  SIDL_CHECK(ex);
    elem = graph_ListOps_getHead(listops, &ex); SIDL_CHECK(ex);
 }
 else {
   graph_ListOps_insertNext(listops, elem, data, &ex); SIDL_CHECK(ex);
   //getting the next node
   next = graph_ListNode_getNext(elem, &ex); SIDL_CHECK(ex);
   graph_ListNode_deleteRef(elem, &ex); SIDL_CHECK(ex);
   elem = next;
 }
 graph_IntData ii = graph_IntData__cast(data, &ex); 
 int number = graph_IntData_getIntData(ii, &ex);
 printf("Element inserted = %d\n", number);
 graph_Data_deleteRef(data, &ex); SIDL_CHECK(ex);
 } 
 graph_ListNode_deleteRef(elem, &ex);



 int size = graph_ListOps_getSize(listops, &ex); SIDL_CHECK(ex);


 printf("List size is now %d \n\n", size);
 


 count = 0;

for (; count < 5; count ++){
 
if (count == 0){
    graph_ListOps_removeNext(listops, NULL,&data, &ex);  SIDL_CHECK(ex);
    elem = graph_ListOps_getHead(listops, &ex); SIDL_CHECK(ex);
 }
 else {
   graph_ListOps_removeNext(listops, elem, &data, &ex); SIDL_CHECK(ex);
   //getting the next node
   next = graph_ListNode_getNext(elem, &ex); SIDL_CHECK(ex);
   graph_ListNode_deleteRef(elem, &ex); SIDL_CHECK(ex);
   elem = next;
 }
 graph_IntData ii = graph_IntData__cast(data, &ex);
 int number = graph_IntData_getIntData(ii, &ex);
 graph_IntData_deleteRef(ii, &ex);
 printf("Element removed = %d\n", number);
 if (data) graph_Data_deleteRef(data, &ex); SIDL_CHECK(ex);
 }
 graph_ListNode_deleteRef(elem, &ex);


 graph_ListOps_deleteRef(listops, &ex);

 //now test the set
 printf("Now testing the Set\n");
 graph_SetC setC = graph_SetC__create(&ex);
 graph_SetOps set = graph_SetOps__cast(setC,&ex); SIDL_CHECK(ex);
 graph_SetC_deleteRef(setC, &ex);


 count = 0;
 for (; count < 20; count ++){
 
 int_data = graph_IntData__create(&ex); SIDL_CHECK(ex);
 graph_IntData_setIntData(int_data, (count)%15 , &ex); SIDL_CHECK(ex);
 graph_Data dataToInsert = graph_Data__cast(int_data, &ex);
 int result = graph_SetOps_insert(set,dataToInsert, &ex);
 if (result == 0){
   printf("Inserted element %d\n", count%15);
 }
 else if (result == 1){
   printf("Element %d already exists\n",count%15);
 }
 else
   SIDL_CHECK(ex);
 
 graph_IntData_deleteRef(int_data,&ex); SIDL_CHECK(ex);
 graph_Data_deleteRef(dataToInsert, &ex);
 }
 
 count = 0;
 for (;count<20; count+=2){
   int_data = graph_IntData__create(&ex); SIDL_CHECK(ex);
   graph_IntData_setIntData(int_data, count , &ex); SIDL_CHECK(ex);
   //if (graph_Set_is_member(set, int_data, &ex)) printf("is member");
   graph_Data dataToRemove = graph_Data__cast(int_data, &ex);
   int  result =  graph_SetOps_remove(set, dataToRemove, &ex);
   if (result == 0) printf("removal successful, element removed = %d\n", count);
   else if (result == -1) printf("failure to remove, element = %d\n", count);
   graph_IntData_deleteRef(int_data, &ex); SIDL_CHECK(ex);
   graph_Data_deleteRef(dataToRemove, &ex);
   }
   graph_SetOps_deleteRef(set, &ex);
 
 int result;

 printf("Creating and testing a graph.\n");
 graph_GraphC gC = graph_GraphC__create(&ex);
 graph_GraphC1 gr1 = graph_GraphC1__create(&ex);
 graph_GraphOps g1 = graph_GraphOps__cast(gr1, &ex);
 graph_GraphC1_deleteRef(gr1, &ex);
 
 graph_GraphC2 gr2 = graph_GraphC2__create(&ex);
 graph_GraphOps g2 = graph_GraphOps__cast(gr2, &ex);
 graph_GraphC2_deleteRef(gr2, &ex);

 graph_GraphOps g = graph_GraphOps__cast(gC, &ex); SIDL_CHECK(ex);
 graph_GraphC_deleteRef(gC, &ex);
 count = 1;
 
   for (; count<90; count++){
     printf ("Iteration %d  ", count);
     graph_IntData d1 = graph_IntData__create(&ex);
     graph_IntData_setIntData(d1, count,  &ex);
     graph_Data vData = graph_Data__cast(d1, &ex);
     result = graph_GraphOps_insVertex(g, vData, &ex);SIDL_CHECK(ex);
     
     graph_GraphOps_insVertex(g1, vData, &ex);SIDL_CHECK(ex);
     int exists1 = graph_GraphOps_vertexExists(g2, vData, &ex);
     graph_GraphOps_insVertex(g2, vData, &ex);
     if (SIDL_CATCH(ex, "sidl.PreViolation")){
       //traceback(ex);
       SIDL_CLEAR(ex);
     }
     if (SIDL_CATCH(ex, "sidl.PostViolation")){
       //traceback(ex);
       SIDL_CLEAR(ex);
     }
     int exists2 = graph_GraphOps_vertexExists(g2, vData, &ex);
     //if (exists2 == 0 && exists1 == 0 ) { printf("VIOLATION"); exit(1);}
     if (result == 1) printf("Error, vertex already exists\n");
     else if (result == 0) printf("Inserted vertex = %d\n", count);
     else if (result == -1) printf("other error happened\n");
     else printf("Some other error, result = %d\n", result);
     graph_IntData_deleteRef(d1, &ex);
     graph_Data_deleteRef(vData, &ex);

   }
   graph_IntData id1 =  graph_IntData__create(&ex);
   graph_IntData_setIntData(id1, 1, &ex);
   graph_Data d1 = graph_Data__cast(id1, &ex);

   graph_IntData id2 =  graph_IntData__create(&ex);
   graph_IntData_setIntData(id2, 2, &ex);
   graph_Data d2 = graph_Data__cast(id2, &ex);

   graph_IntData id3 =  graph_IntData__create(&ex);
   graph_IntData_setIntData(id3, 3, &ex);
   graph_Data d3 = graph_Data__cast(id3, &ex);

   graph_IntData id4 =  graph_IntData__create(&ex);
   graph_IntData_setIntData(id4, 4, &ex);
   graph_Data d4 = graph_Data__cast(id4, &ex);

   graph_IntData id5 =  graph_IntData__create(&ex);
   graph_IntData_setIntData(id5, 5, &ex);
   graph_Data d5 = graph_Data__cast(id5, &ex);

   graph_IntData id6 =  graph_IntData__create(&ex);
   graph_IntData_setIntData(id6, 6, &ex);
   graph_Data d6 = graph_Data__cast(id6, &ex);
  
   //graph_GraphOps_rem_vertex(g, d1, &ex);

   printf("Inserted edge between 1 and 2\n");
   graph_GraphOps_insEdge(g, d1, d2, &ex);
   graph_GraphOps_insEdge(g, d2, d1, &ex);
   graph_GraphOps_insEdge(g1, d1, d2, &ex);
   if (SIDL_CATCH(ex, "sidl.PreViolation")){
     //traceback(ex);
       SIDL_CLEAR(ex);
     }
     if (SIDL_CATCH(ex, "sidl.PostViolation")){
       //traceback(ex);
       SIDL_CLEAR(ex);
     }
   graph_GraphOps_insEdge(g1, d2, d1, &ex);
   if (SIDL_CATCH(ex, "sidl.PreViolation")){
     //traceback(ex);
       SIDL_CLEAR(ex);
     }
     if (SIDL_CATCH(ex, "sidl.PostViolation")){
       //traceback(ex);
       SIDL_CLEAR(ex);
     }
   graph_GraphOps_insEdge(g2, d1, d2, &ex);SIDL_CHECK(ex);
   graph_GraphOps_insEdge(g2, d2, d1, &ex);SIDL_CHECK(ex);

   printf("Inserted edge between 2 and 4\n");
   graph_GraphOps_insEdge(g, d2, d4, &ex);
   graph_GraphOps_insEdge(g, d4, d2, &ex);
   graph_GraphOps_insEdge(g1, d2, d4, &ex);SIDL_CHECK(ex);
   graph_GraphOps_insEdge(g1, d4, d2, &ex);SIDL_CHECK(ex);
   graph_GraphOps_insEdge(g2, d1, d2, &ex);SIDL_CHECK(ex);
   graph_GraphOps_insEdge(g2, d2, d1, &ex);SIDL_CHECK(ex);

   //insert edge between 2 and 3
   printf("Inserted edge between 2 and 3\n");
   graph_GraphOps_insEdge(g, d3, d2, &ex);
   graph_GraphOps_insEdge(g, d2, d3, &ex);
   graph_GraphOps_insEdge(g1, d3, d2, &ex);SIDL_CHECK(ex);
   graph_GraphOps_insEdge(g1, d2, d3, &ex);SIDL_CHECK(ex);
   graph_GraphOps_insEdge(g2, d1, d2, &ex);SIDL_CHECK(ex);
   graph_GraphOps_insEdge(g2, d2, d1, &ex);SIDL_CHECK(ex);

   //insert edge between 1 and 3
   printf("Inserted edge between 1 and 3\n");
   graph_GraphOps_insEdge(g, d1, d3, &ex);
   graph_GraphOps_insEdge(g, d3, d1, &ex);
   graph_GraphOps_insEdge(g1, d1, d3, &ex);SIDL_CHECK(ex);
   graph_GraphOps_insEdge(g1, d3, d1, &ex);SIDL_CHECK(ex);
   graph_GraphOps_insEdge(g2, d1, d2, &ex);SIDL_CHECK(ex);
   graph_GraphOps_insEdge(g2, d2, d1, &ex);SIDL_CHECK(ex);

   //insert edge between 4 and 5
   printf("Inserted edge between 4 and 5\n");
   graph_GraphOps_insEdge(g, d5, d4, &ex);
   graph_GraphOps_insEdge(g, d4, d5, &ex);
   graph_GraphOps_insEdge(g1, d5, d4, &ex);SIDL_CHECK(ex);
   graph_GraphOps_insEdge(g1, d4, d5, &ex);SIDL_CHECK(ex);
   graph_GraphOps_insEdge(g2, d1, d2, &ex);SIDL_CHECK(ex);
   graph_GraphOps_insEdge(g2, d2, d1, &ex);SIDL_CHECK(ex);

   //insert edge between 5 and 3
   printf("Inserted edge between 5 and 3\n");
   graph_GraphOps_insEdge(g, d3, d5, &ex);
   graph_GraphOps_insEdge(g, d5, d3, &ex);
   graph_GraphOps_insEdge(g1, d3, d5, &ex);SIDL_CHECK(ex);
   graph_GraphOps_insEdge(g1, d5, d3, &ex);SIDL_CHECK(ex);
   graph_GraphOps_insEdge(g2, d1, d2, &ex);SIDL_CHECK(ex);
   graph_GraphOps_insEdge(g2, d2, d1, &ex);SIDL_CHECK(ex);

   //insert edge between 5 and 6
   printf("Inserted edge between 5 and 6\n");
   graph_GraphOps_insEdge(g, d6, d5, &ex);
   graph_GraphOps_insEdge(g, d5, d6, &ex);
   graph_GraphOps_insEdge(g1, d6, d5, &ex);SIDL_CHECK(ex);
   graph_GraphOps_insEdge(g1, d5, d6, &ex);SIDL_CHECK(ex);
   graph_GraphOps_insEdge(g2, d1, d2, &ex);SIDL_CHECK(ex);
   graph_GraphOps_insEdge(g2, d2, d1, &ex);SIDL_CHECK(ex);

   int ecount1 = graph_GraphOps_getEdgeCount(g, &ex);
   int ecount2 = graph_GraphOps_getEdgeCount(g1, &ex);
   int ecount3 = graph_GraphOps_getEdgeCount(g2, &ex);
   printf("Ecount1 = %d, Ecount2 = %d, Ecount3 = %d\n", ecount1, ecount2, ecount3);

   int vcount1 = graph_GraphOps_getVertCount(g, &ex);
   int vcount2 = graph_GraphOps_getVertCount(g1, &ex);
   int vcount3 = graph_GraphOps_getVertCount(g2, &ex);
   printf("Vcount1 = %d, Vcount2 = %d, Vcount3 = %d\n", vcount1, vcount2, vcount3);
   
   graph_GraphOps_insEdge(g, d1, d2, &ex);

  //try removing existing edge
   
   result =   graph_GraphOps_isAdjacent(g, d5,d6, &ex);
   if (!result) printf("should be adjacent\n");
   
   graph_GraphOps_remEdge(g, d5, d6, &ex);
  
   graph_GraphOps_remEdge(g, d6, d5, &ex);

   result =   graph_GraphOps_isAdjacent(g, d5,d6, &ex);

   if (result) printf("should not be adjacent\n");

   //try removing some unexisting edges
   printf("Try removing some unexisting edges.. \n");
   graph_GraphOps_remEdge(g, d5, d6, &ex);
   graph_GraphOps_remEdge(g, d6, d5, &ex);
   graph_GraphOps_remEdge(g, d5, d1, &ex);
   graph_GraphOps_remEdge(g, d1, d5, &ex);

   printf("Try removing vertex d6\n");
   result = graph_GraphOps_remVertex(g, d6, &ex);
   if (result == -1) printf("Error, d6 should have been removed\n");
   if (result == 0) printf("Correct, d6 is removed\n");

   printf("Try removing vertex d2\n");
   result = graph_GraphOps_remVertex(g, d2, &ex);

   if (result == 0) printf("Error, d2 should not have been removed\n");
   if (result == -1) printf("Correct, d2 is not removed\n");
 

   graph_GraphOps_remEdge(g, d1, d2, &ex);
   graph_GraphOps_remEdge(g, d2, d1, &ex);
   graph_GraphOps_remEdge(g, d3, d1, &ex);
   graph_GraphOps_remEdge(g, d1, d3, &ex);

   printf("Try removing vertex d1\n");
   result = graph_GraphOps_remVertex(g, d1, &ex);
   if (result == 0) printf("Correct, d1 is removed\n");
   if (result == -1) printf("Error, d1 is not removed\n");
   
   else printf("Try removing d1 again\n");
   result = graph_GraphOps_remVertex(g, d1, &ex);
   if (result == 0) printf("Error, d1 removed\n");
   if (result == -1) printf("Correct, d1 is not removed\n");

   graph_IntData_deleteRef(id1, &ex);
   graph_IntData_deleteRef(id2, &ex);
   graph_IntData_deleteRef(id3, &ex);
   graph_IntData_deleteRef(id4, &ex);
   graph_IntData_deleteRef(id5, &ex);
   graph_IntData_deleteRef(id6, &ex);


   graph_Data_deleteRef(d1, &ex);
   graph_Data_deleteRef(d2, &ex);
   graph_Data_deleteRef(d3, &ex);
   graph_Data_deleteRef(d4, &ex);
   graph_Data_deleteRef(d5, &ex);
   graph_Data_deleteRef(d6, &ex);
  
   

   graph_GraphOps_deleteRef(g, &ex);
   sidl_EnfPolicy_dumpStats("stats.out", 1, "",0, &ex);

 

 
 return 0;
 EXIT:
 {
   printf("\nexiting\n");
   sidl_BaseInterface ignore = NULL;
   sidl_BaseException be = sidl_BaseException__cast(ex, &ignore);

    char * msg = sidl_BaseException_getNote(be, &ignore);
    printf("%s\n",msg);
    sidl_String_free(msg);

    sidl_BaseException_deleteRef(be, &ignore);
    //Containers_SetArr_deleteRef(h,&ex);
    SIDL_CLEAR(ex);
    return 1;


 }
}


