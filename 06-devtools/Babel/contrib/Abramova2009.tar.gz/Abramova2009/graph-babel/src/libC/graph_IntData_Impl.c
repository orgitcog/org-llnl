/*
 * File:          graph_IntData_Impl.c
 * Symbol:        graph.IntData-v1.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for graph.IntData
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "graph.IntData" (version 1.0)
 * 
 * This is a simple Data class wrapping an integer.
 */

#include "graph_IntData_Impl.h"
#include "sidl_NotImplementedException.h"
#include "sidl_Exception.h"
#ifndef included_sidl_MemAllocException_h
#include "sidl_MemAllocException.h"
#endif

/* DO-NOT-DELETE splicer.begin(graph.IntData._includes) */
/* insert code here (includes and arbitrary code) */
/* DO-NOT-DELETE splicer.end(graph.IntData._includes) */

#define SIDL_IOR_MAJOR_VERSION 2
#define SIDL_IOR_MINOR_VERSION 0
/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_IntData__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_IntData__load(
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.IntData._load) */
    /* insert code here (static class initializer) */
    /* DO-NOT-DELETE splicer.end(graph.IntData._load) */
  }
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_IntData__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_IntData__ctor(
  /* in */ graph_IntData self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.IntData._ctor) */
    
     
      struct graph_IntData__data *dptr = (struct graph_IntData__data*)malloc(sizeof(struct graph_IntData__data));
      if (dptr) {
        memset(dptr, 0, sizeof(struct graph_IntData__data));
        // initialize elements of dptr here
	dptr->num = 0;
      graph_IntData__set_data(self, dptr);
      } else {
        sidl_MemAllocException ex = sidl_MemAllocException_getSingletonException(_ex);
        SIDL_CHECK(*_ex);
        sidl_MemAllocException_setNote(ex, "Out of memory.", _ex); SIDL_CHECK(*_ex);
        sidl_MemAllocException_add(ex, __FILE__, __LINE__, "graph.IntData._ctor", _ex);
        SIDL_CHECK(*_ex);
        *_ex = (sidl_BaseInterface)ex;
      }
      EXIT:;
     

    /* DO-NOT-DELETE splicer.end(graph.IntData._ctor) */
  }
}

/*
 * Special Class constructor called when the user wants to wrap his own private data.
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_IntData__ctor2"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_IntData__ctor2(
  /* in */ graph_IntData self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.IntData._ctor2) */
    /* insert code here (special constructor) */
    /* DO-NOT-DELETE splicer.end(graph.IntData._ctor2) */
  }
}
/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_IntData__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_IntData__dtor(
  /* in */ graph_IntData self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.IntData._dtor) */
    
      // boilerplate destructor
      struct graph_IntData__data *dptr = graph_IntData__get_data(self);
      if (dptr) {
        // free contained in dtor before next line
        free(dptr);
        graph_IntData__set_data(self, NULL);
      }
     

    /* DO-NOT-DELETE splicer.end(graph.IntData._dtor) */
  }
}

/*
 * Returns the integer data member
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_IntData_getIntData"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_graph_IntData_getIntData(
  /* in */ graph_IntData self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.IntData.getIntData) */
      struct graph_IntData__data *dptr = graph_IntData__get_data(self);
      return dptr->num;

    /* DO-NOT-DELETE splicer.end(graph.IntData.getIntData) */
  }
}

/*
 * Sets the integer data member
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_IntData_setIntData"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_IntData_setIntData(
  /* in */ graph_IntData self,
  /* in */ int32_t val,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.IntData.setIntData) */
        struct graph_IntData__data *dptr = graph_IntData__get_data(self);
     dptr->num = val;
    /* DO-NOT-DELETE splicer.end(graph.IntData.setIntData) */
  }
}

/*
 * Displays contents of the data if possible
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_IntData_display"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_IntData_display(
  /* in */ graph_IntData self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.IntData.display) */
    struct graph_IntData__data *dptr = graph_IntData__get_data(self);
     int32_t n = dptr->num;
     printf(" %d ",n);
    /* DO-NOT-DELETE splicer.end(graph.IntData.display) */
  }
}

/*
 * Computes and returns a unique integer id - 
 * simply returns value of the data ptr
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_IntData_hashCode"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_graph_IntData_hashCode(
  /* in */ graph_IntData self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.IntData.hashCode) */
     struct graph_IntData__data *dptr = graph_IntData__get_data(self);
    return dptr; 
    /* DO-NOT-DELETE splicer.end(graph.IntData.hashCode) */
  }
}

/*
 * Compares the element with data parameter element, 
 * returns 1 if it's greater than data,
 * 0 if they are equal and -1 if it's less than data
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_IntData_compare"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_graph_IntData_compare(
  /* in */ graph_IntData self,
  /* in */ graph_Data data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.IntData.compare) */
    struct graph_IntData__data *dptr = graph_IntData__get_data(self);
    graph_IntData idata = graph_IntData__cast(data, _ex); SIDL_REPORT(*_ex);
    int32_t num2 = graph_IntData_getIntData(idata,_ex); SIDL_REPORT(*_ex);
    graph_IntData_deleteRef(idata, _ex);
    int32_t num1 = dptr->num;
    if (num1 > num2) return 1;
    if (num1 == num2) return 0;
    if (num1 < num2) return -1;
  EXIT:return -2;
    /* DO-NOT-DELETE splicer.end(graph.IntData.compare) */
  }
}

/*
 * Takes in another Data object and casts it to a 
 * corresponding type + sets internal data members
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_IntData_setData"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_IntData_setData(
  /* in */ graph_IntData self,
  /* in */ graph_Data data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.IntData.setData) */
    graph_IntData i_data = graph_IntData__cast(data, _ex); SIDL_REPORT(*_ex);
    int num = graph_IntData_getIntData(i_data, _ex); SIDL_REPORT(*_ex);
    graph_IntData_deleteRef(i_data, _ex); SIDL_REPORT(*_ex);
    graph_IntData_setIntData(self, num, _ex); SIDL_REPORT(*_ex);
  EXIT: ;
    /* DO-NOT-DELETE splicer.end(graph.IntData.setData) */
  }
}
/* Babel internal methods, Users should not edit below this line. */

/* DO-NOT-DELETE splicer.begin(_misc) */
/* insert code here (miscellaneous code) */
/* DO-NOT-DELETE splicer.end(_misc) */

