/*
 * File:          graph_IntData_Impl.h
 * Symbol:        graph.IntData-v1.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for graph.IntData
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#ifndef included_graph_IntData_Impl_h
#define included_graph_IntData_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_graph_Data_h
#include "graph_Data.h"
#endif
#ifndef included_graph_IntData_h
#include "graph_IntData.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_RuntimeException_h
#include "sidl_RuntimeException.h"
#endif
/* DO-NOT-DELETE splicer.begin(graph.IntData._hincludes) */
/* insert code here (include files) */
/* DO-NOT-DELETE splicer.end(graph.IntData._hincludes) */

/*
 * Private data for class graph.IntData
 */

struct graph_IntData__data {
  /* DO-NOT-DELETE splicer.begin(graph.IntData._data) */
  /* insert code here (private data members) */
  int num; 
  /* DO-NOT-DELETE splicer.end(graph.IntData._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct graph_IntData__data*
graph_IntData__get_data(
  graph_IntData);

extern void
graph_IntData__set_data(
  graph_IntData,
  struct graph_IntData__data*);

extern
void
impl_graph_IntData__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_graph_IntData__ctor(
  /* in */ graph_IntData self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_graph_IntData__ctor2(
  /* in */ graph_IntData self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_graph_IntData__dtor(
  /* in */ graph_IntData self,
  /* out */ sidl_BaseInterface *_ex);

/*
 * User-defined object methods
 */

#ifdef WITH_RMI
extern struct graph_Data__object* impl_graph_IntData_fconnect_graph_Data(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_graph_IntData_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/
extern
int32_t
impl_graph_IntData_getIntData(
  /* in */ graph_IntData self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_graph_IntData_setIntData(
  /* in */ graph_IntData self,
  /* in */ int32_t val,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_graph_IntData_display(
  /* in */ graph_IntData self,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_graph_IntData_hashCode(
  /* in */ graph_IntData self,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_graph_IntData_compare(
  /* in */ graph_IntData self,
  /* in */ graph_Data data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_graph_IntData_setData(
  /* in */ graph_IntData self,
  /* in */ graph_Data data,
  /* out */ sidl_BaseInterface *_ex);

#ifdef WITH_RMI
extern struct graph_Data__object* impl_graph_IntData_fconnect_graph_Data(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_graph_IntData_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/

/* DO-NOT-DELETE splicer.begin(_hmisc) */
/* insert code here (miscellaneous things) */
/* DO-NOT-DELETE splicer.end(_hmisc) */

#ifdef __cplusplus
}
#endif
#endif
