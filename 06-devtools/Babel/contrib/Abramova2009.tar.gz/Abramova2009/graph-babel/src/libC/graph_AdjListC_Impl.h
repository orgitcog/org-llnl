/*
 * File:          graph_AdjListC_Impl.h
 * Symbol:        graph.AdjListC-v1.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for graph.AdjListC
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#ifndef included_graph_AdjListC_Impl_h
#define included_graph_AdjListC_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_graph_AdjList_h
#include "graph_AdjList.h"
#endif
#ifndef included_graph_AdjListC_h
#include "graph_AdjListC.h"
#endif
#ifndef included_graph_Data_h
#include "graph_Data.h"
#endif
#ifndef included_graph_ListOps_h
#include "graph_ListOps.h"
#endif
#ifndef included_graph_SetOps_h
#include "graph_SetOps.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_PostViolation_h
#include "sidl_PostViolation.h"
#endif
#ifndef included_sidl_PreViolation_h
#include "sidl_PreViolation.h"
#endif
#ifndef included_sidl_RuntimeException_h
#include "sidl_RuntimeException.h"
#endif
/* DO-NOT-DELETE splicer.begin(graph.AdjListC._hincludes) */
/* insert code here (include files) */
#ifndef included_graph_SetC_h
#include "graph_SetC.h"
#endif
/* DO-NOT-DELETE splicer.end(graph.AdjListC._hincludes) */

/*
 * Private data for class graph.AdjListC
 */

struct graph_AdjListC__data {
  /* DO-NOT-DELETE splicer.begin(graph.AdjListC._data) */
  /* insert code here (private data members) */
  graph_SetOps adjacent;
  graph_Data vertex;
  /* DO-NOT-DELETE splicer.end(graph.AdjListC._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct graph_AdjListC__data*
graph_AdjListC__get_data(
  graph_AdjListC);

extern void
graph_AdjListC__set_data(
  graph_AdjListC,
  struct graph_AdjListC__data*);

extern
void
impl_graph_AdjListC__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_graph_AdjListC__ctor(
  /* in */ graph_AdjListC self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_graph_AdjListC__ctor2(
  /* in */ graph_AdjListC self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_graph_AdjListC__dtor(
  /* in */ graph_AdjListC self,
  /* out */ sidl_BaseInterface *_ex);

/*
 * User-defined object methods
 */

#ifdef WITH_RMI
extern struct graph_Data__object* impl_graph_AdjListC_fconnect_graph_Data(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_graph_AdjListC_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar,
  sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/
extern
graph_Data
impl_graph_AdjListC_getVertex(
  /* in */ graph_AdjListC self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_graph_AdjListC_display(
  /* in */ graph_AdjListC self,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_graph_AdjListC_hashCode(
  /* in */ graph_AdjListC self,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_graph_AdjListC_compare(
  /* in */ graph_AdjListC self,
  /* in */ graph_Data data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_graph_AdjListC_setData(
  /* in */ graph_AdjListC self,
  /* in */ graph_Data data,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_graph_AdjListC_insert(
  /* in */ graph_AdjListC self,
  /* in */ graph_Data d,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_graph_AdjListC_remove(
  /* in */ graph_AdjListC self,
  /* in */ graph_Data d,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_graph_AdjListC_isMember(
  /* in */ graph_AdjListC self,
  /* in */ graph_Data d,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_graph_AdjListC_clearSet(
  /* in */ graph_AdjListC self,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_graph_AdjListC_isEmpty(
  /* in */ graph_AdjListC self,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_graph_AdjListC_getSize(
  /* in */ graph_AdjListC self,
  /* out */ sidl_BaseInterface *_ex);

extern
graph_ListOps
impl_graph_AdjListC_getList(
  /* in */ graph_AdjListC self,
  /* out */ sidl_BaseInterface *_ex);

#ifdef WITH_RMI
extern struct graph_Data__object* impl_graph_AdjListC_fconnect_graph_Data(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_graph_AdjListC_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar,
  sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/

/* DO-NOT-DELETE splicer.begin(_hmisc) */
/* insert code here (miscellaneous things) */
/* DO-NOT-DELETE splicer.end(_hmisc) */

#ifdef __cplusplus
}
#endif
#endif
