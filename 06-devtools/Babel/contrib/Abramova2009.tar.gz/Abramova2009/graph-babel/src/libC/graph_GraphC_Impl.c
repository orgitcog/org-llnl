/*
 * File:          graph_GraphC_Impl.c
 * Symbol:        graph.GraphC-v1.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for graph.GraphC
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "graph.GraphC" (version 1.0)
 * 
 * Basic class implementing a graph
 */

#include "graph_GraphC_Impl.h"
#include "sidl_NotImplementedException.h"
#include "sidl_Exception.h"
#ifndef included_sidl_MemAllocException_h
#include "sidl_MemAllocException.h"
#endif

/* DO-NOT-DELETE splicer.begin(graph.GraphC._includes) */
/* insert code here (includes and arbitrary code) */
/* DO-NOT-DELETE splicer.end(graph.GraphC._includes) */

#define SIDL_IOR_MAJOR_VERSION 2
#define SIDL_IOR_MINOR_VERSION 0
/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_GraphC__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_GraphC__load(
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.GraphC._load) */
    /* insert code here (static class initializer) */
    /* DO-NOT-DELETE splicer.end(graph.GraphC._load) */
  }
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_GraphC__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_GraphC__ctor(
  /* in */ graph_GraphC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.GraphC._ctor) */
    
      // boilerplate constructor
      struct graph_GraphC__data *dptr = (struct graph_GraphC__data*)malloc(sizeof(struct graph_GraphC__data));
      if (dptr) {
        memset(dptr, 0, sizeof(struct graph_GraphC__data));
        // initialize elements of dptr here
	dptr->vcount = 0;
	dptr->ecount = 0;
	graph_ListC listc = graph_ListC__create(_ex);
	dptr->adjlists = graph_ListOps__cast(listc, _ex);
	graph_ListC_deleteRef(listc, _ex);
      graph_GraphC__set_data(self, dptr);
      } else {
        sidl_MemAllocException ex = sidl_MemAllocException_getSingletonException(_ex);
        SIDL_CHECK(*_ex);
        sidl_MemAllocException_setNote(ex, "Out of memory.", _ex); SIDL_CHECK(*_ex);
        sidl_MemAllocException_add(ex, __FILE__, __LINE__, "graph.GraphC._ctor", _ex);
        SIDL_CHECK(*_ex);
        *_ex = (sidl_BaseInterface)ex;
      }
      EXIT:;
     

    /* DO-NOT-DELETE splicer.end(graph.GraphC._ctor) */
  }
}

/*
 * Special Class constructor called when the user wants to wrap his own private data.
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_GraphC__ctor2"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_GraphC__ctor2(
  /* in */ graph_GraphC self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.GraphC._ctor2) */
    /* insert code here (special constructor) */
    /* DO-NOT-DELETE splicer.end(graph.GraphC._ctor2) */
  }
}
/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_GraphC__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_GraphC__dtor(
  /* in */ graph_GraphC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.GraphC._dtor) */
    
      // boilerplate destructor
      struct graph_GraphC__data *dptr = graph_GraphC__get_data(self);
      if (dptr) {
        // free contained in dtor before next line
	dptr->vcount = NULL;
	dptr->ecount = NULL;
	graph_ListOps_deleteRef(dptr->adjlists, _ex);
        free(dptr);
        graph_GraphC__set_data(self, NULL);
      }
     

    /* DO-NOT-DELETE splicer.end(graph.GraphC._dtor) */
  }
}

/*
 * Inserts a vertex into a graph. 
 * returns 0 if the insertion is successful, 
 * 1 if the vertex already exists. -1 otherwise
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_GraphC_insVertex"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_graph_GraphC_insVertex(
  /* in */ graph_GraphC self,
  /* in */ graph_Data d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.GraphC.insVertex) */
    /* insert code here (insVertex) */
    struct graph_GraphC__data * dptr = graph_GraphC__get_data(self);
    graph_ListNode elem,next;
    graph_AdjList adjlist;
    elem = graph_ListOps_getHead(dptr->adjlists, _ex); SIDL_REPORT(*_ex);
    while (elem){
      adjlist = graph_ListNode_getData(elem, _ex); SIDL_REPORT(*_ex); 
      int compare_result = graph_AdjList_compare(adjlist, d, _ex);
      if (compare_result == 0){
        //means there is already an existing vertex
        graph_AdjList_deleteRef(adjlist, _ex); SIDL_REPORT(*_ex);
        graph_ListNode_deleteRef(elem,_ex); SIDL_REPORT(*_ex);
        return 1;
      }
      graph_AdjList_deleteRef(adjlist,_ex); SIDL_REPORT(*_ex);
      next = graph_ListNode_getNext(elem, _ex); SIDL_REPORT(*_ex);
      graph_ListNode_deleteRef(elem, _ex); SIDL_REPORT(*_ex);
      elem = next; 
    }
    //vertex not found, create adjacency list and insert vertex
    graph_AdjListC ad = graph_AdjListC__create(_ex);
    adjlist = graph_AdjList__cast(ad,_ex); SIDL_REPORT(*_ex);
    graph_AdjListC_deleteRef(ad, _ex);
    graph_AdjList_setData(adjlist, d, _ex); SIDL_REPORT(*_ex); 
    graph_ListNode tail = graph_ListOps_getTail(dptr->adjlists, _ex); SIDL_REPORT(*_ex);
    int retval = -1;
    retval = graph_ListOps_insertNext(dptr->adjlists, tail, adjlist, _ex); SIDL_REPORT(*_ex);
    if (tail) graph_ListNode_deleteRef(tail, _ex); SIDL_REPORT(*_ex);
    graph_AdjList_deleteRef(adjlist, _ex); SIDL_REPORT(*_ex);
    if (retval != 0)
      return retval;
    dptr->vcount++;
    return 0;
  EXIT:
    return -1;
    /* DO-NOT-DELETE splicer.end(graph.GraphC.insVertex) */
  }
}

/*
 * Removes vertex from a graph. 
 * returns 0 if removal was successful, 
 * -1 otherwise 
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_GraphC_remVertex"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_graph_GraphC_remVertex(
  /* in */ graph_GraphC self,
  /* in */ graph_Data d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.GraphC.remVertex) */
    struct graph_GraphC__data * dptr = graph_GraphC__get_data(self);
    //traverse each adjacency list and the vertices it contains
    //do not allow removal of a vertex if it is in an adjacency list.. 
    //test for 3 cases: vertex can be removed, vertex not found, vertex is present in one of adjacency lists
    graph_ListNode elem, next, temp= NULL;
    graph_ListNode prev = NULL;
    int found = 0;
    graph_AdjList adjlist, adjListToRemove;
    elem = graph_ListOps_getHead(dptr->adjlists, _ex); SIDL_REPORT(*_ex);
    while (elem){
      adjlist = graph_ListNode_getData(elem, _ex); SIDL_REPORT(*_ex);
      if (graph_AdjList_isMember(adjlist,d, _ex)){
        graph_AdjList_deleteRef(adjlist, _ex); SIDL_REPORT(*_ex);
        graph_ListNode_deleteRef(elem, _ex); SIDL_REPORT(*_ex);
        if (prev) graph_ListNode_deleteRef(prev, _ex); SIDL_REPORT(*_ex);
        if (temp) graph_ListNode_deleteRef(temp, _ex); SIDL_REPORT(*_ex);
        return -1;
      }
      //compare the vertex, keep a pointer to the adjlist element.
      int retval = graph_AdjList_compare(adjlist, d, _ex);
      if (retval == 0){
        temp = elem;
        adjListToRemove = adjlist;
        found = 1;
      }
      if (retval!= 0){
	graph_AdjList_deleteRef(adjlist, _ex);
        graph_ListNode_deleteRef(elem, _ex);
      }
      
      if (!found){
        if (prev) graph_ListNode_deleteRef(prev, _ex); SIDL_REPORT(*_ex);
        //graph_AdjList_deleteRef(adjlist, _ex);
        prev = elem;
        graph_ListNode_addRef(prev, _ex);
      }           
      next = graph_ListNode_getNext(elem, _ex); SIDL_REPORT(*_ex);
      elem = next;
    }
    if (!found){
      if (prev) graph_ListNode_deleteRef(prev, _ex); SIDL_REPORT(*_ex);
      
      return -1;
    }
    int size = graph_AdjList_getSize(adjListToRemove, _ex);
    if (size > 0){
      graph_ListNode_deleteRef(temp, _ex);
      if (prev) graph_ListNode_deleteRef(prev, _ex);
      graph_AdjList_deleteRef(adjListToRemove, _ex);
      return -1;
    }
    graph_AdjList_deleteRef(adjListToRemove,_ex);
    if (prev)graph_ListNode_deleteRef(prev, _ex);
    graph_ListNode_deleteRef(temp, _ex);
    // graph_AdjList_deleteRef(adjListToRemove, _ex);
    int retval = graph_ListOps_removeNext(dptr->adjlists, prev, &adjlist,_ex);
    if (retval != 0)
      return -1;
    graph_AdjList_deleteRef(adjlist,_ex);
    dptr->vcount--;
    return 0;
      
  EXIT:
    return -1;
      
    /* DO-NOT-DELETE splicer.end(graph.GraphC.remVertex) */
  }
}

/*
 * Inserts an edge specified by vertices d1 and d2. 
 * Both vertices must have been inserted previously. 
 * The new edge is represented by pointer to d2 
 * in the adjacency list of d1. To enter an edge 
 * into an undirected graph, call this operation 
 * twice, once to insert an edge from d1 to d2, 
 * and again to insert an edge from d2 to d1. 
 * Method returns 0 if the insertion was successful,
 * 1 if the edge already exists and -1 otherwise.
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_GraphC_insEdge"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_graph_GraphC_insEdge(
  /* in */ graph_GraphC self,
  /* in */ graph_Data d1,
  /* in */ graph_Data d2,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.GraphC.insEdge) */
     //do not allow insertion of an edge without both of its vertices in the graph
    struct graph_GraphC__data * dptr = graph_GraphC__get_data(self);
    graph_ListNode elem,next;
    graph_AdjList adjlist;
    elem = graph_ListOps_getHead(dptr->adjlists, _ex); SIDL_REPORT(*_ex);
    while (elem){
      adjlist = graph_ListNode_getData(elem, _ex); SIDL_REPORT(*_ex); 
      int compare_result = graph_AdjList_compare(adjlist, d2, _ex);
      if (compare_result == 0){
        //means there is already an existing vertex with d2 element
        graph_AdjList_deleteRef(adjlist, _ex); SIDL_REPORT(*_ex);
        graph_ListNode_deleteRef(elem, _ex); SIDL_REPORT(*_ex);
        break;
      }
      graph_AdjList_deleteRef(adjlist,_ex); SIDL_REPORT(*_ex);
      next = graph_ListNode_getNext(elem, _ex); SIDL_REPORT(*_ex);
      graph_ListNode_deleteRef(elem, _ex); SIDL_REPORT(*_ex);
      elem = next; 
    }
    if (!elem){
      return -1;
    }
    elem = graph_ListOps_getHead(dptr->adjlists, _ex); SIDL_REPORT(*_ex);
    while (elem){
      adjlist = graph_ListNode_getData(elem, _ex); SIDL_REPORT(*_ex); 
      int compare_result = graph_AdjList_compare(adjlist, d1, _ex);
      if (compare_result == 0){
        //means there is already an existing vertex with d2 element
        //graph_AdjList_deleteRef(adjlist, _ex); SIDL_REPORT(*_ex);
        graph_ListNode_deleteRef(elem, _ex); SIDL_REPORT(*_ex);
        break;
      }
      graph_AdjList_deleteRef(adjlist,_ex); SIDL_REPORT(*_ex);
      next = graph_ListNode_getNext(elem, _ex); SIDL_REPORT(*_ex);
      graph_ListNode_deleteRef(elem, _ex); SIDL_REPORT(*_ex);
      elem = next; 
    }
    if (!elem){
      return -1;
    }
    //insert the second vertex into the adjacency list of first vertex
    int retval = graph_AdjList_insert(adjlist, d2, _ex); SIDL_REPORT(*_ex);
    graph_AdjList_deleteRef(adjlist, _ex); SIDL_REPORT(*_ex);
    if (retval != 0) return retval;
    dptr->ecount++;
    return 0;    
  EXIT:
    return -1;
    /* DO-NOT-DELETE splicer.end(graph.GraphC.insEdge) */
  }
}

/*
 * Removes the edge from d1 to d2. returns 0 
 * if removing of edge was successful, -1 otherwise.
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_GraphC_remEdge"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_graph_GraphC_remEdge(
  /* in */ graph_GraphC self,
  /* in */ graph_Data d1,
  /* in */ graph_Data d2,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.GraphC.remEdge) */
    struct graph_GraphC__data * dptr = graph_GraphC__get_data(self);
    graph_ListNode elem,next;
    graph_AdjList adjlist;
    elem = graph_ListOps_getHead(dptr->adjlists, _ex); SIDL_REPORT(*_ex);
    while (elem){
      adjlist = graph_ListNode_getData(elem, _ex); SIDL_REPORT(*_ex); 
      int compare_result = graph_AdjList_compare(adjlist, d1, _ex);
      if (compare_result == 0){
        break;
      }
      next = graph_ListNode_getNext(elem, _ex);
      graph_ListNode_deleteRef(elem, _ex);
      graph_AdjList_deleteRef(adjlist, _ex);
      elem = next;
    }
    if (! elem ){
      return -1;
    }
    int result = graph_AdjList_remove(adjlist, d2, _ex);
    graph_AdjList_deleteRef(adjlist, _ex);
    graph_ListNode_deleteRef(elem, _ex);
    if (result != 0){

      return -1;
    }
    dptr->ecount--;
    return 0;
    EXIT:
    return -1;
    /* DO-NOT-DELETE splicer.end(graph.GraphC.remEdge) */
  }
}

/*
 *  
 * Returns vertices that are adjacent to Data d.
 * The vertices are returned in the form of actual 
 * AdjList data structure with vertex data member pointing to d.
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_GraphC_getAdjList"

#ifdef __cplusplus
extern "C"
#endif
graph_AdjList
impl_graph_GraphC_getAdjList(
  /* in */ graph_GraphC self,
  /* in */ graph_Data d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.GraphC.getAdjList) */
    struct graph_GraphC__data * dptr = graph_GraphC__get_data(self);
    graph_ListNode elem,next;
    graph_AdjList adjlist;
    elem = graph_ListOps_getHead(dptr->adjlists, _ex); SIDL_REPORT(*_ex);
    while (elem){
      adjlist = graph_ListNode_getData(elem, _ex); SIDL_REPORT(*_ex); 
      int compare_result = graph_AdjList_compare(adjlist, d, _ex);
      if (compare_result == 0){
        graph_ListNode_deleteRef(elem, _ex);
        break;
      }
      graph_AdjList_deleteRef(adjlist,_ex); SIDL_REPORT(*_ex);
      next = graph_ListNode_getNext(elem, _ex); SIDL_REPORT(*_ex);
      graph_ListNode_deleteRef(elem, _ex); SIDL_REPORT(*_ex);
      elem = next; 
    }
    if (! elem){
      return NULL;
    } 
    return adjlist;
  EXIT:
      return NULL;
    /* DO-NOT-DELETE splicer.end(graph.GraphC.getAdjList) */
  }
}

/*
 * Determines whether the vertex specified by d2
 * is adjacent to the vertex specified by d1 in graph.
 * Returns 1 if the second vertex is adjacent to the 
 * first vertex, or 0 otherwise
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_GraphC_isAdjacent"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_graph_GraphC_isAdjacent(
  /* in */ graph_GraphC self,
  /* in */ graph_Data d1,
  /* in */ graph_Data d2,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.GraphC.isAdjacent) */
    struct graph_GraphC__data * dptr = graph_GraphC__get_data(self);
    graph_ListNode elem,next;
    graph_AdjList adjlist;
    elem = graph_ListOps_getHead(dptr->adjlists, _ex); SIDL_REPORT(*_ex);
    while (elem){
      adjlist = graph_ListNode_getData(elem, _ex); SIDL_REPORT(*_ex); 
      int compare_result = graph_AdjList_compare(adjlist, d1, _ex);
      if (compare_result == 0){
        break;
      }
      graph_AdjList_deleteRef(adjlist,_ex); SIDL_REPORT(*_ex);
      next = graph_ListNode_getNext(elem, _ex); SIDL_REPORT(*_ex);
      graph_ListNode_deleteRef(elem, _ex); SIDL_REPORT(*_ex);
      elem = next; 
    }
    if (! elem){
      return NULL;
    }
    int32_t result = graph_AdjList_isMember(adjlist, d2, _ex);  
    graph_ListNode_deleteRef(elem, _ex);
    graph_AdjList_deleteRef(adjlist, _ex);
    return result;
    
   EXIT:
    return NULL; 
    /* DO-NOT-DELETE splicer.end(graph.GraphC.isAdjacent) */
  }
}

/*
 * Returns all adjacency data structures in the 
 * form of a List interface. or NULL if fails.
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_GraphC_getAdjLists"

#ifdef __cplusplus
extern "C"
#endif
graph_ListOps
impl_graph_GraphC_getAdjLists(
  /* in */ graph_GraphC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.GraphC.getAdjLists) */
    struct graph_GraphC__data * dptr = graph_GraphC__get_data(self);
    graph_ListOps_addRef(dptr->adjlists, _ex); 
    return dptr->adjlists;
    /* DO-NOT-DELETE splicer.end(graph.GraphC.getAdjLists) */
  }
}

/*
 * Returns current vertex count
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_GraphC_getVertCount"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_graph_GraphC_getVertCount(
  /* in */ graph_GraphC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.GraphC.getVertCount) */
    struct graph_GraphC__data * dptr = graph_GraphC__get_data(self);
    return dptr->vcount;
    /* DO-NOT-DELETE splicer.end(graph.GraphC.getVertCount) */
  }
}

/*
 * Returns current edge count
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_GraphC_getEdgeCount"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_graph_GraphC_getEdgeCount(
  /* in */ graph_GraphC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.GraphC.getEdgeCount) */
     struct graph_GraphC__data * dptr = graph_GraphC__get_data(self);
    return dptr->ecount;
    /* DO-NOT-DELETE splicer.end(graph.GraphC.getEdgeCount) */
  }
}

/*
 * Returns true if the vertex is present in the graph, false otherwise
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_GraphC_vertexExists"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_graph_GraphC_vertexExists(
  /* in */ graph_GraphC self,
  /* in */ graph_Data d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.GraphC.vertexExists) */
    struct graph_GraphC__data * dptr = graph_GraphC__get_data(self);
    graph_ListNode elem,next;
    graph_AdjList adjlist;
    elem = graph_ListOps_getHead(dptr->adjlists, _ex); SIDL_REPORT(*_ex);
    while (elem){
      adjlist = graph_ListNode_getData(elem, _ex); SIDL_REPORT(*_ex); 
      int compare_result = graph_AdjList_compare(adjlist, d, _ex);
      if (compare_result == 0){
        graph_ListNode_deleteRef(elem, _ex);
        break;
      }
      graph_AdjList_deleteRef(adjlist,_ex); SIDL_REPORT(*_ex);
      next = graph_ListNode_getNext(elem, _ex); SIDL_REPORT(*_ex);
      graph_ListNode_deleteRef(elem, _ex); SIDL_REPORT(*_ex);
      elem = next; 
    }
    if (! elem){
      return 0;
    } 
    graph_AdjList_deleteRef(adjlist, _ex);
    return 1;
  EXIT: return -1;
    /* DO-NOT-DELETE splicer.end(graph.GraphC.vertexExists) */
  }
}
/* Babel internal methods, Users should not edit below this line. */

/* DO-NOT-DELETE splicer.begin(_misc) */
/* insert code here (miscellaneous code) */
/* DO-NOT-DELETE splicer.end(_misc) */

