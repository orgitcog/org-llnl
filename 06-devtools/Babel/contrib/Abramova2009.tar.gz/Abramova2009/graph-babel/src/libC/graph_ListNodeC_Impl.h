/*
 * File:          graph_ListNodeC_Impl.h
 * Symbol:        graph.ListNodeC-v1.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for graph.ListNodeC
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#ifndef included_graph_ListNodeC_Impl_h
#define included_graph_ListNodeC_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_graph_Data_h
#include "graph_Data.h"
#endif
#ifndef included_graph_ListNode_h
#include "graph_ListNode.h"
#endif
#ifndef included_graph_ListNodeC_h
#include "graph_ListNodeC.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_RuntimeException_h
#include "sidl_RuntimeException.h"
#endif
/* DO-NOT-DELETE splicer.begin(graph.ListNodeC._hincludes) */
/* insert code here (include files) */
/* DO-NOT-DELETE splicer.end(graph.ListNodeC._hincludes) */

/*
 * Private data for class graph.ListNodeC
 */

struct graph_ListNodeC__data {
  /* DO-NOT-DELETE splicer.begin(graph.ListNodeC._data) */
  /* insert code here (private data members) */
  graph_ListNode node;
  graph_Data data;
  //int ignore; /* dummy to force non-empty struct; remove if you add data */
  /* DO-NOT-DELETE splicer.end(graph.ListNodeC._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct graph_ListNodeC__data*
graph_ListNodeC__get_data(
  graph_ListNodeC);

extern void
graph_ListNodeC__set_data(
  graph_ListNodeC,
  struct graph_ListNodeC__data*);

extern
void
impl_graph_ListNodeC__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_graph_ListNodeC__ctor(
  /* in */ graph_ListNodeC self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_graph_ListNodeC__ctor2(
  /* in */ graph_ListNodeC self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_graph_ListNodeC__dtor(
  /* in */ graph_ListNodeC self,
  /* out */ sidl_BaseInterface *_ex);

/*
 * User-defined object methods
 */

#ifdef WITH_RMI
extern struct graph_Data__object* impl_graph_ListNodeC_fconnect_graph_Data(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct graph_ListNode__object* 
  impl_graph_ListNodeC_fconnect_graph_ListNode(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_graph_ListNodeC_fconnect_sidl_BaseInterface(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/
extern
void
impl_graph_ListNodeC_setData(
  /* in */ graph_ListNodeC self,
  /* in */ graph_Data d,
  /* out */ sidl_BaseInterface *_ex);

extern
graph_Data
impl_graph_ListNodeC_getData(
  /* in */ graph_ListNodeC self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_graph_ListNodeC_setNext(
  /* in */ graph_ListNodeC self,
  /* in */ graph_ListNode n,
  /* out */ sidl_BaseInterface *_ex);

extern
graph_ListNode
impl_graph_ListNodeC_getNext(
  /* in */ graph_ListNodeC self,
  /* out */ sidl_BaseInterface *_ex);

#ifdef WITH_RMI
extern struct graph_Data__object* impl_graph_ListNodeC_fconnect_graph_Data(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct graph_ListNode__object* 
  impl_graph_ListNodeC_fconnect_graph_ListNode(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_graph_ListNodeC_fconnect_sidl_BaseInterface(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/

/* DO-NOT-DELETE splicer.begin(_hmisc) */
/* insert code here (miscellaneous things) */
/* DO-NOT-DELETE splicer.end(_hmisc) */

#ifdef __cplusplus
}
#endif
#endif
