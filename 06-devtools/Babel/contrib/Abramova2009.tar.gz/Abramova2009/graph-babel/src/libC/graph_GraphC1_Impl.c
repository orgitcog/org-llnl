/*
 * File:          graph_GraphC1_Impl.c
 * Symbol:        graph.GraphC1-v1.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for graph.GraphC1
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "graph.GraphC1" (version 1.0)
 * 
 * Flawed Graph Implementation class
 * Edges are inserted only 70% of the time
 */

#include "graph_GraphC1_Impl.h"
#include "sidl_NotImplementedException.h"
#include "sidl_Exception.h"
#ifndef included_sidl_MemAllocException_h
#include "sidl_MemAllocException.h"
#endif

/* DO-NOT-DELETE splicer.begin(graph.GraphC1._includes) */
/* insert code here (includes and arbitrary code) */
#include <time.h>
int randint()
{
  
  int randres = ((rand() % 100) < 70)? 1: 0;
  return randres;
} 
/* DO-NOT-DELETE splicer.end(graph.GraphC1._includes) */

#define SIDL_IOR_MAJOR_VERSION 2
#define SIDL_IOR_MINOR_VERSION 0
static const struct graph_GraphC__epv* superEPV = NULL;

void graph_GraphC1__superEPV(
struct graph_GraphC__epv* parentEPV){
  superEPV = parentEPV;
}
/*
 * Inserts an edge specified by vertices d1 and d2. 
 * Both vertices must have been inserted previously. 
 * The new edge is represented by pointer to d2 
 * in the adjacency list of d1. To enter an edge 
 * into an undirected graph, call this operation 
 * twice, once to insert an edge from d1 to d2, 
 * and again to insert an edge from d2 to d1. 
 * Method returns 0 if the insertion was successful,
 * 1 if the edge already exists and -1 otherwise.
 * this method calls the superclass method only 
 * 70% of the time
 */

static int32_t
super_insEdge(
  /* in */ graph_GraphC1 self,
  /* in */ graph_Data d1,
  /* in */ graph_Data d2,
  /* out */ sidl_BaseInterface *_ex)
{
  return (*superEPV->f_insEdge)((struct graph_GraphC__object*)
    self,
    d1,
    d2,
    _ex);
}

/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_GraphC1__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_GraphC1__load(
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.GraphC1._load) */
    /* insert code here (static class initializer) */
    /* DO-NOT-DELETE splicer.end(graph.GraphC1._load) */
  }
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_GraphC1__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_GraphC1__ctor(
  /* in */ graph_GraphC1 self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.GraphC1._ctor) */
    srand(time(NULL));
    /*
     * // boilerplate constructor
     * struct graph_GraphC1__data *dptr = (struct graph_GraphC1__data*)malloc(sizeof(struct graph_GraphC1__data));
     * if (dptr) {
     *   memset(dptr, 0, sizeof(struct graph_GraphC1__data));
     *   // initialize elements of dptr here
     * graph_GraphC1__set_data(self, dptr);
     * } else {
     *   sidl_MemAllocException ex = sidl_MemAllocException_getSingletonException(_ex);
     *   SIDL_CHECK(*_ex);
     *   sidl_MemAllocException_setNote(ex, "Out of memory.", _ex); SIDL_CHECK(*_ex);
     *   sidl_MemAllocException_add(ex, __FILE__, __LINE__, "graph.GraphC1._ctor", _ex);
     *   SIDL_CHECK(*_ex);
     *   *_ex = (sidl_BaseInterface)ex;
     * }
     * EXIT:;
     */

    /* DO-NOT-DELETE splicer.end(graph.GraphC1._ctor) */
  }
}

/*
 * Special Class constructor called when the user wants to wrap his own private data.
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_GraphC1__ctor2"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_GraphC1__ctor2(
  /* in */ graph_GraphC1 self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.GraphC1._ctor2) */
    /* insert code here (special constructor) */
    /* DO-NOT-DELETE splicer.end(graph.GraphC1._ctor2) */
  }
}
/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_GraphC1__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_GraphC1__dtor(
  /* in */ graph_GraphC1 self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.GraphC1._dtor) */
    /*
     * // boilerplate destructor
     * struct graph_GraphC1__data *dptr = graph_GraphC1__get_data(self);
     * if (dptr) {
     *   // free contained in dtor before next line
     *   free(dptr);
     *   graph_GraphC1__set_data(self, NULL);
     * }
     */

    /* DO-NOT-DELETE splicer.end(graph.GraphC1._dtor) */
  }
}

/*
 * Inserts an edge specified by vertices d1 and d2. 
 * Both vertices must have been inserted previously. 
 * The new edge is represented by pointer to d2 
 * in the adjacency list of d1. To enter an edge 
 * into an undirected graph, call this operation 
 * twice, once to insert an edge from d1 to d2, 
 * and again to insert an edge from d2 to d1. 
 * Method returns 0 if the insertion was successful,
 * 1 if the edge already exists and -1 otherwise.
 * this method calls the superclass method only 
 * 70% of the time
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_GraphC1_insEdge"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_graph_GraphC1_insEdge(
  /* in */ graph_GraphC1 self,
  /* in */ graph_Data d1,
  /* in */ graph_Data d2,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.GraphC1.insEdge) */
    /* insert code here (insEdge) */
    //srand(time(NULL));
    int result = randint();
    //printf("Result = %d\n", result);
    if (result == 1){
      //printf("Super InsEdge method got called \n");
      sidl_BaseInterface throwawayException;
      int super_result = super_insEdge(self, d1, d2, &throwawayException);
      return super_result;
    }
    else return -1;
    
    /* DO-NOT-DELETE splicer.end(graph.GraphC1.insEdge) */
  }
}
/* Babel internal methods, Users should not edit below this line. */

/* DO-NOT-DELETE splicer.begin(_misc) */
/* insert code here (miscellaneous code) */
/* DO-NOT-DELETE splicer.end(_misc) */

