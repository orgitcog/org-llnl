/*
 * File:          graph_ListNodeC_Impl.c
 * Symbol:        graph.ListNodeC-v1.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for graph.ListNodeC
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "graph.ListNodeC" (version 1.0)
 * 
 * This is a ListNode class used by Set and List Implementation
 * It contains a pointer to Data and a pointer to the next Node
 * forming a chained list data structure.
 * Note: For graph vertex (node) use Data class.
 */

#include "graph_ListNodeC_Impl.h"
#include "sidl_NotImplementedException.h"
#include "sidl_Exception.h"
#ifndef included_sidl_MemAllocException_h
#include "sidl_MemAllocException.h"
#endif

/* DO-NOT-DELETE splicer.begin(graph.ListNodeC._includes) */
/* insert code here (includes and arbitrary code) */
/* DO-NOT-DELETE splicer.end(graph.ListNodeC._includes) */

#define SIDL_IOR_MAJOR_VERSION 2
#define SIDL_IOR_MINOR_VERSION 0
/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_ListNodeC__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_ListNodeC__load(
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.ListNodeC._load) */
    /* insert code here (static class initializer) */
    /* DO-NOT-DELETE splicer.end(graph.ListNodeC._load) */
  }
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_ListNodeC__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_ListNodeC__ctor(
  /* in */ graph_ListNodeC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.ListNodeC._ctor) */
    
      // boilerplate constructor
      struct graph_ListNodeC__data *dptr = (struct graph_ListNodeC__data*)malloc(sizeof(struct graph_ListNodeC__data));
      if (dptr) {
        memset(dptr, 0, sizeof(struct graph_ListNodeC__data));
        // initialize elements of dptr here
	dptr->data = NULL;
	dptr->node = NULL;
      graph_ListNodeC__set_data(self, dptr);
      } else {
        sidl_MemAllocException ex = sidl_MemAllocException_getSingletonException(_ex);
        SIDL_CHECK(*_ex);
        sidl_MemAllocException_setNote(ex, "Out of memory.", _ex); SIDL_CHECK(*_ex);
        sidl_MemAllocException_add(ex, __FILE__, __LINE__, "graph.ListNodeC._ctor", _ex);
        SIDL_CHECK(*_ex);
        *_ex = (sidl_BaseInterface)ex;
      }
      EXIT:;
     

    /* DO-NOT-DELETE splicer.end(graph.ListNodeC._ctor) */
  }
}

/*
 * Special Class constructor called when the user wants to wrap his own private data.
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_ListNodeC__ctor2"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_ListNodeC__ctor2(
  /* in */ graph_ListNodeC self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.ListNodeC._ctor2) */
    /* insert code here (special constructor) */
    /* DO-NOT-DELETE splicer.end(graph.ListNodeC._ctor2) */
  }
}
/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_ListNodeC__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_ListNodeC__dtor(
  /* in */ graph_ListNodeC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.ListNodeC._dtor) */
    
      // boilerplate destructor
      struct graph_ListNodeC__data *dptr = graph_ListNodeC__get_data(self);
      if (dptr) {
        // free contained in dtor before next line
	if (dptr->data)
	  graph_Data_deleteRef(dptr->data, _ex);
        if (dptr-> node)
	  graph_ListNode_deleteRef(dptr->node, _ex);
	dptr->data = NULL;
        dptr-> node = NULL;
        free(dptr);
        graph_ListNodeC__set_data(self, NULL);
      }
     

    /* DO-NOT-DELETE splicer.end(graph.ListNodeC._dtor) */
  }
}

/*
 * Sets the data pointer to point to data object
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_ListNodeC_setData"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_ListNodeC_setData(
  /* in */ graph_ListNodeC self,
  /* in */ graph_Data d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.ListNodeC.setData) */
    struct graph_ListNodeC__data *dptr = graph_ListNodeC__get_data(self);
    dptr->data = d;
    graph_Data_addRef(d, _ex);
    SIDL_REPORT(*_ex);
    return;
  EXIT:
    return;
    /* DO-NOT-DELETE splicer.end(graph.ListNodeC.setData) */
  }
}

/*
 * Returns Data object pointed by the Data pointer
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_ListNodeC_getData"

#ifdef __cplusplus
extern "C"
#endif
graph_Data
impl_graph_ListNodeC_getData(
  /* in */ graph_ListNodeC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.ListNodeC.getData) */
    struct graph_ListNodeC__data *dptr = graph_ListNodeC__get_data(self);
    graph_Data grData = dptr->data;
    if (grData)
      graph_Data_addRef(grData,_ex);
    SIDL_REPORT(*_ex);
    return (grData);
  EXIT:
    return NULL;
    /* DO-NOT-DELETE splicer.end(graph.ListNodeC.getData) */
  }
}

/*
 * Sets the Node pointer to point to the next Node object
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_ListNodeC_setNext"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_ListNodeC_setNext(
  /* in */ graph_ListNodeC self,
  /* in */ graph_ListNode n,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.ListNodeC.setNext) */
    struct graph_ListNodeC__data *dptr = graph_ListNodeC__get_data(self);
    dptr->node = n;
    if (n) {
    	graph_ListNode_addRef(n, _ex);  SIDL_REPORT(*_ex);
    }
    SIDL_REPORT(*_ex);

     EXIT:;
    /* DO-NOT-DELETE splicer.end(graph.ListNodeC.setNext) */
  }
}

/*
 * Returns the Node pointed to by the Node pointer
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_ListNodeC_getNext"

#ifdef __cplusplus
extern "C"
#endif
graph_ListNode
impl_graph_ListNodeC_getNext(
  /* in */ graph_ListNodeC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.ListNodeC.getNext) */
    struct graph_ListNodeC__data *dptr = graph_ListNodeC__get_data(self);
    graph_ListNode grNode = dptr->node;
    if (grNode)
      graph_ListNode_addRef(grNode,_ex);
    SIDL_REPORT(*_ex);
    return (grNode);
  EXIT:
    return NULL;
    /* DO-NOT-DELETE splicer.end(graph.ListNodeC.getNext) */
  }
}
/* Babel internal methods, Users should not edit below this line. */

/* DO-NOT-DELETE splicer.begin(_misc) */
/* insert code here (miscellaneous code) */
/* DO-NOT-DELETE splicer.end(_misc) */

