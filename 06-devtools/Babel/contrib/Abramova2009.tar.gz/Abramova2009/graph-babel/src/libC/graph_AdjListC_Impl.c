/*
 * File:          graph_AdjListC_Impl.c
 * Symbol:        graph.AdjListC-v1.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for graph.AdjListC
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "graph.AdjListC" (version 1.0)
 */

#include "graph_AdjListC_Impl.h"
#include "sidl_NotImplementedException.h"
#include "sidl_Exception.h"
#ifndef included_sidl_MemAllocException_h
#include "sidl_MemAllocException.h"
#endif

/* DO-NOT-DELETE splicer.begin(graph.AdjListC._includes) */
/* insert code here (includes and arbitrary code) */
/* DO-NOT-DELETE splicer.end(graph.AdjListC._includes) */

#define SIDL_IOR_MAJOR_VERSION 2
#define SIDL_IOR_MINOR_VERSION 0
/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_AdjListC__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_AdjListC__load(
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.AdjListC._load) */
    /* insert code here (static class initializer) */
    /* DO-NOT-DELETE splicer.end(graph.AdjListC._load) */
  }
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_AdjListC__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_AdjListC__ctor(
  /* in */ graph_AdjListC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.AdjListC._ctor) */
    
      // boilerplate constructor
      struct graph_AdjListC__data *dptr = (struct graph_AdjListC__data*)malloc(sizeof(struct graph_AdjListC__data));
      if (dptr) {
        memset(dptr, 0, sizeof(struct graph_AdjListC__data));
        // initialize elements of dptr here
	graph_SetC adjacentC = graph_SetC__create(_ex);
	dptr->adjacent = graph_SetOps__cast(adjacentC, _ex);
	graph_SetC_deleteRef(adjacentC, _ex);
	dptr->vertex = NULL;
      graph_AdjListC__set_data(self, dptr);
      } else {
        sidl_MemAllocException ex = sidl_MemAllocException_getSingletonException(_ex);
        SIDL_CHECK(*_ex);
       sidl_MemAllocException_setNote(ex, "Out of memory.", _ex); SIDL_CHECK(*_ex);
        sidl_MemAllocException_add(ex, __FILE__, __LINE__, "graph.AdjListC._ctor", _ex);
        SIDL_CHECK(*_ex);
        *_ex = (sidl_BaseInterface)ex;
      }
      EXIT:;
     

    /* DO-NOT-DELETE splicer.end(graph.AdjListC._ctor) */
  }
}

/*
 * Special Class constructor called when the user wants to wrap his own private data.
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_AdjListC__ctor2"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_AdjListC__ctor2(
  /* in */ graph_AdjListC self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.AdjListC._ctor2) */
    /* insert code here (special constructor) */
    /* DO-NOT-DELETE splicer.end(graph.AdjListC._ctor2) */
  }
}
/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_AdjListC__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_AdjListC__dtor(
  /* in */ graph_AdjListC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.AdjListC._dtor) */
    
      // boilerplate destructor
      struct graph_AdjListC__data *dptr = graph_AdjListC__get_data(self);
      if (dptr) {
        // free contained in dtor before next line
	if (dptr->adjacent) graph_SetOps_deleteRef(dptr->adjacent, _ex);
	if (dptr->vertex) graph_Data_deleteRef(dptr->vertex, _ex);
        free(dptr);
        graph_AdjListC__set_data(self, NULL);
      }
     

    /* DO-NOT-DELETE splicer.end(graph.AdjListC._dtor) */
  }
}

/*
 * Returns the Data object stored as a vertex
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_AdjListC_getVertex"

#ifdef __cplusplus
extern "C"
#endif
graph_Data
impl_graph_AdjListC_getVertex(
  /* in */ graph_AdjListC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.AdjListC.getVertex) */
    struct graph_AdjListC__data *dptr = graph_AdjListC__get_data(self);
    if (dptr->vertex)    graph_Data_addRef(dptr->vertex, _ex);
    return dptr->vertex;
    /* DO-NOT-DELETE splicer.end(graph.AdjListC.getVertex) */
  }
}

/*
 * Displays contents of the data if possible
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_AdjListC_display"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_AdjListC_display(
  /* in */ graph_AdjListC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.AdjListC.display) */
    struct graph_AdjListC__data *dptr = graph_AdjListC__get_data(self);
    graph_Data_display(dptr->vertex, _ex);
    /* DO-NOT-DELETE splicer.end(graph.AdjListC.display) */
  }
}

/*
 * Computes and returns a unique integer id - 
 * simply returns value of the data ptr
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_AdjListC_hashCode"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_graph_AdjListC_hashCode(
  /* in */ graph_AdjListC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.AdjListC.hashCode) */
    struct graph_AdjListC__data *dptr = graph_AdjListC__get_data(self);
    return dptr;
    /* DO-NOT-DELETE splicer.end(graph.AdjListC.hashCode) */
  }
}

/*
 * Compares the element with data parameter element, 
 * returns 1 if it's greater than data,
 * 0 if they are equal and -1 if it's less than data
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_AdjListC_compare"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_graph_AdjListC_compare(
  /* in */ graph_AdjListC self,
  /* in */ graph_Data data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.AdjListC.compare) */
    struct graph_AdjListC__data *dptr = graph_AdjListC__get_data(self);
    int result = graph_Data_compare(dptr->vertex, data, _ex); SIDL_REPORT(*_ex);
    return result;
  EXIT: 
    return result;
    /* DO-NOT-DELETE splicer.end(graph.AdjListC.compare) */
  }
}

/*
 * Takes in another Data object and casts it to a 
 * corresponding type + sets internal data members
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_AdjListC_setData"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_AdjListC_setData(
  /* in */ graph_AdjListC self,
  /* in */ graph_Data data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.AdjListC.setData) */
    struct graph_AdjListC__data *dptr = graph_AdjListC__get_data(self);
    dptr->vertex = data;
    graph_Data_addRef(data, _ex); SIDL_REPORT(*_ex);
    return;
  EXIT:
    ;  
    /* DO-NOT-DELETE splicer.end(graph.AdjListC.setData) */
  }
}

/*
 *  
 * inserts Data element in the set. 
 * returns 0 if the insertion is successful,
 * 1 if the member  is already in the set. -1 otherwise
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_AdjListC_insert"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_graph_AdjListC_insert(
  /* in */ graph_AdjListC self,
  /* in */ graph_Data d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.AdjListC.insert) */
    struct graph_AdjListC__data *dptr = graph_AdjListC__get_data(self);
    int result = graph_SetOps_insert(dptr->adjacent, d, _ex); SIDL_REPORT(*_ex);
    return result;
  EXIT:
    return result;
    /* DO-NOT-DELETE splicer.end(graph.AdjListC.insert) */
  }
}

/*
 * removes Data element from the set. 
 * returns 0 if the removal is successful, -1 otherwise
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_AdjListC_remove"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_graph_AdjListC_remove(
  /* in */ graph_AdjListC self,
  /* in */ graph_Data d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.AdjListC.remove) */
    struct graph_AdjListC__data *dptr = graph_AdjListC__get_data(self);
    int result = graph_SetOps_remove(dptr->adjacent, d, _ex); SIDL_REPORT(*_ex);
    return result;
  EXIT:
    return result;
    /* DO-NOT-DELETE splicer.end(graph.AdjListC.remove) */
  }
}

/*
 * returns true if the element exists in the set, false otherwise
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_AdjListC_isMember"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_graph_AdjListC_isMember(
  /* in */ graph_AdjListC self,
  /* in */ graph_Data d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.AdjListC.isMember) */
    struct graph_AdjListC__data * dptr = graph_AdjListC__get_data(self);
    int result = graph_SetOps_isMember(dptr->adjacent, d, _ex); SIDL_REPORT(*_ex);
    return result;
  EXIT:
    return result;
    /* DO-NOT-DELETE splicer.end(graph.AdjListC.isMember) */
  }
}

/*
 * Clears the set, decrements references to all elements in the set,
 * sets the set size to 0
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_AdjListC_clearSet"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_AdjListC_clearSet(
  /* in */ graph_AdjListC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.AdjListC.clearSet) */
    struct graph_AdjListC__data *dptr = graph_AdjListC__get_data(self);
    graph_SetOps_clearSet(dptr->adjacent, _ex); SIDL_REPORT(*_ex);
    return;
  EXIT:
    ;
    /* DO-NOT-DELETE splicer.end(graph.AdjListC.clearSet) */
  }
}

/*
 * Tests whether the set is empty. Returns true if empty
 * false otherwise
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_AdjListC_isEmpty"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_graph_AdjListC_isEmpty(
  /* in */ graph_AdjListC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.AdjListC.isEmpty) */
    struct graph_AdjListC__data *dptr = graph_AdjListC__get_data(self);
    int result = graph_SetOps_isEmpty(dptr->adjacent, _ex); SIDL_REPORT(*_ex);
    return result;
  EXIT:
    return result; 
    /* DO-NOT-DELETE splicer.end(graph.AdjListC.isEmpty) */
  }
}

/*
 * Returns the size of the set
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_AdjListC_getSize"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_graph_AdjListC_getSize(
  /* in */ graph_AdjListC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.AdjListC.getSize) */
     struct graph_AdjListC__data *dptr = graph_AdjListC__get_data(self);
     int size = graph_SetOps_getSize(dptr->adjacent, _ex);
     return size; 
    /* DO-NOT-DELETE splicer.end(graph.AdjListC.getSize) */
  }
}

/*
 *  
 * Returns the elements in the form of a list.
 * Actual elements are returned.
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_AdjListC_getList"

#ifdef __cplusplus
extern "C"
#endif
graph_ListOps
impl_graph_AdjListC_getList(
  /* in */ graph_AdjListC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.AdjListC.getList) */
     struct graph_AdjListC__data *dptr = graph_AdjListC__get_data(self);
     return graph_SetOps_getList(dptr->adjacent, _ex);
    /* DO-NOT-DELETE splicer.end(graph.AdjListC.getList) */
  }
}
/* Babel internal methods, Users should not edit below this line. */

/* DO-NOT-DELETE splicer.begin(_misc) */
/* insert code here (miscellaneous code) */
/* DO-NOT-DELETE splicer.end(_misc) */

