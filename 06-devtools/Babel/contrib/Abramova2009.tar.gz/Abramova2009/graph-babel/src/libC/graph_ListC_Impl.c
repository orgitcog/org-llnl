/*
 * File:          graph_ListC_Impl.c
 * Symbol:        graph.ListC-v1.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for graph.ListC
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "graph.ListC" (version 1.0)
 * 
 * This is a class implementing a linked list
 */

#include "graph_ListC_Impl.h"
#include "sidl_NotImplementedException.h"
#include "sidl_Exception.h"
#ifndef included_sidl_MemAllocException_h
#include "sidl_MemAllocException.h"
#endif

/* DO-NOT-DELETE splicer.begin(graph.ListC._includes) */
/* insert code here (includes and arbitrary code) */
/* DO-NOT-DELETE splicer.end(graph.ListC._includes) */

#define SIDL_IOR_MAJOR_VERSION 2
#define SIDL_IOR_MINOR_VERSION 0
/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_ListC__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_ListC__load(
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.ListC._load) */
    /* insert code here (static class initializer) */
    /* DO-NOT-DELETE splicer.end(graph.ListC._load) */
  }
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_ListC__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_ListC__ctor(
  /* in */ graph_ListC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.ListC._ctor) */
    
      // boilerplate constructor
      struct graph_ListC__data *dptr = (struct graph_ListC__data*)malloc(sizeof(struct graph_ListC__data));
      if (dptr) {
        memset(dptr, 0, sizeof(struct graph_ListC__data));
        // initialize elements of dptr here
	dptr->size = 0;
	dptr-> head = NULL;
	dptr->tail = NULL;
     graph_ListC__set_data(self, dptr);
      } else {
        sidl_MemAllocException ex = sidl_MemAllocException_getSingletonException(_ex);
        SIDL_CHECK(*_ex);
        sidl_MemAllocException_setNote(ex, "Out of memory.", _ex); SIDL_CHECK(*_ex);
        sidl_MemAllocException_add(ex, __FILE__, __LINE__, "graph.ListC._ctor", _ex);
        SIDL_CHECK(*_ex);
        *_ex = (sidl_BaseInterface)ex;
      }
      EXIT:;
     

    /* DO-NOT-DELETE splicer.end(graph.ListC._ctor) */
  }
}

/*
 * Special Class constructor called when the user wants to wrap his own private data.
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_ListC__ctor2"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_ListC__ctor2(
  /* in */ graph_ListC self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.ListC._ctor2) */
    /* insert code here (special constructor) */
    /* DO-NOT-DELETE splicer.end(graph.ListC._ctor2) */
  }
}
/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_ListC__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_ListC__dtor(
  /* in */ graph_ListC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.ListC._dtor) */
    
      // boilerplate destructor
      struct graph_ListC__data *dptr = graph_ListC__get_data(self);
      graph_Data temp;
      if (dptr) {
        // free contained in dtor before next line
	while (dptr->size > 0) {
	  graph_ListC_removeNext(self, NULL, &temp, _ex);
	  graph_Data_deleteRef(temp, _ex); SIDL_REPORT(*_ex);
	}
        free(dptr);
        graph_ListC__set_data(self, NULL);
      }
  EXIT: ;

    /* DO-NOT-DELETE splicer.end(graph.ListC._dtor) */
  }
}

/*
 * Inserts element of type Data after the specified Node
 * returns 0 if inserting is successful, -1 otherwise
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_ListC_insertNext"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_graph_ListC_insertNext(
  /* in */ graph_ListC self,
  /* in */ graph_ListNode n,
  /* in */ graph_Data d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.ListC.insertNext) */
    graph_ListNodeC new_nodeC;
    new_nodeC = graph_ListNodeC__create(_ex); SIDL_REPORT(*_ex);
    graph_ListNode new_node = graph_ListNode__cast(new_nodeC, _ex);
    graph_ListNodeC_deleteRef(new_nodeC, _ex);
    graph_ListNode_setData(new_node, d, _ex); SIDL_REPORT(*_ex);
    struct graph_ListC__data *dptr = graph_ListC__get_data(self);
    if (n == NULL){
      //handle insertion at the head of the list
      if (dptr->size == 0)
	    dptr->tail = new_node;

      graph_ListNode_setNext(new_node,dptr->head, _ex); SIDL_REPORT(*_ex);
      // graph_Node_addRef(new_node, _ex); SIDL_REPORT(*_ex);
      if (dptr->head) graph_ListNode_deleteRef(dptr->head, _ex); SIDL_REPORT(*_ex);
      dptr->head = new_node;
    }
    else {
      graph_ListNode nextel = graph_ListNode_getNext(n,_ex); SIDL_REPORT(*_ex);
      if (nextel == NULL)
	dptr->tail = new_node;
      graph_ListNode_setNext(new_node, nextel, _ex); SIDL_REPORT(*_ex);
      graph_ListNode_setNext(n, new_node, _ex); SIDL_REPORT(*_ex);
      if (new_node) graph_ListNode_deleteRef(new_node, _ex); SIDL_REPORT(*_ex);
      if (nextel) graph_ListNode_deleteRef(nextel, _ex); SIDL_REPORT(*_ex);
      if (nextel) graph_ListNode_deleteRef(nextel, _ex); SIDL_REPORT(*_ex);
    }
    dptr->size++;
    return 0;

  EXIT:
    return -1;
    /* DO-NOT-DELETE splicer.end(graph.ListC.insertNext) */
  }
}

/*
 * Removes element after the specified Node element
 * returns 0 if the removal was successful, -1 otherwise
 * the Data object that is removed is returned in d
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_ListC_removeNext"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_graph_ListC_removeNext(
  /* in */ graph_ListC self,
  /* in */ graph_ListNode n,
  /* out */ graph_Data* d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.ListC.removeNext) */
    graph_ListNode  old_element;
    graph_Data temp;
    struct graph_ListC__data *dptr = graph_ListC__get_data(self);
    if (dptr->size == 0)
      return -1;
    if (n == NULL){
      //handle removal from the head of the list
      temp = graph_ListNode_getData(dptr->head, _ex); SIDL_REPORT(*_ex);
      old_element = dptr->head;
      dptr->head =  graph_ListNode_getNext(dptr->head, _ex); SIDL_REPORT(*_ex);
      if (old_element)  graph_ListNode_deleteRef(old_element, _ex);
      //graph_Node_deleteRef(old_element, _ex);

      if (dptr->size == 1)
	dptr->tail = NULL;
    }
    else {
      //handle removal from somewhere other than the head

      graph_ListNode nextel = graph_ListNode_getNext(n,_ex);
      if (nextel == NULL){
	return -1;
      }
      temp = graph_ListNode_getData(nextel, _ex); SIDL_REPORT(*_ex);
      old_element = nextel;
      graph_ListNode next_nextel = graph_ListNode_getNext(nextel, _ex); SIDL_REPORT(*_ex);
      graph_ListNode_setNext(n, next_nextel, _ex); SIDL_REPORT(*_ex);

      if (next_nextel == NULL){
	dptr->tail = n;
        
      }
      graph_ListNode_deleteRef(nextel,_ex); SIDL_REPORT(*_ex);
      graph_ListNode_deleteRef(nextel,_ex); SIDL_REPORT(*_ex);
      if (next_nextel)
        graph_ListNode_deleteRef(next_nextel, _ex); SIDL_REPORT(*_ex);
    }
    dptr->size--;
    *d = temp;
    return 0;

  EXIT: ;
    /* DO-NOT-DELETE splicer.end(graph.ListC.removeNext) */
  }
}

/*
 * Returns the number of elements currently present in a list
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_ListC_getSize"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_graph_ListC_getSize(
  /* in */ graph_ListC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.ListC.getSize) */
    struct graph_ListC__data *dptr = graph_ListC__get_data(self);
    return dptr->size;
    /* DO-NOT-DELETE splicer.end(graph.ListC.getSize) */
  }
}

/*
 * Returns Data stored in the element at indexed position
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_ListC_getDataAt"

#ifdef __cplusplus
extern "C"
#endif
graph_Data
impl_graph_ListC_getDataAt(
  /* in */ graph_ListC self,
  /* in */ int32_t index,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.ListC.getDataAt) */
    struct graph_ListC__data *dptr = graph_ListC__get_data(self);
    graph_Data result;
    int i = 0;
    graph_ListNode elem = graph_ListC_getHead(self, _ex);
    graph_ListNode next;
    while(elem && i<= index){
      if (i == index && elem){        
	result = graph_ListNode_getData(elem, _ex); SIDL_REPORT(*_ex);
	graph_ListNode_deleteRef(elem, _ex);
        return result;
      }
     
      next = graph_ListNode_getNext(elem, _ex); SIDL_REPORT(*_ex);
      graph_ListNode_deleteRef(elem, _ex); SIDL_REPORT(*_ex);
      elem = next;
      i++;
    }
    return result;
  EXIT: 
    
    return NULL;
    /* DO-NOT-DELETE splicer.end(graph.ListC.getDataAt) */
  }
}

/*
 * Returns the pointer to the head Node
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_ListC_getHead"

#ifdef __cplusplus
extern "C"
#endif
graph_ListNode
impl_graph_ListC_getHead(
  /* in */ graph_ListC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.ListC.getHead) */
    struct graph_ListC__data *dptr = graph_ListC__get_data(self);
    if (dptr->head)
       graph_ListNode_addRef(dptr->head, _ex); SIDL_REPORT(*_ex);
    return dptr->head;
  EXIT:
    return NULL;
    /* DO-NOT-DELETE splicer.end(graph.ListC.getHead) */
  }
}

/*
 * Returns the pointer to the tail Node
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_ListC_getTail"

#ifdef __cplusplus
extern "C"
#endif
graph_ListNode
impl_graph_ListC_getTail(
  /* in */ graph_ListC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.ListC.getTail) */
    struct graph_ListC__data *dptr = graph_ListC__get_data(self);
    if (dptr->tail)
       graph_ListNode_addRef(dptr->tail, _ex); SIDL_REPORT(*_ex);
    return dptr->tail;
  EXIT: return NULL;
    /* DO-NOT-DELETE splicer.end(graph.ListC.getTail) */
  }
}
/* Babel internal methods, Users should not edit below this line. */

/* DO-NOT-DELETE splicer.begin(_misc) */
/* insert code here (miscellaneous code) */
/* DO-NOT-DELETE splicer.end(_misc) */

