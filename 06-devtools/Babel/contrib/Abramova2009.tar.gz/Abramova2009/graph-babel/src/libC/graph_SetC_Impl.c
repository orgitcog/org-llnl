/*
 * File:          graph_SetC_Impl.c
 * Symbol:        graph.SetC-v1.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for graph.SetC
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "graph.SetC" (version 1.0)
 * 
 * Basic class implementing a simple set
 * Elements are stored internally in the form of a linked list
 */

#include "graph_SetC_Impl.h"
#include "sidl_NotImplementedException.h"
#include "sidl_Exception.h"
#ifndef included_sidl_MemAllocException_h
#include "sidl_MemAllocException.h"
#endif

/* DO-NOT-DELETE splicer.begin(graph.SetC._includes) */
/* insert code here (includes and arbitrary code) */
/* DO-NOT-DELETE splicer.end(graph.SetC._includes) */

#define SIDL_IOR_MAJOR_VERSION 2
#define SIDL_IOR_MINOR_VERSION 0
/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_SetC__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_SetC__load(
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.SetC._load) */
    /* insert code here (static class initializer) */
    /* DO-NOT-DELETE splicer.end(graph.SetC._load) */
  }
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_SetC__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_SetC__ctor(
  /* in */ graph_SetC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.SetC._ctor) */
    
      // boilerplate constructor
      struct graph_SetC__data *dptr = (struct graph_SetC__data*)malloc(sizeof(struct graph_SetC__data));
      if (dptr) {
        memset(dptr, 0, sizeof(struct graph_SetC__data));
        // initialize elements of dptr here
	graph_ListC listC = graph_ListC__create(_ex);
	dptr->list = graph_ListOps__cast(listC, _ex);
	graph_ListC_deleteRef(listC, _ex);
      graph_SetC__set_data(self, dptr);
      } else {
        sidl_MemAllocException ex = sidl_MemAllocException_getSingletonException(_ex);
        SIDL_CHECK(*_ex);
        sidl_MemAllocException_setNote(ex, "Out of memory.", _ex); SIDL_CHECK(*_ex);
        sidl_MemAllocException_add(ex, __FILE__, __LINE__, "graph.SetC._ctor", _ex);
        SIDL_CHECK(*_ex);
        *_ex = (sidl_BaseInterface)ex;
      }
      EXIT:;
     

    /* DO-NOT-DELETE splicer.end(graph.SetC._ctor) */
  }
}

/*
 * Special Class constructor called when the user wants to wrap his own private data.
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_SetC__ctor2"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_SetC__ctor2(
  /* in */ graph_SetC self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.SetC._ctor2) */
    /* insert code here (special constructor) */
    /* DO-NOT-DELETE splicer.end(graph.SetC._ctor2) */
  }
}
/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_SetC__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_SetC__dtor(
  /* in */ graph_SetC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.SetC._dtor) */
    
      // boilerplate destructor
      struct graph_SetC__data *dptr = graph_SetC__get_data(self);
      if (dptr) {
        // free contained in dtor before next line
	graph_ListOps_deleteRef(dptr->list, _ex);
	dptr->list = NULL;
        free(dptr);
        graph_SetC__set_data(self, NULL);
      }
     

    /* DO-NOT-DELETE splicer.end(graph.SetC._dtor) */
  }
}

/*
 *  
 * inserts Data element in the set. 
 * returns 0 if the insertion is successful,
 * 1 if the member  is already in the set. -1 otherwise
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_SetC_insert"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_graph_SetC_insert(
  /* in */ graph_SetC self,
  /* in */ graph_Data d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.SetC.insert) */
    struct graph_SetC__data * dptr = graph_SetC__get_data(self);
    if (graph_SetC_isMember(self,d, _ex)) {
      //check to see if it's member of the set
      SIDL_REPORT(*_ex);
      //no insertion, return 1
      return 1;
    }
    graph_ListNode tail = graph_ListOps_getTail(dptr->list, _ex); SIDL_REPORT(*_ex);
    graph_ListOps_insertNext(dptr->list, tail, d, _ex); SIDL_REPORT(*_ex);
    if (tail) graph_ListNode_deleteRef(tail, _ex); SIDL_REPORT(*_ex);
    //successful insertion
    return 0;
  EXIT: return -1; //insertion failed
    /* DO-NOT-DELETE splicer.end(graph.SetC.insert) */
  }
}

/*
 * removes Data element from the set. 
 * returns 0 if the removal is successful, -1 otherwise
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_SetC_remove"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_graph_SetC_remove(
  /* in */ graph_SetC self,
  /* in */ graph_Data d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.SetC.remove) */
    struct graph_SetC__data * dptr = graph_SetC__get_data(self);
    graph_ListNode elem, next, prev = NULL;
    graph_Data elem_data;
    elem = graph_ListOps_getHead(dptr->list,_ex);SIDL_REPORT(*_ex);
    while (elem){
      elem_data = graph_ListNode_getData(elem, _ex); SIDL_REPORT(*_ex);
      if (!graph_Data_compare(elem_data, d, _ex)){
        break;
      }
      graph_Data_deleteRef(elem_data, _ex); SIDL_REPORT(*_ex);
      next = graph_ListNode_getNext(elem, _ex); SIDL_REPORT(*_ex);
      if (prev) graph_ListNode_deleteRef(prev, _ex); SIDL_REPORT(*_ex);
      prev = elem;
     
      elem = next;
    }
    if (! elem){ //element not found
      if (prev) graph_ListNode_deleteRef(prev, _ex); SIDL_REPORT(*_ex);
      return -1; 
    }
    graph_Data_deleteRef(elem_data, _ex); SIDL_REPORT(*_ex);
    graph_ListOps_removeNext(dptr->list, prev, &elem_data, _ex); SIDL_REPORT(*_ex);
    graph_Data_deleteRef(elem_data, _ex); SIDL_REPORT(*_ex); 
    graph_ListNode_deleteRef(elem, _ex); SIDL_REPORT(*_ex);

    if (prev) graph_ListNode_deleteRef(prev, _ex); SIDL_REPORT(*_ex);
    // if (prev) graph_ListNode_deleteRef(prev, _ex); SIDL_REPORT(*_ex);
    return 0;
  EXIT: return -1;
    /* DO-NOT-DELETE splicer.end(graph.SetC.remove) */
  }
}

/*
 * returns true if the element exists in the set, false otherwise
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_SetC_isMember"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_graph_SetC_isMember(
  /* in */ graph_SetC self,
  /* in */ graph_Data d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.SetC.isMember) */
    struct graph_SetC__data * dptr = graph_SetC__get_data(self);
    graph_ListNode elem, next;
    graph_Data elem_data;
    elem = graph_ListOps_getHead(dptr->list,_ex);SIDL_REPORT(*_ex);
    while (elem){
      elem_data = graph_ListNode_getData(elem, _ex); SIDL_REPORT(*_ex);
      int result = graph_Data_compare(elem_data,d,_ex);
      if (result == 0){
        graph_Data_deleteRef(elem_data, _ex); SIDL_REPORT(*_ex);
        graph_ListNode_deleteRef(elem, _ex); SIDL_REPORT(*_ex);
        return 1;
      }
      graph_Data_deleteRef(elem_data, _ex); SIDL_REPORT(*_ex);
      next = graph_ListNode_getNext(elem, _ex); SIDL_REPORT(*_ex);
      graph_ListNode_deleteRef(elem, _ex); SIDL_REPORT(*_ex);
      elem = next;
    }
    return 0;
  EXIT: return 0;
    /* DO-NOT-DELETE splicer.end(graph.SetC.isMember) */
  }
}

/*
 * Clears the set, decrements references to all elements in the set,
 * sets the set size to 0
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_SetC_clearSet"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_SetC_clearSet(
  /* in */ graph_SetC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.SetC.clearSet) */
    struct graph_SetC__data * dptr = graph_SetC__get_data(self);
    graph_Data temp;
    int size; 
    while (size = graph_ListOps_getSize(dptr->list, _ex) > 0){
      graph_ListOps_removeNext(dptr->list, NULL, &temp, _ex); SIDL_REPORT(*_ex);
      graph_Data_deleteRef(temp, _ex); SIDL_REPORT(*_ex);
    }
  EXIT: ;
    /* DO-NOT-DELETE splicer.end(graph.SetC.clearSet) */
  }
}

/*
 * Tests whether the set is empty. Returns true if empty
 * false otherwise
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_SetC_isEmpty"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_graph_SetC_isEmpty(
  /* in */ graph_SetC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.SetC.isEmpty) */
    struct graph_SetC__data * dptr = graph_SetC__get_data(self);
    int size = graph_ListOps_getSize(dptr->list, _ex); SIDL_REPORT(*_ex);
    if (size==0) return 1;
    else return 0; 
  EXIT: return 0;
    /* DO-NOT-DELETE splicer.end(graph.SetC.isEmpty) */
  }
}

/*
 * Returns the size of the set
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_SetC_getSize"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_graph_SetC_getSize(
  /* in */ graph_SetC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.SetC.getSize) */
    struct graph_SetC__data * dptr = graph_SetC__get_data(self);
    int size = graph_ListOps_getSize(dptr->list, _ex); SIDL_REPORT(*_ex);
    return size;
  EXIT: return NULL;
    /* DO-NOT-DELETE splicer.end(graph.SetC.getSize) */
  }
}

/*
 *  
 * Returns the elements in the form of a list.
 * Actual elements are returned.
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_SetC_getList"

#ifdef __cplusplus
extern "C"
#endif
graph_ListOps
impl_graph_SetC_getList(
  /* in */ graph_SetC self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.SetC.getList) */
     struct graph_SetC__data * dptr = graph_SetC__get_data(self);
     if (dptr->list) graph_ListOps_addRef(dptr->list, _ex);
     return (dptr->list);
    /* DO-NOT-DELETE splicer.end(graph.SetC.getList) */
  }
}
/* Babel internal methods, Users should not edit below this line. */

/* DO-NOT-DELETE splicer.begin(_misc) */
/* insert code here (miscellaneous code) */
/* DO-NOT-DELETE splicer.end(_misc) */

