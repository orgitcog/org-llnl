/*
 * File:          graph_SetC_Impl.h
 * Symbol:        graph.SetC-v1.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for graph.SetC
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#ifndef included_graph_SetC_Impl_h
#define included_graph_SetC_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_graph_Data_h
#include "graph_Data.h"
#endif
#ifndef included_graph_ListOps_h
#include "graph_ListOps.h"
#endif
#ifndef included_graph_SetC_h
#include "graph_SetC.h"
#endif
#ifndef included_graph_SetOps_h
#include "graph_SetOps.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_PostViolation_h
#include "sidl_PostViolation.h"
#endif
#ifndef included_sidl_PreViolation_h
#include "sidl_PreViolation.h"
#endif
#ifndef included_sidl_RuntimeException_h
#include "sidl_RuntimeException.h"
#endif
/* DO-NOT-DELETE splicer.begin(graph.SetC._hincludes) */
/* insert code here (include files) */
#ifndef included_graph_ListC_h
#include "graph_ListC.h"
#endif
/* DO-NOT-DELETE splicer.end(graph.SetC._hincludes) */

/*
 * Private data for class graph.SetC
 */

struct graph_SetC__data {
  /* DO-NOT-DELETE splicer.begin(graph.SetC._data) */
  /* insert code here (private data members) */
  graph_ListOps list;
  /* DO-NOT-DELETE splicer.end(graph.SetC._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct graph_SetC__data*
graph_SetC__get_data(
  graph_SetC);

extern void
graph_SetC__set_data(
  graph_SetC,
  struct graph_SetC__data*);

extern
void
impl_graph_SetC__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_graph_SetC__ctor(
  /* in */ graph_SetC self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_graph_SetC__ctor2(
  /* in */ graph_SetC self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_graph_SetC__dtor(
  /* in */ graph_SetC self,
  /* out */ sidl_BaseInterface *_ex);

/*
 * User-defined object methods
 */

#ifdef WITH_RMI
extern struct graph_Data__object* impl_graph_SetC_fconnect_graph_Data(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_graph_SetC_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/
extern
int32_t
impl_graph_SetC_insert(
  /* in */ graph_SetC self,
  /* in */ graph_Data d,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_graph_SetC_remove(
  /* in */ graph_SetC self,
  /* in */ graph_Data d,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_graph_SetC_isMember(
  /* in */ graph_SetC self,
  /* in */ graph_Data d,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_graph_SetC_clearSet(
  /* in */ graph_SetC self,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_graph_SetC_isEmpty(
  /* in */ graph_SetC self,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_graph_SetC_getSize(
  /* in */ graph_SetC self,
  /* out */ sidl_BaseInterface *_ex);

extern
graph_ListOps
impl_graph_SetC_getList(
  /* in */ graph_SetC self,
  /* out */ sidl_BaseInterface *_ex);

#ifdef WITH_RMI
extern struct graph_Data__object* impl_graph_SetC_fconnect_graph_Data(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_graph_SetC_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/

/* DO-NOT-DELETE splicer.begin(_hmisc) */
/* insert code here (miscellaneous things) */
/* DO-NOT-DELETE splicer.end(_hmisc) */

#ifdef __cplusplus
}
#endif
#endif
