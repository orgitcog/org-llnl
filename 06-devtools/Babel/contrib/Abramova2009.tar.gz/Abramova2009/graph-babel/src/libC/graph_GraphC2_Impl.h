/*
 * File:          graph_GraphC2_Impl.h
 * Symbol:        graph.GraphC2-v1.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for graph.GraphC2
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#ifndef included_graph_GraphC2_Impl_h
#define included_graph_GraphC2_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_graph_GraphC2_IOR_h
#include "graph_GraphC2_IOR.h"
#endif
#ifndef included_graph_AdjList_h
#include "graph_AdjList.h"
#endif
#ifndef included_graph_Data_h
#include "graph_Data.h"
#endif
#ifndef included_graph_GraphC_h
#include "graph_GraphC.h"
#endif
#ifndef included_graph_GraphC2_h
#include "graph_GraphC2.h"
#endif
#ifndef included_graph_GraphOps_h
#include "graph_GraphOps.h"
#endif
#ifndef included_graph_ListOps_h
#include "graph_ListOps.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_PostViolation_h
#include "sidl_PostViolation.h"
#endif
#ifndef included_sidl_PreViolation_h
#include "sidl_PreViolation.h"
#endif
#ifndef included_sidl_RuntimeException_h
#include "sidl_RuntimeException.h"
#endif
/* DO-NOT-DELETE splicer.begin(graph.GraphC2._hincludes) */
/* insert code here (include files) */
/* DO-NOT-DELETE splicer.end(graph.GraphC2._hincludes) */

/*
 * Private data for class graph.GraphC2
 */

struct graph_GraphC2__data {
  /* DO-NOT-DELETE splicer.begin(graph.GraphC2._data) */
  /* insert code here (private data members) */
  int ignore; /* dummy to force non-empty struct; remove if you add data */
  /* DO-NOT-DELETE splicer.end(graph.GraphC2._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct graph_GraphC2__data*
graph_GraphC2__get_data(
  graph_GraphC2);

extern void
graph_GraphC2__set_data(
  graph_GraphC2,
  struct graph_GraphC2__data*);

extern void graph_GraphC2__superEPV(
struct graph_GraphC__epv*);

extern
void
impl_graph_GraphC2__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_graph_GraphC2__ctor(
  /* in */ graph_GraphC2 self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_graph_GraphC2__ctor2(
  /* in */ graph_GraphC2 self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_graph_GraphC2__dtor(
  /* in */ graph_GraphC2 self,
  /* out */ sidl_BaseInterface *_ex);

/*
 * User-defined object methods
 */

#ifdef WITH_RMI
extern struct graph_Data__object* impl_graph_GraphC2_fconnect_graph_Data(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_graph_GraphC2_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/
extern
int32_t
impl_graph_GraphC2_insVertex(
  /* in */ graph_GraphC2 self,
  /* in */ graph_Data d,
  /* out */ sidl_BaseInterface *_ex);

#ifdef WITH_RMI
extern struct graph_Data__object* impl_graph_GraphC2_fconnect_graph_Data(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_graph_GraphC2_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/

/* DO-NOT-DELETE splicer.begin(_hmisc) */
/* insert code here (miscellaneous things) */
/* DO-NOT-DELETE splicer.end(_hmisc) */

#ifdef __cplusplus
}
#endif
#endif
