/*
 * File:          graph_GraphC_Impl.h
 * Symbol:        graph.GraphC-v1.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for graph.GraphC
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#ifndef included_graph_GraphC_Impl_h
#define included_graph_GraphC_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_graph_AdjList_h
#include "graph_AdjList.h"
#endif
#ifndef included_graph_Data_h
#include "graph_Data.h"
#endif
#ifndef included_graph_GraphC_h
#include "graph_GraphC.h"
#endif
#ifndef included_graph_GraphOps_h
#include "graph_GraphOps.h"
#endif
#ifndef included_graph_ListOps_h
#include "graph_ListOps.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_PostViolation_h
#include "sidl_PostViolation.h"
#endif
#ifndef included_sidl_PreViolation_h
#include "sidl_PreViolation.h"
#endif
#ifndef included_sidl_RuntimeException_h
#include "sidl_RuntimeException.h"
#endif
/* DO-NOT-DELETE splicer.begin(graph.GraphC._hincludes) */
/* insert code here (include files) */
#ifndef included_graph_ListC_h
#include "graph_ListC.h"
#endif
#ifndef included_graph_AdjListC_h
#include "graph_AdjListC.h"
#endif
/* DO-NOT-DELETE splicer.end(graph.GraphC._hincludes) */

/*
 * Private data for class graph.GraphC
 */

struct graph_GraphC__data {
  /* DO-NOT-DELETE splicer.begin(graph.GraphC._data) */
  /* insert code here (private data members) */
  int vcount;
  int ecount;
  graph_ListOps adjlists;
  /* DO-NOT-DELETE splicer.end(graph.GraphC._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct graph_GraphC__data*
graph_GraphC__get_data(
  graph_GraphC);

extern void
graph_GraphC__set_data(
  graph_GraphC,
  struct graph_GraphC__data*);

extern
void
impl_graph_GraphC__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_graph_GraphC__ctor(
  /* in */ graph_GraphC self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_graph_GraphC__ctor2(
  /* in */ graph_GraphC self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_graph_GraphC__dtor(
  /* in */ graph_GraphC self,
  /* out */ sidl_BaseInterface *_ex);

/*
 * User-defined object methods
 */

#ifdef WITH_RMI
extern struct graph_Data__object* impl_graph_GraphC_fconnect_graph_Data(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_graph_GraphC_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/
extern
int32_t
impl_graph_GraphC_insVertex(
  /* in */ graph_GraphC self,
  /* in */ graph_Data d,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_graph_GraphC_remVertex(
  /* in */ graph_GraphC self,
  /* in */ graph_Data d,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_graph_GraphC_insEdge(
  /* in */ graph_GraphC self,
  /* in */ graph_Data d1,
  /* in */ graph_Data d2,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_graph_GraphC_remEdge(
  /* in */ graph_GraphC self,
  /* in */ graph_Data d1,
  /* in */ graph_Data d2,
  /* out */ sidl_BaseInterface *_ex);

extern
graph_AdjList
impl_graph_GraphC_getAdjList(
  /* in */ graph_GraphC self,
  /* in */ graph_Data d,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_graph_GraphC_isAdjacent(
  /* in */ graph_GraphC self,
  /* in */ graph_Data d1,
  /* in */ graph_Data d2,
  /* out */ sidl_BaseInterface *_ex);

extern
graph_ListOps
impl_graph_GraphC_getAdjLists(
  /* in */ graph_GraphC self,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_graph_GraphC_getVertCount(
  /* in */ graph_GraphC self,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_graph_GraphC_getEdgeCount(
  /* in */ graph_GraphC self,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_graph_GraphC_vertexExists(
  /* in */ graph_GraphC self,
  /* in */ graph_Data d,
  /* out */ sidl_BaseInterface *_ex);

#ifdef WITH_RMI
extern struct graph_Data__object* impl_graph_GraphC_fconnect_graph_Data(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
extern struct sidl_BaseInterface__object* 
  impl_graph_GraphC_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/

/* DO-NOT-DELETE splicer.begin(_hmisc) */
/* insert code here (miscellaneous things) */
/* DO-NOT-DELETE splicer.end(_hmisc) */

#ifdef __cplusplus
}
#endif
#endif
