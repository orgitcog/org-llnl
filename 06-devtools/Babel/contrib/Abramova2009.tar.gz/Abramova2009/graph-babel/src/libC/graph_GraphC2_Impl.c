/*
 * File:          graph_GraphC2_Impl.c
 * Symbol:        graph.GraphC2-v1.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for graph.GraphC2
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "graph.GraphC2" (version 1.0)
 * 
 * Flawed Graph Implementation
 * Vertices are inserted only 70% of the time
 */

#include "graph_GraphC2_Impl.h"
#include "sidl_NotImplementedException.h"
#include "sidl_Exception.h"
#ifndef included_sidl_MemAllocException_h
#include "sidl_MemAllocException.h"
#endif

/* DO-NOT-DELETE splicer.begin(graph.GraphC2._includes) */
/* insert code here (includes and arbitrary code) */
#include <time.h>
/* int randint() */
/* { */
  
/*   int randres = ((rand() % 100) < 70)? 1: 0; */
/*   return randres; */
/* }  */
/* DO-NOT-DELETE splicer.end(graph.GraphC2._includes) */

#define SIDL_IOR_MAJOR_VERSION 2
#define SIDL_IOR_MINOR_VERSION 0
static const struct graph_GraphC__epv* superEPV = NULL;

void graph_GraphC2__superEPV(
struct graph_GraphC__epv* parentEPV){
  superEPV = parentEPV;
}
/*
 * Inserts a vertex into a graph. 
 * returns 0 if the insertion is successful, 
 * 1 if the vertex already exists. -1 otherwise
 */

static int32_t
super_insVertex(
  /* in */ graph_GraphC2 self,
  /* in */ graph_Data d,
  /* out */ sidl_BaseInterface *_ex)
{
  return (*superEPV->f_insVertex)((struct graph_GraphC__object*)
    self,
    d,
    _ex);
}

/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_GraphC2__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_GraphC2__load(
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.GraphC2._load) */
    /* insert code here (static class initializer) */
    /* DO-NOT-DELETE splicer.end(graph.GraphC2._load) */
  }
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_GraphC2__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_GraphC2__ctor(
  /* in */ graph_GraphC2 self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.GraphC2._ctor) */
    srand(time(NULL));
    /*
     * // boilerplate constructor
     * struct graph_GraphC2__data *dptr = (struct graph_GraphC2__data*)malloc(sizeof(struct graph_GraphC2__data));
     * if (dptr) {
     *   memset(dptr, 0, sizeof(struct graph_GraphC2__data));
     *   // initialize elements of dptr here
     * graph_GraphC2__set_data(self, dptr);
     * } else {
     *   sidl_MemAllocException ex = sidl_MemAllocException_getSingletonException(_ex);
     *   SIDL_CHECK(*_ex);
     *   sidl_MemAllocException_setNote(ex, "Out of memory.", _ex); SIDL_CHECK(*_ex);
     *   sidl_MemAllocException_add(ex, __FILE__, __LINE__, "graph.GraphC2._ctor", _ex);
     *   SIDL_CHECK(*_ex);
     *   *_ex = (sidl_BaseInterface)ex;
     * }
     * EXIT:;
     */

    /* DO-NOT-DELETE splicer.end(graph.GraphC2._ctor) */
  }
}

/*
 * Special Class constructor called when the user wants to wrap his own private data.
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_GraphC2__ctor2"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_GraphC2__ctor2(
  /* in */ graph_GraphC2 self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.GraphC2._ctor2) */
    /* insert code here (special constructor) */
    /* DO-NOT-DELETE splicer.end(graph.GraphC2._ctor2) */
  }
}
/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_GraphC2__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_graph_GraphC2__dtor(
  /* in */ graph_GraphC2 self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.GraphC2._dtor) */
    /*
     * // boilerplate destructor
     * struct graph_GraphC2__data *dptr = graph_GraphC2__get_data(self);
     * if (dptr) {
     *   // free contained in dtor before next line
     *   free(dptr);
     *   graph_GraphC2__set_data(self, NULL);
     * }
     */

    /* DO-NOT-DELETE splicer.end(graph.GraphC2._dtor) */
  }
}

/*
 * Inserts a vertex into a graph. 
 * returns 0 if the insertion is successful, 
 * 1 if the vertex already exists. -1 otherwise
 */

#undef __FUNC__
#define __FUNC__ "impl_graph_GraphC2_insVertex"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_graph_GraphC2_insVertex(
  /* in */ graph_GraphC2 self,
  /* in */ graph_Data d,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(graph.GraphC2.insVertex) */
    int result = randint();
    
    if (result == 1){
    
      sidl_BaseInterface throwawayException;
      int super_result = super_insVertex(self, d, &throwawayException);
      return super_result;
    }
    else return -1;
    /* DO-NOT-DELETE splicer.end(graph.GraphC2.insVertex) */
  }
}
/* Babel internal methods, Users should not edit below this line. */

/* DO-NOT-DELETE splicer.begin(_misc) */
/* insert code here (miscellaneous code) */
/* DO-NOT-DELETE splicer.end(_misc) */

