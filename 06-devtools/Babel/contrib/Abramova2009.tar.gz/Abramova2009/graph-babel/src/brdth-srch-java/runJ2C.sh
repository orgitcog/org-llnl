#! /bin/sh


prefix=`babel-config --prefix`

exec_prefix=`babel-config --exec_prefix`

bindir=`babel-config --bindir`

libdir=`babel-config --libdir`
JAVA=`which java`
VERSION="1.4.0"

CLASSPATH="${libdir}/sidl-${VERSION}.jar:${libdir}/sidlstub_${VERSION}.jar:."
SIDL_DLL_PATH="libclient.scl;../libC/libgraph.scl;${libdir}/libsidl.scl;${libdir}/libsidlstub_java.scl"
JAVA_LIBRARY_PATH="${libdir}"
LD_LIBRARY_PATH="${libdir}:${LD_LIBRARY_PATH}"
export LD_LIBRARY_PATH
SIDL_LIBRARY_NAME=sidl

export SIDL_DLL_PATH;
export CLASSPATH


${JAVA} \
  -Djava.library.path="${JAVA_LIBRARY_PATH}" \
  -Dsidl.library.name="${SIDL_LIBRARY_NAME}" \
  BFS
exit $?

