import graph.GraphOps;
import graph.Data;
import graph.AdjList;
import graph.ListNode;
import graph.ListOps;



public class BfsSearch {

   
    public int bfs(graph.GraphOps graph, graph.Data startNode, java.util.List < graph.Data> verticesList, java.util.List <Integer> hopsList){

        java.util.Queue <graph.AdjList> queue = new java.util.LinkedList <graph.AdjList> ();
        
        java.util.HashMap <Integer, Integer> vertMap = new java.util.HashMap <Integer, Integer> ();

        
	

        //initialize BfsLists to adjacency lists and all of the vertices of the graph.
         graph.ListNode elem;
	 

	 graph.ListOps graphAdjacencyLists;
	 graphAdjacencyLists = graph.getAdjLists();
	 elem =  graphAdjacencyLists.getHead();
	 for (; elem!= null; elem = elem.getNext()){
	    graph.AdjList adjListElem = (graph.AdjList)elem.getData()._cast2("graph.AdjList");
            graph.Data vert = adjListElem.getVertex();	    
	    Integer hopCnt;	    
            if (vert.compare(startNode) == 0){ 
		//meaning if this is the start vertex
		hopCnt = Integer.valueOf(0);
		//initialize the result list, add the startNode and its hopcount, ie 0
		verticesList.add(vert);
		hopsList.add(Integer.valueOf(0));
	    }
	    else { //these are all the rest of vertices
		hopCnt = Integer.valueOf(-1);
	    }	    
	    vertMap.put(Integer.valueOf(vert.hashCode()), hopCnt);
	    
	    
	    
	}
	
	//initialize the queue with the adjacency list of the first vertex
	queue.offer(graph.getAdjList(startNode));
	
	
	//perform breadth-first search
	graph.AdjList adjlist;
	while ((adjlist = queue.peek()) != null){
	    graph.Data vert = adjlist.getVertex();

	    Integer hCnt = vertMap.get(Integer.valueOf(vert.hashCode()));
	    
	    //traverse each vertex in the current adjacency list
	    graph.ListNode vertNode = adjlist.getList().getHead();

	    for (; vertNode!= null; vertNode = vertNode.getNext()){
		graph.Data adjVert = vertNode.getData();
		Integer hCntAdj = vertMap.get(Integer.valueOf(adjVert.hashCode()));
		if (hCntAdj == -1){
		    //if this vertex has not yet been discovered
		    hCntAdj = hCnt +1;
		    //initialize the result data structures
		    verticesList.add(adjVert);
		    hopsList.add(hCntAdj);		    
                    vertMap.put(Integer.valueOf(adjVert.hashCode()), hCntAdj);
		    //insert the adjacency list of the vertex to the processing queue
		    queue.offer(graph.getAdjList(adjVert));
		}
	    }
	    //we are done with the vertex, remove it now
	    queue.remove(adjlist);	   	    
	}
	return 0;
    }
    
}
