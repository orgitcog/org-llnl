#! /bin/sh

prefix="/export/tmp-abramova1/babel/babel-inst-nofl"
#prefix=`babel-config --prefix`
exec_prefix="/export/tmp-abramova1/babel/babel-inst-nofl"
#exec_prefix=`babel-config --exec_prefix`
bindir="${exec_prefix}/bin"
#bindir=`babel-config --bindir`
libdir="${exec_prefix}/lib"
#libdir=`babel-config --libdir`
JAVA="/usr/apps/java/jdk1.6.0/bin/java"
VERSION="1.4.0"
python_version="2.5"
pylib=`$PYTHON -c "import sys; print sys.__dict__.get('lib','lib')"`
PYTHONPATH="../libPython:$exec_prefix/$pylib/python$python_version/site-packages:$PYTHONPATH"
CLASSPATH="${libdir}/sidl-${VERSION}.jar:${libdir}/sidlstub_${VERSION}.jar:."
SIDL_DLL_PATH="libclient.scl;../libPython/libgraph.scl;${libdir}/libsidl.scl;${libdir}/libsidlstub_java.scl"
JAVA_LIBRARY_PATH="${libdir}"
LD_LIBRARY_PATH="${libdir}:${LD_LIBRARY_PATH}"
export LD_LIBRARY_PATH

SIDL_LIBRARY_NAME=sidl
export PYTHONPATH
echo $SIDL_DLL_PATH
export SIDL_DLL_PATH;
export CLASSPATH


${JAVA} \
  -Djava.library.path="${JAVA_LIBRARY_PATH}" \
  -Dsidl.library.name="${SIDL_LIBRARY_NAME}" \
  BFS
exit $?
