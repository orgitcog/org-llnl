import graph.ListOps;
import graph.ListNode;
import graph.Data;
import graph.IntData;
import graph.GraphC;
import graph.GraphOps;
import graph.GraphC1;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.FileReader;

import sidl.EnfPolicy;
//import sidl.Exception;

public class BFS {

    InitGraph ig;
    BfsSearch b;
    
    public BFS(){
	ig = new InitGraph();
	b = new BfsSearch();
    }
    


    //this is a main routine for the breadth first search client
    //graph is initialized from a file whose name is stored in a file "setup"
    //filename with graph settings is read from "setup"
    //as well as true/false parameter for making graph undirected or directed
    //and true/false parameter for enabling/disabling enforcement policy
    //the value of the startNode that is used as a node for performing
    //breadth first search is read from there as well

    public static void main(String args[]){
        //fname - name of the file that stores vertices and edges
	String fname;

	//String value of a boolean indicating whether a graph is to be
        //undirected or not
	String undirected;

        //String value of a boolean read from a file
        //that determines the policy enforcement enabling
	String policyEnf;

	boolean undir, policyEnbl;

        //int value read from a file that determines the value of a startNode
        //used for breadth first search
	int nodeValue=0;
	graph.Data startV;
	BFS bfs = new BFS();
	
        
	try {
	    String setup = "setup";
	    BufferedReader in = new BufferedReader(new FileReader(setup));
	    fname = in.readLine();
	    undirected = in.readLine();
	    policyEnf = in.readLine();
	    undir = new Boolean(undirected).booleanValue();
	    policyEnbl = new Boolean(policyEnf).booleanValue();
	    nodeValue = new Integer(in.readLine()).intValue();
	    in.close();

	} catch (java.io.IOException e){
	    //default settings if file is not found
	    fname = "graphS";
            undir = false;
	    policyEnbl = false;
	}
        


        //turn on contract enforcement
        sidl.EnfPolicy policy = new sidl.EnfPolicy();
	if (policyEnbl) policy.setEnforceAll(sidl.ContractClass.ALLCLASSES, true);
	else policy.setEnforceNone(true);

        //create the startNode used for breadth first search
	graph.IntData d1 = new IntData();
        d1.setIntData(nodeValue);

        
	String str;
 
        //create Graph
        graph.GraphC grC = new graph.GraphC();
	bfs.initAndSearch(grC, d1,  fname, undir);
	//wait for some user input
	try {
	str = new BufferedReader(new InputStreamReader(System.in)).readLine(); 
	}catch (java.io.IOException e){}
	
        //create flawed Graph that inserts 70% of the edges.
        graph.GraphC1 grC1 = new graph.GraphC1();
	
	
        bfs.initAndSearch(grC1, d1, fname, undir);
        //wait for some user input
	try {
	str = new BufferedReader(new InputStreamReader(System.in)).readLine(); 
	}catch (java.io.IOException e){}
	
 
        //create flawed Graph that inserts 70% of the vertices
        graph.GraphC2 grC2 = new graph.GraphC2();	
        bfs.initAndSearch(grC2, d1, fname, undir);  


	//dump stats for the enforcement policy
	policy.dumpStats("stats.out", true, "",false); 

	
    }
    int initAndSearch(graph.GraphOps testGraph,graph.Data startNode, String fname, boolean undir){
	
        graph.Data startV;
	
        //initialize a graph from a file
        this.ig.initFromFile(testGraph, fname , undir);
        graph.AdjList adjlist = testGraph.getAdjList(startNode);
	
	if (adjlist!=null)  startV = adjlist.getVertex();
	else return -1;
	
 	java.util.List < graph.Data> verticesList = new java.util.LinkedList < graph.Data> ();
	java.util.List <Integer> hopsList = new java.util.LinkedList <Integer> ();
	
	java.util.Date date1 = new java.util.Date();
        long time1=date1.getTime();

        //perform breadth-first search
      	this.b.bfs(testGraph, startV, verticesList, hopsList);

	//display search results
	//for (BfsData bd:hops){
	java.util.Iterator <Integer> iter = hopsList.iterator();
	for (graph.Data vert : verticesList){
	    
	    int val=((graph.IntData) vert._cast2("graph.IntData")).getIntData();
	    System.out.print("vertex = "+val);
	    System.out.println(" , hop count = "+ iter.next());
	}

	//hops = null;
	
	testGraph = null;
	java.util.Date date2 = new java.util.Date();
	long time2 = date2.getTime();
	time2 = time2 - time1;
        System.out.println("Time taken " + (time2) + " milliseconds");
	return 0;
    }

    
    
}
