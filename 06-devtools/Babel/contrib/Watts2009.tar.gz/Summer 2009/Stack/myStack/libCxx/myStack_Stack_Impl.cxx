// 
// File:          myStack_Stack_Impl.cxx
// Symbol:        myStack.Stack-v1.0
// Symbol Type:   class
// Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
// Description:   Server-side implementation for myStack.Stack
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "myStack_Stack_Impl.hxx"
#include "iostream.h"
// 
// Includes for all method dependencies.
// 
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
// DO-NOT-DELETE splicer.begin(myStack.Stack._includes)
// insert code here (additional includes or code)
// DO-NOT-DELETE splicer.end(myStack.Stack._includes)

// special constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
myStack::Stack_impl::Stack_impl() : StubBase(reinterpret_cast< void*>(
  ::myStack::Stack::_wrapObj(reinterpret_cast< void*>(this))),false) , _wrapped(
  true){ 
  // DO-NOT-DELETE splicer.begin(myStack.Stack._ctor2)
  // insert code here (ctor2)
  // DO-NOT-DELETE splicer.end(myStack.Stack._ctor2)
}

// user defined constructor
void myStack::Stack_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(myStack.Stack._ctor)
  // insert code here (constructor)
  // DO-NOT-DELETE splicer.end(myStack.Stack._ctor)
}

// user defined destructor
void myStack::Stack_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(myStack.Stack._dtor)
  // insert code here (destructor)
  // DO-NOT-DELETE splicer.end(myStack.Stack._dtor)
}

// static class initializer
void myStack::Stack_impl::_load() {
  // DO-NOT-DELETE splicer.begin(myStack.Stack._load)
  // insert code here (class initialization)
  // DO-NOT-DELETE splicer.end(myStack.Stack._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  push[]
 */
void
myStack::Stack_impl::push_impl (
  /* in */::sidl::BaseInterface& s ) 
{
  // DO-NOT-DELETE splicer.begin(myStack.Stack.push)
	Node *dptr;
	
	if(dptr->stack){
		struct Node *tmp = dptr->stack;
		cout<<"I am about to PUSH on a non-empty stack.."<<endl;
		tmp->data[tmp->top] = s;
		tmp->top++;
	}

	else{
		cout<<"Pushing on an empty stack.."<<endl;
		dptr->stack->data[dptr->stack->top++] = s;
		dptr->stack->top++;
	} 
  // DO-NOT-DELETE splicer.end(myStack.Stack.push)
}

/**
 * Method:  pop[]
 */
void
myStack::Stack_impl::pop_impl () 

{
  // DO-NOT-DELETE splicer.begin(myStack.Stack.pop)
   Node *dptr;

	if(dptr->stack){
		struct Node *tmp = dptr->stack;
		cout<<"About to POP from a non-empty stack.."<<endl;
		tmp->top--;
	}

	else
		cout<<"Can't POP from an empty stack..."<<endl;

  // DO-NOT-DELETE splicer.end(myStack.Stack.pop)
}

/**
 * Method:  full[]
 */
int32_t
myStack::Stack_impl::full_impl () 

{
  // DO-NOT-DELETE splicer.begin(myStack.Stack.full)
 	Node *dptr = dptr->stack;
		return (dptr->stack->top >= 10); 
  // DO-NOT-DELETE splicer.end(myStack.Stack.full)
}

/**
 * Method:  display[]
 */
void
myStack::Stack_impl::display_impl () 

{
  // DO-NOT-DELETE splicer.begin(myStack.Stack.display)
  // insert code here
  // DO-NOT-DELETE splicer.end(myStack.Stack.display)
}


// DO-NOT-DELETE splicer.begin(myStack.Stack._misc)
// insert code here (miscellaneous code)
// DO-NOT-DELETE splicer.end(myStack.Stack._misc)

