// 
// File:          myStack_Stack_Skel.cxx
// Symbol:        myStack.Stack-v1.0
// Symbol Type:   class
// Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
// Description:   Server-side glue code for myStack.Stack
// 
// WARNING: Automatically generated; changes will be lost
// 
// 
#ifndef included_myStack_Stack_Impl_hxx
#include "myStack_Stack_Impl.hxx"
#endif
#ifndef included_myStack_Stack_IOR_h
#include "myStack_Stack_IOR.h"
#endif
#ifndef included_sidl_BaseException_hxx
#include "sidl_BaseException.hxx"
#endif
#ifndef included_sidl_LangSpecificException_hxx
#include "sidl_LangSpecificException.hxx"
#endif
// 
// Includes for all method dependencies.
// 
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#include "sidl_String.h"
#include <stddef.h>
#include <cstring>

extern "C" {

  static void
  skel_myStack_Stack_push( 
  /* in */ struct myStack_Stack__object* self, /* in */ struct 
    sidl_BaseInterface__object* s, sidl_BaseInterface__object ** _exception )
  {
    // pack args to dispatch to impl
    ::myStack::Stack_impl *_this = reinterpret_cast< ::myStack::Stack_impl*>(
      self->d_data);
    ::sidl::BaseInterface  _local_s(s);
    *_exception = 0;//init just to be safe

    // dispatch to impl
    try { 
      _this->push_impl( /* in */ _local_s );
    } catch ( ::sidl::RuntimeException _ex ) { 
      sidl_BaseInterface _throwaway_exception;
      (_ex._get_ior()->d_epv->f_add) (_ex._get_ior()->d_object,  __FILE__, __LINE__,"C++ skeleton for push.", &_throwaway_exception);
      _ex.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _ex._get_ior());

    } catch (...) {
      // Convert all other exceptions to LangSpecific
      ::sidl::LangSpecificException _unexpected = 
        ::sidl::LangSpecificException::_create();
      sidl_BaseInterface _throwaway_exception;
      (_unexpected._get_ior()->d_epv->f_setNote) (_unexpected._get_ior(),
        "Unexpected C++ exception", &_throwaway_exception);
      _unexpected.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _unexpected._get_ior());

    }
    // unpack results and cleanup

  }

  static void
  skel_myStack_Stack_pop( 
  /* in */ struct myStack_Stack__object* self, sidl_BaseInterface__object ** 
    _exception )
  {
    // pack args to dispatch to impl
    ::myStack::Stack_impl *_this = reinterpret_cast< ::myStack::Stack_impl*>(
      self->d_data);
    *_exception = 0;//init just to be safe

    // dispatch to impl
    try { 
      _this->pop_impl(  );
    } catch ( ::sidl::RuntimeException _ex ) { 
      sidl_BaseInterface _throwaway_exception;
      (_ex._get_ior()->d_epv->f_add) (_ex._get_ior()->d_object,  __FILE__, __LINE__,"C++ skeleton for pop.", &_throwaway_exception);
      _ex.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _ex._get_ior());

    } catch (...) {
      // Convert all other exceptions to LangSpecific
      ::sidl::LangSpecificException _unexpected = 
        ::sidl::LangSpecificException::_create();
      sidl_BaseInterface _throwaway_exception;
      (_unexpected._get_ior()->d_epv->f_setNote) (_unexpected._get_ior(),
        "Unexpected C++ exception", &_throwaway_exception);
      _unexpected.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _unexpected._get_ior());

    }
    // unpack results and cleanup

  }

  static int32_t
  skel_myStack_Stack_full( 
  /* in */ struct myStack_Stack__object* self, sidl_BaseInterface__object ** 
    _exception )
  {
    // pack args to dispatch to impl
    int32_t _result = 0;
    ::myStack::Stack_impl *_this = reinterpret_cast< ::myStack::Stack_impl*>(
      self->d_data);
    *_exception = 0;//init just to be safe

    // dispatch to impl
    try { 
      _result = _this->full_impl(  );
    } catch ( ::sidl::RuntimeException _ex ) { 
      sidl_BaseInterface _throwaway_exception;
      (_ex._get_ior()->d_epv->f_add) (_ex._get_ior()->d_object,  __FILE__, __LINE__,"C++ skeleton for full.", &_throwaway_exception);
      _ex.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _ex._get_ior());

      return _result;
    } catch (...) {
      // Convert all other exceptions to LangSpecific
      ::sidl::LangSpecificException _unexpected = 
        ::sidl::LangSpecificException::_create();
      sidl_BaseInterface _throwaway_exception;
      (_unexpected._get_ior()->d_epv->f_setNote) (_unexpected._get_ior(),
        "Unexpected C++ exception", &_throwaway_exception);
      _unexpected.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _unexpected._get_ior());

      return _result;
    }
    // unpack results and cleanup

    return _result;
  }

  static void
  skel_myStack_Stack_display( 
  /* in */ struct myStack_Stack__object* self, sidl_BaseInterface__object ** 
    _exception )
  {
    // pack args to dispatch to impl
    ::myStack::Stack_impl *_this = reinterpret_cast< ::myStack::Stack_impl*>(
      self->d_data);
    *_exception = 0;//init just to be safe

    // dispatch to impl
    try { 
      _this->display_impl(  );
    } catch ( ::sidl::RuntimeException _ex ) { 
      sidl_BaseInterface _throwaway_exception;
      (_ex._get_ior()->d_epv->f_add) (_ex._get_ior()->d_object,  __FILE__, __LINE__,"C++ skeleton for display.", &_throwaway_exception);
      _ex.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _ex._get_ior());

    } catch (...) {
      // Convert all other exceptions to LangSpecific
      ::sidl::LangSpecificException _unexpected = 
        ::sidl::LangSpecificException::_create();
      sidl_BaseInterface _throwaway_exception;
      (_unexpected._get_ior()->d_epv->f_setNote) (_unexpected._get_ior(),
        "Unexpected C++ exception", &_throwaway_exception);
      _unexpected.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _unexpected._get_ior());

    }
    // unpack results and cleanup

  }

#ifdef WITH_RMI
  struct sidl_BaseInterface__object* 
    skel_myStack_Stack_fconnect_sidl_BaseInterface(const char* url, sidl_bool 
    ar, sidl_BaseInterface *_ex) { 
    return sidl_BaseInterface__connectI(url, ar, _ex);
  }

#endif /*WITH_RMI*/
  void
  myStack_Stack__call_load(void) {::myStack::Stack_impl::_load();}

  static void
  skel_myStack_Stack__ctor(struct myStack_Stack__object* self, struct 
    sidl_BaseInterface__object **_ex ) { 
    try {
      self->d_data = reinterpret_cast< void*>(new ::myStack::Stack_impl(self));
    } catch ( ::sidl::RuntimeException _exc ) {
      sidl_BaseInterface _throwaway_exception;
      (_exc._get_ior()->d_epv->f_add) (_exc._get_ior()->d_object, __FILE__, __LINE__," C++ skeleton for _ctor.", &_throwaway_exception);
      _exc.addRef();
      *_ex = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _exc._get_ior());
    } catch (...) {
      // Convert all other exceptions to LangSpecific
      ::sidl::LangSpecificException _unexpected = 
        ::sidl::LangSpecificException::_create();
      _unexpected.setNote("Unexpected C++ exception in _ctor.");
      _unexpected.addRef();
      *_ex = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _unexpected._get_ior());
    }
  }

  static void
  skel_myStack_Stack__ctor2(struct myStack_Stack__object* self, void* 
    private_data, struct sidl_BaseInterface__object **_ex ) { 
    *_ex = NULL;
  }

  static void
  skel_myStack_Stack__dtor(struct myStack_Stack__object* self, struct 
    sidl_BaseInterface__object **_ex ) { 
    try {
      ::myStack::Stack_impl* loc_data = reinterpret_cast< 
        ::myStack::Stack_impl*>(self->d_data);
      if(!loc_data->_isWrapped()) {
        delete (loc_data);
      }
    } catch ( ::sidl::RuntimeException _exc ) {
      sidl_BaseInterface _throwaway_exception;
      (_exc._get_ior()->d_epv->f_add) (_exc._get_ior()->d_object, __FILE__, __LINE__," C++ skeleton for _dtor.", &_throwaway_exception);
      _exc.addRef();
      *_ex = reinterpret_cast< struct sidl_BaseInterface__object * >(_exc._get_ior());
    } catch (...) {
      // Convert all other exceptions to LangSpecific
      ::sidl::LangSpecificException _unexpected = ::sidl::LangSpecificException::_create();
      _unexpected.setNote("Unexpected C++ exception in _dtor.");
      _unexpected.addRef();
      *_ex = reinterpret_cast< struct sidl_BaseInterface__object * >(_unexpected._get_ior());
    }
  }

  void
  myStack_Stack__set_epv(struct myStack_Stack__epv *epv,
  struct myStack_Stack__pre_epv *pre_epv, struct myStack_Stack__post_epv *post_epv){
    // initialize builtin methods
    epv->f__ctor = skel_myStack_Stack__ctor;
    epv->f__ctor2 = skel_myStack_Stack__ctor2;
    epv->f__dtor = skel_myStack_Stack__dtor;
    // initialize local methods
    pre_epv->f_push_pre = NULL;
    epv->f_push = skel_myStack_Stack_push;
    post_epv->f_push_post = NULL;
    pre_epv->f_pop_pre = NULL;
    epv->f_pop = skel_myStack_Stack_pop;
    post_epv->f_pop_post = NULL;
    pre_epv->f_full_pre = NULL;
    epv->f_full = skel_myStack_Stack_full;
    post_epv->f_full_post = NULL;
    pre_epv->f_display_pre = NULL;
    epv->f_display = skel_myStack_Stack_display;
    post_epv->f_display_post = NULL;
  }


} // end extern "C"
