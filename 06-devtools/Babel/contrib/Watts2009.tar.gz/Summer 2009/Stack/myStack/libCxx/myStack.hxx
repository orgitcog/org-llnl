// 
// File:          myStack.hxx
// Symbol:        myStack-v1.0
// Symbol Type:   package
// Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
// Description:   Client-side glue code for myStack
// 
// WARNING: Automatically generated; changes will be lost
// 
// 


#ifndef included_myStack_Stack_hxx
#include "myStack_Stack.hxx"
#endif


