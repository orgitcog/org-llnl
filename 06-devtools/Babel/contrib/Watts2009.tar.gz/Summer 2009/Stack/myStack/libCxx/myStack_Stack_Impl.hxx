// 
// File:          myStack_Stack_Impl.hxx
// Symbol:        myStack.Stack-v1.0
// Symbol Type:   class
// Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
// Description:   Server-side implementation for myStack.Stack
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_myStack_Stack_Impl_hxx
#define included_myStack_Stack_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_myStack_Stack_IOR_h
#include "myStack_Stack_IOR.h"
#endif
#ifndef included_myStack_Stack_hxx
#include "myStack_Stack.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif


// DO-NOT-DELETE splicer.begin(myStack.Stack._hincludes)
	struct Node{
		sidl::BaseInterface data[10];
		int top;
	struct Node *stack;
		int size;
	};
//DO-NOT-DELETE splicer.end(myStack.Stack._hincludes)

namespace myStack { 

  /**
   * Symbol "myStack.Stack" (version 1.0)
   */
  class Stack_impl : public virtual ::myStack::Stack 
  // DO-NOT-DELETE splicer.begin(myStack.Stack._inherits)
  // insert code here (optional inheritance here)
  // DO-NOT-DELETE splicer.end(myStack.Stack._inherits)

  {

  // All data marked protected will be accessable by 
  // descendant Impl classes
  protected:

    bool _wrapped;

    // DO-NOT-DELETE splicer.begin(myStack.Stack._implementation)
    int size;
    //struct Node *stack;
    // DO-NOT-DELETE splicer.end(myStack.Stack._implementation)

  public:
    // default constructor, used for data wrapping(required)
    Stack_impl();
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    Stack_impl( struct myStack_Stack__object * ior ) : StubBase(ior,true) , 
      _wrapped(false) {_ctor();}


    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~Stack_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // true if this object was created by a user newing the impl
    inline bool _isWrapped() {return _wrapped;}

    // static class initializer
    static void _load();

  public:

    /**
     * user defined non-static method.
     */
    void
    push_impl (
      /* in */::sidl::BaseInterface& s
    )
    ;

    /**
     * user defined non-static method.
     */
    void
    pop_impl() ;
    /**
     * user defined non-static method.
     */
    int32_t
    full_impl() ;
    /**
     * user defined non-static method.
     */
    void
    display_impl() ;
  };  // end class Stack_impl

} // end namespace myStack

// DO-NOT-DELETE splicer.begin(myStack.Stack._hmisc)
// insert code here (miscellaneous things)
// DO-NOT-DELETE splicer.end(myStack.Stack._hmisc)

#endif
