/*
 * File:          myStack_Stack_Skel.c
 * Symbol:        myStack.Stack-v1.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side glue code for myStack.Stack
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 */

#include "myStack_Stack_IOR.h"
#include "myStack_Stack.h"
#include <stddef.h>

#ifdef WITH_RMI
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#endif /* WITH_RMI */
extern
void
impl_myStack_Stack__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_myStack_Stack__ctor(
  /* in */ myStack_Stack self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_myStack_Stack__ctor2(
  /* in */ myStack_Stack self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_myStack_Stack__dtor(
  /* in */ myStack_Stack self,
  /* out */ sidl_BaseInterface *_ex);

#ifdef WITH_RMI
extern struct sidl_BaseInterface__object* 
  impl_myStack_Stack_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/
extern
void
impl_myStack_Stack_push(
  /* in */ myStack_Stack self,
  /* in */ sidl_BaseInterface s,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_myStack_Stack_pop(
  /* in */ myStack_Stack self,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_myStack_Stack_full(
  /* in */ myStack_Stack self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_myStack_Stack_display(
  /* in */ myStack_Stack self,
  /* out */ sidl_BaseInterface *_ex);

#ifdef WITH_RMI
extern struct sidl_BaseInterface__object* 
  impl_myStack_Stack_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/
#ifdef __cplusplus
extern "C" {
#endif

void
myStack_Stack__set_epv(struct myStack_Stack__epv *epv,
  struct myStack_Stack__pre_epv *pre_epv, 
  struct myStack_Stack__post_epv *post_epv
)
{
  epv->f__ctor = impl_myStack_Stack__ctor;
  epv->f__ctor2 = impl_myStack_Stack__ctor2;
  epv->f__dtor = impl_myStack_Stack__dtor;
  pre_epv->f_push_pre = NULL;
  epv->f_push = impl_myStack_Stack_push;
  post_epv->f_push_post = NULL;
  pre_epv->f_pop_pre = NULL;
  epv->f_pop = impl_myStack_Stack_pop;
  post_epv->f_pop_post = NULL;
  pre_epv->f_full_pre = NULL;
  epv->f_full = impl_myStack_Stack_full;
  post_epv->f_full_post = NULL;
  pre_epv->f_display_pre = NULL;
  epv->f_display = impl_myStack_Stack_display;
  post_epv->f_display_post = NULL;

}
#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
extern "C" {
#endif

void myStack_Stack__call_load(void) { 
  sidl_BaseInterface _throwaway_exception = NULL;
  impl_myStack_Stack__load(&_throwaway_exception);
}
#ifdef WITH_RMI
struct sidl_BaseInterface__object* 
  skel_myStack_Stack_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex) { 
  return sidl_BaseInterface__connectI(url, ar, _ex);
}

#endif /*WITH_RMI*/
struct myStack_Stack__data*
myStack_Stack__get_data(myStack_Stack self)
{
  return (struct myStack_Stack__data*)(self ? self->d_data : NULL);
}

void myStack_Stack__set_data(
  myStack_Stack self,
  struct myStack_Stack__data* data)
{
  if (self) {
    self->d_data = data;
  }
}
#ifdef __cplusplus
}
#endif
