/*
 * File:          myStack_Stack_Impl.h
 * Symbol:        myStack.Stack-v1.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for myStack.Stack
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#ifndef included_myStack_Stack_Impl_h
#define included_myStack_Stack_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_myStack_Stack_h
#include "myStack_Stack.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_RuntimeException_h
#include "sidl_RuntimeException.h"
#endif
/* DO-NOT-DELETE splicer.begin(myStack.Stack._hincludes) */
struct Node{
	sidl_BaseInterface data[10];
	int32_t top;
	};
/* DO-NOT-DELETE splicer.end(myStack.Stack._hincludes) */

/*
 * Private data for class myStack.Stack
 */

struct myStack_Stack__data {
  /* DO-NOT-DELETE splicer.begin(myStack.Stack._data) */
  /* insert code here (private data members) */
  
	int ignore; /* dummy to force non-empty struct; remove if you add data */
	int32_t size;
	struct Node *node;
  /* DO-NOT-DELETE splicer.end(myStack.Stack._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct myStack_Stack__data*
myStack_Stack__get_data(
  myStack_Stack);

extern void
myStack_Stack__set_data(
  myStack_Stack,
  struct myStack_Stack__data*);

extern
void
impl_myStack_Stack__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_myStack_Stack__ctor(
  /* in */ myStack_Stack self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_myStack_Stack__ctor2(
  /* in */ myStack_Stack self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_myStack_Stack__dtor(
  /* in */ myStack_Stack self,
  /* out */ sidl_BaseInterface *_ex);

/*
 * User-defined object methods
 */

#ifdef WITH_RMI
extern struct sidl_BaseInterface__object* 
  impl_myStack_Stack_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/
extern
void
impl_myStack_Stack_push(
  /* in */ myStack_Stack self,
  /* in */ sidl_BaseInterface s,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_myStack_Stack_pop(
  /* in */ myStack_Stack self,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_myStack_Stack_full(
  /* in */ myStack_Stack self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_myStack_Stack_display(
  /* in */ myStack_Stack self,
  /* out */ sidl_BaseInterface *_ex);

#ifdef WITH_RMI
extern struct sidl_BaseInterface__object* 
  impl_myStack_Stack_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/

/* DO-NOT-DELETE splicer.begin(_hmisc) */
/* insert code here (miscellaneous things) */
/* DO-NOT-DELETE splicer.end(_hmisc) */

#ifdef __cplusplus
}
#endif
#endif
