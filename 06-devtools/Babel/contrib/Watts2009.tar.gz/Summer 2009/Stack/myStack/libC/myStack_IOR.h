/*
 * File:          myStack_IOR.h
 * Symbol:        myStack-v1.0
 * Symbol Type:   package
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Intermediate Object Representation for myStack
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 */

#ifndef included_myStack_IOR_h
#define included_myStack_IOR_h

/*
 * Symbol "myStack" (version 1.0)
 */

#ifndef included_myStack_Stack_IOR_h
#include "myStack_Stack_IOR.h"
#endif

#endif
