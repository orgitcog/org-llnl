/*
 * File:          myStack_Stack_Impl.c
 * Symbol:        myStack.Stack-v1.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for myStack.Stack
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "myStack.Stack" (version 1.0)
 */

#include "myStack_Stack_Impl.h"
#include "sidl_NotImplementedException.h"
#include "sidl_Exception.h"
#ifndef included_sidl_MemAllocException_h
#include "sidl_MemAllocException.h"
#endif

/* DO-NOT-DELETE splicer.begin(myStack.Stack._includes) */
/* insert code here (includes and arbitrary code) */
/* DO-NOT-DELETE splicer.end(myStack.Stack._includes) */

#define SIDL_IOR_MAJOR_VERSION 2
#define SIDL_IOR_MINOR_VERSION 0
/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_myStack_Stack__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_myStack_Stack__load(
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(myStack.Stack._load) */
    /* insert code here (static class initializer) */
    /* DO-NOT-DELETE splicer.end(myStack.Stack._load) */
  }
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_myStack_Stack__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_myStack_Stack__ctor(
  /* in */ myStack_Stack self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(myStack.Stack._ctor) */
    
     /* boilerplate constructor*/
      struct myStack_Stack__data *dptr = (struct myStack_Stack__data*)malloc(sizeof(struct myStack_Stack__data));
      if (dptr) {
        memset(dptr, 0, sizeof(struct myStack_Stack__data));
        // initialize elements of dptr here
      myStack_Stack__set_data(self, dptr);
      } else {
        sidl_MemAllocException ex = sidl_MemAllocException_getSingletonException(_ex);
        SIDL_CHECK(*_ex);
        sidl_MemAllocException_setNote(ex, "Out of memory.", _ex); SIDL_CHECK(*_ex);
        sidl_MemAllocException_add(ex, __FILE__, __LINE__, "myStack.Stack._ctor", _ex);
        SIDL_CHECK(*_ex);
        *_ex = (sidl_BaseInterface)ex;
      }
      EXIT:;

    /* DO-NOT-DELETE splicer.end(myStack.Stack._ctor) */
  }
}

/*
 * Special Class constructor called when the user wants to wrap his own private data.
 */

#undef __FUNC__
#define __FUNC__ "impl_myStack_Stack__ctor2"

#ifdef __cplusplus
extern "C"
#endif
void
impl_myStack_Stack__ctor2(
  /* in */ myStack_Stack self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(myStack.Stack._ctor2) */
    /* insert code here (special constructor) */
    /* DO-NOT-DELETE splicer.end(myStack.Stack._ctor2) */
  }
}
/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_myStack_Stack__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_myStack_Stack__dtor(
  /* in */ myStack_Stack self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(myStack.Stack._dtor) */
    
      // boilerplate destructor
      struct myStack_Stack__data *dptr = myStack_Stack__get_data(self);
      if (dptr) {
        // free contained in dtor before next line
        free(dptr);
        myStack_Stack__set_data(self, NULL);
      }
    

    /* DO-NOT-DELETE splicer.end(myStack.Stack._dtor) */
  }
}

/*
 * Method:  push[]
 */

#undef __FUNC__
#define __FUNC__ "impl_myStack_Stack_push"

#ifdef __cplusplus
extern "C"
#endif
void
impl_myStack_Stack_push(
  /* in */ myStack_Stack self,
  /* in */ sidl_BaseInterface s,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(myStack.Stack.push) */
     	struct myStack_Stack__data *dptr = myStack_Stack__get_data(self);
	
	if(dptr->node)
	{
		struct Node *tmp = dptr->node;
		printf("I am about to PUSH on a non-empty stack...\n");
		tmp->data[tmp->top] = s;
		tmp->top ++;
	}

	else{
		printf("Pushing to an empty stack...\n");
		dptr->node = (struct Node *)malloc(sizeof(struct Node));
		dptr->node->data[(dptr->node->top)++] = s;
		dptr->node->top++;		
	}
    /* DO-NOT-DELETE splicer.end(myStack.Stack.push) */
  }
}

/*
 * Method:  pop[]
 */

#undef __FUNC__
#define __FUNC__ "impl_myStack_Stack_pop"

#ifdef __cplusplus
extern "C"
#endif
void
impl_myStack_Stack_pop(
  /* in */ myStack_Stack self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(myStack.Stack.pop) */
   struct myStack_Stack__data *dptr = myStack_Stack__get_data(self);

	if(dptr->node)
	{
		struct Node *tmp = dptr->node;
		printf("About to POP from a non-empty stack...\n");
		tmp->top--;
		//tmp->data[tmp->top];	
	}

	else
	printf("Can't pop from an empty stack...\n");
    /* DO-NOT-DELETE splicer.end(myStack.Stack.pop) */
  }
}

/*
 * Method:  full[]
 */

#undef __FUNC__
#define __FUNC__ "impl_myStack_Stack_full"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_myStack_Stack_full(
  /* in */ myStack_Stack self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(myStack.Stack.full) */
   struct myStack_Stack__data *dptr = myStack_Stack__get_data(self);

	return (dptr->node->top >= 10); 
    /* DO-NOT-DELETE splicer.end(myStack.Stack.full) */
  }
}

/*
 * Method:  display[]
 */

#undef __FUNC__
#define __FUNC__ "impl_myStack_Stack_display"

#ifdef __cplusplus
extern "C"
#endif
void
impl_myStack_Stack_display(
  /* in */ myStack_Stack self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(myStack.Stack.display) */
    /* insert code here (display) */
    /* DO-NOT-DELETE splicer.end(myStack.Stack.display) */
  }
}
/* Babel internal methods, Users should not edit below this line. */

/* DO-NOT-DELETE splicer.begin(_misc) */
/* insert code here (miscellaneous code) */
/* DO-NOT-DELETE splicer.end(_misc) */

