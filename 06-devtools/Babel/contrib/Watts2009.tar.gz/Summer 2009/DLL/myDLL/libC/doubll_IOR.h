/*
 * File:          doubll_IOR.h
 * Symbol:        doubll-v1.0
 * Symbol Type:   package
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Intermediate Object Representation for doubll
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 */

#ifndef included_doubll_IOR_h
#define included_doubll_IOR_h

/*
 * Symbol "doubll" (version 1.0)
 */

#ifndef included_doubll_Dll_IOR_h
#include "doubll_Dll_IOR.h"
#endif
#ifndef included_doubll_Iterator_IOR_h
#include "doubll_Iterator_IOR.h"
#endif
#ifndef included_doubll_List_IOR_h
#include "doubll_List_IOR.h"
#endif

#endif
