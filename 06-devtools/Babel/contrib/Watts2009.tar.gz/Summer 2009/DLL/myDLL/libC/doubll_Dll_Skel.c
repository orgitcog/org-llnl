/*
 * File:          doubll_Dll_Skel.c
 * Symbol:        doubll.Dll-v1.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side glue code for doubll.Dll
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 */

#include "doubll_Dll_IOR.h"
#include "doubll_Dll.h"
#include <stddef.h>

#ifdef WITH_RMI
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_doubll_Dll_h
#include "doubll_Dll.h"
#endif
#endif /* WITH_RMI */
extern
void
impl_doubll_Dll__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_doubll_Dll__ctor(
  /* in */ doubll_Dll self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_doubll_Dll__ctor2(
  /* in */ doubll_Dll self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_doubll_Dll__dtor(
  /* in */ doubll_Dll self,
  /* out */ sidl_BaseInterface *_ex);

#ifdef WITH_RMI
extern struct sidl_BaseInterface__object* 
  impl_doubll_Dll_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct doubll_Dll__object* impl_doubll_Dll_fconnect_doubll_Dll(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/
extern
doubll_Iterator
impl_doubll_Dll_getItr(
  /* in */ doubll_Dll self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_doubll_Dll_addbefore(
  /* in */ doubll_Dll self,
  /* in */ sidl_BaseInterface i,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_doubll_Dll_addafter(
  /* in */ doubll_Dll self,
  /* in */ sidl_BaseInterface i,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_doubll_Dll_remove(
  /* in */ doubll_Dll self,
  /* in */ sidl_BaseInterface i,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_doubll_Dll_search(
  /* in */ doubll_Dll self,
  /* in */ sidl_BaseInterface i,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_doubll_Dll_size(
  /* in */ doubll_Dll self,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_BaseInterface
impl_doubll_Dll_GetNth(
  /* in */ doubll_Dll self,
  /* in */ int32_t n,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_doubll_Dll_InsertNth(
  /* in */ doubll_Dll self,
  /* in */ int32_t n,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_doubll_Dll_Append(
  /* in */ doubll_Dll self,
  /* in */ doubll_Dll A,
  /* in */ doubll_Dll B,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_doubll_Dll_show(
  /* in */ doubll_Dll self,
  /* out */ sidl_BaseInterface *_ex);

#ifdef WITH_RMI
extern struct sidl_BaseInterface__object* 
  impl_doubll_Dll_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct doubll_Dll__object* impl_doubll_Dll_fconnect_doubll_Dll(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/
#ifdef __cplusplus
extern "C" {
#endif

void
doubll_Dll__set_epv(struct doubll_Dll__epv *epv,
  struct doubll_Dll__pre_epv *pre_epv, 
  struct doubll_Dll__post_epv *post_epv
)
{
  epv->f__ctor = impl_doubll_Dll__ctor;
  epv->f__ctor2 = impl_doubll_Dll__ctor2;
  epv->f__dtor = impl_doubll_Dll__dtor;
  pre_epv->f_getItr_pre = NULL;
  epv->f_getItr = impl_doubll_Dll_getItr;
  post_epv->f_getItr_post = NULL;
  pre_epv->f_addbefore_pre = NULL;
  epv->f_addbefore = impl_doubll_Dll_addbefore;
  post_epv->f_addbefore_post = NULL;
  pre_epv->f_addafter_pre = NULL;
  epv->f_addafter = impl_doubll_Dll_addafter;
  post_epv->f_addafter_post = NULL;
  pre_epv->f_remove_pre = NULL;
  epv->f_remove = impl_doubll_Dll_remove;
  post_epv->f_remove_post = NULL;
  pre_epv->f_search_pre = NULL;
  epv->f_search = impl_doubll_Dll_search;
  post_epv->f_search_post = NULL;
  pre_epv->f_size_pre = NULL;
  epv->f_size = impl_doubll_Dll_size;
  post_epv->f_size_post = NULL;
  pre_epv->f_GetNth_pre = NULL;
  epv->f_GetNth = impl_doubll_Dll_GetNth;
  post_epv->f_GetNth_post = NULL;
  pre_epv->f_InsertNth_pre = NULL;
  epv->f_InsertNth = impl_doubll_Dll_InsertNth;
  post_epv->f_InsertNth_post = NULL;
  pre_epv->f_Append_pre = NULL;
  epv->f_Append = impl_doubll_Dll_Append;
  post_epv->f_Append_post = NULL;
  pre_epv->f_show_pre = NULL;
  epv->f_show = impl_doubll_Dll_show;
  post_epv->f_show_post = NULL;

}
#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
extern "C" {
#endif

void doubll_Dll__call_load(void) { 
  sidl_BaseInterface _throwaway_exception = NULL;
  impl_doubll_Dll__load(&_throwaway_exception);
}
#ifdef WITH_RMI
struct sidl_BaseInterface__object* skel_doubll_Dll_fconnect_sidl_BaseInterface(
  const char* url, sidl_bool ar, sidl_BaseInterface *_ex) { 
  return sidl_BaseInterface__connectI(url, ar, _ex);
}

struct doubll_Dll__object* skel_doubll_Dll_fconnect_doubll_Dll(const char* url, 
  sidl_bool ar, sidl_BaseInterface *_ex) { 
  return doubll_Dll__connectI(url, ar, _ex);
}

#endif /*WITH_RMI*/
struct doubll_Dll__data*
doubll_Dll__get_data(doubll_Dll self)
{
  return (struct doubll_Dll__data*)(self ? self->d_data : NULL);
}

void doubll_Dll__set_data(
  doubll_Dll self,
  struct doubll_Dll__data* data)
{
  if (self) {
    self->d_data = data;
  }
}
#ifdef __cplusplus
}
#endif
