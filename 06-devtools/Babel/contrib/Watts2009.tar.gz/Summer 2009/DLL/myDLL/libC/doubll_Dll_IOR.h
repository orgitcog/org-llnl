/*
 * File:          doubll_Dll_IOR.h
 * Symbol:        doubll.Dll-v1.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Intermediate Object Representation for doubll.Dll
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 */

#ifndef included_doubll_Dll_IOR_h
#define included_doubll_Dll_IOR_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
struct sidl_rmi_InstanceHandle__object;
#ifndef included_doubll_List_IOR_h
#include "doubll_List_IOR.h"
#endif
#ifndef included_sidl_BaseClass_IOR_h
#include "sidl_BaseClass_IOR.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Symbol "doubll.Dll" (version 1.0)
 */

struct doubll_Dll__array;
struct doubll_Dll__object;

/*
 * Forward references for external classes and interfaces.
 */

struct doubll_Iterator__array;
struct doubll_Iterator__object;
struct sidl_BaseException__array;
struct sidl_BaseException__object;
struct sidl_BaseInterface__array;
struct sidl_BaseInterface__object;
struct sidl_ClassInfo__array;
struct sidl_ClassInfo__object;
struct sidl_RuntimeException__array;
struct sidl_RuntimeException__object;
struct sidl_rmi_Call__array;
struct sidl_rmi_Call__object;
struct sidl_rmi_Return__array;
struct sidl_rmi_Return__object;

/*
 * Declare the method entry point vector.
 */

struct doubll_Dll__epv {
  /* Implicit builtin methods */
  /* 0 */
  void* (*f__cast)(
    /* in */ struct doubll_Dll__object* self,
    /* in */ const char* name,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 1 */
  void (*f__delete)(
    /* in */ struct doubll_Dll__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 2 */
  void (*f__exec)(
    /* in */ struct doubll_Dll__object* self,
    /* in */ const char* methodName,
    /* in */ struct sidl_rmi_Call__object* inArgs,
    /* in */ struct sidl_rmi_Return__object* outArgs,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 3 */
  char* (*f__getURL)(
    /* in */ struct doubll_Dll__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 4 */
  void (*f__raddRef)(
    /* in */ struct doubll_Dll__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 5 */
  sidl_bool (*f__isRemote)(
    /* in */ struct doubll_Dll__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 6 */
  void (*f__set_hooks)(
    /* in */ struct doubll_Dll__object* self,
    /* in */ sidl_bool enable,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 7 */
  void (*f__set_contracts)(
    /* in */ struct doubll_Dll__object* self,
    /* in */ sidl_bool enable,
    /* in */ const char* enfFilename,
    /* in */ sidl_bool resetCounters,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 8 */
  void (*f__dump_stats)(
    /* in */ struct doubll_Dll__object* self,
    /* in */ const char* filename,
    /* in */ const char* prefix,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 9 */
  void (*f__ctor)(
    /* in */ struct doubll_Dll__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 10 */
  void (*f__ctor2)(
    /* in */ struct doubll_Dll__object* self,
    /* in */ void* private_data,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 11 */
  void (*f__dtor)(
    /* in */ struct doubll_Dll__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 12 */
  void (*f__load)(
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* Methods introduced in sidl.BaseInterface-v0.9.17 */
  void (*f_addRef)(
    /* in */ struct doubll_Dll__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_deleteRef)(
    /* in */ struct doubll_Dll__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  sidl_bool (*f_isSame)(
    /* in */ struct doubll_Dll__object* self,
    /* in */ struct sidl_BaseInterface__object* iobj,
    /* out */ struct sidl_BaseInterface__object **_ex);
  sidl_bool (*f_isType)(
    /* in */ struct doubll_Dll__object* self,
    /* in */ const char* name,
    /* out */ struct sidl_BaseInterface__object **_ex);
  struct sidl_ClassInfo__object* (*f_getClassInfo)(
    /* in */ struct doubll_Dll__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* Methods introduced in sidl.BaseClass-v0.9.17 */
  /* Methods introduced in doubll.List-v1.0 */
  struct doubll_Iterator__object* (*f_getItr)(
    /* in */ struct doubll_Dll__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_addbefore)(
    /* in */ struct doubll_Dll__object* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_addafter)(
    /* in */ struct doubll_Dll__object* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_remove)(
    /* in */ struct doubll_Dll__object* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_search)(
    /* in */ struct doubll_Dll__object* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  int32_t (*f_size)(
    /* in */ struct doubll_Dll__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  struct sidl_BaseInterface__object* (*f_GetNth)(
    /* in */ struct doubll_Dll__object* self,
    /* in */ int32_t n,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_InsertNth)(
    /* in */ struct doubll_Dll__object* self,
    /* in */ int32_t n,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_Append)(
    /* in */ struct doubll_Dll__object* self,
    /* in */ struct doubll_Dll__object* A,
    /* in */ struct doubll_Dll__object* B,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_show)(
    /* in */ struct doubll_Dll__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* Methods introduced in doubll.Dll-v1.0 */
};

/*
 * Declare the method pre hooks entry point vector.
 */

struct doubll_Dll__pre_epv {
  void (*f_getItr_pre)(
    /* in */ struct doubll_Dll__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_addbefore_pre)(
    /* in */ struct doubll_Dll__object* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_addafter_pre)(
    /* in */ struct doubll_Dll__object* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_remove_pre)(
    /* in */ struct doubll_Dll__object* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_search_pre)(
    /* in */ struct doubll_Dll__object* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_size_pre)(
    /* in */ struct doubll_Dll__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_GetNth_pre)(
    /* in */ struct doubll_Dll__object* self,
    /* in */ int32_t n,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_InsertNth_pre)(
    /* in */ struct doubll_Dll__object* self,
    /* in */ int32_t n,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_Append_pre)(
    /* in */ struct doubll_Dll__object* self,
    /* in */ struct doubll_Dll__object* A,
    /* in */ struct doubll_Dll__object* B,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_show_pre)(
    /* in */ struct doubll_Dll__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
};

/*
 * Declare the method post hooks entry point vector.
 */

struct doubll_Dll__post_epv {
  void (*f_getItr_post)(
    /* in */ struct doubll_Dll__object* self,
    /* in */ struct doubll_Iterator__object* _retval,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_addbefore_post)(
    /* in */ struct doubll_Dll__object* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_addafter_post)(
    /* in */ struct doubll_Dll__object* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_remove_post)(
    /* in */ struct doubll_Dll__object* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_search_post)(
    /* in */ struct doubll_Dll__object* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_size_post)(
    /* in */ struct doubll_Dll__object* self,
    /* in */ int32_t _retval,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_GetNth_post)(
    /* in */ struct doubll_Dll__object* self,
    /* in */ int32_t n,
    /* in */ struct sidl_BaseInterface__object* _retval,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_InsertNth_post)(
    /* in */ struct doubll_Dll__object* self,
    /* in */ int32_t n,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_Append_post)(
    /* in */ struct doubll_Dll__object* self,
    /* in */ struct doubll_Dll__object* A,
    /* in */ struct doubll_Dll__object* B,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_show_post)(
    /* in */ struct doubll_Dll__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
};

/*
 * Define the controls and statistics structure.
 */


struct doubll_Dll__cstats {
  sidl_bool use_hooks;
};

/*
 * Define the class object structure.
 */

struct doubll_Dll__object {
  struct sidl_BaseClass__object d_sidl_baseclass;
  struct doubll_List__object    d_doubll_list;
  struct doubll_Dll__epv*       d_epv;
  struct doubll_Dll__cstats     d_cstats;
  void*                         d_data;
};

struct doubll_Dll__external {
  struct doubll_Dll__object*
  (*createObject)(void* ddata, struct sidl_BaseInterface__object **_ex);

  struct sidl_BaseClass__epv*(*getSuperEPV)(void);
  int d_ior_major_version;
  int d_ior_minor_version;
};

/*
 * This function returns a pointer to a static structure of
 * pointers to function entry points.  Its purpose is to provide
 * one-stop shopping for loading DLLs.
 */

const struct doubll_Dll__external*
doubll_Dll__externals(void);

extern struct doubll_Dll__object*
doubll_Dll__createObject(void* ddata,struct sidl_BaseInterface__object ** _ex);

extern void doubll_Dll__init(
  struct doubll_Dll__object* self, void* ddata, struct 
    sidl_BaseInterface__object ** _ex);

extern void doubll_Dll__getEPVs(
  struct sidl_BaseInterface__epv **s_arg_epv__sidl_baseinterface,
  struct sidl_BaseClass__epv **s_arg_epv__sidl_baseclass,
  struct doubll_List__epv **s_arg_epv__doubll_list,
  struct doubll_List__epv **s_arg_epv_hooks__doubll_list,
  struct doubll_Dll__epv **s_arg_epv__doubll_dll,
  struct doubll_Dll__epv **s_arg_epv_hooks__doubll_dll);

extern void doubll_Dll__fini(
  struct doubll_Dll__object* self, struct sidl_BaseInterface__object ** _ex);

extern void doubll_Dll__IOR_version(int32_t *major, int32_t *minor);

struct sidl_BaseInterface__object* skel_doubll_Dll_fconnect_sidl_BaseInterface(
  const char* url, sidl_bool ar, struct sidl_BaseInterface__object * *_ex);
struct doubll_Dll__object* skel_doubll_Dll_fconnect_doubll_Dll(const char* url, 
  sidl_bool ar, struct sidl_BaseInterface__object * *_ex);
struct doubll_Dll__remote{
  int d_refcount;
  struct sidl_rmi_InstanceHandle__object *d_ih;
};

#ifdef __cplusplus
}
#endif
#endif
