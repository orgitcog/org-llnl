/*
 * File:          doubll_List_IOR.h
 * Symbol:        doubll.List-v1.0
 * Symbol Type:   interface
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Intermediate Object Representation for doubll.List
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 */

#ifndef included_doubll_List_IOR_h
#define included_doubll_List_IOR_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
struct sidl_rmi_InstanceHandle__object;
#ifndef included_sidl_BaseInterface_IOR_h
#include "sidl_BaseInterface_IOR.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Symbol "doubll.List" (version 1.0)
 */

struct doubll_List__array;
struct doubll_List__object;

/*
 * Forward references for external classes and interfaces.
 */

struct doubll_Dll__array;
struct doubll_Dll__object;
struct doubll_Iterator__array;
struct doubll_Iterator__object;
struct sidl_BaseException__array;
struct sidl_BaseException__object;
struct sidl_ClassInfo__array;
struct sidl_ClassInfo__object;
struct sidl_RuntimeException__array;
struct sidl_RuntimeException__object;
struct sidl_rmi_Call__array;
struct sidl_rmi_Call__object;
struct sidl_rmi_Return__array;
struct sidl_rmi_Return__object;

/*
 * Declare the method entry point vector.
 */

struct doubll_List__epv {
  /* Implicit builtin methods */
  /* 0 */
  void* (*f__cast)(
    /* in */ void* self,
    /* in */ const char* name,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 1 */
  void (*f__delete)(
    /* in */ void* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 2 */
  void (*f__exec)(
    /* in */ void* self,
    /* in */ const char* methodName,
    /* in */ struct sidl_rmi_Call__object* inArgs,
    /* in */ struct sidl_rmi_Return__object* outArgs,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 3 */
  char* (*f__getURL)(
    /* in */ void* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 4 */
  void (*f__raddRef)(
    /* in */ void* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 5 */
  sidl_bool (*f__isRemote)(
    /* in */ void* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 6 */
  void (*f__set_hooks)(
    /* in */ void* self,
    /* in */ sidl_bool enable,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 7 */
  void (*f__set_contracts)(
    /* in */ void* self,
    /* in */ sidl_bool enable,
    /* in */ const char* enfFilename,
    /* in */ sidl_bool resetCounters,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 8 */
  void (*f__dump_stats)(
    /* in */ void* self,
    /* in */ const char* filename,
    /* in */ const char* prefix,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* Methods introduced in sidl.BaseInterface-v0.9.17 */
  void (*f_addRef)(
    /* in */ void* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_deleteRef)(
    /* in */ void* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  sidl_bool (*f_isSame)(
    /* in */ void* self,
    /* in */ struct sidl_BaseInterface__object* iobj,
    /* out */ struct sidl_BaseInterface__object **_ex);
  sidl_bool (*f_isType)(
    /* in */ void* self,
    /* in */ const char* name,
    /* out */ struct sidl_BaseInterface__object **_ex);
  struct sidl_ClassInfo__object* (*f_getClassInfo)(
    /* in */ void* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* Methods introduced in doubll.List-v1.0 */
  struct doubll_Iterator__object* (*f_getItr)(
    /* in */ void* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_addbefore)(
    /* in */ void* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_addafter)(
    /* in */ void* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_remove)(
    /* in */ void* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_search)(
    /* in */ void* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  int32_t (*f_size)(
    /* in */ void* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  struct sidl_BaseInterface__object* (*f_GetNth)(
    /* in */ void* self,
    /* in */ int32_t n,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_InsertNth)(
    /* in */ void* self,
    /* in */ int32_t n,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_Append)(
    /* in */ void* self,
    /* in */ struct doubll_Dll__object* A,
    /* in */ struct doubll_Dll__object* B,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_show)(
    /* in */ void* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
};

/*
 * Declare the method pre hooks entry point vector.
 */

struct doubll_List__pre_epv {
  void (*f_getItr_pre)(
    /* in */ void* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_addbefore_pre)(
    /* in */ void* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_addafter_pre)(
    /* in */ void* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_remove_pre)(
    /* in */ void* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_search_pre)(
    /* in */ void* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_size_pre)(
    /* in */ void* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_GetNth_pre)(
    /* in */ void* self,
    /* in */ int32_t n,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_InsertNth_pre)(
    /* in */ void* self,
    /* in */ int32_t n,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_Append_pre)(
    /* in */ void* self,
    /* in */ struct doubll_Dll__object* A,
    /* in */ struct doubll_Dll__object* B,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_show_pre)(
    /* in */ void* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
};

/*
 * Declare the method post hooks entry point vector.
 */

struct doubll_List__post_epv {
  void (*f_getItr_post)(
    /* in */ void* self,
    /* in */ struct doubll_Iterator__object* _retval,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_addbefore_post)(
    /* in */ void* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_addafter_post)(
    /* in */ void* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_remove_post)(
    /* in */ void* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_search_post)(
    /* in */ void* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_size_post)(
    /* in */ void* self,
    /* in */ int32_t _retval,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_GetNth_post)(
    /* in */ void* self,
    /* in */ int32_t n,
    /* in */ struct sidl_BaseInterface__object* _retval,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_InsertNth_post)(
    /* in */ void* self,
    /* in */ int32_t n,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_Append_post)(
    /* in */ void* self,
    /* in */ struct doubll_Dll__object* A,
    /* in */ struct doubll_Dll__object* B,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_show_post)(
    /* in */ void* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
};

/*
 * Define the interface object structure.
 */

struct doubll_List__object {
  struct doubll_List__epv* d_epv;
  void*                    d_object;
};

/**
 * 
 * 
 * Anonymous class definition
 * 
 * 
 */
/*
 * Symbol "doubll._List" (version 1.0)
 */

struct doubll__List__array;
struct doubll__List__object;

/*
 * Declare the method entry point vector.
 */

struct doubll__List__epv {
  /* Implicit builtin methods */
  void* (*f__cast)(
    /* in */ struct doubll__List__object* self,
    /* in */ const char* name,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f__delete)(
    /* in */ struct doubll__List__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f__exec)(
    /* in */ struct doubll__List__object* self,
    /* in */ const char* methodName,
    /* in */ struct sidl_rmi_Call__object* inArgs,
    /* in */ struct sidl_rmi_Return__object* outArgs,
    /* out */ struct sidl_BaseInterface__object **_ex);
  char* (*f__getURL)(
    /* in */ struct doubll__List__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f__raddRef)(
    /* in */ struct doubll__List__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  sidl_bool (*f__isRemote)(
    /* in */ struct doubll__List__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f__set_hooks)(
    /* in */ struct doubll__List__object* self,
    /* in */ sidl_bool enable,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f__set_contracts)(
    /* in */ struct doubll__List__object* self,
    /* in */ sidl_bool enable,
    /* in */ const char* enfFilename,
    /* in */ sidl_bool resetCounters,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f__dump_stats)(
    /* in */ struct doubll__List__object* self,
    /* in */ const char* filename,
    /* in */ const char* prefix,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f__ctor)(
    /* in */ struct doubll__List__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f__ctor2)(
    /* in */ struct doubll__List__object* self,
    /* in */ void* private_data,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f__dtor)(
    /* in */ struct doubll__List__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* Methods introduced in sidl.BaseInterface-v0.9.17 */
  void (*f_addRef)(
    /* in */ struct doubll__List__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_deleteRef)(
    /* in */ struct doubll__List__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  sidl_bool (*f_isSame)(
    /* in */ struct doubll__List__object* self,
    /* in */ struct sidl_BaseInterface__object* iobj,
    /* out */ struct sidl_BaseInterface__object **_ex);
  sidl_bool (*f_isType)(
    /* in */ struct doubll__List__object* self,
    /* in */ const char* name,
    /* out */ struct sidl_BaseInterface__object **_ex);
  struct sidl_ClassInfo__object* (*f_getClassInfo)(
    /* in */ struct doubll__List__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* Methods introduced in doubll.List-v1.0 */
  struct doubll_Iterator__object* (*f_getItr)(
    /* in */ struct doubll__List__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_addbefore)(
    /* in */ struct doubll__List__object* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_addafter)(
    /* in */ struct doubll__List__object* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_remove)(
    /* in */ struct doubll__List__object* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_search)(
    /* in */ struct doubll__List__object* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  int32_t (*f_size)(
    /* in */ struct doubll__List__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  struct sidl_BaseInterface__object* (*f_GetNth)(
    /* in */ struct doubll__List__object* self,
    /* in */ int32_t n,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_InsertNth)(
    /* in */ struct doubll__List__object* self,
    /* in */ int32_t n,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_Append)(
    /* in */ struct doubll__List__object* self,
    /* in */ struct doubll_Dll__object* A,
    /* in */ struct doubll_Dll__object* B,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_show)(
    /* in */ struct doubll__List__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* Methods introduced in doubll._List-v1.0 */
};

/*
 * Define the controls and statistics structure.
 */


struct doubll__List__cstats {
  sidl_bool use_hooks;
};

/*
 * Define the class object structure.
 */

struct doubll__List__object {
  struct doubll_List__object        d_doubll_list;
  struct sidl_BaseInterface__object d_sidl_baseinterface;
  struct doubll__List__epv*         d_epv;
  void*                             d_data;
};


struct doubll__List__remote{
  int d_refcount;
  struct sidl_rmi_InstanceHandle__object *d_ih;
};

#ifdef __cplusplus
}
#endif
#endif
