/*
 * File:          doubll_Dll_Impl.h
 * Symbol:        doubll.Dll-v1.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for doubll.Dll
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#ifndef included_doubll_Dll_Impl_h
#define included_doubll_Dll_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_doubll_Dll_h
#include "doubll_Dll.h"
#endif
#ifndef included_doubll_Iterator_h
#include "doubll_Iterator.h"
#endif
#ifndef included_doubll_List_h
#include "doubll_List.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_RuntimeException_h
#include "sidl_RuntimeException.h"
#endif
/* DO-NOT-DELETE splicer.begin(doubll.Dll._hincludes) */
struct List{
	sidl_BaseInterface data;
	struct List *next;
	struct List *prev;
};

/* DO-NOT-DELETE splicer.end(doubll.Dll._hincludes) */

/*
 * Private data for class doubll.Dll
 */

struct doubll_Dll__data {
  /* DO-NOT-DELETE splicer.begin(doubll.Dll._data) */
  /* insert code here (private data members) */
int32_t size;
struct List *list;
  /* DO-NOT-DELETE splicer.end(doubll.Dll._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct doubll_Dll__data*
doubll_Dll__get_data(
  doubll_Dll);

extern void
doubll_Dll__set_data(
  doubll_Dll,
  struct doubll_Dll__data*);

extern
void
impl_doubll_Dll__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_doubll_Dll__ctor(
  /* in */ doubll_Dll self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_doubll_Dll__ctor2(
  /* in */ doubll_Dll self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_doubll_Dll__dtor(
  /* in */ doubll_Dll self,
  /* out */ sidl_BaseInterface *_ex);

/*
 * User-defined object methods
 */

#ifdef WITH_RMI
extern struct sidl_BaseInterface__object* 
  impl_doubll_Dll_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct doubll_Dll__object* impl_doubll_Dll_fconnect_doubll_Dll(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/
extern
doubll_Iterator
impl_doubll_Dll_getItr(
  /* in */ doubll_Dll self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_doubll_Dll_addbefore(
  /* in */ doubll_Dll self,
  /* in */ sidl_BaseInterface i,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_doubll_Dll_addafter(
  /* in */ doubll_Dll self,
  /* in */ sidl_BaseInterface i,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_doubll_Dll_remove(
  /* in */ doubll_Dll self,
  /* in */ sidl_BaseInterface i,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_doubll_Dll_search(
  /* in */ doubll_Dll self,
  /* in */ sidl_BaseInterface i,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_doubll_Dll_size(
  /* in */ doubll_Dll self,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_BaseInterface
impl_doubll_Dll_GetNth(
  /* in */ doubll_Dll self,
  /* in */ int32_t n,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_doubll_Dll_InsertNth(
  /* in */ doubll_Dll self,
  /* in */ int32_t n,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_doubll_Dll_Append(
  /* in */ doubll_Dll self,
  /* in */ doubll_Dll A,
  /* in */ doubll_Dll B,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_doubll_Dll_show(
  /* in */ doubll_Dll self,
  /* out */ sidl_BaseInterface *_ex);

#ifdef WITH_RMI
extern struct sidl_BaseInterface__object* 
  impl_doubll_Dll_fconnect_sidl_BaseInterface(const char* url, sidl_bool ar, 
  sidl_BaseInterface *_ex);
extern struct doubll_Dll__object* impl_doubll_Dll_fconnect_doubll_Dll(const 
  char* url, sidl_bool ar, sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/

/* DO-NOT-DELETE splicer.begin(_hmisc) */
/* insert code here (miscellaneous things) */
/* DO-NOT-DELETE splicer.end(_hmisc) */

#ifdef __cplusplus
}
#endif
#endif
