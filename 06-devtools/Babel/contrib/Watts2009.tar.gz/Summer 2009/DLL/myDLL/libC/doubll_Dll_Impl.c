/*
 * File:          doubll_Dll_Impl.c
 * Symbol:        doubll.Dll-v1.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for doubll.Dll
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "doubll.Dll" (version 1.0)
 */

#include "doubll_Dll_Impl.h"
#include "sidl_NotImplementedException.h"
#include "sidl_Exception.h"
#ifndef included_sidl_MemAllocException_h
#include "sidl_MemAllocException.h"
#endif

/* DO-NOT-DELETE splicer.begin(doubll.Dll._includes) */
/* insert code here (includes and arbitrary code) */
/* DO-NOT-DELETE splicer.end(doubll.Dll._includes) */

#define SIDL_IOR_MAJOR_VERSION 2
#define SIDL_IOR_MINOR_VERSION 0
/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_doubll_Dll__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_doubll_Dll__load(
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(doubll.Dll._load) */
    /* insert code here (static class initializer) */
    /* DO-NOT-DELETE splicer.end(doubll.Dll._load) */
  }
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_doubll_Dll__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_doubll_Dll__ctor(
  /* in */ doubll_Dll self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(doubll.Dll._ctor) */
    
      // boilerplate constructor
      struct doubll_Dll__data *dptr = (struct doubll_Dll__data*)malloc(sizeof(struct doubll_Dll__data));
      if (dptr) {
        memset(dptr, 0, sizeof(struct doubll_Dll__data));
        // initialize elements of dptr here
      doubll_Dll__set_data(self, dptr);
      } else {
        sidl_MemAllocException ex = sidl_MemAllocException_getSingletonException(_ex);
        SIDL_CHECK(*_ex);
        sidl_MemAllocException_setNote(ex, "Out of memory.", _ex); SIDL_CHECK(*_ex);
        sidl_MemAllocException_add(ex, __FILE__, __LINE__, "doubll.Dll._ctor", _ex);
        SIDL_CHECK(*_ex);
        *_ex = (sidl_BaseInterface)ex;
      }
      EXIT:;
     

    /* DO-NOT-DELETE splicer.end(doubll.Dll._ctor) */
  }
}

/*
 * Special Class constructor called when the user wants to wrap his own private data.
 */

#undef __FUNC__
#define __FUNC__ "impl_doubll_Dll__ctor2"

#ifdef __cplusplus
extern "C"
#endif
void
impl_doubll_Dll__ctor2(
  /* in */ doubll_Dll self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(doubll.Dll._ctor2) */
    /* insert code here (special constructor) */
    /* DO-NOT-DELETE splicer.end(doubll.Dll._ctor2) */
  }
}
/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_doubll_Dll__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_doubll_Dll__dtor(
  /* in */ doubll_Dll self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(doubll.Dll._dtor) */
    /*
     * // boilerplate destructor
     * struct doubll_Dll__data *dptr = doubll_Dll__get_data(self);
     * if (dptr) {
     *   // free contained in dtor before next line
     *   free(dptr);
     *   doubll_Dll__set_data(self, NULL);
     * }
     */

    /* DO-NOT-DELETE splicer.end(doubll.Dll._dtor) */
  }
}

/*
 * Method:  getItr[]
 */

#undef __FUNC__
#define __FUNC__ "impl_doubll_Dll_getItr"

#ifdef __cplusplus
extern "C"
#endif
doubll_Iterator
impl_doubll_Dll_getItr(
  /* in */ doubll_Dll self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(doubll.Dll.getItr) */
    /* insert code here (getItr) */
    /* DO-NOT-DELETE splicer.end(doubll.Dll.getItr) */
  }
}

/*
 * Method:  addbefore[]
 */

#undef __FUNC__
#define __FUNC__ "impl_doubll_Dll_addbefore"

#ifdef __cplusplus
extern "C"
#endif
void
impl_doubll_Dll_addbefore(
  /* in */ doubll_Dll self,
  /* in */ sidl_BaseInterface i,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(doubll.Dll.addbefore) */
     
    /* DO-NOT-DELETE splicer.end(doubll.Dll.addbefore) */
  }
}

/*
 * Method:  addafter[]
 */

#undef __FUNC__
#define __FUNC__ "impl_doubll_Dll_addafter"

#ifdef __cplusplus
extern "C"
#endif
void
impl_doubll_Dll_addafter(
  /* in */ doubll_Dll self,
  /* in */ sidl_BaseInterface i,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(doubll.Dll.addafter) */
  struct doubll_Dll__data *dptr = doubll_Dll__get_data(self);
  if(dptr){
	dptr->size = dptr->size + 1;
	if(dptr->list){
		struct List *tmp = dptr->list;
		while(tmp->next)
		{
		  if(tmp->data = i)
	  	{
			printf("Found the item, now adding another.\n");
			tmp->next = (struct List *)malloc(sizeof(struct List));
			tmp->next->data = i;
			tmp->prev = tmp->next;
			tmp->next->next = NULL;
		}
		tmp = tmp->next;
	}
		if(tmp->next == NULL)
		{
			printf("Didn't find the item, now adding to the tail..\n");
			tmp->next = (struct List *)malloc(sizeof(struct List));
			tmp->next->data = i;
			tmp->prev->prev = tmp->prev;	
			tmp->next->next = NULL;					
		}

		}
		}
		
	else 
	{
		printf("Empty list, now adding item to head.\n");
		dptr->list = (struct List *)malloc(sizeof(struct List));
		dptr->list->prev = NULL;
		dptr->list->next= NULL;
		dptr->list->data = i;	
	}
}
	
    /* DO-NOT-DELETE splicer.end(doubll.Dll.addafter) */
  }
/*
 * Method:  remove[]
 */

#undef __FUNC__
#define __FUNC__ "impl_doubll_Dll_remove"

#ifdef __cplusplus
extern "C"
#endif
void
impl_doubll_Dll_remove(
  /* in */ doubll_Dll self,
  /* in */ sidl_BaseInterface i,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(doubll.Dll.remove) */
   	struct doubll_Dll__data *dptr = doubll_Dll__get_data(self);
		if(dptr->list){
		struct List *tmp = dptr->list;
			while(tmp->next){
				if(tmp->data = i){
					printf("Found the item to remove, now removing\n");
					tmp->prev->data = tmp->next->data;								
				}
			}		
		}
    /* DO-NOT-DELETE splicer.end(doubll.Dll.remove) */
  }
}

/*
 * Method:  search[]
 */

#undef __FUNC__
#define __FUNC__ "impl_doubll_Dll_search"

#ifdef __cplusplus
extern "C"
#endif
void
impl_doubll_Dll_search(
  /* in */ doubll_Dll self,
  /* in */ sidl_BaseInterface i,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(doubll.Dll.search) */
	struct doubll_Dll__data *dptr = doubll_Dll__get_data(self);
	struct List *tmp = dptr->list;
	while(tmp)
	{
		if(((i == NULL) && (tmp->data == NULL)) ||
		((i != NULL) && sidl_BaseInterface_isSame(i, tmp->data,_ex))){
			printf("Item found, HOORAY!\n");
			return 0;
		}
	tmp = tmp->next;
	}
	printf("Search failed, item not found.\n");
	return 0;
	
    /* DO-NOT-DELETE splicer.end(doubll.Dll.search) */
  }
}

/*
 * Method:  size[]
 */

#undef __FUNC__
#define __FUNC__ "impl_doubll_Dll_size"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_doubll_Dll_size(
  /* in */ doubll_Dll self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(doubll.Dll.size) */
    struct doubll_Dll__data *dptr = doubll_Dll__get_data(self);
    struct List *li = dptr->list;

	int32_t s = dptr->size;
	return s;
    /* DO-NOT-DELETE splicer.end(doubll.Dll.size) */
  }
}

/*
 * Method:  GetNth[]
 */

#undef __FUNC__
#define __FUNC__ "impl_doubll_Dll_GetNth"

#ifdef __cplusplus
extern "C"
#endif
sidl_BaseInterface
impl_doubll_Dll_GetNth(
  /* in */ doubll_Dll self,
  /* in */ int32_t n,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(doubll.Dll.GetNth) */
   struct doubll_Dll__data * dptr = doubll_Dll__get_data(self);
   
	if(dptr->list){
		struct List *tmp = dptr->list;
		int32_t i = 0;
		for(i; i <= n; i++){
			if(i = n){
			printf("Data for Nth item in stack: %s", tmp->data); 
 			}
			tmp = tmp->next;
		}
	}
    /* DO-NOT-DELETE splicer.end(doubll.Dll.GetNth) */
  }
}

/*
 * Method:  InsertNth[]
 */

#undef __FUNC__
#define __FUNC__ "impl_doubll_Dll_InsertNth"

#ifdef __cplusplus
extern "C"
#endif
void
impl_doubll_Dll_InsertNth(
  /* in */ doubll_Dll self,
  /* in */ int32_t n,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(doubll.Dll.InsertNth) */
    
    /* DO-NOT-DELETE splicer.end(doubll.Dll.InsertNth) */
  }
}

/*
 * Method:  Append[]
 */

#undef __FUNC__
#define __FUNC__ "impl_doubll_Dll_Append"

#ifdef __cplusplus
extern "C"
#endif
void
impl_doubll_Dll_Append(
  /* in */ doubll_Dll self,
  /* in */ doubll_Dll A,
  /* in */ doubll_Dll B,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(doubll.Dll.Append) */
	struct doubll_Dll__data *dptr = doubll_Dll__get_data(A);
	struct doubll_Dll__data *dptr2 = doubll_Dll__get_data(B);

	struct List *l = dptr->list;
	struct List *l2 = dptr2->list;		

	if(!dptr->list || !dptr2->list)
	{
		printf("Sorry, one of the lists were empty...cannot append.\n");
	}
	    
	else{
		while(l->next)
		{	
			l = l->next;
		}		
		
	//l->next = l2;
	
	}

	//*l2 = NULL;
    /* DO-NOT-DELETE splicer.end(doubll.Dll.Append) */
  }
}

/*
 * Method:  show[]
 */

#undef __FUNC__
#define __FUNC__ "impl_doubll_Dll_show"

#ifdef __cplusplus
extern "C"
#endif
void
impl_doubll_Dll_show(
  /* in */ doubll_Dll self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(doubll.Dll.show) */
    /* insert code here (show) */
    /* DO-NOT-DELETE splicer.end(doubll.Dll.show) */
  }
}
/* Babel internal methods, Users should not edit below this line. */

/* DO-NOT-DELETE splicer.begin(_misc) */
/* insert code here (miscellaneous code) */
/* DO-NOT-DELETE splicer.end(_misc) */

