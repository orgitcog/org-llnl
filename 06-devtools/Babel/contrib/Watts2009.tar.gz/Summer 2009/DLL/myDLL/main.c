 #include <stdio.h>
 #include "doubll.h"
 #include "sidl_BaseInterface.h"
 #include "sidl_BaseClass.h"
 #include "sidl_Exception.h"  

   
 int main() { 
      doubll_Dll me;
      doubll_Dll me2;
      sidl_BaseInterface ex;
      sidl_BaseClass bc;
      doubll_Dll firstlist;
      doubll_Dll secondlist;

      /* create instance of face_C */
      me = doubll_Dll__create(&ex); SIDL_CHECK(ex);
     
	 if ( me == NULL ) { 
       		fprintf(stderr,"%s:%d Failed to create an instance of mylist_LinkedList!\n",
               __FILE__,__LINE__);
     		return 2;
     	} 
    bc = sidl_BaseClass__create(&ex); SIDL_CHECK(ex);
    doubll_Dll_addafter(me, (sidl_BaseInterface)bc, &ex); SIDL_CHECK(ex);
    doubll_Dll_addafter(me, (sidl_BaseInterface)bc, &ex); SIDL_CHECK(ex);    

    doubll_Dll_search(me, (sidl_BaseInterface) bc, &ex); SIDL_CHECK(ex);

  /* append 2 lists */
    firstlist = doubll_Dll__create(&ex); SIDL_CHECK(ex);
    secondlist = doubll_Dll__create(&ex); SIDL_CHECK(ex);

	if(firstlist == NULL || secondlist == NULL){
		fprintf(stderr,"%s:%d Failed to create an instance of doubll_Dll!\n",
		__FILE__,__LINE__);
		return 2;
	}

	doubll_Dll_addafter(firstlist, (sidl_BaseInterface)bc, &ex); SIDL_CHECK(ex);
	doubll_Dll_addafter(secondlist, (sidl_BaseInterface)bc, &ex); SIDL_CHECK(ex);

	//doubll_Dll_search(firstlist, (sidl_BaseInterface)bc, &ex); SIDL_CHECK(ex);
	//doubll_Dll_Append(firstlist, secondlist, (sidl_BaseInterface)bc,  &ex); SIDL_CHECK(ex); 

      /*done with object so we can release it */
     doubll_Dll_deleteRef(me, &ex); SIDL_CHECK(ex);
   

     return 0;
     
    EXIT:{} /* this is error handling code for any exceptions that were thrown */
     /*{
       fprintf(stderr,"%s:%d: Error, exception caught\n",__FILE__,__LINE__);
       sidl_BaseInterface ignore = NULL;
       sidl_BaseException be = sidl_BaseException__cast(ex,&ignore);
   
       msg = sidl_BaseException_getNote(be, &ignore);
       fprintf(stderr,"%s\n",msg);
       sidl_String_free(msg);
   
       msg = sidl_BaseException_getTrace(be, &ignore);
       fprintf(stderr,"%s\n",msg);
       sidl_String_free(msg);
 
       sidl_BaseException_deleteRef(be, &ignore);
       SIDL_CLEAR(ex);
       return 1;
     }
	*/
}
