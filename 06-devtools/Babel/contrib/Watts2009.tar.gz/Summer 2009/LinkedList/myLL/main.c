 #include <stdio.h>
 #include "mylist.h"
 #include "sidl_BaseInterface.h"
#include "sidl_BaseClass.h"
 #include "sidl_Exception.h"  

   
 int main() { 
      mylist_LinkedList me;
      sidl_BaseInterface ex;
      sidl_BaseClass bc;

      /* create instance of face_C */
     me = mylist_LinkedList__create(&ex); SIDL_CHECK(ex);
 
	 if ( me == NULL ) { 
       		fprintf(stderr,"%s:%d Failed to create an instance of mylist_LinkedList!\n",
               __FILE__,__LINE__);
     		return 2;
     	} 
    bc = sidl_BaseClass__create(&ex); SIDL_CHECK(ex);
    mylist_LinkedList_add(me, (sidl_BaseInterface)bc, &ex); SIDL_CHECK(ex);
    
//	 if (!mylist_LinkedList_search(me,(sidl_BaseInterface) bc, &ex)) {
  //  		printf("Can't find the object just added. Something is very wrong.\n");
    //		}
  		
	int s = mylist_LinkedList_size(me, &ex); SIDL_CHECK(ex);	
	 printf("Size: %d ", s);
	 printf("\n");
	
//	mylist_LinkedList_remove(me, (sidl_BaseInterface)bc, &ex); SIDL_CHECK(ex);
	
//	mylist_LinkedList_display( (sidl_BaseInterface)bc, &ex); SIDL_CHECK(ex);	

//	sidl_BaseClass_deleteRef(bc, &ex); SIDL_CHECK(ex); 


      /*done with object so we can release it */
     mylist_LinkedList_deleteRef(me, &ex); SIDL_CHECK(ex);
   

     return 0;
     
    EXIT:{} /* this is error handling code for any exceptions that were thrown */
     /*{
       fprintf(stderr,"%s:%d: Error, exception caught\n",__FILE__,__LINE__);
       sidl_BaseInterface ignore = NULL;
       sidl_BaseException be = sidl_BaseException__cast(ex,&ignore);
   
       msg = sidl_BaseException_getNote(be, &ignore);
       fprintf(stderr,"%s\n",msg);
       sidl_String_free(msg);
   
       msg = sidl_BaseException_getTrace(be, &ignore);
       fprintf(stderr,"%s\n",msg);
       sidl_String_free(msg);
 
       sidl_BaseException_deleteRef(be, &ignore);
       SIDL_CLEAR(ex);
       return 1;
     }
	*/
}
