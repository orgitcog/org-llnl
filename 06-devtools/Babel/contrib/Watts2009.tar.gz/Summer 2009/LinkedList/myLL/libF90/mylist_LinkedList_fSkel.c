/*
 * File:          mylist_LinkedList_fSkel.c
 * Symbol:        mylist.LinkedList-v1.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side glue code for mylist.LinkedList
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 */


#ifndef included_mylist_LinkedList_fStub_h
#include "mylist_LinkedList_fStub.h"
#endif
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "sidlfortran.h"
#ifndef included_sidl_io_Serializer_h
#include "sidl_io_Serializer.h"
#endif
#ifndef included_sidl_io_Deserializer_h
#include "sidl_io_Deserializer.h"
#endif
#ifndef included_sidlf90array_h
#include "sidlf90array.h"
#endif
#include "sidl_header.h"
#ifndef included_sidl_interface_IOR_h
#include "sidl_interface_IOR.h"
#endif
#ifndef included_sidl_Exception_h
#include "sidl_Exception.h"
#endif
#include <stdio.h>
#include "babel_config.h"
#ifdef SIDL_DYNAMIC_LIBRARY
#include "sidl_Loader.h"
#endif
#include "mylist_LinkedList_IOR.h"
#include "mylist_LinkedList_fAbbrev.h"
#include "mylist_Iterator_IOR.h"
#include "sidl_BaseException_IOR.h"
#include "sidl_BaseInterface_IOR.h"
#include "sidl_ClassInfo_IOR.h"
#include "sidl_RuntimeException_IOR.h"
#ifndef included_sidl_rmi_ConnectRegistry_h
#include "sidl_rmi_ConnectRegistry.h"
#endif
#ifndef included_sidlOps_h
#include "sidlOps.h"
#endif
/*
 * Includes for all method dependencies.
 */

#ifndef included_mylist_Iterator_fStub_h
#include "mylist_Iterator_fStub.h"
#endif
#ifndef included_mylist_LinkedList_fStub_h
#include "mylist_LinkedList_fStub.h"
#endif
#ifndef included_mylist_List_fStub_h
#include "mylist_List_fStub.h"
#endif
#ifndef included_sidl_BaseClass_fStub_h
#include "sidl_BaseClass_fStub.h"
#endif
#ifndef included_sidl_BaseInterface_fStub_h
#include "sidl_BaseInterface_fStub.h"
#endif
#ifndef included_sidl_ClassInfo_fStub_h
#include "sidl_ClassInfo_fStub.h"
#endif
#ifndef included_sidl_RuntimeException_fStub_h
#include "sidl_RuntimeException_fStub.h"
#endif
#include <string.h>
#include <stdio.h>



void
SIDLFortran90Symbol(mylist_linkedlist__ctor_mi,MYLIST_LINKEDLIST__CTOR_MI,mylist_LinkedList__ctor_mi)
(
  int64_t *self,
  int64_t *exception
);

static void
skel__ctor(
  struct mylist_LinkedList__object* self,
  struct sidl_BaseInterface__object** exception)
{
  int64_t _proxy_self = 0;
  int64_t _proxy_exception = 0;
  _proxy_self = ((ptrdiff_t)self);
  SIDLFortran90Symbol(mylist_linkedlist__ctor_mi,MYLIST_LINKEDLIST__CTOR_MI,
    mylist_LinkedList__ctor_mi)(
    &_proxy_self,
    &_proxy_exception);
  if (_proxy_exception) {
    *exception = (struct sidl_BaseInterface__object*)
      (ptrdiff_t)(_proxy_exception);
  } else {
    *exception = (struct sidl_BaseInterface__object*)(
      ptrdiff_t)_proxy_exception;
  }
}


void
SIDLFortran90Symbol(mylist_linkedlist__dtor_mi,MYLIST_LINKEDLIST__DTOR_MI,mylist_LinkedList__dtor_mi)
(
  int64_t *self,
  int64_t *exception
);

static void
skel__dtor(
  struct mylist_LinkedList__object* self,
  struct sidl_BaseInterface__object** exception)
{
  int64_t _proxy_self = 0;
  int64_t _proxy_exception = 0;
  _proxy_self = ((ptrdiff_t)self);
  SIDLFortran90Symbol(mylist_linkedlist__dtor_mi,MYLIST_LINKEDLIST__DTOR_MI,
    mylist_LinkedList__dtor_mi)(
    &_proxy_self,
    &_proxy_exception);
  if (_proxy_exception) {
    *exception = (struct sidl_BaseInterface__object*)
      (ptrdiff_t)(_proxy_exception);
  } else {
    *exception = (struct sidl_BaseInterface__object*)(
      ptrdiff_t)_proxy_exception;
  }
  if (self->d_data) free(self->d_data);
}


void
SIDLFortran90Symbol(mylist_linkedlist_getiter_mi,MYLIST_LINKEDLIST_GETITER_MI,mylist_LinkedList_getIter_mi)
(
  int64_t *self,
  int64_t *retval,
  int64_t *exception
);

static struct mylist_Iterator__object*
skel_getIter(
  struct mylist_LinkedList__object* self,
  struct sidl_BaseInterface__object** exception)
{
  struct mylist_Iterator__object* retval = NULL;
  int64_t _proxy_self = 0;
  int64_t _proxy_retval = 0;
  int64_t _proxy_exception = 0;
  _proxy_self = ((ptrdiff_t)self);
  SIDLFortran90Symbol(mylist_linkedlist_getiter_mi,MYLIST_LINKEDLIST_GETITER_MI,
    mylist_LinkedList_getIter_mi)(
    &_proxy_self,
    &_proxy_retval,
    &_proxy_exception);
  if (_proxy_exception) {
    retval = 0;
    *exception = (struct sidl_BaseInterface__object*)
      (ptrdiff_t)(_proxy_exception);
  } else {
    retval = (struct mylist_Iterator__object*)(ptrdiff_t)_proxy_retval;
    *exception = (struct sidl_BaseInterface__object*)(
      ptrdiff_t)_proxy_exception;
  }
  return retval;
}


void
SIDLFortran90Symbol(mylist_linkedlist_add_mi,MYLIST_LINKEDLIST_ADD_MI,mylist_LinkedList_add_mi)
(
  int64_t *self,
  int64_t *i,
  int64_t *exception
);

static void
skel_add(
  struct mylist_LinkedList__object* self,
  struct sidl_BaseInterface__object* i,
  struct sidl_BaseInterface__object** exception)
{
  int64_t _proxy_self = 0;
  int64_t _proxy_i = 0;
  int64_t _proxy_exception = 0;
  _proxy_self = ((ptrdiff_t)self);
  _proxy_i = ((ptrdiff_t)i);
  SIDLFortran90Symbol(mylist_linkedlist_add_mi,MYLIST_LINKEDLIST_ADD_MI,
    mylist_LinkedList_add_mi)(
    &_proxy_self,
    &_proxy_i,
    &_proxy_exception);
  if (_proxy_exception) {
    *exception = (struct sidl_BaseInterface__object*)
      (ptrdiff_t)(_proxy_exception);
  } else {
    *exception = (struct sidl_BaseInterface__object*)(
      ptrdiff_t)_proxy_exception;
  }
}


void
SIDLFortran90Symbol(mylist_linkedlist_remove_mi,MYLIST_LINKEDLIST_REMOVE_MI,mylist_LinkedList_remove_mi)
(
  int64_t *self,
  int64_t *i,
  int64_t *exception
);

static void
skel_remove(
  struct mylist_LinkedList__object* self,
  struct sidl_BaseInterface__object* i,
  struct sidl_BaseInterface__object** exception)
{
  int64_t _proxy_self = 0;
  int64_t _proxy_i = 0;
  int64_t _proxy_exception = 0;
  _proxy_self = ((ptrdiff_t)self);
  _proxy_i = ((ptrdiff_t)i);
  SIDLFortran90Symbol(mylist_linkedlist_remove_mi,MYLIST_LINKEDLIST_REMOVE_MI,
    mylist_LinkedList_remove_mi)(
    &_proxy_self,
    &_proxy_i,
    &_proxy_exception);
  if (_proxy_exception) {
    *exception = (struct sidl_BaseInterface__object*)
      (ptrdiff_t)(_proxy_exception);
  } else {
    *exception = (struct sidl_BaseInterface__object*)(
      ptrdiff_t)_proxy_exception;
  }
}


void
SIDLFortran90Symbol(mylist_linkedlist_search_mi,MYLIST_LINKEDLIST_SEARCH_MI,mylist_LinkedList_search_mi)
(
  int64_t *self,
  int64_t *i,
  SIDL_F90_Bool *retval,
  int64_t *exception
);

static sidl_bool
skel_search(
  struct mylist_LinkedList__object* self,
  struct sidl_BaseInterface__object* i,
  struct sidl_BaseInterface__object** exception)
{
  sidl_bool retval;
  int64_t _proxy_self = 0;
  int64_t _proxy_i = 0;
  SIDL_F90_Bool _proxy_retval;
  int64_t _proxy_exception = 0;
  _proxy_self = ((ptrdiff_t)self);
  _proxy_i = ((ptrdiff_t)i);
  _proxy_retval = SIDL_F90_TRUE;
  SIDLFortran90Symbol(mylist_linkedlist_search_mi,MYLIST_LINKEDLIST_SEARCH_MI,
    mylist_LinkedList_search_mi)(
    &_proxy_self,
    &_proxy_i,
    &_proxy_retval,
    &_proxy_exception);
  if (_proxy_exception) {
    retval = 0;
    *exception = (struct sidl_BaseInterface__object*)
      (ptrdiff_t)(_proxy_exception);
  } else {
    retval = ((SIDL_F90_TRUE == _proxy_retval) ? TRUE : FALSE);
    *exception = (struct sidl_BaseInterface__object*)(
      ptrdiff_t)_proxy_exception;
  }
  return retval;
}


void
SIDLFortran90Symbol(mylist_linkedlist_display_mi,MYLIST_LINKEDLIST_DISPLAY_MI,mylist_LinkedList_display_mi)
(
  int64_t *self,
  int64_t *exception
);

static void
skel_display(
  struct mylist_LinkedList__object* self,
  struct sidl_BaseInterface__object** exception)
{
  int64_t _proxy_self = 0;
  int64_t _proxy_exception = 0;
  _proxy_self = ((ptrdiff_t)self);
  SIDLFortran90Symbol(mylist_linkedlist_display_mi,MYLIST_LINKEDLIST_DISPLAY_MI,
    mylist_LinkedList_display_mi)(
    &_proxy_self,
    &_proxy_exception);
  if (_proxy_exception) {
    *exception = (struct sidl_BaseInterface__object*)
      (ptrdiff_t)(_proxy_exception);
  } else {
    *exception = (struct sidl_BaseInterface__object*)(
      ptrdiff_t)_proxy_exception;
  }
}


void
SIDLFortran90Symbol(mylist_linkedlist_size_mi,MYLIST_LINKEDLIST_SIZE_MI,mylist_LinkedList_size_mi)
(
  int64_t *self,
  int32_t *retval,
  int64_t *exception
);

static int32_t
skel_size(
  struct mylist_LinkedList__object* self,
  struct sidl_BaseInterface__object** exception)
{
  int32_t retval;
  int64_t _proxy_self = 0;
  int32_t _proxy_retval;
  int64_t _proxy_exception = 0;
  _proxy_self = ((ptrdiff_t)self);
  SIDLFortran90Symbol(mylist_linkedlist_size_mi,MYLIST_LINKEDLIST_SIZE_MI,
    mylist_LinkedList_size_mi)(
    &_proxy_self,
    &_proxy_retval,
    &_proxy_exception);
  if (_proxy_exception) {
    retval = 0;
    *exception = (struct sidl_BaseInterface__object*)
      (ptrdiff_t)(_proxy_exception);
  } else {
    retval = _proxy_retval;
    *exception = (struct sidl_BaseInterface__object*)(
      ptrdiff_t)_proxy_exception;
  }
  return retval;
}
void
SIDLFortran90Symbol(mylist_linkedlist__ctor2_mi,MYLIST_LINKEDLIST__CTOR2_MI,mylist_LinkedList__ctor2_mi)
(
  int64_t *self,
  void    *private_data,
  int64_t *exception
);

static void
skel__ctor2(
  struct mylist_LinkedList__object* self,
  void* private_data,
  struct sidl_BaseInterface__object** exception)
{
  int64_t _proxy_self = (ptrdiff_t)self;
  int64_t _proxy_exception = 0;
  SIDLFortran90Symbol(mylist_linkedlist__ctor2_mi,MYLIST_LINKEDLIST__CTOR2_MI,
    mylist_LinkedList__ctor2_mi)(
    &_proxy_self, private_data, &_proxy_exception
  );
  *exception = (struct sidl_BaseInterface__object *)(ptrdiff_t)_proxy_exception;
}
#ifdef WITH_RMI
struct sidl_BaseInterface__object* 
  skel_mylist_LinkedList_fconnect_sidl_BaseInterface(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex) { 
  return sidl_BaseInterface__connectI(url, ar, _ex);
}

#endif /*WITH_RMI*/
void
SIDLFortran90Symbol(mylist_linkedlist__load_mi,MYLIST_LINKEDLIST__LOAD_MI,mylist_LinkedList__load_mi)
(
  int64_t *exception
);

void mylist_LinkedList__call_load(void) { 
  int64_t _proxy_exception;
  SIDLFortran90Symbol(mylist_linkedlist__load_mi,MYLIST_LINKEDLIST__LOAD_MI,
    mylist_LinkedList__load_mi)(
    &_proxy_exception);
}


#ifdef __cplusplus
extern "C" {
#endif

void
mylist_LinkedList__set_epv(struct mylist_LinkedList__epv * epv) {
  epv->f__ctor = skel__ctor;
  epv->f__dtor = skel__dtor;
  epv->f_getIter = skel_getIter;
  epv->f_add = skel_add;
  epv->f_remove = skel_remove;
  epv->f_search = skel_search;
  epv->f_display = skel_display;
  epv->f_size = skel_size;
  epv->f__ctor2 = skel__ctor2;
}
#ifdef __cplusplus
}
#endif

/*
 * The FORTRAN impl calls this to get the data pointer.
 * This function name may be a mangled form of
 * mylist_LinkedList__get_data_m
 */

void
SIDLFortran90Symbol(mylist_linkedlist__get_data_m,
  MYLIST_LINKEDLIST__GET_DATA_M,
  mylist_LinkedList__get_data_m)
  (int64_t *object, void *data)
{
  struct mylist_LinkedList__object *local = 
    ((struct mylist_LinkedList__object *)(ptrdiff_t)*object);
  if (local && local->d_data) {
    memcpy(data, local->d_data, SIDL_F90_POINTER_SIZE);
  } else {
    /* _get_data called before _set_data */
fputs("Babel:mylist_LinkedList__get_data_m called before mylist_LinkedList__set_data_m! FATAL ERROR (unitialized pointer)!", stderr);
    abort();/*NOTREACHED*/
  }
}

/*
 * The FORTRAN impl calls this to set the data pointer.
 * This function name may be a mangled form of
 * mylist_LinkedList__set_data_m
 */

void
SIDLFortran90Symbol(mylist_linkedlist__set_data_m,
  MYLIST_LINKEDLIST__SET_DATA_M,
  mylist_LinkedList__set_data_m)
  (int64_t *object, void *data)
{
  struct mylist_LinkedList__object *local = 
    ((struct mylist_LinkedList__object *)(ptrdiff_t)*object);
  if (local) {
    if (!(local->d_data)) {
      local->d_data = malloc(SIDL_F90_POINTER_SIZE);
    }
    if (local->d_data) {
      memcpy(local->d_data, data, SIDL_F90_POINTER_SIZE);
    } else {
fputs("mylist_LinkedList__set_data_m failed in a malloc call!", stderr);
    }
  }
}

