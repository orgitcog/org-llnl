/*
 * File:          mylist_LinkedList_Skel.c
 * Symbol:        mylist.LinkedList-v1.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side glue code for mylist.LinkedList
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 */

#include "mylist_LinkedList_IOR.h"
#include "mylist_LinkedList.h"
#include <stddef.h>

#ifdef WITH_RMI
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#endif /* WITH_RMI */
extern
void
impl_mylist_LinkedList__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_mylist_LinkedList__ctor(
  /* in */ mylist_LinkedList self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_mylist_LinkedList__ctor2(
  /* in */ mylist_LinkedList self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_mylist_LinkedList__dtor(
  /* in */ mylist_LinkedList self,
  /* out */ sidl_BaseInterface *_ex);

#ifdef WITH_RMI
extern struct sidl_BaseInterface__object* 
  impl_mylist_LinkedList_fconnect_sidl_BaseInterface(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/
extern
mylist_Iterator
impl_mylist_LinkedList_getIter(
  /* in */ mylist_LinkedList self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_mylist_LinkedList_add(
  /* in */ mylist_LinkedList self,
  /* in */ sidl_BaseInterface i,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_mylist_LinkedList_remove(
  /* in */ mylist_LinkedList self,
  /* in */ sidl_BaseInterface i,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_mylist_LinkedList_search(
  /* in */ mylist_LinkedList self,
  /* in */ sidl_BaseInterface i,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_mylist_LinkedList_display(
  /* in */ mylist_LinkedList self,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_mylist_LinkedList_size(
  /* in */ mylist_LinkedList self,
  /* out */ sidl_BaseInterface *_ex);

#ifdef WITH_RMI
extern struct sidl_BaseInterface__object* 
  impl_mylist_LinkedList_fconnect_sidl_BaseInterface(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/
#ifdef __cplusplus
extern "C" {
#endif

void
mylist_LinkedList__set_epv(struct mylist_LinkedList__epv *epv,
  struct mylist_LinkedList__pre_epv *pre_epv, 
  struct mylist_LinkedList__post_epv *post_epv
)
{
  epv->f__ctor = impl_mylist_LinkedList__ctor;
  epv->f__ctor2 = impl_mylist_LinkedList__ctor2;
  epv->f__dtor = impl_mylist_LinkedList__dtor;
  pre_epv->f_getIter_pre = NULL;
  epv->f_getIter = impl_mylist_LinkedList_getIter;
  post_epv->f_getIter_post = NULL;
  pre_epv->f_add_pre = NULL;
  epv->f_add = impl_mylist_LinkedList_add;
  post_epv->f_add_post = NULL;
  pre_epv->f_remove_pre = NULL;
  epv->f_remove = impl_mylist_LinkedList_remove;
  post_epv->f_remove_post = NULL;
  pre_epv->f_search_pre = NULL;
  epv->f_search = impl_mylist_LinkedList_search;
  post_epv->f_search_post = NULL;
  pre_epv->f_display_pre = NULL;
  epv->f_display = impl_mylist_LinkedList_display;
  post_epv->f_display_post = NULL;
  pre_epv->f_size_pre = NULL;
  epv->f_size = impl_mylist_LinkedList_size;
  post_epv->f_size_post = NULL;

}
#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
extern "C" {
#endif

void mylist_LinkedList__call_load(void) { 
  sidl_BaseInterface _throwaway_exception = NULL;
  impl_mylist_LinkedList__load(&_throwaway_exception);
}
#ifdef WITH_RMI
struct sidl_BaseInterface__object* 
  skel_mylist_LinkedList_fconnect_sidl_BaseInterface(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex) { 
  return sidl_BaseInterface__connectI(url, ar, _ex);
}

#endif /*WITH_RMI*/
struct mylist_LinkedList__data*
mylist_LinkedList__get_data(mylist_LinkedList self)
{
  return (struct mylist_LinkedList__data*)(self ? self->d_data : NULL);
}

void mylist_LinkedList__set_data(
  mylist_LinkedList self,
  struct mylist_LinkedList__data* data)
{
  if (self) {
    self->d_data = data;
  }
}
#ifdef __cplusplus
}
#endif
