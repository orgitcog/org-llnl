/*
 * File:          mylist_LinkedList_IOR.h
 * Symbol:        mylist.LinkedList-v1.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Intermediate Object Representation for mylist.LinkedList
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 */

#ifndef included_mylist_LinkedList_IOR_h
#define included_mylist_LinkedList_IOR_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
struct sidl_rmi_InstanceHandle__object;
#ifndef included_mylist_List_IOR_h
#include "mylist_List_IOR.h"
#endif
#ifndef included_sidl_BaseClass_IOR_h
#include "sidl_BaseClass_IOR.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Symbol "mylist.LinkedList" (version 1.0)
 */

struct mylist_LinkedList__array;
struct mylist_LinkedList__object;

/*
 * Forward references for external classes and interfaces.
 */

struct mylist_Iterator__array;
struct mylist_Iterator__object;
struct sidl_BaseException__array;
struct sidl_BaseException__object;
struct sidl_BaseInterface__array;
struct sidl_BaseInterface__object;
struct sidl_ClassInfo__array;
struct sidl_ClassInfo__object;
struct sidl_RuntimeException__array;
struct sidl_RuntimeException__object;
struct sidl_rmi_Call__array;
struct sidl_rmi_Call__object;
struct sidl_rmi_Return__array;
struct sidl_rmi_Return__object;

/*
 * Declare the method entry point vector.
 */

struct mylist_LinkedList__epv {
  /* Implicit builtin methods */
  /* 0 */
  void* (*f__cast)(
    /* in */ struct mylist_LinkedList__object* self,
    /* in */ const char* name,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 1 */
  void (*f__delete)(
    /* in */ struct mylist_LinkedList__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 2 */
  void (*f__exec)(
    /* in */ struct mylist_LinkedList__object* self,
    /* in */ const char* methodName,
    /* in */ struct sidl_rmi_Call__object* inArgs,
    /* in */ struct sidl_rmi_Return__object* outArgs,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 3 */
  char* (*f__getURL)(
    /* in */ struct mylist_LinkedList__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 4 */
  void (*f__raddRef)(
    /* in */ struct mylist_LinkedList__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 5 */
  sidl_bool (*f__isRemote)(
    /* in */ struct mylist_LinkedList__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 6 */
  void (*f__set_hooks)(
    /* in */ struct mylist_LinkedList__object* self,
    /* in */ sidl_bool enable,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 7 */
  void (*f__set_contracts)(
    /* in */ struct mylist_LinkedList__object* self,
    /* in */ sidl_bool enable,
    /* in */ const char* enfFilename,
    /* in */ sidl_bool resetCounters,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 8 */
  void (*f__dump_stats)(
    /* in */ struct mylist_LinkedList__object* self,
    /* in */ const char* filename,
    /* in */ const char* prefix,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 9 */
  void (*f__ctor)(
    /* in */ struct mylist_LinkedList__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 10 */
  void (*f__ctor2)(
    /* in */ struct mylist_LinkedList__object* self,
    /* in */ void* private_data,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 11 */
  void (*f__dtor)(
    /* in */ struct mylist_LinkedList__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* 12 */
  void (*f__load)(
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* Methods introduced in sidl.BaseInterface-v0.9.17 */
  void (*f_addRef)(
    /* in */ struct mylist_LinkedList__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_deleteRef)(
    /* in */ struct mylist_LinkedList__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  sidl_bool (*f_isSame)(
    /* in */ struct mylist_LinkedList__object* self,
    /* in */ struct sidl_BaseInterface__object* iobj,
    /* out */ struct sidl_BaseInterface__object **_ex);
  sidl_bool (*f_isType)(
    /* in */ struct mylist_LinkedList__object* self,
    /* in */ const char* name,
    /* out */ struct sidl_BaseInterface__object **_ex);
  struct sidl_ClassInfo__object* (*f_getClassInfo)(
    /* in */ struct mylist_LinkedList__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* Methods introduced in sidl.BaseClass-v0.9.17 */
  /* Methods introduced in mylist.List-v1.0 */
  struct mylist_Iterator__object* (*f_getIter)(
    /* in */ struct mylist_LinkedList__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_add)(
    /* in */ struct mylist_LinkedList__object* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_remove)(
    /* in */ struct mylist_LinkedList__object* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  sidl_bool (*f_search)(
    /* in */ struct mylist_LinkedList__object* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_display)(
    /* in */ struct mylist_LinkedList__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  int32_t (*f_size)(
    /* in */ struct mylist_LinkedList__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  /* Methods introduced in mylist.LinkedList-v1.0 */
};

/*
 * Declare the method pre hooks entry point vector.
 */

struct mylist_LinkedList__pre_epv {
  void (*f_getIter_pre)(
    /* in */ struct mylist_LinkedList__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_add_pre)(
    /* in */ struct mylist_LinkedList__object* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_remove_pre)(
    /* in */ struct mylist_LinkedList__object* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_search_pre)(
    /* in */ struct mylist_LinkedList__object* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_display_pre)(
    /* in */ struct mylist_LinkedList__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_size_pre)(
    /* in */ struct mylist_LinkedList__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
};

/*
 * Declare the method post hooks entry point vector.
 */

struct mylist_LinkedList__post_epv {
  void (*f_getIter_post)(
    /* in */ struct mylist_LinkedList__object* self,
    /* in */ struct mylist_Iterator__object* _retval,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_add_post)(
    /* in */ struct mylist_LinkedList__object* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_remove_post)(
    /* in */ struct mylist_LinkedList__object* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_search_post)(
    /* in */ struct mylist_LinkedList__object* self,
    /* in */ struct sidl_BaseInterface__object* i,
    /* in */ sidl_bool _retval,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_display_post)(
    /* in */ struct mylist_LinkedList__object* self,
    /* out */ struct sidl_BaseInterface__object **_ex);
  void (*f_size_post)(
    /* in */ struct mylist_LinkedList__object* self,
    /* in */ int32_t _retval,
    /* out */ struct sidl_BaseInterface__object **_ex);
};

/*
 * Define the controls and statistics structure.
 */


struct mylist_LinkedList__cstats {
  sidl_bool use_hooks;
};

/*
 * Define the class object structure.
 */

struct mylist_LinkedList__object {
  struct sidl_BaseClass__object    d_sidl_baseclass;
  struct mylist_List__object       d_mylist_list;
  struct mylist_LinkedList__epv*   d_epv;
  struct mylist_LinkedList__cstats d_cstats;
  void*                            d_data;
};

struct mylist_LinkedList__external {
  struct mylist_LinkedList__object*
  (*createObject)(void* ddata, struct sidl_BaseInterface__object **_ex);

  struct sidl_BaseClass__epv*(*getSuperEPV)(void);
  int d_ior_major_version;
  int d_ior_minor_version;
};

/*
 * This function returns a pointer to a static structure of
 * pointers to function entry points.  Its purpose is to provide
 * one-stop shopping for loading DLLs.
 */

const struct mylist_LinkedList__external*
mylist_LinkedList__externals(void);

extern struct mylist_LinkedList__object*
mylist_LinkedList__createObject(void* ddata,struct sidl_BaseInterface__object 
  ** _ex);

extern void mylist_LinkedList__init(
  struct mylist_LinkedList__object* self, void* ddata, struct 
    sidl_BaseInterface__object ** _ex);

extern void mylist_LinkedList__getEPVs(
  struct sidl_BaseInterface__epv **s_arg_epv__sidl_baseinterface,
  struct sidl_BaseClass__epv **s_arg_epv__sidl_baseclass,
  struct mylist_List__epv **s_arg_epv__mylist_list,
  struct mylist_List__epv **s_arg_epv_hooks__mylist_list,
  struct mylist_LinkedList__epv **s_arg_epv__mylist_linkedlist,
  struct mylist_LinkedList__epv **s_arg_epv_hooks__mylist_linkedlist);

extern void mylist_LinkedList__fini(
  struct mylist_LinkedList__object* self, struct sidl_BaseInterface__object ** 
    _ex);

extern void mylist_LinkedList__IOR_version(int32_t *major, int32_t *minor);

struct sidl_BaseInterface__object* 
  skel_mylist_LinkedList_fconnect_sidl_BaseInterface(const char* url, sidl_bool 
  ar, struct sidl_BaseInterface__object * *_ex);
struct mylist_LinkedList__remote{
  int d_refcount;
  struct sidl_rmi_InstanceHandle__object *d_ih;
};

#ifdef __cplusplus
}
#endif
#endif
