/*
 * File:          mylist_IOR.h
 * Symbol:        mylist-v1.0
 * Symbol Type:   package
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Intermediate Object Representation for mylist
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 */

#ifndef included_mylist_IOR_h
#define included_mylist_IOR_h

/*
 * Symbol "mylist" (version 1.0)
 */

#ifndef included_mylist_Iterator_IOR_h
#include "mylist_Iterator_IOR.h"
#endif
#ifndef included_mylist_LinkedList_IOR_h
#include "mylist_LinkedList_IOR.h"
#endif
#ifndef included_mylist_List_IOR_h
#include "mylist_List_IOR.h"
#endif

#endif
