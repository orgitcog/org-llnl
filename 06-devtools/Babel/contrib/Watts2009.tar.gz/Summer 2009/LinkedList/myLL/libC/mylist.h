/*
 * File:          mylist.h
 * Symbol:        mylist-v1.0
 * Symbol Type:   package
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Client-side glue code for mylist
 * 
 * WARNING: Automatically generated; changes will be lost
 * 
 */

#ifndef included_mylist_Iterator_h
#include "mylist_Iterator.h"
#endif
#ifndef included_mylist_LinkedList_h
#include "mylist_LinkedList.h"
#endif
#ifndef included_mylist_List_h
#include "mylist_List.h"
#endif

