/*
 * File:          mylist_LinkedList_Impl.h
 * Symbol:        mylist.LinkedList-v1.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for mylist.LinkedList
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

#ifndef included_mylist_LinkedList_Impl_h
#define included_mylist_LinkedList_Impl_h

#ifndef included_sidl_header_h
#include "sidl_header.h"
#endif
#ifndef included_mylist_Iterator_h
#include "mylist_Iterator.h"
#endif
#ifndef included_mylist_LinkedList_h
#include "mylist_LinkedList.h"
#endif
#ifndef included_mylist_List_h
#include "mylist_List.h"
#endif
#ifndef included_sidl_BaseClass_h
#include "sidl_BaseClass.h"
#endif
#ifndef included_sidl_BaseInterface_h
#include "sidl_BaseInterface.h"
#endif
#ifndef included_sidl_ClassInfo_h
#include "sidl_ClassInfo.h"
#endif
#ifndef included_sidl_RuntimeException_h
#include "sidl_RuntimeException.h"
#endif
/* DO-NOT-DELETE splicer.begin(mylist.LinkedList._hincludes) */
struct List{
	sidl_BaseInterface data;
	struct List *next;
};

/* DO-NOT-DELETE splicer.end(mylist.LinkedList._hincludes) */

/*
 * Private data for class mylist.LinkedList
 */

struct mylist_LinkedList__data {
  /* DO-NOT-DELETE splicer.begin(mylist.LinkedList._data) */
  int32_t size;
  struct List *list;
  /* DO-NOT-DELETE splicer.end(mylist.LinkedList._data) */
};

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Access functions for class private data and built-in methods
 */

extern struct mylist_LinkedList__data*
mylist_LinkedList__get_data(
  mylist_LinkedList);

extern void
mylist_LinkedList__set_data(
  mylist_LinkedList,
  struct mylist_LinkedList__data*);

extern
void
impl_mylist_LinkedList__load(
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_mylist_LinkedList__ctor(
  /* in */ mylist_LinkedList self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_mylist_LinkedList__ctor2(
  /* in */ mylist_LinkedList self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_mylist_LinkedList__dtor(
  /* in */ mylist_LinkedList self,
  /* out */ sidl_BaseInterface *_ex);

/*
 * User-defined object methods
 */

#ifdef WITH_RMI
extern struct sidl_BaseInterface__object* 
  impl_mylist_LinkedList_fconnect_sidl_BaseInterface(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/
extern
mylist_Iterator
impl_mylist_LinkedList_getIter(
  /* in */ mylist_LinkedList self,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_mylist_LinkedList_add(
  /* in */ mylist_LinkedList self,
  /* in */ sidl_BaseInterface i,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_mylist_LinkedList_remove(
  /* in */ mylist_LinkedList self,
  /* in */ sidl_BaseInterface i,
  /* out */ sidl_BaseInterface *_ex);

extern
sidl_bool
impl_mylist_LinkedList_search(
  /* in */ mylist_LinkedList self,
  /* in */ sidl_BaseInterface i,
  /* out */ sidl_BaseInterface *_ex);

extern
void
impl_mylist_LinkedList_display(
  /* in */ mylist_LinkedList self,
  /* out */ sidl_BaseInterface *_ex);

extern
int32_t
impl_mylist_LinkedList_size(
  /* in */ mylist_LinkedList self,
  /* out */ sidl_BaseInterface *_ex);

#ifdef WITH_RMI
extern struct sidl_BaseInterface__object* 
  impl_mylist_LinkedList_fconnect_sidl_BaseInterface(const char* url, sidl_bool 
  ar, sidl_BaseInterface *_ex);
#endif /*WITH_RMI*/

/* DO-NOT-DELETE splicer.begin(_hmisc) */
/* insert code here (miscellaneous things) */
/* DO-NOT-DELETE splicer.end(_hmisc) */

#ifdef __cplusplus
}
#endif
#endif
