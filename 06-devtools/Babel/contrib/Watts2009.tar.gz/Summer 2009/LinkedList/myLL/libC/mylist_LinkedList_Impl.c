/*
 * File:          mylist_LinkedList_Impl.c
 * Symbol:        mylist.LinkedList-v1.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for mylist.LinkedList
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

/*
 * DEVELOPERS ARE EXPECTED TO PROVIDE IMPLEMENTATIONS
 * FOR THE FOLLOWING METHODS BETWEEN SPLICER PAIRS.
 */

/*
 * Symbol "mylist.LinkedList" (version 1.0)
 */

#include "mylist_LinkedList_Impl.h"
#include "sidl_NotImplementedException.h"
#include "sidl_Exception.h"
#ifndef included_sidl_MemAllocException_h
#include "sidl_MemAllocException.h"
#endif

/* DO-NOT-DELETE splicer.begin(mylist.LinkedList._includes) */

/* DO-NOT-DELETE splicer.end(mylist.LinkedList._includes) */

#define SIDL_IOR_MAJOR_VERSION 2
#define SIDL_IOR_MINOR_VERSION 0
/*
 * Static class initializer called exactly once before any user-defined method is dispatched
 */

#undef __FUNC__
#define __FUNC__ "impl_mylist_LinkedList__load"

#ifdef __cplusplus
extern "C"
#endif
void
impl_mylist_LinkedList__load(
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(mylist.LinkedList._load) */
    /* insert code here (static class initializer) */
    /* DO-NOT-DELETE splicer.end(mylist.LinkedList._load) */
  }
}
/*
 * Class constructor called when the class is created.
 */

#undef __FUNC__
#define __FUNC__ "impl_mylist_LinkedList__ctor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_mylist_LinkedList__ctor(
  /* in */ mylist_LinkedList self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(mylist.LinkedList._ctor) */
    
     /* boilerplate constructor*/
      struct mylist_LinkedList__data *dptr = (struct mylist_LinkedList__data*)malloc(sizeof(struct mylist_LinkedList__data));
	
      if (dptr) {
        memset(dptr, 0, sizeof(struct mylist_LinkedList__data));
        // initialize elements of dptr here
      mylist_LinkedList__set_data(self, dptr);
      } else {
        sidl_MemAllocException ex = sidl_MemAllocException_getSingletonException(_ex);
        SIDL_CHECK(*_ex);
        sidl_MemAllocException_setNote(ex, "Out of memory.", _ex); SIDL_CHECK(*_ex);
        sidl_MemAllocException_add(ex, __FILE__, __LINE__, "mylist.LinkedList._ctor", _ex);
        SIDL_CHECK(*_ex);
        *_ex = (sidl_BaseInterface)ex;
      }
      EXIT:;
     

    /* DO-NOT-DELETE splicer.end(mylist.LinkedList._ctor) */
  }
}

/*
 * Special Class constructor called when the user wants to wrap his own private data.
 */

#undef __FUNC__
#define __FUNC__ "impl_mylist_LinkedList__ctor2"

#ifdef __cplusplus
extern "C"
#endif
void
impl_mylist_LinkedList__ctor2(
  /* in */ mylist_LinkedList self,
  /* in */ void* private_data,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(mylist.LinkedList._ctor2) */
    /* insert code here (special constructor) */
    /* DO-NOT-DELETE splicer.end(mylist.LinkedList._ctor2) */
  }
}
/*
 * Class destructor called when the class is deleted.
 */

#undef __FUNC__
#define __FUNC__ "impl_mylist_LinkedList__dtor"

#ifdef __cplusplus
extern "C"
#endif
void
impl_mylist_LinkedList__dtor(
  /* in */ mylist_LinkedList self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(mylist.LinkedList._dtor) */
    
     // boilerplate destructor
      struct mylist_LinkedList__data *dptr = mylist_LinkedList__get_data(self);
      if (dptr) {
        // free contained in dtor before next line
        free(dptr);
        mylist_LinkedList__set_data(self, NULL);
      }

    /* DO-NOT-DELETE splicer.end(mylist.LinkedList._dtor) */
  }
}

/*
 * Method:  getIter[]
 */

#undef __FUNC__
#define __FUNC__ "impl_mylist_LinkedList_getIter"

#ifdef __cplusplus
extern "C"
#endif
mylist_Iterator
impl_mylist_LinkedList_getIter(
  /* in */ mylist_LinkedList self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(mylist.LinkedList.getIter) */
    
    /* DO-NOT-DELETE splicer.end(mylist.LinkedList.getIter) */
  }
}

/*
 * Method:  add[]
 */

#undef __FUNC__
#define __FUNC__ "impl_mylist_LinkedList_add"

#ifdef __cplusplus
extern "C"
#endif
void
impl_mylist_LinkedList_add(
  /* in */ mylist_LinkedList self,
  /* in */ sidl_BaseInterface i,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(mylist.LinkedList.add) */
      struct mylist_LinkedList__data *dptr = mylist_LinkedList__get_data(self);
      printf("About to add to the list...\n");
      if (dptr) {
	dptr->size = dptr->size + 1;
	if (dptr->list) {
	  struct List *tmp = dptr->list;
	  while (tmp->next) {
	    tmp = tmp->next;
	  }
	  tmp->next = (struct List *)malloc(sizeof(struct List));
	  tmp->next->next = NULL;
	  tmp->next->data = i;
	}
	else {
	  dptr->list = (struct List *)malloc(sizeof(struct List));
	  dptr->list->next = NULL;
	  dptr->list->data = i;
	}
	if (i) sidl_BaseInterface_addRef(i, _ex);
      }
    /* DO-NOT-DELETE splicer.end(mylist.LinkedList.add) */
  }
}

/*
 * Method:  remove[]
 */

#undef __FUNC__
#define __FUNC__ "impl_mylist_LinkedList_remove"

#ifdef __cplusplus
extern "C"
#endif
void
impl_mylist_LinkedList_remove(
  /* in */ mylist_LinkedList self,
  /* in */ sidl_BaseInterface i,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
	printf("Trying to remove object\n");

    /* DO-NOT-DELETE splicer.begin(mylist.LinkedList.remove) */
    struct mylist_LinkedList__data *dptr = mylist_LinkedList__get_data(self);	
    struct List *tmp = dptr->list;
	
	if(dptr->list)
	{		
	  if (sidl_BaseInterface_isSame(i, tmp->data, _ex)) {
             dptr->list = tmp->next;
             sidl_BaseInterface_deleteRef(tmp->data, _ex);
	     --(dptr->size);
	     free(tmp);
          }
          else {
	    struct List *next = tmp->next;
	    while (next && !sidl_BaseInterface_isSame(i, next->data, _ex)) {
	       tmp = next;
               next = next->next;
            }
	    if (next) {
	       tmp->next = next->next;
               sidl_BaseInterface_deleteRef(next->data, _ex);
	     --(dptr->size);
               free(next);
            }
          }
     	}

    /* DO-NOT-DE<F9>LETE splicer.end(mylist.LinkedList.remove) */
  }
}

/*
 * Method:  search[]
 */

#undef __FUNC__
#define __FUNC__ "impl_mylist_LinkedList_search"

#ifdef __cplusplus
extern "C"
#endif
sidl_bool
impl_mylist_LinkedList_search(
  /* in */ mylist_LinkedList self,
  /* in */ sidl_BaseInterface i,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(mylist.LinkedList.search) */
    struct mylist_LinkedList__data *dptr = mylist_LinkedList__get_data(self);
    struct List* m = dptr->list;
    while(m){
      if(((i == NULL) && (m->data == NULL)) ||
	 ((i != NULL) && sidl_BaseInterface_isSame(i, m->data, _ex))) {
	return TRUE;
      }
      m = m->next;
    }
    return FALSE;
    /* DO-NOT-DELETE splicer.end(mylist.LinkedList.search) */
  }
}

/*
 * Method:  display[]
 */

#undef __FUNC__
#define __FUNC__ "impl_mylist_LinkedList_display"

#ifdef __cplusplus
extern "C"
#endif
void
impl_mylist_LinkedList_display(
  /* in */ mylist_LinkedList self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
    /* DO-NOT-DELETE splicer.begin(mylist.LinkedList.display) */
   	 struct mylist_LinkedList__data *dptr = mylist_LinkedList__get_data(self);
	 struct List* m = dptr->list;

	 printf("%s", dptr->data); 
    /* DO-NOT-DELETE splicer.end(mylist.LinkedList.display) */
  }
}

/*
 * Method:  size[]
 */

#undef __FUNC__
#define __FUNC__ "impl_mylist_LinkedList_size"

#ifdef __cplusplus
extern "C"
#endif
int32_t
impl_mylist_LinkedList_size(
  /* in */ mylist_LinkedList self,
  /* out */ sidl_BaseInterface *_ex)
{
  *_ex = 0;
  {
  	printf("Now checking for size...\n");
  /* DO-NOT-DELETE splicer.begin(mylist.LinkedList.size) */
    struct mylist_LinkedList__data *dptr = mylist_LinkedList__get_data(self);
    struct List *li =  dptr->list;
	int32_t s = dptr->size; 
	return s;
    /* DO-NOT-DELETE splicer.end(mylist.LinkedList.size) */
  }
}
/* Babel internal methods, Users should not edit below this line. */

/* DO-NOT-DELETE splicer.begin(_misc) */
/* insert code here (miscellaneous code) */
/* DO-NOT-DELETE splicer.end(_misc) */

