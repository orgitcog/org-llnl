// 
// File:          mylist_LinkedList_Skel.cxx
// Symbol:        mylist.LinkedList-v1.0
// Symbol Type:   class
// Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
// Description:   Server-side glue code for mylist.LinkedList
// 
// WARNING: Automatically generated; changes will be lost
// 
// 
#ifndef included_mylist_LinkedList_Impl_hxx
#include "mylist_LinkedList_Impl.hxx"
#endif
#ifndef included_mylist_LinkedList_IOR_h
#include "mylist_LinkedList_IOR.h"
#endif
#ifndef included_sidl_BaseException_hxx
#include "sidl_BaseException.hxx"
#endif
#ifndef included_sidl_LangSpecificException_hxx
#include "sidl_LangSpecificException.hxx"
#endif
// 
// Includes for all method dependencies.
// 
#ifndef included_mylist_Iterator_hxx
#include "mylist_Iterator.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#include "sidl_String.h"
#include <stddef.h>
#include <cstring>

extern "C" {

  static struct mylist_Iterator__object*
  skel_mylist_LinkedList_getIter( 
  /* in */ struct mylist_LinkedList__object* self, sidl_BaseInterface__object 
    ** _exception )
  {
    // pack args to dispatch to impl
    struct mylist_Iterator__object* _result = 0;
    ::mylist::Iterator _local_result;
    ::mylist::LinkedList_impl *_this = reinterpret_cast< 
      ::mylist::LinkedList_impl*>(self->d_data);
    *_exception = 0;//init just to be safe

    // dispatch to impl
    try { 
      _local_result = _this->getIter_impl(  );
    } catch ( ::sidl::RuntimeException _ex ) { 
      sidl_BaseInterface _throwaway_exception;
      (_ex._get_ior()->d_epv->f_add) (_ex._get_ior()->d_object,  __FILE__, __LINE__,"C++ skeleton for getIter.", &_throwaway_exception);
      _ex.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _ex._get_ior());

      return _result;
    } catch (...) {
      // Convert all other exceptions to LangSpecific
      ::sidl::LangSpecificException _unexpected = 
        ::sidl::LangSpecificException::_create();
      sidl_BaseInterface _throwaway_exception;
      (_unexpected._get_ior()->d_epv->f_setNote) (_unexpected._get_ior(),
        "Unexpected C++ exception", &_throwaway_exception);
      _unexpected.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _unexpected._get_ior());

      return _result;
    }
    // unpack results and cleanup
    if ( _local_result._not_nil() ) {
      _local_result.addRef();
    }
    _result = (struct mylist_Iterator__object*) 
      _local_result.::mylist::Iterator::_get_ior();
    return _result;
  }

  static void
  skel_mylist_LinkedList_add( 
  /* in */ struct mylist_LinkedList__object* self, /* in */ struct 
    sidl_BaseInterface__object* i, sidl_BaseInterface__object ** _exception )
  {
    // pack args to dispatch to impl
    ::mylist::LinkedList_impl *_this = reinterpret_cast< 
      ::mylist::LinkedList_impl*>(self->d_data);
    ::sidl::BaseInterface  _local_i(i);
    *_exception = 0;//init just to be safe

    // dispatch to impl
    try { 
      _this->add_impl( /* in */ _local_i );
    } catch ( ::sidl::RuntimeException _ex ) { 
      sidl_BaseInterface _throwaway_exception;
      (_ex._get_ior()->d_epv->f_add) (_ex._get_ior()->d_object,  __FILE__, __LINE__,"C++ skeleton for add.", &_throwaway_exception);
      _ex.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _ex._get_ior());

    } catch (...) {
      // Convert all other exceptions to LangSpecific
      ::sidl::LangSpecificException _unexpected = 
        ::sidl::LangSpecificException::_create();
      sidl_BaseInterface _throwaway_exception;
      (_unexpected._get_ior()->d_epv->f_setNote) (_unexpected._get_ior(),
        "Unexpected C++ exception", &_throwaway_exception);
      _unexpected.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _unexpected._get_ior());

    }
    // unpack results and cleanup

  }

  static void
  skel_mylist_LinkedList_remove( 
  /* in */ struct mylist_LinkedList__object* self, /* in */ struct 
    sidl_BaseInterface__object* i, sidl_BaseInterface__object ** _exception )
  {
    // pack args to dispatch to impl
    ::mylist::LinkedList_impl *_this = reinterpret_cast< 
      ::mylist::LinkedList_impl*>(self->d_data);
    ::sidl::BaseInterface  _local_i(i);
    *_exception = 0;//init just to be safe

    // dispatch to impl
    try { 
      _this->remove_impl( /* in */ _local_i );
    } catch ( ::sidl::RuntimeException _ex ) { 
      sidl_BaseInterface _throwaway_exception;
      (_ex._get_ior()->d_epv->f_add) (_ex._get_ior()->d_object,  __FILE__, __LINE__,"C++ skeleton for remove.", &_throwaway_exception);
      _ex.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _ex._get_ior());

    } catch (...) {
      // Convert all other exceptions to LangSpecific
      ::sidl::LangSpecificException _unexpected = 
        ::sidl::LangSpecificException::_create();
      sidl_BaseInterface _throwaway_exception;
      (_unexpected._get_ior()->d_epv->f_setNote) (_unexpected._get_ior(),
        "Unexpected C++ exception", &_throwaway_exception);
      _unexpected.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _unexpected._get_ior());

    }
    // unpack results and cleanup

  }

  static sidl_bool
  skel_mylist_LinkedList_search( 
  /* in */ struct mylist_LinkedList__object* self, /* in */ struct 
    sidl_BaseInterface__object* i, sidl_BaseInterface__object ** _exception )
  {
    // pack args to dispatch to impl
    sidl_bool _result = FALSE;
    bool _local_result;
    ::mylist::LinkedList_impl *_this = reinterpret_cast< 
      ::mylist::LinkedList_impl*>(self->d_data);
    ::sidl::BaseInterface  _local_i(i);
    *_exception = 0;//init just to be safe

    // dispatch to impl
    try { 
      _local_result = _this->search_impl( /* in */ _local_i );
    } catch ( ::sidl::RuntimeException _ex ) { 
      sidl_BaseInterface _throwaway_exception;
      (_ex._get_ior()->d_epv->f_add) (_ex._get_ior()->d_object,  __FILE__, __LINE__,"C++ skeleton for search.", &_throwaway_exception);
      _ex.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _ex._get_ior());

      return _result;
    } catch (...) {
      // Convert all other exceptions to LangSpecific
      ::sidl::LangSpecificException _unexpected = 
        ::sidl::LangSpecificException::_create();
      sidl_BaseInterface _throwaway_exception;
      (_unexpected._get_ior()->d_epv->f_setNote) (_unexpected._get_ior(),
        "Unexpected C++ exception", &_throwaway_exception);
      _unexpected.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _unexpected._get_ior());

      return _result;
    }
    // unpack results and cleanup
    _result = ( _local_result ? TRUE : FALSE );
    return _result;
  }

  static void
  skel_mylist_LinkedList_display( 
  /* in */ struct mylist_LinkedList__object* self, sidl_BaseInterface__object 
    ** _exception )
  {
    // pack args to dispatch to impl
    ::mylist::LinkedList_impl *_this = reinterpret_cast< 
      ::mylist::LinkedList_impl*>(self->d_data);
    *_exception = 0;//init just to be safe

    // dispatch to impl
    try { 
      _this->display_impl(  );
    } catch ( ::sidl::RuntimeException _ex ) { 
      sidl_BaseInterface _throwaway_exception;
      (_ex._get_ior()->d_epv->f_add) (_ex._get_ior()->d_object,  __FILE__, __LINE__,"C++ skeleton for display.", &_throwaway_exception);
      _ex.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _ex._get_ior());

    } catch (...) {
      // Convert all other exceptions to LangSpecific
      ::sidl::LangSpecificException _unexpected = 
        ::sidl::LangSpecificException::_create();
      sidl_BaseInterface _throwaway_exception;
      (_unexpected._get_ior()->d_epv->f_setNote) (_unexpected._get_ior(),
        "Unexpected C++ exception", &_throwaway_exception);
      _unexpected.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _unexpected._get_ior());

    }
    // unpack results and cleanup

  }

  static int32_t
  skel_mylist_LinkedList_size( 
  /* in */ struct mylist_LinkedList__object* self, sidl_BaseInterface__object 
    ** _exception )
  {
    // pack args to dispatch to impl
    int32_t _result = 0;
    ::mylist::LinkedList_impl *_this = reinterpret_cast< 
      ::mylist::LinkedList_impl*>(self->d_data);
    *_exception = 0;//init just to be safe

    // dispatch to impl
    try { 
      _result = _this->size_impl(  );
    } catch ( ::sidl::RuntimeException _ex ) { 
      sidl_BaseInterface _throwaway_exception;
      (_ex._get_ior()->d_epv->f_add) (_ex._get_ior()->d_object,  __FILE__, __LINE__,"C++ skeleton for size.", &_throwaway_exception);
      _ex.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _ex._get_ior());

      return _result;
    } catch (...) {
      // Convert all other exceptions to LangSpecific
      ::sidl::LangSpecificException _unexpected = 
        ::sidl::LangSpecificException::_create();
      sidl_BaseInterface _throwaway_exception;
      (_unexpected._get_ior()->d_epv->f_setNote) (_unexpected._get_ior(),
        "Unexpected C++ exception", &_throwaway_exception);
      _unexpected.addRef();
      *_exception = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _unexpected._get_ior());

      return _result;
    }
    // unpack results and cleanup

    return _result;
  }

#ifdef WITH_RMI
  struct sidl_BaseInterface__object* 
    skel_mylist_LinkedList_fconnect_sidl_BaseInterface(const char* url, 
    sidl_bool ar, sidl_BaseInterface *_ex) { 
    return sidl_BaseInterface__connectI(url, ar, _ex);
  }

#endif /*WITH_RMI*/
  void
  mylist_LinkedList__call_load(void) {::mylist::LinkedList_impl::_load();}

  static void
  skel_mylist_LinkedList__ctor(struct mylist_LinkedList__object* self, struct 
    sidl_BaseInterface__object **_ex ) { 
    try {
      self->d_data = reinterpret_cast< void*>(new ::mylist::LinkedList_impl(
        self));
    } catch ( ::sidl::RuntimeException _exc ) {
      sidl_BaseInterface _throwaway_exception;
      (_exc._get_ior()->d_epv->f_add) (_exc._get_ior()->d_object, __FILE__, __LINE__," C++ skeleton for _ctor.", &_throwaway_exception);
      _exc.addRef();
      *_ex = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _exc._get_ior());
    } catch (...) {
      // Convert all other exceptions to LangSpecific
      ::sidl::LangSpecificException _unexpected = 
        ::sidl::LangSpecificException::_create();
      _unexpected.setNote("Unexpected C++ exception in _ctor.");
      _unexpected.addRef();
      *_ex = reinterpret_cast< struct sidl_BaseInterface__object * >(
        _unexpected._get_ior());
    }
  }

  static void
  skel_mylist_LinkedList__ctor2(struct mylist_LinkedList__object* self, void* 
    private_data, struct sidl_BaseInterface__object **_ex ) { 
    *_ex = NULL;
  }

  static void
  skel_mylist_LinkedList__dtor(struct mylist_LinkedList__object* self, struct 
    sidl_BaseInterface__object **_ex ) { 
    try {
      ::mylist::LinkedList_impl* loc_data = reinterpret_cast< 
        ::mylist::LinkedList_impl*>(self->d_data);
      if(!loc_data->_isWrapped()) {
        delete (loc_data);
      }
    } catch ( ::sidl::RuntimeException _exc ) {
      sidl_BaseInterface _throwaway_exception;
      (_exc._get_ior()->d_epv->f_add) (_exc._get_ior()->d_object, __FILE__, __LINE__," C++ skeleton for _dtor.", &_throwaway_exception);
      _exc.addRef();
      *_ex = reinterpret_cast< struct sidl_BaseInterface__object * >(_exc._get_ior());
    } catch (...) {
      // Convert all other exceptions to LangSpecific
      ::sidl::LangSpecificException _unexpected = ::sidl::LangSpecificException::_create();
      _unexpected.setNote("Unexpected C++ exception in _dtor.");
      _unexpected.addRef();
      *_ex = reinterpret_cast< struct sidl_BaseInterface__object * >(_unexpected._get_ior());
    }
  }

  void
  mylist_LinkedList__set_epv(struct mylist_LinkedList__epv *epv,
  struct mylist_LinkedList__pre_epv *pre_epv, struct mylist_LinkedList__post_epv *post_epv){
    // initialize builtin methods
    epv->f__ctor = skel_mylist_LinkedList__ctor;
    epv->f__ctor2 = skel_mylist_LinkedList__ctor2;
    epv->f__dtor = skel_mylist_LinkedList__dtor;
    // initialize local methods
    pre_epv->f_getIter_pre = NULL;
    epv->f_getIter = skel_mylist_LinkedList_getIter;
    post_epv->f_getIter_post = NULL;
    pre_epv->f_add_pre = NULL;
    epv->f_add = skel_mylist_LinkedList_add;
    post_epv->f_add_post = NULL;
    pre_epv->f_remove_pre = NULL;
    epv->f_remove = skel_mylist_LinkedList_remove;
    post_epv->f_remove_post = NULL;
    pre_epv->f_search_pre = NULL;
    epv->f_search = skel_mylist_LinkedList_search;
    post_epv->f_search_post = NULL;
    pre_epv->f_display_pre = NULL;
    epv->f_display = skel_mylist_LinkedList_display;
    post_epv->f_display_post = NULL;
    pre_epv->f_size_pre = NULL;
    epv->f_size = skel_mylist_LinkedList_size;
    post_epv->f_size_post = NULL;
  }


} // end extern "C"
