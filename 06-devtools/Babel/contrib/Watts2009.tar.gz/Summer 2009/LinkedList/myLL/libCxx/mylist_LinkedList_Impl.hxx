// 
// File:          mylist_LinkedList_Impl.hxx
// Symbol:        mylist.LinkedList-v1.0
// Symbol Type:   class
// Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
// Description:   Server-side implementation for mylist.LinkedList
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_mylist_LinkedList_Impl_hxx
#define included_mylist_LinkedList_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_mylist_LinkedList_IOR_h
#include "mylist_LinkedList_IOR.h"
#endif
#ifndef included_mylist_Iterator_hxx
#include "mylist_Iterator.hxx"
#endif
#ifndef included_mylist_LinkedList_hxx
#include "mylist_LinkedList.hxx"
#endif
#ifndef included_mylist_List_hxx
#include "mylist_List.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif


// DO-NOT-DELETE splicer.begin(mylist.LinkedList._hincludes)

	struct Node{
		sidl_BaseInterface ldata;
		Node *next;
		int lsize;
			
	};	

	struct mylist_LinkedList__data{
		int size;
		struct Node *list;
	};
		
//DO-NOT-DELETE splicer.end(mylist.LinkedList._hincludes)

namespace mylist { 

  /**
   * Symbol "mylist.LinkedList" (version 1.0)
   */
  class LinkedList_impl : public virtual ::mylist::LinkedList 
  // DO-NOT-DELETE splicer.begin(mylist.LinkedList._inherits)
  // DO-NOT-DELETE splicer.end(mylist.LinkedList._inherits)

  {

  // All data marked protected will be accessable by 
  // descendant Impl classes
  protected:

    bool _wrapped;

    // DO-NOT-DELETE splicer.begin(mylist.LinkedList._implementation)


    // DO-NOT-DELETE splicer.end(mylist.LinkedList._implementation)

  public:
    // default constructor, used for data wrapping(required)
    LinkedList_impl();
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
      LinkedList_impl( struct mylist_LinkedList__object * ior ) : StubBase(ior,
        true), 
    ::mylist::List((ior==NULL) ? NULL : &((*ior).d_mylist_list)) , _wrapped(
      false) {_ctor();}


    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~LinkedList_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // true if this object was created by a user newing the impl
    inline bool _isWrapped() {return _wrapped;}

    // static class initializer
    static void _load();

  public:

    /**
     * user defined non-static method.
     */
    ::mylist::Iterator
    getIter_impl() ;
    /**
     * user defined non-static method.
     */
    void
    add_impl (
      /* in */::sidl::BaseInterface& i
    )
    ;

    /**
     * user defined non-static method.
     */
    void
    remove_impl (
      /* in */::sidl::BaseInterface& i
    )
    ;

    /**
     * user defined non-static method.
     */
    bool
    search_impl (
      /* in */::sidl::BaseInterface& i
    )
    ;

    /**
     * user defined non-static method.
     */
    void
    display_impl() ;
    /**
     * user defined non-static method.
     */
    int32_t
    size_impl() ;
  };  // end class LinkedList_impl

} // end namespace mylist

// DO-NOT-DELETE splicer.begin(mylist.LinkedList._hmisc)
// insert code here (miscellaneous things)
// DO-NOT-DELETE splicer.end(mylist.LinkedList._hmisc)

#endif
