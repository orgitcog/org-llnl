// 
// File:          mylist_LinkedList_Impl.cxx
// Symbol:        mylist.LinkedList-v1.0
// Symbol Type:   class
// Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
// Description:   Server-side implementation for mylist.LinkedList
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "mylist_LinkedList_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_mylist_Iterator_hxx
#include "mylist_Iterator.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
// DO-NOT-DELETE splicer.begin(mylist.LinkedList._includes)		
// DO-NOT-DELETE splicer.end(mylist.LinkedList._includes)

// special constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
mylist::LinkedList_impl::LinkedList_impl() : StubBase(reinterpret_cast< void*>(
  ::mylist::LinkedList::_wrapObj(reinterpret_cast< void*>(this))),false) , 
  _wrapped(true){ 
  // DO-NOT-DELETE splicer.begin(mylist.LinkedList._ctor2)
  // insert code here (ctor2)
  // DO-NOT-DELETE splicer.end(mylist.LinkedList._ctor2)
}

// user defined constructor
void mylist::LinkedList_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(mylist.LinkedList._ctor)
  // insert code here (constructor)
  // DO-NOT-DELETE splicer.end(mylist.LinkedList._ctor)
}

// user defined destructor
void mylist::LinkedList_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(mylist.LinkedList._dtor)
  // insert code here (destructor)
  // DO-NOT-DELETE splicer.end(mylist.LinkedList._dtor)
}

// static class initializer
void mylist::LinkedList_impl::_load() {
  // DO-NOT-DELETE splicer.begin(mylist.LinkedList._load)
  // insert code here (class initialization)
  // DO-NOT-DELETE splicer.end(mylist.LinkedList._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  getIter[]
 */
::mylist::Iterator
mylist::LinkedList_impl::getIter_impl () 

{
  // DO-NOT-DELETE splicer.begin(mylist.LinkedList.getIter)
  // insert code here
  // DO-NOT-DELETE splicer.end(mylist.LinkedList.getIter)
}

/**
 * Method:  add[]
 */
void
mylist::LinkedList_impl::add_impl (
  /* in */::sidl::BaseInterface& i ) 
{
  // DO-NOT-DELETE splicer.begin(mylist.LinkedList.add)
	struct Node *dptr;
	if(dptr){
		dptr->lsize = dptr->lsize +1;
		
		if(dptr->next){
			Node *tmp = dptr;
			while(tmp->next){
				tmp = tmp->next;
			
			}
		}
	}
  // DO-NOT-DELETE splicer.end(mylist.LinkedList.add)
}

/**
 * Method:  remove[]
 */
void
mylist::LinkedList_impl::remove_impl (
  /* in */::sidl::BaseInterface& i ) 
{
  // DO-NOT-DELETE splicer.begin(mylist.LinkedList.remove)
  // insert code here
  // DO-NOT-DELETE splicer.end(mylist.LinkedList.remove)
}

/**
 * Method:  search[]
 */
bool
mylist::LinkedList_impl::search_impl (
  /* in */::sidl::BaseInterface& i ) 
{
  // DO-NOT-DELETE splicer.begin(mylist.LinkedList.search)
  // insert code here
  // DO-NOT-DELETE splicer.end(mylist.LinkedList.search)
}

/**
 * Method:  display[]
 */
void
mylist::LinkedList_impl::display_impl () 

{
  // DO-NOT-DELETE splicer.begin(mylist.LinkedList.display)
  // insert code here
  // DO-NOT-DELETE splicer.end(mylist.LinkedList.display)
}

/**
 * Method:  size[]
 */
int32_t
mylist::LinkedList_impl::size_impl () 

{
  // DO-NOT-DELETE splicer.begin(mylist.LinkedList.size)
  // insert code here
  // DO-NOT-DELETE splicer.end(mylist.LinkedList.size)
}


// DO-NOT-DELETE splicer.begin(mylist.LinkedList._misc)
// insert code here (miscellaneous code)
// DO-NOT-DELETE splicer.end(mylist.LinkedList._misc)

