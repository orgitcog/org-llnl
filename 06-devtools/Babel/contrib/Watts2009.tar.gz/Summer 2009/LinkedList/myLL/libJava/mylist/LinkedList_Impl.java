/*
 * File:          LinkedList_Impl.java
 * Symbol:        mylist.LinkedList-v1.0
 * Symbol Type:   class
 * Babel Version: 1.4.0 (Revision: 6607 release-1-4-0-branch)
 * Description:   Server-side implementation for mylist.LinkedList
 * 
 * WARNING: Automatically generated; only changes within splicers preserved
 * 
 */

package mylist;

import mylist.Iterator;
import mylist.List;
import sidl.BaseClass;
import sidl.BaseInterface;
import sidl.ClassInfo;
import sidl.RuntimeException;
import java.util.ListIterator;
// DO-NOT-DELETE splicer.begin(mylist.LinkedList._imports)
// DO-NOT-DELETE splicer.end(mylist.LinkedList._imports)

/**
 * Symbol "mylist.LinkedList" (version 1.0)
 */
//DO-NOT-DELETE splicer.begin(mylist.LinkedList._data)
public class LinkedList_Impl extends LinkedList
{	
	public class Node{
		private sidl.BaseInterface ldata;
		private Node next;	
		int lsize;  /*  Size of the list */
	// 2 constructors	

	public Node(sidl.BaseInterface d){
		this(d, null);
	}
	
 	public Node(sidl.BaseInterface d, Node n){
		ldata = d;
		next = n;
	}
	// access to fields
 	public Object getData(){
		return ldata;
	}
	public Node getNext(){
		return next;
	}
	public int getSize(){
		return lsize;
	}
	//modify fields
	public void setData(sidl.BaseInterface ob)
	{
		ldata = ob;
	}
	public void setNext(Node n)
	{
		next = n;
	}
}

static{
  // DO-NOT-DELETE splicer.end(mylist.LinkedList._data)

 
  // DO-NOT-DELETE splicer.begin(mylist.LinkedList._load)
  
// DO-NOT-DELETE splicer.end(mylist.LinkedList._load)

  }

  /**
   * User defined constructor
   */
  public LinkedList_Impl(long IORpointer){
    super(IORpointer);
    // DO-NOT-DELETE splicer.begin(mylist.LinkedList.LinkedList)
  	
			
    // DO-NOT-DELETE splicer.end(mylist.LinkedList.LinkedList)

  }

  /**
   * Back door constructor
   */
  public LinkedList_Impl(){
    d_ior = _wrap(this);
    // DO-NOT-DELETE splicer.begin(mylist.LinkedList._wrap)
    // insert code here (_wr     
    // DO-NOT-DELETE splicer.end(mylist.LinkedList._wrap)

  }

  /**
   * User defined destructing method
   */
  public void dtor() throws Throwable{
    // DO-NOT-DELETE splicer.begin(mylist.LinkedList._dtor)
    // insert code here (destructor)
    // DO-NOT-DELETE splicer.end(mylist.LinkedList._dtor)

  }

  /**
   * finalize method (Only use this if you're sure you need it!)
   */
  public void finalize() throws Throwable{
    // DO-NOT-DELETE splicer.begin(mylist.LinkedList.finalize)
    // insert code here (finalize)
    // DO-NOT-DELETE splicer.end(mylist.LinkedList.finalize)

  }

  // user defined static methods: (none)

  // user defined non-static methods:
  /**
   * Method:  getIter[]
   */
  //public mylist.Iterator getIter_Impl () 
    //throws sidl.RuntimeException.Wrapper
  //{
    // DO-NOT-DELETE splicer.begin(mylist.LinkedList.getIter)
//	return;
    // DO-NOT-DELETE splicer.end(mylist.LinkedList.getIter)

  //}

  /**
   * Method:  add[]
   */
  public void add_Impl (
    /*in*/ sidl.BaseInterface i ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(mylist.LinkedList.add)
    
	 //mylist_LinkedList__data *dptr = mylist_LinkedList__get_data(self);
	
 	Node dptr = new Node(null);
	// if the list is empty
   if(dptr){
	dptr.lsize = dptr.lsize +1;
	if(dptr.getNext() != null)
	{
		while(dptr.getNext())
		{
			dptr.next = dptr.getNext();
		}
		// insert a new node
		Node tmp = new Node(i);
		tmp.setNext(dptr.getNext());
		dptr.setNext(tmp);	
	}
	else{
		
		dptr.next = new Node(null, null);	}			
	}	
}
		 			
    // DO-NOT-DELETE splicer.end(mylist.LinkedList.add)
  
  /**
   * Method:  remove[]
   */
  public void remove_Impl (
    /*in*/ sidl.BaseInterface i ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(mylist.LinkedList.remove)
    // insert code here (remove)
    /*
     * This method has not been implemented
     */
return;
    // DO-NOT-DELETE splicer.end(mylist.LinkedList.remove)

  }

  /**
   * Method:  search[]
   */
  public boolean search_Impl (
    /*in*/ sidl.BaseInterface i ) 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(mylist.LinkedList.search)
   Node dptr = new Node(i);
   if(dptr != null){
	while(dptr.getNext() != null){
	   if(dptr.getData().equals(i)){
		return true;
	   }
         dptr.getNext();
	
	} 
     
	return false;
}
    // DO-NOT-DELETE splicer.end(mylist.LinkedList.search)

  }

  /**
   * Method:  display[]
   */
  public void display_Impl () 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(mylist.LinkedList.display)
    // insert code here (display)
    /*
     * This method has not been implemented
     */

    // DO-NOT-DELETE splicer.end(mylist.LinkedList.display)

  }

  /**
   * Method:  size[]
   */
  public int size_Impl () 
    throws sidl.RuntimeException.Wrapper
  {
    // DO-NOT-DELETE splicer.begin(mylist.LinkedList.size)
    // insert code here (size)
   	Node n = new Node(null); 
	int s = n.getSize();
	return s;

    // DO-NOT-DELETE splicer.end(mylist.LinkedList.size)

  }


  // DO-NOT-DELETE splicer.begin(mylist.LinkedList._misc)
  // insert code here (miscellaneous)
  // DO-NOT-DELETE splicer.end(mylist.LinkedList._misc)

} // end class LinkedList

