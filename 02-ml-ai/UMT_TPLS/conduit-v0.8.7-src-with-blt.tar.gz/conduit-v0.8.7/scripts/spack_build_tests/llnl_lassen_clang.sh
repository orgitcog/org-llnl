python uberenv/uberenv.py --install --run_tests --spec="%clang@coral~python~fortran" --prefix="_uberenv_test_lassen_clang"


