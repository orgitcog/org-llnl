python uberenv/uberenv.py --install --run_tests --prefix="_uberenv_test_darwin_clang"


